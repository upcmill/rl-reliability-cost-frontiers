# Submission Gap Closure Checklist

The package is an internally audited submission candidate, not a submission-
ready article. The four gates below are the remaining conditions for a
defensible submission. A gate is closed only when the listed artifact exists
and the claim--evidence matrix is updated.

## Gate 1: external reproducibility

**Current status:** closed for a different-machine rerun of the frozen
protocol; independent-team identity and scientific replication remain open.

**Required artifact:** a sealed rerun by a different operator or on a second
machine, using the frozen test seeds and the exact deviation form in
`EXTERNAL_RERUN_PROTOCOL.md`.

**Acceptance checks:**

- runtime, OS, CPU, Python, Gymnasium, Stable-Baselines3, PyTorch, and NumPy
  versions are recorded;
- raw seed-level metrics and the rerun summary are archived;
- all deviations and failed runs are reported;
- differences from the v3 summary are shown at row level;
- the manuscript calls this external reproducibility only if the operator and
  machine are genuinely independent of the original run.

The returned artifact is audited in `复跑结果/EXTERNAL_RERUN_AUDIT.md`:
600 rows and all output/source hashes pass; all 15 selected configurations and
terminal decisions match; 14/15 cells have zero seed-level differences and
the remaining `Acrobot-v1:DQN` cell has mean absolute difference 0.00105 and
maximum difference 0.01640. The handoff reports no reference-directory access
and no failed rows. The operator's institutional independence is not verified.

## Gate 2: public archive

**Required artifact:** a public, immutable repository or archive record for the
source bundle, raw data, lockfile, and release hash.

**Acceptance checks:**

- the URL or DOI resolves without author credentials;
- the deposited archive hash matches the local sidecar;
- the license and citation text are stated;
- private machine paths and secrets are absent;
- `SUBMISSION_METADATA_TEMPLATE.md`, the manuscript declarations, and the
  package index use the same URL or DOI.

## Gate 3: independent literature screening

**Required artifact:** exports from Web of Science, Scopus, IEEE Xplore, ACM
Digital Library, and Google Scholar (or a documented unavailable source), plus
deduplication and a second screener's decisions.

**Acceptance checks:**

- search strings, date, filters, and result counts are frozen;
- DOI/title deduplication is reproducible;
- include/exclude/uncertain decisions are stored per record;
- disagreements and their resolution are documented;
- directly overlapping protocols are compared in
  `LITERATURE_SCREENING_TABLE.md`;
- only then may the manuscript remove the `[待核实]` qualification from a
  literature-wide novelty sentence.

## Gate 4: declarations and author metadata

**Required artifact:** completed author, affiliation, correspondence, funding,
conflict, contribution, data/code, and license fields.

**Acceptance checks:**

- every placeholder in `SUBMISSION_METADATA_TEMPLATE.md` is resolved or
  explicitly marked not applicable;
- the English and Chinese Word files agree with the Markdown manuscript;
- the cover letter and target-journal form use the same metadata;
- no author identity, funding source, or archive URL is inferred by the agent.

## Current status

As of 2026-10-31, Gate 1 is closed for the different-machine rerun, while the
public archive, independent literature screening, and declarations gates
remain open. Internal tests, artifact audits, the same-machine cross-script
replay, and the external rerun audit are complete. The package must continue
to report `submission_candidate_with_blockers` until the remaining gates are
closed or the authors explicitly choose to submit as a pilot with those
limitations.

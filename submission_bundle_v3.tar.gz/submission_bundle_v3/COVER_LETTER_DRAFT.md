# Cover Letter Draft

**Recommended target:** _Machine Learning_ (Springer; current SCI/SCIE
status, APC, and article-type requirements `[待核实]`)

**Manuscript title:** Reliability--Cost Frontiers for Sequential Evaluation of
Reinforcement Learning Algorithms

Dear Editor,

We submit the manuscript “Reliability--Cost Frontiers for Sequential
Evaluation of Reinforcement Learning Algorithms” for consideration as an
original research article. The paper addresses a recurring evaluation problem
in reinforcement learning: how configuration selection, training-seed
variation, repeated interim inspection, and uncertainty control interact when
the test budget is finite.

The paper makes a deliberately bounded methodological contribution. It defines
a conditional estimand for the configuration selected using validation data,
freezes that configuration before sealed testing, and combines an unpaired
bounded interval with predeclared finite looks and family-wise error spending.
The manuscript proves the corresponding conditional coverage statement under
explicit within-algorithm seed-independence assumptions and proves a
locked-stopping lemma that connects the simultaneous finite-look event to the
implemented state machine. It also derives a pre-study feasibility audit that
can identify an impossible resolution budget before sealed test data are
opened.

The primary study is preregistered and includes PPO, DQN, and A2C on five
disclosed discrete-action tasks. The 15 algorithm-pair comparisons use an
equal four-candidate validation grid, five validation seeds per candidate, and
20 sealed test seeds. All 15 comparisons reach the maximum budget without a
formal superiority or 0.10-width precision decision. The analytic feasibility
result shows that this outcome is forced by the registered bounded interval and
error allocation for every possible metric sequence in `[0,1]`; it is not
evidence that the algorithms are equivalent. We present this as a
reliability--cost boundary, not as an algorithm ranking or a power estimate.

The paper reports the resulting frontier with its analytic uncertainty radius
and machine-specific recorded runtime kept as separate quantities. Additional
new-seed extensions, tuning-stability analyses, normalization and episode
sensitivity checks, and a controlled dependence stress test are explicitly
labelled supplementary diagnostics. They are not pooled into the primary
family and do not support universal seed requirements, compute savings, or
general PPO/DQN/A2C rankings.

The manuscript is positioned against prior work on RL reproducibility, seed
uncertainty, evaluation overfitting, reliability metrics, and sequential
inference. It does not claim to have invented Hoeffding concentration,
alpha-spending, sealed testing, or RL reliability measurement. The intended
distinction is the auditable combination of a validation-conditioned
estimand, sealed unpaired test sequences, finite-look family control, and an
observed resolution-cost characterization for a frozen RL task family. A
literature-wide novelty claim remains qualified `[待核实]` until database
exports and independent second screening are completed.

The accompanying materials contain preregistration files, raw seed-level CSV
files, analysis scripts, source hashes, environment metadata, and a separate
same-machine recomputation. A sealed Windows AMD64 rerun matches all 15
selected configurations and terminal decisions; 14 of 15 cells have zero
seed-level metric differences and one reports a small platform difference.
This supports different-machine reproducibility of the frozen protocol. The
operator's independent-team identity and a public repository DOI are not yet
verified, so the package does not claim independent scientific replication.

The paper has no claim of prior publication or guaranteed acceptance. The
confirmed author record is 穆浩然 and 赵海龙 (corresponding author), both at
北京建筑大学. English romanization, email, funding, competing interests,
license, and public archive fields remain placeholders for author confirmation.
The journal's current
indexing, APC, and submission-system requirements will be checked against
official sources before submission `[待核实]`.

Thank you for considering the manuscript.

Sincerely,

穆浩然; 赵海龙 (corresponding author)
北京建筑大学
Corresponding email: `[待补充]`

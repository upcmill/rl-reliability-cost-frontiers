import unittest

import numpy as np

import gymnasium as gym
from nonstationary_queue_env import ENV_ID, NonstationaryQueueEnv


class NonstationaryQueueTests(unittest.TestCase):
    def test_spaces_and_reward_bounds(self):
        env = NonstationaryQueueEnv(capacity=3, horizon=6, switch_step=3)
        observation, _ = env.reset(seed=1)
        self.assertTrue(env.observation_space.contains(observation))
        rewards = []
        for action in [0, 1, 1, 0, 1, 0]:
            observation, reward, terminated, truncated, info = env.step(action)
            self.assertTrue(env.observation_space.contains(observation))
            self.assertIn(info["phase"], (0, 1))
            rewards.append(reward)
        self.assertTrue(truncated)
        self.assertFalse(terminated)
        self.assertGreaterEqual(min(rewards), env.reward_lower_bound)
        self.assertLessEqual(max(rewards), env.reward_upper_bound)

    def test_seed_reproducibility(self):
        def rollout(seed):
            env = NonstationaryQueueEnv(capacity=5, horizon=20, switch_step=10)
            observations = []
            rewards = []
            obs, _ = env.reset(seed=seed)
            for action in [0, 1] * 10:
                observations.append(obs.copy())
                obs, reward, _, _, _ = env.step(action)
                rewards.append(reward)
            env.close()
            return np.asarray(observations), np.asarray(rewards)

        first = rollout(77)
        second = rollout(77)
        np.testing.assert_array_equal(first[0], second[0])
        np.testing.assert_array_equal(first[1], second[1])

    def test_gymnasium_registration(self):
        env = gym.make(ENV_ID)
        observation, _ = env.reset(seed=3)
        self.assertTrue(env.observation_space.contains(observation))
        env.close()


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Generate descriptive effect sizes for the frozen v3 test metrics."""

from __future__ import annotations

import csv
import statistics
from collections import defaultdict
from itertools import combinations
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ENVIRONMENTS = ("CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0")
ALGORITHMS = ("PPO", "DQN", "A2C")


def cliffs_delta(first: list[float], second: list[float]) -> float:
    wins = sum((x > y) - (x < y) for x in first for y in second)
    return wins / (len(first) * len(second))


def main() -> None:
    values: dict[tuple[str, str], list[float]] = defaultdict(list)
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["split"] == "test":
                values[(row["env_id"], row["algorithm"])].append(float(row["metric_normalized"]))
    lines = [
        "# v3 Descriptive Effect-Size Table",
        "",
        "Generated from the frozen selected-configuration test metrics. The rows are descriptive and do not replace the primary family-wise intervals.",
        "",
        "`mean_diff` is mean(A) - mean(B); `Cliff_delta` counts pairwise wins minus losses divided by 400; `standardized_diff` uses the pooled sample SD and is set to 0 when both sample SDs are zero.",
        "",
        "| Environment | Comparison | Mean difference | Cliff delta | Standardized difference | Pooled SD |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for environment in ENVIRONMENTS:
        for first, second in combinations(ALGORITHMS, 2):
            x = values[(environment, first)]
            y = values[(environment, second)]
            if len(x) != 20 or len(y) != 20:
                raise ValueError(f"expected 20 metrics for {environment}/{first}/{second}")
            mean_diff = statistics.mean(x) - statistics.mean(y)
            pooled = ((19 * statistics.variance(x) + 19 * statistics.variance(y)) / 38) ** 0.5
            standardized = mean_diff / pooled if pooled else 0.0
            lines.append(
                f"| {environment} | {first} - {second} | {mean_diff:.6f} | "
                f"{cliffs_delta(x, y):.6f} | {standardized:.6f} | {pooled:.6f} |"
            )
    output = ROOT / "EFFECT_SIZE_TABLE_V3.md"
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()

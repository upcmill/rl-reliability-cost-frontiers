# Strict Reviewer Self-Audit: v3

This audit treats the v3 package as a submission candidate and lists the
objections most likely to produce rejection. It does not convert missing
evidence into a claim.

| Likely objection | Current evidence | Required strengthening | Risk |
|---|---|---|---|
| The protocol is a combination of known concentration, alpha-spending, and RL reporting ideas. | Proposition 1, the five-task v3 primary execution plus v6 scope extension, verified references, and the direct Chan et al. reliability comparison. | Complete the remaining database/second-screener review and state the contribution only as a narrower finite-look, conditional, sealed-test reliability--cost characterization. | High |
| Validation-based tuning may invalidate the test interval. | Proposition 0 gives a pointwise conditioning argument for any measurable validation-only selection rule; the v3 split audit verifies disjoint validation and sealed-test rows; the validation-cost audit records 100 candidate-seed rows per algorithm. | Obtain independent statistical review of the conditional target, retain the explicit prohibition on test-informed selection, and state that equal row counts do not prove equal computational difficulty. | High |
| Hoeffding intervals are too conservative to be useful. | Corollary 2 proves that the formal v3 allocation and 20-seed budget cannot resolve any bounded data, while all 15 v3 comparisons and the 80-cell calibration grid reach the same boundary. | Present the non-resolution region as a design property, report the calibration grid only as diagnostic support, and evaluate a less conservative method only after an independently checked error guarantee. | High |
| The primary experiment was run under a budget that could not answer its registered decision question. | The pre-study feasibility audit computes the maximum possible bounded lower endpoint and minimum clipped width at every v3 look before using RL rows; all superiority and precision feasibility flags are false. | Frame v3 as an intentional protocol-resolution characterization, expose the audit as a pre-study design tool, and do not describe 20 seeds as an empirical power study. | Medium |
| Pairwise early stopping may invalidate the fixed-look argument when different comparisons stop at different looks. | Proposition 2 proves that the reported terminal interval is contained in the simultaneous event over all predeclared looks; terminal-locking tests verify that later rows cannot overwrite a locked record. | Keep the finite look set, alpha schedule, and family closed; do not describe the lemma as an anytime confidence sequence. | Medium |
| The tuning budget is still weak or algorithmically unequal. | Four candidates, five validation seeds, equal grid, all candidate metrics retained; the ten-seed diagnostic changed 4/15 selections and the prospective twenty-seed extension changed 7/15 relative to v3. | Keep the stronger extension as supplementary selection-sensitivity evidence, justify the grid and compute budget, and retain the limitation that no grid is shown to be globally optimal. | High |
| The validation bootstrap frequencies are being mistaken for probabilities of global optimality. | `VALIDATION_SELECTION_UNCERTAINTY_V3.md` resamples only the five observed validation rows and explicitly labels frequencies as descriptive. | Keep the conditional estimand and validation/test separation primary; do not interpret the frequencies as population or optimality probabilities. | Medium |
| Seven discrete tasks do not support broad RL conclusions. | Five v3 tasks plus the v6 CliffWalking/FrozenLake extension, two continuous-action scope diagnostics, and a separately preregistered fixed-mask partial-observation diagnostic with same-machine cross-script replay. | Add visual tasks and external reruns under a new frozen family, or keep the claims scoped to fixed-budget evaluation; v6 remains a same-machine scope diagnostic. | High |
| The queue is an ad hoc environment. | Source, bounds, registration, tests, exact finite-state oracle, and six switch-time checks are disclosed. | Keep it explicitly controlled and diagnostic; do not claim standard-benchmark or broad external validity. | Medium |
| The interval proof conditions are not met by actual RL training. | Metrics are bounded; validation/test split and fixed looks are implemented; within-algorithm seed independence is an assumption. | Obtain independent statistical review and discuss environment and framework nondeterminism; do not call the guarantee unconditional. | High |
| Same-machine replay is described as reproducibility. | Independent script reproduces 15/15 means with difference 0.0; a returned Windows AMD64 sealed rerun adds a different-machine check. | Use “same-machine cross-script repeatability” for the first result and “different-machine reproducibility of the disclosed protocol” for the second; do not infer independent-team identity or scientific replication. | Medium |
| The study has no positive result. | 15/15 comparisons are maximum-budget inconclusive. | Present the negative result as the principal reliability--cost finding and avoid algorithm-ranking framing. | Medium |
| The 400-seed queue result is being promoted to a general DQN ranking or seed rule. | The post-v3 follow-up resolves only one fixed queue comparison after reusing the v3 20-seed prefix; its audit records the exact 200/400 stop trace. | Keep it as a single-task resolution-cost diagnostic, state that it was initiated after v3, and do not pool it with the 15-cell confirmatory family. | High |
| The v4 positive queue result is treated as independent confirmation or a universal budget. | V4 uses seeds 30000--30399, frozen v3 configurations, 6,000 rows, and one terminal decision with 14/15 cells unresolved at 400. | Keep v4 as a prospective new-seed, same-family budget observation; state that it is not an external rerun, task-family sample, or general algorithm ranking. | High |
| The v5 extension is presented as a general power curve or seed requirement. | V5 uses seeds 30400--31399, 15,000 rows, four terminal decisions by 1,000 seeds, and 11/15 cells unresolved. | Report observed resolution cost for the frozen family only; do not pool it into v3, estimate prospective power, or generalize the 1,000-seed cap. | High |
| The v6 extension is presented as evidence of task-family generalization. | V6 adds two fixed discrete tasks, 1,440 rows, and an independent raw-CSV audit; all six comparisons remain unresolved at 200 seeds and CliffWalking is at the normalized floor. | Report it only as an execution/scope diagnostic; do not treat the added task IDs as cross-family power or a ranking result. | High |
| Agreement between the two queue sequences is overinterpreted as replication. | The descriptive consistency diagnostic shows positive estimates at 200/400 in both sequences, but both runs use the same machine, task, and frozen procedures. | Report the agreement without pooling or calling it independent replication; retain the external-rerun limitation. | High |
| The 0.05 practical margin and 0.10 width target are arbitrary. | Both are frozen in the v3 preregistration; the stored-row margin sensitivity spans 0.00--0.50. | Keep them identified as design choices, report the post-hoc margin diagnostic as sensitivity only, and preregister future task-specific thresholds. | Medium |
| The alpha-spending schedule is arbitrary and the paper does not analyze the design tradeoff. | A deterministic minimax allocation lemma compares worst-case radius across looks with the preregistered power-series schedule. | Present it as a planning diagnostic, retain the preregistered primary rule, and avoid claiming universal optimality for stopping cost. | Medium |
| Validation-only selection of an alpha schedule may add hidden multiplicity or overstate cost savings. | Corollary 4 conditions on a validation-selected schedule; four-scenario sealed-test diagnostic has zero observed coverage failures and no uniform cost gain. | Keep every candidate schedule individually valid, retain the v3 schedule as confirmatory, and describe the adaptive result as diagnostic only. | Medium |
| The theoretical results are not translated into a usable evaluation protocol. | Discussion Section 6.3 derives seven bounded-scope recommendations tied to Propositions 0/2/3, Corollaries 0/2/5, and the v3/v5 frontier and dependence diagnostics. | Retain the explicit applicability limits, require a predeclared dependence diagnosis before any known-block fallback, and convert each recommendation into a preregistered field in any future study; do not present them as universal evaluator rules or RL dependence corrections. | Medium |
| The within-algorithm seed-independence assumption is treated as a formality. | Section 5.6.1 adds a six-condition block-dependence stress test; coverage falls from 1.0000 at block size 1 to 0.1244 at block size 50, with false-superiority rate rising to 0.7756. Proposition 3 and Section 5.6.2 add a known-block fallback; its 5,000-replicate synthetic coverage is 1.0000 with zero observed false-superiority in every tested condition. | Keep both results as surrogate assumption diagnostics, require dependence diagnosis before invoking the fallback, state the effective-sample-size cost, and do not claim that either the stress model or fallback estimates or corrects unknown dependence in RL environments. | High |
| Numerical theory values may contain a transcription error shared by the implementation and manuscript. | A separate formula-only implementation matches alpha, radius, width, and threshold values in `THEORY_AUDIT_V3.json`. | Retain the cross-check as internal evidence and still obtain an independent statistical review before making a stronger theorem claim. | Medium |
| The primary result may depend on a hidden production helper or generated summary. | A standard-library recomputer reads the raw v3 CSV and matches all 15 means, intervals, and terminal decisions. | Retain the raw-CSV recomputation and still distinguish same-workspace verification from external reproducibility. | Medium |
| The metric normalization can affect conclusions. | Bounds are predeclared and raw returns are retained. | Report raw-return secondary summaries and sensitivity to plausible alternative bounds. | Medium |
| Evaluation episodes and training budget are too small. | Four checkpoints, five episodes, and 4096 training steps define v3; fixed-selection diagnostics at 16,384 steps and ten episodes retain 15/15 maximum-budget inconclusive decisions, while descriptive means remain budget/aggregation dependent. | Keep both diagnostics supplementary and preregister a broader budget/episode study before making stronger claims. | Medium |
| Sequential execution does not save compute here. | Actual stop traces show all pairs continued to 20. | State explicitly that no savings were observed in v3; use simulations only for prospective planning if their error rates are calibrated. | Medium |
| The phrase “cost frontier” may be read as a hardware-independent efficiency claim. | `RELIABILITY_COST_FRONTIER_V3.md` combines analytic radius/threshold values with raw-CSV wall-clock sums and labels the runtime as Apple Silicon CPU accounting. | Keep the analytic and machine-specific columns separate; report no cross-hardware algorithm cost ranking or compute-savings claim. | Medium |
| The family-level alpha allocation is treated as a fixed detail even though the number of comparisons changes the resolution cost. | The v3 family is fixed at 15 comparisons and the primary bound allocates `0.05/15` per comparison. | The new analytic family-size sensitivity varies 1, 3, 9, 15, and 30 comparisons and reports the resulting radius and necessary seed thresholds; it contains no RL observations and does not estimate power. | Medium |
| Simulation evidence is being mistaken for a theorem. | `STATISTICAL_AUDIT_V3.md` separates proof assumptions, Monte Carlo intervals, and RL observations. | Keep all simulation claims qualified and report the scenario family, replicate count, and Monte Carlo intervals. | Medium |
| Literature and venue claims may be stale. | Sixteen audited source records plus an OpenAlex first-screener export, deterministic deduplication, and candidate screening table; unresolved items marked `[待核实]`. | Recheck every citation, software citation, and target venue immediately before submission and obtain an independent second screener. | Medium |

## Current weakest evidence-chain link

The weakest link is external validity and independent scientific replication.
The returned Windows rerun closes the different-machine reproducibility check,
but it uses the same frozen task family and does not independently verify the
operator's institutional identity or test a new task family. The second
weakest link is substantive novelty:
the current evidence demonstrates a careful application and characterization
of established statistical ideas, while the exact literature-wide distinction
remains `[待核实]`.

## Claim gate

The following claims are permitted in the current manuscript:

- conditional finite-look coverage under explicit assumptions;
- 15/15 v3 maximum-budget inconclusive decisions;
- one continuous-control supplement comparison, also maximum-budget inconclusive;
- descriptive selected-configuration means;
- same-machine cross-script repeatability with zero mean differences;
- the four-look reliability--cost frontier for the disclosed protocol and machine;
- the analytic family-size planning sensitivity for the disclosed bounded interval,
  explicitly as a planning diagnostic rather than empirical power;
- the post-v3 fixed-configuration queue DQN--A2C resolution-cost diagnostic,
  explicitly scoped to 400 observed seeds;
- limitations of the fixed task family and budget.

The following claims are blocked until new evidence exists:

- general PPO, DQN, or A2C rankings;
- universal seed requirements or universal compute savings;
- independent-team identity or scientific replication on a new task family;
- generalization to continuous, visual, or large-scale RL;
- a literature-wide novelty claim or guaranteed SCI acceptance.

## Pre-submission checklist

- [ ] Independent statistical review of Proposition 1 and conditional estimand.
- [ ] Current literature and venue verification; resolve all `[待核实]` tags.
- [x] Different-machine sealed rerun with raw-output comparison; independent-team identity and new-family replication remain open.
- [x] Raw-return and normalization sensitivity appendix.
- [x] Budget and evaluation-episode sensitivity diagnostics; both remain supplementary and estimand-specific.
- [x] Practical-margin sensitivity diagnostic over the stored v3 rows; it remains post-hoc and does not establish a universal margin.
- [x] Queue budget follow-up with row-level v3 prefix audit and explicit
  post-v3 resolution-cost labeling.
- [x] Queue oracle and switch-time checks are archived; broad queue claims remain excluded.
- [x] Archive source hashes, environment lockfile, commands, and the supported-runtime toolchain note (`VERIFICATION_LOG_V3.md`).
- [x] Audit the reliability--cost frontier against the raw test CSV (`audit_reliability_cost_frontier.py`).
- [x] Audit the family-size planning sensitivity against its analytic formula (`audit_design_planning_sensitivity.py`).
- [x] Run the pre-study budget feasibility audit and deterministic checks (`generate_budget_feasibility_audit.py`, `test_budget_feasibility_audit.py`).
- [x] Run `./.rl-arm64-venv/bin/python audit_v3_artifacts.py` immediately before submission.
- [x] Run `./.rl-arm64-venv/bin/python audit_continuous_artifacts.py` immediately before submission.

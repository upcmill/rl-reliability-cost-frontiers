#!/usr/bin/env python3
"""Run a fixed-configuration budget follow-up on the controlled queue task.

This follow-up is deliberately separate from the frozen v3 analysis.  It
reuses the v3-selected configurations and the first 20 sealed test metrics,
then extends the same seed sequence until a predeclared finite-look decision
or the 1,000-seed cap.  It measures resolution cost; it does not amend the
v3 estimand or establish a universal RL seed requirement.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path

import gymnasium as gym
import torch

from pilot_protocol import ProtocolConfig, sequential_decision
from sb3_pilot import train_curve
from sequential_sb3_runner_v3 import CONFIGS


ENV_ID = "NonstationaryQueue-v0"
ALGORITHMS = ("DQN", "A2C")
REFERENCE_DIR = Path("sb3_formal_v3")
REFERENCE_MIN_SEED = 0
REFERENCE_MAX_SEED = 19


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-dir", type=Path, default=REFERENCE_DIR)
    parser.add_argument("--output-dir", type=Path, default=Path("sb3_queue_budget_followup_v1"))
    parser.add_argument("--max-seeds", type=int, default=1000)
    parser.add_argument("--initial-seeds", type=int, default=200)
    parser.add_argument("--batch-size", type=int, default=200)
    parser.add_argument("--timesteps", type=int, default=4096)
    parser.add_argument("--checkpoints", type=int, default=4)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--family-alpha", type=float, default=0.05)
    parser.add_argument("--comparison-count", type=int, default=15)
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    args = parser.parse_args()
    if args.max_seeds < 20 or args.initial_seeds < 2 or args.initial_seeds > args.max_seeds:
        parser.error("max-seeds must be >= 20 and initial-seeds must be in [2, max-seeds]")
    if args.batch_size < 1 or args.checkpoints < 1 or args.timesteps < args.checkpoints:
        parser.error("invalid batch/checkpoint settings")
    if args.max_seeds % args.batch_size != 0 or args.initial_seeds % args.batch_size != 0:
        parser.error("max-seeds and initial-seeds must be multiples of batch-size")
    if not 0 < args.family_alpha < 1 or args.comparison_count < 1:
        parser.error("invalid alpha/comparison count")
    return args


def read_reference(reference_dir: Path) -> tuple[dict[str, str], dict[str, list[float]], list[dict]]:
    """Read v3 selections and the first 20 queue test values without mutation."""
    payload = json.loads((reference_dir / "summary.json").read_text(encoding="utf-8"))
    summary = payload["summary"]
    selected = {
        algorithm: summary[f"{ENV_ID}:{algorithm}"]["selected_config"]
        for algorithm in ALGORITHMS
    }
    values = {algorithm: [] for algorithm in ALGORITHMS}
    rows = []
    with (reference_dir / "raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["env_id"] != ENV_ID or row["split"] != "test" or row["algorithm"] not in ALGORITHMS:
                continue
            seed = int(row["seed"])
            if seed > REFERENCE_MAX_SEED:
                continue
            if row["config_id"] != selected[row["algorithm"]]:
                raise ValueError("reference row does not use the frozen selected configuration")
            values[row["algorithm"]].append(float(row["metric_normalized"]))
            rows.append({**row, "source": "v3_reference"})
    for algorithm in ALGORITHMS:
        if len(values[algorithm]) != REFERENCE_MAX_SEED - REFERENCE_MIN_SEED + 1:
            raise ValueError(f"expected 20 v3 metrics for {algorithm}")
    return selected, values, rows


def decision(values: dict[str, list[float]], args: argparse.Namespace) -> dict:
    config = ProtocolConfig(
        alpha=args.family_alpha / args.comparison_count,
        practical_margin=args.practical_margin,
        initial_seeds=args.initial_seeds,
        batch_size=args.batch_size,
        max_seeds=args.max_seeds,
        target_width=args.target_width,
        interval_method="hoeffding_unpaired",
        bootstrap_resamples=1000,
    )
    return sequential_decision(values["DQN"], values["A2C"], config)


def main() -> None:
    args = parse_args()
    selected, values, records = read_reference(args.reference_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = [args.timesteps * i // args.checkpoints for i in range(1, args.checkpoints + 1)]
    trace = []
    resolved = None

    # The first 20 values are immutable v3 rows.  New training runs begin at
    # seed 20020 and are appended in batches before each predeclared look.
    current_count = REFERENCE_MAX_SEED + 1
    for batch_end in range(args.initial_seeds, args.max_seeds + 1, args.batch_size):
        for seed_offset in range(current_count, batch_end):
            train_seed = 20_000 + seed_offset
            for algorithm in ALGORITHMS:
                result = train_curve(
                    ENV_ID,
                    algorithm,
                    train_seed,
                    CONFIGS[selected[algorithm]],
                    checkpoints,
                    args.eval_episodes,
                )
                values[algorithm].append(result["metric_normalized"])
                records.append(
                    {
                        "env_id": ENV_ID,
                        "algorithm": algorithm,
                        "config_id": selected[algorithm],
                        "split": "test",
                        "seed": seed_offset,
                        "train_seed": train_seed,
                        "evaluation_seed_base": result["evaluation_seed_base"],
                        "metric_normalized": result["metric_normalized"],
                        "metric_raw": result["metric_raw"],
                        "runtime_seconds": result["runtime_seconds"],
                        "status": "ok",
                        "source": "followup_training",
                    }
                )
        current = decision(values, args)
        trace.append({"n": batch_end, "decision": current})
        if current["decision"] != "max_budget_inconclusive":
            resolved = current
            break
        current_count = batch_end
    if resolved is None:
        resolved = decision(values, args)

    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    try:
        sb3_version = importlib.metadata.version("stable-baselines3")
    except importlib.metadata.PackageNotFoundError:
        sb3_version = "unknown"
    metadata = {
        "status": "fixed_configuration_budget_followup",
        "warning": "Post-v3 resolution-cost diagnostic; not a replacement for the preregistered v3 result.",
        "environment_id": ENV_ID,
        "algorithms": list(ALGORITHMS),
        "selected_configurations": selected,
        "reference_dir": str(args.reference_dir),
        "reference_test_seeds": "20000-20019",
        "new_test_seed_range": f"20020-{20_000 + len(values[ALGORITHMS[0]]) - 1}",
        "run_config": {
            "max_seeds": args.max_seeds,
            "initial_seeds": args.initial_seeds,
            "batch_size": args.batch_size,
            "timesteps": args.timesteps,
            "checkpoints": args.checkpoints,
            "checkpoints_resolved": checkpoints,
            "eval_episodes": args.eval_episodes,
            "family_alpha": args.family_alpha,
            "comparison_count_context": args.comparison_count,
            "comparison_alpha": args.family_alpha / args.comparison_count,
            "practical_margin": args.practical_margin,
            "target_width": args.target_width,
            "interval_method": "hoeffding_unpaired",
            "execution_mode": "append_fixed_configuration_until_predeclared_look",
        },
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "gymnasium": gym.__version__,
        "stable_baselines3": sb3_version,
        "mps_available": bool(torch.backends.mps.is_available()),
        "script_sha256": script_hash,
        "final_decision": resolved,
        "stop_trace": trace,
        "metric_counts": {algorithm: len(values[algorithm]) for algorithm in ALGORITHMS},
        "interpretation": {
            "estimand": "fixed v3-selected queue configurations under the same normalized learning-curve metric",
            "claim_scope": "resolution cost for this controlled task and observed configuration; not a universal seed requirement",
            "v3_status": "primary v3 results remain immutable",
        },
    }
    fields = [
        "env_id", "algorithm", "config_id", "split", "seed", "train_seed",
        "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status", "source",
    ]
    with (args.output_dir / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    (args.output_dir / "run_config.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "summary.json").write_text(
        json.dumps({"metadata": metadata, "metrics": values}, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()

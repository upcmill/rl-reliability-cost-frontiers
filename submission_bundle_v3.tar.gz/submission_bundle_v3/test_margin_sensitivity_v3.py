import json
import unittest
from pathlib import Path

from margin_sensitivity_v3 import possible_threshold


class MarginSensitivityTests(unittest.TestCase):
    def test_necessary_thresholds_match_formal_v3_margin(self):
        comparison_alpha = 0.05 / 15.0
        self.assertEqual(
            [possible_threshold(comparison_alpha, look, 0.05) for look in (1, 2, 3, 4)],
            [17, 20, 22, 23],
        )

    def test_generated_diagnostic_has_seven_margins_and_fifteen_cells(self):
        payload = json.loads(Path("margin_sensitivity_v3.json").read_text(encoding="utf-8"))
        self.assertEqual(payload["status"], "post_hoc_margin_sensitivity_diagnostic")
        self.assertEqual(len(payload["rows"]), 7)
        for row in payload["rows"]:
            self.assertEqual(
                row["observed_v3_decision_counts_at_target_width_0.10"],
                {"max_budget_inconclusive": 15},
            )


if __name__ == "__main__":
    unittest.main()


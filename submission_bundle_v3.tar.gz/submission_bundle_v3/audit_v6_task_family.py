#!/usr/bin/env python3
"""Audit the raw rows and finite-look decisions of the v6 extension."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "sb3_v6_task_family"
ENVIRONMENTS = ("CliffWalking-v1", "FrozenLake-v1")
ALGORITHMS = ("PPO", "DQN", "A2C")
EXPECTED_SPLITS = {"validation": 240, "extension_test": 1200}
LOOKS = (50, 100, 150, 200)
CONFIG_ORDER = ("lr3e4_long", "lr1e4_long", "lr3e4_short", "lr1e4_short")


def expected_config(rows: list[dict]) -> str:
    candidates = [candidate for candidate in CONFIG_ORDER if any(row["config_id"] == candidate for row in rows)]
    means = {candidate: sum(float(row["metric_normalized"]) for row in rows if row["config_id"] == candidate) / sum(row["config_id"] == candidate for row in rows) for candidate in candidates}
    return max(candidates, key=lambda candidate: (means[candidate], -candidates.index(candidate)))


def compare_decision(actual: dict, expected: dict) -> bool:
    keys = ("decision", "n", "look")
    if any(actual.get(key) != expected.get(key) for key in keys):
        return False
    for key in ("estimate", "lower", "upper"):
        if abs(float(actual[key]) - float(expected[key])) > 1e-12:
            return False
    return True


def main() -> None:
    raw_path = OUTPUT / "raw_seed_metrics.csv"
    config_path = OUTPUT / "run_config.json"
    summary_path = OUTPUT / "summary.json"
    rows = list(csv.DictReader(raw_path.open(encoding="utf-8", newline="")))
    config = json.loads(config_path.read_text(encoding="utf-8"))
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    checks: dict[str, bool] = {}
    checks["row_count"] = len(rows) == 1440
    checks["split_counts"] = dict(Counter(row["split"] for row in rows)) == EXPECTED_SPLITS
    checks["environment_ids"] = set(row["env_id"] for row in rows) == set(ENVIRONMENTS)
    checks["algorithm_ids"] = set(row["algorithm"] for row in rows) == set(ALGORITHMS)
    checks["normalized_range"] = all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows)
    checks["no_duplicate_rows"] = len({(row["env_id"], row["algorithm"], row["config_id"], row["split"], row["seed"]) for row in rows}) == len(rows)
    checks["seed_ranges"] = (
        {int(row["train_seed"]) for row in rows if row["split"] == "validation"} == set(range(40000, 40010))
        and {int(row["train_seed"]) for row in rows if row["split"] == "extension_test"} == set(range(41000, 41200))
    )
    checks["environment_options"] = config["environment_options"] == {"FrozenLake-v1": {"map_name": "4x4", "is_slippery": True}}
    checks["torch_threads"] = config.get("torch_num_threads") == 1
    checks["no_seed_overlap"] = set(range(40000, 40010)).isdisjoint(set(range(41000, 41200)))

    grouped_validation: dict[tuple[str, str, str], list[dict]] = defaultdict(list)
    grouped_test: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in rows:
        if row["split"] == "validation":
            grouped_validation[(row["env_id"], row["algorithm"], row["config_id"])].append(row)
        else:
            grouped_test[(row["env_id"], row["algorithm"])].append(row)
    checks["validation_candidate_counts"] = all(len(group) == 10 for group in grouped_validation.values()) and len(grouped_validation) == 24
    checks["test_cell_counts"] = all(len(group) == 200 for group in grouped_test.values()) and len(grouped_test) == 6

    selected_expected = {}
    for env_id in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            groups = [rows_for_config for (e, a, _), rows_for_config in grouped_validation.items() if e == env_id and a == algorithm]
            selected = expected_config([row for group in groups for row in group])
            selected_expected[f"{env_id}:{algorithm}"] = selected
    checks["selected_configurations"] = selected_expected == config["selected_configurations"]
    checks["test_config_freeze"] = all(row["config_id"] == selected_expected[f"{row['env_id']}:{row['algorithm']}"] for row in rows if row["split"] == "extension_test")

    trace_by_n = {trace["n"]: trace["decisions"] for trace in config["stop_traces"]}
    decision_checks = []
    for n in LOOKS:
        protocol = ProtocolConfig(alpha=0.05 / 6, practical_margin=0.05, initial_seeds=50, batch_size=50, max_seeds=n, target_width=0.10, interval_method="hoeffding_unpaired", bootstrap_resamples=1000)
        for env_id in ENVIRONMENTS:
            for algorithm_a, algorithm_b in combinations(ALGORITHMS, 2):
                key = f"{env_id}:{algorithm_a}_vs_{algorithm_b}"
                left = [float(row["metric_normalized"]) for row in grouped_test[(env_id, algorithm_a)][:n]]
                right = [float(row["metric_normalized"]) for row in grouped_test[(env_id, algorithm_b)][:n]]
                expected = sequential_decision(left, right, protocol)
                actual = trace_by_n[n][key]
                decision_checks.append(compare_decision(actual, expected))
    checks["decision_recomputation"] = all(decision_checks) and len(decision_checks) == 24
    checks["all_final_inconclusive"] = all(trace_by_n[200][key]["decision"] == "max_budget_inconclusive" for key in trace_by_n[200])

    script_hash = hashlib.sha256((ROOT / "sb3_v6_task_family_extension.py").read_bytes()).hexdigest()
    checks["script_hash"] = script_hash == config["script_sha256"]
    summary_selected = {f"{env_id}:{algorithm}": config_id for env_id, algorithms in summary["selected"].items() for algorithm, config_id in algorithms.items()}
    checks["summary_matches_metadata"] = summary_selected == config["selected_configurations"]
    status = "PASS" if all(checks.values()) else "FAIL"
    report = {"schema": "v6-task-family-audit-v1", "status": status, "checks": checks, "rows": len(rows), "decision_checks": len(decision_checks)}
    (OUTPUT / "V6_TASK_FAMILY_AUDIT.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    lines = ["# v6 Task-Family Audit", "", f"Status: **{status}**", "", "| Check | Result |", "|---|---|"]
    lines.extend(f"| `{name}` | {'PASS' if result else 'FAIL'} |" for name, result in checks.items())
    lines.extend(["", "The audit recomputes all 24 finite-look decisions directly from the raw CSV.", ""])
    (OUTPUT / "V6_TASK_FAMILY_AUDIT.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if status != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()

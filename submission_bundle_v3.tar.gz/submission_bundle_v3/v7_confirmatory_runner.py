#!/usr/bin/env python3
"""Collect the frozen V7 new-seed validation sequence with resumable writes."""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import gymnasium as gym
import torch

from sb3_pilot import ALGORITHMS, ADDITIONAL_ENV_IDS, DEFAULT_ENV_IDS, QUEUE_ENV_ID, train_curve
from sequential_sb3_runner_v3 import CONFIGS

ROOT = Path(__file__).resolve().parent
ENVS = (*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)
SEED_START, SEED_STOP = 31_400, 32_400
LOOKS = (200, 400, 600, 800, 1000)
FIELDS = ("env_id", "algorithm", "config_id", "split", "seed", "train_seed",
          "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status")
LOCK_PATH = ROOT / "V7_CONFIRMATION_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_lock() -> dict:
    lock = json.loads(LOCK_PATH.read_text())
    for relative, expected in lock["hashes"].items():
        actual = sha(ROOT / relative)
        if actual != expected:
            raise RuntimeError(f"frozen V7 source changed: {relative}")
    return lock


def selected_configs() -> dict[str, str]:
    v3 = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text())
    v5 = json.loads((ROOT / "sb3_v5_extension/run_config.json").read_text())
    selected = {f"{env}:{algo}": v3["summary"][f"{env}:{algo}"]["selected_config"]
                for env in ENVS for algo in ALGORITHMS}
    if selected != v5["selected_configurations"]:
        raise RuntimeError("V3 selected configurations differ from V5 frozen configuration")
    return selected


def static_metadata(lock: dict, selected: dict[str, str]) -> dict:
    try:
        sb3_version = importlib.metadata.version("stable-baselines3")
    except importlib.metadata.PackageNotFoundError:
        sb3_version = "unknown"
    return {
        "status": "RUNNING",
        "interpretation": "prospective new-seed validation after prior results; not independent-team reproduction",
        "plan": "V7_PROSPECTIVE_VALIDATION_PLAN.md",
        "plan_sha256": lock["hashes"]["V7_PROSPECTIVE_VALIDATION_PLAN.md"],
        "source_hashes": lock["hashes"],
        "environment_ids": list(ENVS), "algorithm_ids": list(ALGORITHMS),
        "selected_configurations": selected,
        "seed_range_inclusive": [SEED_START, SEED_STOP - 1],
        "expected_rows": len(ENVS) * len(ALGORITHMS) * (SEED_STOP - SEED_START),
        "training": {"timesteps": 4096, "checkpoints": [1024, 2048, 3072, 4096],
                     "evaluation_episodes_per_checkpoint": 5, "device": "cpu"},
        "analysis_lock": {"looks": list(LOOKS), "family_alpha": 0.05,
                          "comparison_alpha": 0.05 / 15, "practical_margin": 0.05,
                          "target_width": 0.10},
        "software": {"python": platform.python_version(), "architecture": platform.machine(),
                     "platform": platform.platform(), "torch": torch.__version__,
                     "gymnasium": gym.__version__, "stable_baselines3": sb3_version,
                     "mps_available": bool(torch.backends.mps.is_available())},
    }


def key(row: dict) -> tuple[str, str, int]:
    return row["env_id"], row["algorithm"], int(row["train_seed"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("sb3_v7_confirmation"))
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--validate-only", action="store_true",
                        help="verify the source lock and selected configurations without training")
    args = parser.parse_args()
    lock = verify_lock()
    selected = selected_configs()
    if args.validate_only:
        print(json.dumps({"status": "LOCK_VALID", "selected_configurations": selected,
                          "source_hashes": lock["hashes"]}, indent=2))
        return
    output = args.output_dir if args.output_dir.is_absolute() else ROOT / args.output_dir
    metadata_path = output / "run_config.json"
    csv_path = output / "raw_seed_metrics.csv"
    if args.resume:
        if not output.is_dir() or not metadata_path.is_file() or not csv_path.is_file():
            parser.error("--resume requires an existing run_config.json and raw_seed_metrics.csv")
        existing = json.loads(metadata_path.read_text())
        expected = static_metadata(lock, selected)
        for field, value in expected.items():
            if field == "status":
                continue
            if existing.get(field) != value:
                raise RuntimeError(f"run metadata differs from frozen settings: {field}")
        with csv_path.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        completed = {key(row) for row in rows if row["status"] == "ok"}
        if len(completed) != len(rows):
            raise RuntimeError("raw file contains failed or duplicate rows; inspect before resuming")
        if len(completed) != len(rows) or len(set(map(key, rows))) != len(rows):
            raise RuntimeError("raw file contains duplicate records")
    else:
        if output.exists():
            parser.error("output directory exists; use --resume only for a validated partial run")
        output.mkdir(parents=True)
        completed = set()
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            csv.DictWriter(handle, fieldnames=FIELDS).writeheader()
        metadata = static_metadata(lock, selected)
        metadata["started_utc"] = datetime.now(timezone.utc).isoformat()
        metadata_path.write_text(json.dumps(metadata, indent=2) + "\n")

    new_rows = 0
    started = time.monotonic()
    with csv_path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        for seed in range(SEED_START, SEED_STOP):
            pending = [(env, algo) for env in ENVS for algo in ALGORITHMS
                       if (env, algo, seed) not in completed]
            for env, algo in pending:
                config_id = selected[f"{env}:{algo}"]
                try:
                    result = train_curve(env, algo, seed, CONFIGS[config_id],
                                         [1024, 2048, 3072, 4096], 5)
                except Exception as error:
                    event = {"utc": datetime.now(timezone.utc).isoformat(), "env_id": env,
                             "algorithm": algo, "train_seed": seed,
                             "error_type": type(error).__name__, "error": str(error)}
                    with (output / "failed_attempts.jsonl").open("a", encoding="utf-8") as log:
                        log.write(json.dumps(event) + "\n")
                    raise
                writer.writerow({"env_id": env, "algorithm": algo, "config_id": config_id,
                    "split": "v7_confirmation", "seed": seed - SEED_START, "train_seed": seed,
                    "evaluation_seed_base": result["evaluation_seed_base"],
                    "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"],
                    "runtime_seconds": result["runtime_seconds"], "status": "ok"})
                handle.flush()
                completed.add((env, algo, seed))
                new_rows += 1
            if seed % 10 == 9 or seed == SEED_STOP - 1:
                print(json.dumps({"completed_rows": len(completed), "expected_rows": 15000,
                                  "through_seed": seed, "new_rows_this_process": new_rows,
                                  "elapsed_seconds": round(time.monotonic() - started, 1)}), flush=True)
                metadata = json.loads(metadata_path.read_text())
                metadata["last_completed_seed"] = seed
                metadata["completed_rows"] = len(completed)
                metadata["status"] = "RUNNING"
                metadata_path.write_text(json.dumps(metadata, indent=2) + "\n")
    metadata = json.loads(metadata_path.read_text())
    metadata["status"] = "COMPLETED" if len(completed) == 15000 else "PARTIAL"
    metadata["completed_rows"] = len(completed)
    metadata["elapsed_seconds_this_process"] = time.monotonic() - started
    metadata_path.write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps({"status": metadata["status"], "completed_rows": len(completed),
                      "output_dir": str(output)}, flush=True))


if __name__ == "__main__":
    main()

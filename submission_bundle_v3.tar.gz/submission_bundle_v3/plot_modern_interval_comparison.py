"""Create the manuscript's new post-hoc interval-width comparison figure."""
import csv
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/rl-paper-mplconfig')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'sequential_comparison_v1/results_v2/real_intervals.csv'
DEST = ROOT / 'manuscript_figures/fig_modern_interval_comparison.png'
DATASETS = [('primary20', '主研究：20 个种子'), ('extension400', '扩展：400 个种子'), ('extension1000', '扩展：1,000 个种子')]
METHODS = ['H-original', 'H-finite', 'H-uniform', 'EB-uniform', 'CS-normal', 'CS-EB-stitch', 'CS-EB-gamma']
NAMES = {'H-original': 'Hoeffding 原方案', 'H-finite': 'Hoeffding 有限支出',
         'H-uniform': 'Hoeffding 均匀支出', 'EB-uniform': 'Empirical Bernstein',
         'CS-normal': 'Normal-mixture CS', 'CS-EB-stitch': 'EB stitched CS', 'CS-EB-gamma': 'EB gamma CS'}
COLORS = ['#333333', '#777777', '#2878B5', '#D55E00', '#009E73', '#CC79A7', '#E69F00']


def main():
    plt.rcParams['font.sans-serif'] = ['Heiti TC', 'Arial Unicode MS', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    with SOURCE.open() as file:
        rows = list(csv.DictReader(file))
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.1), sharey=True)
    for ax, (dataset, title) in zip(axes, DATASETS):
        selected = [r for r in rows if r['dataset'] == dataset]
        looks = sorted({int(r['look']) for r in selected})
        for method, color in zip(METHODS, COLORS):
            medians, low, high = [], [], []
            for look in looks:
                values = np.array([float(r['width']) for r in selected if r['method'] == method and int(r['look']) == look])
                medians.append(np.median(values)); low.append(np.quantile(values, .25)); high.append(np.quantile(values, .75))
            ax.plot(looks, medians, marker='o', linewidth=1.8, markersize=4, label=NAMES[method], color=color)
            ax.fill_between(looks, low, high, color=color, alpha=.10, linewidth=0)
        ax.axhline(.1, linestyle=':', color='#666666', linewidth=1)
        ax.set_title(title, fontsize=11)
        ax.set_xlabel('每臂完整训练运行数')
        ax.grid(axis='y', alpha=.2)
        ax.set_xticks(looks)
    axes[0].set_ylabel('15 项比较的区间宽度中位数（IQR 阴影）')
    axes[-1].legend(loc='upper right', fontsize=8, frameon=False)
    fig.tight_layout()
    DEST.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(DEST, dpi=220, bbox_inches='tight')
    plt.close(fig)
    print(DEST)


if __name__ == '__main__':
    main()

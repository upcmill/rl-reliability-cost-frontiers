#!/usr/bin/env python3
"""Independently recompute the stored v3 comparison decisions from raw CSV."""

from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RAW = ROOT / "sb3_formal_v3/raw_seed_metrics.csv"
SUMMARY = ROOT / "sb3_formal_v3/summary.json"
REFERENCE = ROOT / "sb3_formal_v3/familywise_cost_summary.json"
OUTPUT = ROOT / "INDEPENDENT_V3_RECOMPUTE.json"
REPORT = ROOT / "INDEPENDENT_V3_RECOMPUTE.md"


def alpha_spend(alpha: float, look: int) -> float:
    return alpha * 6.0 / (math.pi * math.pi * look * look)


def interval(values_a: list[float], values_b: list[float], alpha: float) -> tuple[float, float, float]:
    n_a = len(values_a)
    n_b = len(values_b)
    estimate = sum(values_a) / n_a - sum(values_b) / n_b
    radius_a = math.sqrt(math.log(4.0 / alpha) / (2.0 * n_a))
    radius_b = math.sqrt(math.log(4.0 / alpha) / (2.0 * n_b))
    return estimate, max(-1.0, estimate - radius_a - radius_b), min(1.0, estimate + radius_a + radius_b)


def decide(values_a: list[float], values_b: list[float], alpha: float) -> dict:
    for look, n in enumerate((5, 10, 15, 20), start=1):
        estimate, lower, upper = interval(values_a[:n], values_b[:n], alpha_spend(alpha, look))
        if lower > 0.05:
            return {"decision": "a_superior", "n": n, "estimate": estimate, "lower": lower, "upper": upper, "look": look}
        if upper < -0.05:
            return {"decision": "b_superior", "n": n, "estimate": estimate, "lower": lower, "upper": upper, "look": look}
        if upper - lower <= 0.10:
            return {"decision": "inconclusive_precision", "n": n, "estimate": estimate, "lower": lower, "upper": upper, "look": look}
    estimate, lower, upper = interval(values_a, values_b, alpha_spend(alpha, 4))
    return {"decision": "max_budget_inconclusive", "n": 20, "estimate": estimate, "lower": lower, "upper": upper, "look": 4}


def run() -> dict:
    summary = json.loads(SUMMARY.read_text(encoding="utf-8"))
    reference = json.loads(REFERENCE.read_text(encoding="utf-8"))
    selected = {
        (env, algorithm): summary["summary"][f"{env}:{algorithm}"]["selected_config"]
        for env in summary["environment_ids"]
        for algorithm in summary["algorithm_ids"]
    }
    rows = defaultdict(list)
    with RAW.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            key = (row["env_id"], row["algorithm"])
            if row["split"] == "test" and row["config_id"] == selected[key]:
                rows[key].append((int(row["seed"]), float(row["metric_normalized"])))
    results = []
    reference_rows = {(row["env_id"], row["comparison"]): row for row in reference["rows"]}
    for env in summary["environment_ids"]:
        for left, right in (("PPO", "DQN"), ("PPO", "A2C"), ("DQN", "A2C")):
            left_values = [value for _, value in sorted(rows[(env, left)])]
            right_values = [value for _, value in sorted(rows[(env, right)])]
            comparison = f"{left}_vs_{right}"
            recomputed = decide(left_values, right_values, summary["run_config"]["comparison_alpha"])
            reference_row = reference_rows[(env, comparison)]
            results.append({
                "env_id": env,
                "comparison": comparison,
                "recomputed": recomputed,
                "reference": reference_row,
                "matches": recomputed["decision"] == reference_row["decision"]
                and recomputed["n"] == reference_row["n"]
                and abs(recomputed["estimate"] - reference_row["estimate"]) < 1e-12,
            })
    payload = {
        "status": "PASS" if all(row["matches"] for row in results) else "FAIL",
        "scope": "independent raw-CSV recomputation of v3 decisions",
        "warning": "This is an internal second implementation; it is not external reproducibility or an independent statistical review.",
        "comparison_count": len(results),
        "matching_count": sum(row["matches"] for row in results),
        "results": results,
    }
    OUTPUT.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    REPORT.write_text("\n".join([
        "# Independent v3 Raw-CSV Recompute",
        "",
        "A standard-library implementation independently reads the selected v3",
        "test rows and recomputes all 15 means, bounded intervals, and terminal",
        "decisions. It does not import the production runner or interval helper.",
        "",
        f"- Status: `{payload['status']}`",
        f"- Matching comparisons: `{payload['matching_count']}/{payload['comparison_count']}`",
        "- Scope: internal second implementation; not external reproducibility.",
        "",
    ]), encoding="utf-8")
    return payload


if __name__ == "__main__":
    result = run()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)

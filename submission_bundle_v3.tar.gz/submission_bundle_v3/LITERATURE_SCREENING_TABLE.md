# Literature Screening Table

This table records exact-title or DOI-level screening decisions made during
the current scoping review. It is an audit aid, not a claim of exhaustive
coverage. A record is included in the manuscript bibliography only when its
bibliographic metadata and substantive relevance are both verified.

| Record | Bibliographic verification | Evaluation-method relevance | Direct overlap with this protocol | Decision and reason |
|---|---|---|---|---|
| Henderson et al. (2018), “Deep Reinforcement Learning That Matters” | DOI `10.1609/aaai.v32i1.11694`; Crossref and AAAI landing page checked; listed as L1. | High for seed variability, nondeterminism, and reporting practice. | No finite-look bounded interval, sealed post-validation test, or explicit reliability--cost frontier was verified. | Include as motivation and reporting background (L1). |
| Colas et al. (2018), “How Many Random Seeds? Statistical Power Analysis in Deep Reinforcement Learning Experiments” | arXiv DOI `10.48550/arXiv.1806.08295`; arXiv record checked; listed as L2. | High for seed counts, power, and uncertainty. | Does not establish the present conditional estimand or finite-look family construction. | Include as statistical motivation (L2); venue status remains as recorded. |
| Colas et al. (2019), “A Hitchhiker's Guide to Statistical Comparisons of Reinforcement Learning Algorithms” | arXiv DOI `10.48550/arXiv.1904.06979`; arXiv record checked; listed as L3. | High for comparing statistical tests, effect sizes, power, and assumptions. | Does not validate this implementation or its sealed-seed protocol. | Include as comparison-method background (L3). |
| Agarwal et al. (2021), “Deep Reinforcement Learning at the Edge of the Statistical Precipice” | arXiv DOI `10.48550/arXiv.2108.13264`; arXiv record checked; listed as L4. | High for uncertainty-aware RL evaluation. | Does not establish this exact sequential construction; final venue status remains `[待核实]`. | Include with the existing qualification (L4). |
| Whiteson et al. (2011), “Protecting against evaluation overfitting in empirical reinforcement learning” | Crossref DOI metadata verifies authors, title, *2011 IEEE Symposium on Adaptive Dynamic Programming and Reinforcement Learning (ADPRL)*, pp. 120--127, and DOI `10.1109/ADPRL.2011.5967363`; linked IEEE full text was not retrieved in this run. | High for the general evaluation-overfitting problem, based on the verified title and venue. | Method-level overlap with the present finite-look, sealed-test construction remains unknown until the full text is checked. | Include as L11 for bounded background only; do not attribute method details or claim a novelty distinction yet. |
| Mrzljak and Hrkać (2019), “Experimental Evaluation of Deep Reinforcement Learning Algorithms” | DOI `10.20532/ccvw.2018.0003`; Crossref and OpenAlex records checked. OpenAlex reports *Proceedings of the Croatian Computer Vision Workshop*, pp. 7--12, published 2019-02-06, with an open-access PDF URL. | Algorithm-comparison experiment on Atari Breakout; useful as evidence that benchmark comparisons exist. | Abstract describes an overview/comparison of algorithms and does not report configuration-selection/test separation, finite-look inference, bounded coverage, or a reliability--cost analysis. Full-text retrieval failed during this run because the host DNS was unavailable. | Screened and excluded from direct-method overlap; do not cite as evidence that this protocol is novel. Full-text content remains `[待核实]`. |
| Towers et al. (2025), “Gymnasium: A Standard Interface for Reinforcement Learning Environments” | DOI `10.52202/085713-4916`; Crossref record checked; listed as L10. | Software/environment provenance. | No evaluation-statistics contribution. | Include only for software provenance (L10). |
| Raffin et al. (2021), “Stable-Baselines3: Reliable Reinforcement Learning Implementations” | Official repository `CITATION.bib` and JMLR landing page verify authors, title, volume 22, article 268, pages 1--8, and URL `https://jmlr.org/papers/v22/20-1364.html`; listed as L12. | Software implementation provenance. | Does not establish the present statistical protocol, hyperparameters, results, or external reproducibility. | Include as software citation (L12). |
| Chan et al. (2019), “Measuring the Reliability of Reinforcement Learning Algorithms” | arXiv API record `1912.05663v2`, DOI `10.48550/arXiv.1912.05663`, and OpenAlex DOI record checked; listed as L15. | Directly relevant: proposes reliability metrics for variability and risk, statistical comparison tools, and reporting recommendations. | The available abstract does not establish the present conditional post-validation estimand, finite-look alpha spending, sealed test protocol, or reliability--cost resolution boundary; full-text comparison remains `[待核实]`. | Include as direct related work and novelty boundary (L15). The manuscript must not claim to introduce RL reliability measurement generally. |
| Khamaru et al. (2022), “Instance-Dependent Confidence and Early Stopping for Reinforcement Learning” | arXiv API record `2201.08536`, DOI `10.48550/arXiv.2201.08536`, and OpenAlex record checked; listed as L16. | Directly relevant to confidence regions and data-dependent early stopping for policy/value evaluation. | The abstract concerns theoretical MDP evaluation and does not establish overlap with the empirical training-seed, validation-selection, sealed-test, family-wise benchmark protocol; full-text comparison remains `[待核实]`. | Include as adjacent theory and explicitly distinguish the estimand and evidence type (L16). |

## Screening limits

- The current table is a transparent scoping record, not a systematic review
  suitable for a literature-wide novelty claim.
- Web of Science, Scopus, IEEE Xplore, ACM Digital Library, and Google Scholar
  exports, deduplication across databases, and second-reviewer screening are
  still absent. The OpenAlex export is retained as one discovery database, not
  as a substitute for those checks.
- The failed full-text retrieval for the CCVW record means that only its
  authoritative metadata and OpenAlex abstract were used for the exclusion
  decision; any stronger content claim remains `[待核实]`.
- Until these gaps are closed, the manuscript must retain the bounded wording
  that the exact protocol's novelty is `[待核实]`.

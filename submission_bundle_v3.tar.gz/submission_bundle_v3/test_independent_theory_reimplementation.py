import unittest

from independent_theory_reimplementation import run_check


class IndependentTheoryReimplementationTests(unittest.TestCase):
    def test_independent_reimplementation_matches_reference(self):
        payload = run_check()
        self.assertEqual(payload["status"], "PASS")
        self.assertTrue(all(payload["checks"].values()))


if __name__ == "__main__":
    unittest.main()

# v3 Validation Tuning Cost Table

This table reports the recorded validation-stage tuning cost for the
four-candidate grid. Every algorithm--environment cell used four
candidate configurations and five validation seeds, giving 100
successful validation rows per algorithm and 300 rows overall.

The runtime is wall-clock time on the recorded Apple Silicon CPU
environment. It documents the executed tuning budget; it is not a
cross-hardware benchmark, a claim of equal computational difficulty,
or evidence that one algorithm is generally more efficient.

- Source: `sb3_formal_v3/raw_seed_metrics.csv`
- Successful validation rows: `300`
- Total recorded validation runtime: `0.058` hours

## Algorithm-level summaries

| Algorithm | Candidate-seed runs | Total hours | Mean seconds | Sample SD | Median seconds | Min | Max |
|---|---:|---:|---:|---:|---:|---:|---:|
| A2C | 100 | 0.018 | 0.650 | 0.226 | 0.577 | 0.420 | 1.211 |
| DQN | 100 | 0.021 | 0.768 | 0.196 | 0.705 | 0.532 | 1.184 |
| PPO | 100 | 0.019 | 0.668 | 0.215 | 0.602 | 0.448 | 1.194 |

## Accounting rule

The validation cost is 5 environments × 3 algorithms × 4 candidate
configurations × 5 seeds = 300 training-seed runs. The same number of
candidate-seed rows is allocated to each algorithm. The selected test
runs and post-v3 extensions are excluded and reported separately.

import math
import unittest

from pilot_protocol import (
    ProtocolConfig,
    alpha_spend,
    bootstrap_interval,
    empirical_bernstein_interval,
    empirical_bernstein_unpaired_interval,
    hoeffding_interval,
    hoeffding_unpaired_interval,
    mean_difference_interval,
    sequential_decision,
)
from unpaired_budget_requirements import (
    seeds_for_possible_superiority,
    seeds_for_superiority,
    seeds_for_width,
    total_seeds_for_possible_superiority,
    total_seeds_for_width,
)
from simulation_uncertainty import wilson
from sequential_sb3_runner import lock_resolved_decisions


class PilotProtocolTests(unittest.TestCase):
    def test_alpha_spending_is_bounded_by_alpha(self):
        total = sum(alpha_spend(0.05, look) for look in range(1, 10000))
        self.assertLessEqual(total, 0.05)

    def test_interval_contains_identical_difference(self):
        estimate, lower, upper = mean_difference_interval([0.5] * 5, [0.5] * 5, 0.05)
        self.assertEqual(estimate, 0.0)
        self.assertEqual(lower, upper)
        self.assertEqual(lower, 0.0)

    def test_clear_difference_stops_as_superiority(self):
        config = ProtocolConfig(practical_margin=0.05, target_width=0.01)
        result = sequential_decision([0.9] * 20, [0.1] * 20, config)
        self.assertEqual(result["decision"], "a_superior")
        self.assertEqual(result["n"], config.initial_seeds)

    def test_empirical_bernstein_interval_is_bounded(self):
        estimate, lower, upper = empirical_bernstein_interval(
            [0.8, 0.9, 0.7, 0.85, 0.75],
            [0.2, 0.1, 0.3, 0.15, 0.25],
            0.05,
        )
        self.assertGreaterEqual(lower, -1.0)
        self.assertLessEqual(upper, 1.0)

    def test_empirical_bernstein_unpaired_interval_is_bounded(self):
        estimate, lower, upper = empirical_bernstein_unpaired_interval(
            [0.1, 0.2, 0.3, 0.4], [0.2, 0.3, 0.4, 0.5], 0.05
        )
        self.assertAlmostEqual(estimate, -0.1)
        self.assertGreaterEqual(lower, -1.0)
        self.assertLessEqual(upper, 1.0)
        self.assertLessEqual(lower, estimate)
        self.assertLessEqual(estimate, upper)

    def test_bootstrap_interval_is_deterministic(self):
        args = ([0.8, 0.9, 0.7, 0.85, 0.75], [0.2, 0.1, 0.3, 0.15, 0.25], 0.05, 200, 42)
        self.assertEqual(bootstrap_interval(*args), bootstrap_interval(*args))

    def test_hoeffding_interval_is_bounded(self):
        estimate, lower, upper = hoeffding_interval([1.0, 0.8], [0.0, 0.2], 0.05)
        self.assertEqual(estimate, 0.8)
        self.assertGreaterEqual(lower, -1.0)
        self.assertLessEqual(upper, 1.0)

    def test_unpaired_hoeffding_allows_different_sample_sizes(self):
        estimate, lower, upper = hoeffding_unpaired_interval(
            [0.8, 0.9, 0.7, 0.85, 0.75], [0.2, 0.1, 0.3], 0.05
        )
        self.assertAlmostEqual(estimate, 0.6)
        self.assertLessEqual(lower, estimate)
        self.assertGreaterEqual(upper, estimate)
        self.assertGreaterEqual(lower, -1.0)
        self.assertLessEqual(upper, 1.0)

    def test_unpaired_hoeffding_rejects_out_of_range_metric(self):
        with self.assertRaises(ValueError):
            hoeffding_unpaired_interval([1.1], [0.2], 0.05)

    def test_unpaired_sequential_decision_does_not_depend_on_order(self):
        config = ProtocolConfig(
            interval_method="hoeffding_unpaired",
            initial_seeds=2,
            batch_size=1,
            max_seeds=4,
        )
        first = sequential_decision([0.9, 0.8, 0.7, 0.6], [0.2, 0.3, 0.4, 0.5], config)
        second = sequential_decision([0.6, 0.7, 0.8, 0.9], [0.5, 0.4, 0.3, 0.2], config)
        self.assertAlmostEqual(first["estimate"], second["estimate"])
        self.assertEqual(first["n"], second["n"])
        self.assertEqual(first["decision"], second["decision"])

    def test_budget_planning_is_monotone_in_target_width(self):
        narrow = seeds_for_width(0.05, 1, 0.05)
        wide = seeds_for_width(0.05, 1, 0.10)
        self.assertGreater(narrow, wide)

    def test_family_alpha_width_planning_matches_manuscript(self):
        self.assertEqual(seeds_for_width(0.05, 1, 0.10), 3904)
        self.assertEqual(seeds_for_width(0.05 / 15.0, 1, 0.10), 6071)
        self.assertEqual(seeds_for_width(0.05 / 15.0, 4, 0.10), 8289)

    def test_formal_v3_budget_is_structurally_non_resolving(self):
        config = ProtocolConfig(
            alpha=0.05 / 15.0,
            practical_margin=0.05,
            target_width=0.10,
            initial_seeds=5,
            batch_size=5,
            max_seeds=20,
            interval_method="hoeffding_unpaired",
        )
        result_a = sequential_decision([1.0] * 20, [0.0] * 20, config)
        result_b = sequential_decision([0.0] * 20, [1.0] * 20, config)
        self.assertEqual(result_a["decision"], "max_budget_inconclusive")
        self.assertEqual(result_b["decision"], "max_budget_inconclusive")

        final_alpha = alpha_spend(config.alpha, 4)
        radius_sum = 2.0 * math.sqrt(math.log(4.0 / final_alpha) / (2.0 * 20.0))
        self.assertAlmostEqual(radius_sum, 1.0178588242230167, places=12)
        self.assertLessEqual(1.0 - radius_sum, config.practical_margin)
        self.assertGreaterEqual(min(2.0, radius_sum), config.target_width)

    def test_superiority_budget_is_undefined_inside_margin(self):
        self.assertIsNone(seeds_for_superiority(0.05, 1, 0.05, 0.05))

    def test_possible_superiority_threshold_matches_v3_boundary(self):
        alpha = 0.05 / 15.0
        self.assertEqual(seeds_for_possible_superiority(alpha, 1, 0.05), 17)
        self.assertEqual(seeds_for_possible_superiority(alpha, 2, 0.05), 20)
        self.assertEqual(seeds_for_possible_superiority(alpha, 3, 0.05), 22)
        self.assertEqual(seeds_for_possible_superiority(alpha, 4, 0.05), 23)

    def test_balanced_total_budget_thresholds_match_two_arm_values(self):
        alpha = 0.05 / 15.0
        self.assertEqual(total_seeds_for_width(alpha, 1, 0.10), 12141)
        self.assertEqual(total_seeds_for_width(alpha, 4, 0.10), 16577)
        self.assertEqual(total_seeds_for_possible_superiority(alpha, 1, 0.05), 34)
        self.assertEqual(total_seeds_for_possible_superiority(alpha, 4, 0.05), 46)

    def test_wilson_interval_handles_zero_and_one(self):
        zero = wilson(0, 100)
        one = wilson(100, 100)
        self.assertEqual(zero["estimate"], 0.0)
        self.assertGreater(zero["upper"], 0.0)
        self.assertEqual(one["estimate"], 1.0)
        self.assertLess(one["lower"], 1.0)

    def test_sequential_runner_locks_terminal_pair_decisions(self):
        locked = {}
        first = lock_resolved_decisions(
            {
                "PPO_vs_DQN": {"decision": "a_superior", "n": 5},
                "PPO_vs_A2C": {"decision": "max_budget_inconclusive", "n": 5},
            },
            locked,
            5,
        )
        second = lock_resolved_decisions(
            {
                "PPO_vs_DQN": {"decision": "b_superior", "n": 10},
                "PPO_vs_A2C": {"decision": "a_superior", "n": 10},
            },
            locked,
            10,
        )
        self.assertEqual(second["PPO_vs_DQN"]["decision"], "a_superior")
        self.assertEqual(second["PPO_vs_DQN"]["locked_at"], 5)
        self.assertEqual(second["PPO_vs_A2C"]["decision"], "a_superior")
        self.assertEqual(second["PPO_vs_A2C"]["locked_at"], 10)


if __name__ == "__main__":
    unittest.main()

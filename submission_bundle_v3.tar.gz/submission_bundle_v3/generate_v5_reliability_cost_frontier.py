#!/usr/bin/env python3
"""Generate the audited v5 resolution-cost frontier from stored rows."""

from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

from pilot_protocol import ProtocolConfig, alpha_spend, sequential_decision

# Keep the frozen v3 order without importing the Gymnasium runner so this
# analytic artifact can run under the document-generation interpreter.
ALGORITHMS = ("PPO", "DQN", "A2C")


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "sb3_v5_extension/raw_seed_metrics.csv"
OUTPUT_JSON = ROOT / "V5_RELIABILITY_COST_FRONTIER.json"
OUTPUT_MD = ROOT / "V5_RELIABILITY_COST_FRONTIER.md"


def build() -> dict[str, object]:
    with INPUT.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    rows = [row for row in rows if row["split"] == "extension_test" and row["status"] == "ok"]
    cells = sorted({(row["env_id"], row["algorithm"]) for row in rows})
    if len(rows) != 15_000 or len(cells) != 15:
        raise ValueError(f"expected 15000 rows and 15 cells, found {len(rows)} and {len(cells)}")
    grouped: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[(row["env_id"], row["algorithm"])].append(row)
    for key, cell in grouped.items():
        cell.sort(key=lambda row: int(row["seed"]))
        if [int(row["seed"]) for row in cell] != list(range(1000)):
            raise ValueError(f"cell {key} does not contain ordered seeds 0..999")

    family_alpha = 0.05
    comparison_alpha = family_alpha / 15.0
    margin = 0.05
    target_width = 0.10
    look_sizes = (200, 400, 600, 800, 1000)
    cfg = ProtocolConfig(
        alpha=comparison_alpha,
        practical_margin=margin,
        target_width=target_width,
        initial_seeds=200,
        batch_size=200,
        max_seeds=1000,
        interval_method="hoeffding_unpaired",
    )
    values = {
        key: [float(row["metric_normalized"]) for row in cell]
        for key, cell in grouped.items()
    }
    decisions = {}
    for env_id in sorted({key[0] for key in cells}):
        algorithms = [algorithm for algorithm in ALGORITHMS if (env_id, algorithm) in cells]
        for algorithm_a, algorithm_b in combinations(algorithms, 2):
            key = f"{env_id}:{algorithm_a}_vs_{algorithm_b}"
            decisions[key] = sequential_decision(
                values[(env_id, algorithm_a)], values[(env_id, algorithm_b)], cfg
            )

    looks = []
    for look_index, n in enumerate(look_sizes, start=1):
        alpha = alpha_spend(comparison_alpha, look_index)
        radius = 2.0 * math.sqrt(math.log(4.0 / alpha) / (2.0 * n))
        runtime_seconds = sum(
            float(row["runtime_seconds"])
            for cell in grouped.values()
            for row in cell[:n]
        )
        resolved_by = sum(result["decision"] != "max_budget_inconclusive" and result["n"] <= n for result in decisions.values())
        newly_resolved = sum(result["decision"] != "max_budget_inconclusive" and result["n"] == n for result in decisions.values())
        looks.append(
            {
                "look": look_index,
                "seeds_per_algorithm": n,
                "comparison_alpha": alpha,
                "radius_sum": radius,
                "minimum_clipped_width": min(2.0, radius),
                "family_rows": len(cells) * n,
                "cumulative_runtime_seconds": runtime_seconds,
                "cumulative_runtime_hours": runtime_seconds / 3600.0,
                "newly_resolved_comparisons": newly_resolved,
                "resolved_comparisons": resolved_by,
                "unresolved_comparisons": len(decisions) - resolved_by,
            }
        )
    decision_counts = Counter(result["decision"] for result in decisions.values())
    return {
        "status": "audited_v5_reliability_cost_frontier",
        "warning": "Radius values are analytic. Runtime is same-machine Apple Silicon accounting. Complete v5 rows were collected, so cumulative runtime is not an observed stopping saving.",
        "source": str(INPUT.name),
        "family_alpha": family_alpha,
        "comparison_count": len(decisions),
        "comparison_alpha": comparison_alpha,
        "practical_margin": margin,
        "target_width": target_width,
        "decision_counts": dict(sorted(decision_counts.items())),
        "looks": looks,
        "decisions": decisions,
    }


def render(payload: dict[str, object]) -> str:
    lines = [
        "# v5 Reliability--Cost Frontier",
        "",
        "This table combines the analytic unpaired-Hoeffding radius with the",
        "cumulative runtime of the complete stored v5 sequence. The radius is a",
        "distribution-free design quantity; runtime is machine-specific. Because",
        "all 1,000 rows per cell were collected, cumulative runtime is not an",
        "observed compute saving from early stopping.",
        "",
        f"- Source rows: `{payload['source']}`",
        f"- Family: `{payload['comparison_count']}` comparisons; family alpha `{payload['family_alpha']}`",
        f"- Decision counts: `{json.dumps(payload['decision_counts'], sort_keys=True)}`",
        "",
        "| Look | Seeds/algorithm | Radius sum | Min clipped width | Family rows | Runtime (hours) | New decisions | Resolved | Unresolved |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in payload["looks"]:
        lines.append(
            f"| {row['look']} | {row['seeds_per_algorithm']} | {row['radius_sum']:.6f} | "
            f"{row['minimum_clipped_width']:.6f} | {row['family_rows']} | "
            f"{row['cumulative_runtime_hours']:.6f} | {row['newly_resolved_comparisons']} | "
            f"{row['resolved_comparisons']} | {row['unresolved_comparisons']} |"
        )
    lines.extend([
        "",
        "The four terminal decisions are the observed v5 outcomes for the frozen",
        "task family and new seed sequence. This artifact is descriptive: it is",
        "not a prospective power curve, universal seed rule, algorithm ranking,",
        "or external reproducibility result.",
    ])
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    payload = build()
    OUTPUT_JSON.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    OUTPUT_MD.write_text(render(payload), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "looks": len(payload["looks"])}, indent=2))

# External Sealed-Rerun Protocol

This document is an operator-facing handoff for a different machine or
independent team. It is not evidence that the rerun has occurred. The primary
v3 results must remain unchanged if an external rerun is added.

## Scope

Run the five v3 tasks (`CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`,
`Taxi-v4`, and `NonstationaryQueue-v0`) with PPO, DQN, and A2C from
Stable-Baselines3 2.9.2. Use the four v3 candidate configurations, five
validation seeds per candidate, and the selected configuration for sealed test
seeds 20,000--20,019. The primary training budget is 4,096 steps with
checkpoints 1,024, 2,048, 3,072, and 4,096; use five evaluation episodes per
checkpoint.

The primary decision family has 15 comparisons, family alpha 0.05, comparison
alpha `0.05/15`, looks at 5, 10, 15, and 20 test seeds, practical margin 0.05,
target width 0.10, and the unpaired Hoeffding interval with the recorded
finite-look spending schedule.

## Required software record

Record the operating system, CPU architecture, Python version, NumPy,
PyTorch, Gymnasium, Stable-Baselines3, and `mps_available`/CUDA status. Use
the exact versions in `requirements-rl-lock.txt` and the source/wheel hashes in
`REPRODUCTION_MANIFEST_V3.md`; report any
version or platform deviation before interpreting metric differences.

## Execution

Install the pinned dependencies, then run:

```bash
python3 sequential_sb3_runner_v3.py \
  --environment-ids CartPole-v1,Acrobot-v1,MountainCar-v0,Taxi-v4,NonstationaryQueue-v0 \
  --validation-seeds 5 --test-seeds 20 --initial-test-seeds 5 \
  --test-batch-size 5 --timesteps 4096 --checkpoints 4 \
  --eval-episodes 5 --family-alpha 0.05 \
  --practical-margin 0.05 --target-width 0.10 \
  --output-dir sb3_formal_v3_external_rerun
```

Replace `python3` with the interpreter from the pinned external environment
when that environment is activated; the command does not require the local
`.rl-arm64-venv/` path.

Do not open or use the stored v3 test metrics to alter configuration selection
or stop rules. The external run must retain validation candidates, selected
configurations, raw seed-level test metrics, stop traces, failures, and runtime
metadata.

## Acceptance checks

Run the local schema audit after copying the external output into a separate
directory. Compare, without overwriting v3:

- 600 rows: 300 validation and 300 selected-configuration test rows;
- 20 test seeds for every task--algorithm cell;
- 15 final decisions and all four look traces;
- normalized metrics in `[0,1]` and raw returns retained;
- selected configuration IDs, means, standard deviations, and decision states;
- exact deviations, failed runs, and missing seeds.

Report absolute and relative differences in seed-level metrics, not only a
matching rounded mean. A different machine is not expected to reproduce every
floating-point value exactly; the external report must define its comparison
tolerance before inspecting the result.

The archived schema and comparison validator can be run without importing
Gymnasium or Stable-Baselines3 after the external run finishes:

```bash
python3 validate_external_rerun.py \
  --external-dir sb3_formal_v3_external_rerun \
  --reference-dir sb3_formal_v3 \
  --output sb3_formal_v3_external_rerun/validation_report.json
```

The validator reports schema errors, selected-configuration matches, per-cell
seed-level metric differences, and recomputed decision-state differences. A
pass on the local v3 directory is only a self-test of the validator; it is not
an external reproducibility result.

## Reporting template

```text
Operator/team:
Machine and OS:
Python and package versions:
Source-manifest hash:
Completed rows:
Failed rows:
Missing seeds:
Configuration deviations:
Mean absolute metric difference by cell:
Maximum absolute metric difference:
Decision-state differences:
Stop-trace differences:
Unresolved deviations:
```

An external rerun upgrades the evidence label only after raw outputs, metadata,
deviations, and the comparison report are archived. Until then, the v3 package
supports same-machine cross-script repeatability only.

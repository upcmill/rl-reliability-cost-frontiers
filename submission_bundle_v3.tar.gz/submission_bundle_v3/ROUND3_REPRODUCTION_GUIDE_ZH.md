# 第三轮新增诊断与修订产物复核说明

本轮仅增加事后诊断与写作修订，没有训练新的 RL 模型或修改原预注册。主文当前为中文正式稿；英文主稿尚未同步第三轮修订。

## 查看文件

- 正式稿：MANUSCRIPT_FORMAL_ZH.docx / .md。
- 补充材料：SUPPLEMENTARY_FORMAL_ZH.docx / .md，章节 S1–S21。
- 2026-11-03 全文比较更新：KEY_LITERATURE_FULLTEXT_COMPARISON_ZH.md；12 篇原文的来源和 SHA-256 见 literature_fulltext/2026-11-03/SOURCES.json。
- 新分析计划：round3_analysis/ANALYSIS_PLAN.md。
- 原有结果和计划：沿用补充材料索引及 REPRODUCTION_MANIFEST_V3.md，不重新定义。

## 本机执行

已记录的 RL 解释器执行统计分析和 unittest；文档解释器需要 python-docx，图形解释器需要 Matplotlib。它们是不同的环境，不将文档依赖误写为 RL 运行版本。

同目标序贯方法事后重分析使用单独的 Python 3.11 环境和锁定依赖，命令、参数、输入哈希及模拟材料见 `sequential_comparison_v1/ANALYSIS_PLAN.md` 与 `RUN_MANIFEST.json`。该对照未启动新的强化学习训练。

2026-11-03 对完整重分析再次在独立输出目录运行：四个 CSV/JSON 汇总文件逐字节一致，八个模拟归档的全部数组逐值一致。核对报告为 `sequential_comparison_v1/RECOMPUTATION_AUDIT.json`；这属于同团队同机可重复性，不能称为不同团队可复现性。

```bash
./.rl-arm64-venv/bin/python -m unittest -v
python3 budget_calculator.py --looks 5 10 15 20 --comparisons 15 --margin 0.05 --width 0.10
python3 generate_formal_chinese_manuscript.py
python3 audit_formal_round3.py
make -f Makefile.review check
```

另一机器安装依赖后可覆盖解释器，例如 `make -f Makefile.review RL_PYTHON=python DOC_PYTHON=python check`。Windows 无 make 时按上面顺序分别运行 Python 命令即可。原 RL 精确版本见 requirements-rl-lock.txt，平台和 Python 版本见原清单；不能保证这些旧版本在任意新平台都可直接安装。

## 重算新增诊断

新结果必须输出到新目录，脚本会拒绝覆盖既有分析文件：

```bash
python round3_diagnostics.py --replicates 10000 --permutations 9999 --seed 20261103 --output round3_rerun
python inventory_round3_environments.py --output round3_rerun/environment_features.json
```

`round3_diagnostics.py` 需要 NumPy。随机数实现记录为 NumPy 2.2.6、PCG64、固定批大小 500；精确计数比较应保持该版本与实现。输出包含计数、Wilson 区间、原始与 Holm 校正 p 值、参数、运行版本、输入及脚本哈希。输出目录的存在本身不会阻止运行，但同名结果存在会阻止覆盖。

图生成读取 round3_analysis 中已审计的结果，不自动换用重跑目录：

```bash
MPLCONFIGDIR=/tmp/rl-paper-mpl ./.rl-venv/bin/python generate_round3_figures.py
```

在其他平台使用已有 Matplotlib 的 Python 运行相同脚本，缓存变量根据本机情况设置即可。图形像素或 Word 压缩包元数据可能因字体/环境不同而改变；首先比较分析 JSON 数值与正文表格，而不是要求所有 DOCX 二进制字节相等。

## 材料包范围

`第三轮修订材料包.zip` 是本地审阅和分析复核包：含主稿、补充材料、所列证据文件、新诊断源码/输出、测试及必要的本地模块。包内 MANIFEST.csv 记录相对路径、字节数和 SHA-256。包内旧 MANUSCRIPT_MACHINE_LEARNING_EN/ZH.docx 及旧稿 Markdown 仅为既有回归测试所需的历史文件，不是第三轮稿件；当前稿件以 MANUSCRIPT_FORMAL_ZH 为准。它不包含多 GB 的 wheel 归档，不替代原始模型级跨平台复跑包；若要完整重训 RL，请继续使用原“复跑资料”和原清单。

没有发布或验证 Docker 镜像、Conda 求解环境、GitHub Pages、CI 云端执行或 Zenodo DOI。没有因为添加本地检查命令就声称公开仓库已通过 CI。许可证及作者声明仍需作者确认。此轮没有网络发布行为。

全文比较的原始 PDF 与提取文本保存在项目的 literature_fulltext/2026-11-03 目录，不随修订材料包自动再分发。包内包含核读位置、比较报告及原文哈希。审计会核对当前目录中存在的原文；在不带原文的材料包中，原文哈希检查数量为 0，不能解释成重新下载并独立验证了来源。

## 审阅时应保留的证据边界

- Bernoulli 校准是事后模型检查，不是实际 RL 分布功效或完整 15 项族模拟覆盖。
- 顺序诊断未拒绝不证明种子独立；不可计算项目公开保留。
- 预算计算器给出必要可行性条件和未截断宽度规划，不给普遍样本数或自动节约时间承诺。
- 11 篇关键文献的方法级重叠已核查；全部文献范围内的新颖性、现代置信序列的公平成本对照、作者声明及公共仓库可访问性仍未完成核验，不能由材料包完整性推断可发表性。

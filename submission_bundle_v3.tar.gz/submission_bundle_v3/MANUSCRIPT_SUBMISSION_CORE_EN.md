# Reliability--Cost Frontiers for Sequential Evaluation of Reinforcement Learning Algorithms

**Concise submission main-text version.** The full audited v3 manuscript and supplementary diagnostics remain in `MANUSCRIPT_DRAFT_V3.md` and the submission archive.

## Abstract

Reinforcement-learning (RL) benchmark comparisons are affected by training-seed variation, environment randomness, configuration selection, and repeated interim inspection. We study the reliability--cost boundary of a sequential evaluation protocol rather than proposing a policy-learning algorithm. The protocol selects configurations on validation seeds, freezes them before sealed testing, defines a bounded normalized learning-curve metric, and uses a finite-look unpaired Hoeffding interval with predeclared family-wise error spending. A selection-invariance proposition covers validation-only selection, and a locked-stopping lemma covers pairwise decisions at different predeclared looks. We evaluate PPO, DQN, and A2C on five disclosed discrete-action tasks; each of 15 algorithm-pair comparisons uses four candidate configurations, five validation seeds per candidate, and 20 sealed test seeds. All comparisons reach the maximum budget without a superiority or 0.10-width precision decision. A pre-study feasibility audit and analytic corollary show that this non-resolution is forced by the bounded interval and the formal budget for any data in the metric range, so it is not evidence of algorithmic equivalence. A separately implemented replay matches the stored summaries on the same machine, and a sealed Windows AMD64 rerun matches all 15 selected configurations and terminal decisions; 14 of 15 cells have zero seed-level differences and one cell shows a small reported platform difference. These results support repeatability and different-machine reproducibility of the disclosed protocol, but not scientific replication on a new task family or verified independent-team identity. A controlled dependence stress test shows that correlated seed observations can invalidate the nominal interval; a known-block fallback is valid only under its explicit independent-block assumptions. The study therefore provides a conditional protocol characterization for the disclosed tasks and budget. It does not establish universal seed requirements, algorithm rankings, compute savings, or scientific replication beyond the frozen task family.

## 1. Introduction


An RL result is a random quantity over training seeds, environment randomness,
implementation details, and evaluation episodes. Consequently, a small point
estimate difference between two algorithms need not be stable under a new
seed. Prior work has documented reproducibility and reporting problems in deep
RL [L1], shown that deep-RL agents can overfit and separate training from test
performance [L13], and identified implementation nondeterminism as a source of
performance variance [L14]. Chan et al. have also proposed reliability metrics
and statistical comparison tools for RL [L15]. Khamaru et al. study
instance-dependent confidence regions and data-dependent early stopping for
policy/value evaluation [L16]. Other work has studied seed
counts and statistical power [L2, L3] and advocated uncertainty-aware
aggregate reporting [L4]. These sources motivate careful evaluation, but they
do not establish a universal number of seeds or validate the protocol studied
here.

Sequential evaluation creates a concrete reliability--cost question. If a
comparison is inspected after several batches of test seeds, an interval must
remain valid at every predeclared look. Methods using normal or bootstrap
approximations may be narrower under favorable distributions, while bounded
distribution-free intervals can be too wide to decide a practically relevant
difference at a realistic budget. Configuration tuning introduces a second
source of optimism unless it is completed before sealed test data are opened.

This paper studies that boundary with an auditable nested protocol. Each
algorithm--task cell has an equal four-candidate validation grid. A selected
configuration is frozen before sealed testing. The primary comparison is an
unpaired difference of marginal expected normalized learning-curve metrics,
with a bounded interval and finite-look alpha spending. We record the actual
batch-by-batch execution, retain all validation candidates and test-level
metrics, and report repeatability separately from reproducibility.

The contribution is an empirical and methodological characterization of this
protocol at the stated task and budget. A transparent scoping review is
provided in `SYSTEMATIC_NOVELTY_REVIEW.md`, with candidate inclusion and
exclusion decisions in `LITERATURE_SCREENING_TABLE.md`; a literature-wide
novelty claim still remains `[待核实]` until database exports and independent
screening are complete. The study makes
the following evidence-bounded claims:

1. Under explicit bounded-seed and finite-look assumptions, the stated
   interval construction has a conditional family-wise coverage guarantee.
2. Under the formal v3 alpha allocation, the 20-seed budget is analytically
   unable to trigger either superiority or 0.10-width precision for any
   bounded data; all 15 observed comparisons are consistent with this
   design-implied non-resolution region.
3. A separately implemented same-machine runner reproduces the stored v3
   summaries exactly to the recorded metric precision.

4. A sealed Windows AMD64 rerun matches all 15 selected configurations and
   terminal decisions; 14 of 15 cells have zero seed-level differences and one
   cell has a reported platform difference. This supports different-machine
   reproducibility of the frozen protocol, not independent-team identity or
   scientific replication on a new task family.

5. A prospective new-seed extension shows that one controlled queue comparison
   can cross the predeclared practical margin at 200 seeds while the remaining
   14 cells do not resolve by 400 seeds; this is reported as a scoped budget
   observation rather than a universal requirement.

6. A finite-look minimax alpha-spending lemma characterizes the early-versus-
   late resolution tradeoff of the bounded interval without changing the
   preregistered v3 decision rule.

7. A family-size sensitivity calculation makes the multiplicity--resolution
   tradeoff explicit for future preregistered evaluation families; it is
   reported as an analytic planning diagnostic rather than an RL power result.
8. A pre-study feasibility audit converts the bounded-radius formulas into an
   executable check that flags an impossible budget before sealed test data are
   collected; its output is a design diagnostic, not an empirical power claim.
9. A locked-stopping lemma connects the simultaneous finite-look guarantee to
   the executable state machine: deleting rows after a terminal decision does
   not weaken coverage because the selected look is contained in the event on
   which every predeclared interval is valid.

### 1.1 Research questions and evidence-typed hypotheses

The study separates four questions that are often collapsed into a single
claim about algorithm performance. Each question has a different evidence
standard, so an observed result is not allowed to substitute for a theorem or
an external replication.

| Question | Hypothesis or expectation | Evidence type and decision rule |
|---|---|---|
| RQ1. Does the finite-look interval control error for the conditional estimand? | H1: Under bounded metrics, fixed looks, validation conditioning, and within-algorithm seed independence, the interval has the stated conditional family-wise coverage. | Formal proposition and proof; RL data are not used to validate the theorem. |
| RQ2. Can the formal v3 budget resolve a practically meaningful difference? | H2: No bounded data can trigger the 0.05 superiority margin or 0.10 precision rule by 20 seeds under the v3 allocation. | Analytic corollary checked by deterministic code; the 15 observed inconclusive cells are a consistency check. |
| RQ3. Is resolution cost heterogeneous across frozen task--algorithm pairs? | H3: Increasing the disclosed new-seed budget can resolve some frozen comparisons while leaving others unresolved; the pattern is task-specific rather than a universal seed rule. | v4 and v5 new-seed diagnostics, reported as observed stopping costs without prospective-power or population claims. |
| RQ4. Does a second implementation reproduce the stored summaries? | H4: A separately implemented script on the same machine reproduces the stored summaries; the sealed Windows rerun tests different-machine reproducibility without implying scientific replication. | Same-machine row-level replay plus `复跑结果/EXTERNAL_RERUN_AUDIT.json`; independent-team identity and new-family replication remain open. |

These hypotheses define the scope of the evidence rather than presupposing a
positive algorithm ranking. In particular, H2 predicts a negative resolution
result by construction, while H3 and H4 are descriptive checks whose validity
depends on the frozen artifacts and the stated reproducibility boundary.

It does not claim that any algorithm is generally superior, that 20 seeds are
universally sufficient or necessary, or that the study has been reproduced by
an independent team.

## 2. Related Work


Henderson et al. report that deep-RL results can be sensitive to random seeds,
environment nondeterminism, and reporting choices [L1]. Zhang et al. show that
deep-RL agents can overfit and exhibit train/test performance gaps [L13], while
Nagarajan et al. isolate implementation nondeterminism as a reproducibility
source [L14]. Chan et al. propose reliability metrics and statistical tools for
variability and risk [L15]. Khamaru et al. provide adjacent theory on
instance-dependent confidence and early stopping [L16]. Colas et al. analyze
seed counts, statistical power,
and assumptions behind comparisons [L2, L3]. Agarwal et al. emphasize
uncertainty-aware reporting for few-run deep-RL evaluations [L4]. Whiteson et
al. identify evaluation overfitting as a distinct empirical RL concern [L11],
which motivates the separation between validation selection and sealed testing
here. We use Hoeffding's
bounded-variable inequality as the concentration result [L5] and use a
summable finite-look spending schedule,
with sequential error spending as general statistical background [L6].

The verified bibliography is intentionally short. Candidate screening is
reported separately so that an adjacent algorithm-comparison paper is not
mistaken for evidence about this protocol. The publication venue of
the Agarwal et al. record and the novelty of this exact protocol require a
systematic literature review before submission `[待核实]`. In particular,
Chan et al. already establish prior work on RL reliability metrics, so the
present contribution is limited to the narrower finite-look, conditional,
sealed-test reliability--cost characterization; see
`LITERATURE_VERIFICATION.md`.

Table 1 makes the contribution boundary explicit. Entries describing an
absence are limited to the verified abstract or metadata record; a full-text
method comparison remains `[待核实]` where indicated.

| Work | Primary object | Reliability or statistical contribution | Validation/test separation | Finite-look family control | Resolution-cost frontier |
|---|---|---|---|---|---|
| Henderson et al. [L1] | Deep-RL experimental practice | Reproducibility, nondeterminism, and reporting concerns | Not established in the verified record | Not established in the verified record | Not established in the verified record |
| Colas et al. [L2, L3] | Seed counts and algorithm comparisons | Power, error, effect size, and test-assumption diagnostics | Not the present conditional selected-configuration estimand | Not established in the verified record | Not the present stopping-cost analysis |
| Zhang et al. [L13] and Whiteson et al. [L11] | Overfitting and evaluation protection | Train/test generalization and evaluation-overfitting motivation | Related separation principle; method-level overlap `[待核实]` | `[待核实]` | `[待核实]` |
| Nagarajan et al. [L14] | Implementation nondeterminism | Deterministic training and reproducibility analysis | Not the present validation/test protocol | Not established in the verified record | Not established in the verified record |
| Chan et al. [L15] | RL reliability measurement | Variability/risk metrics and statistical comparison tools | Not established in the verified abstract | Not established in the verified abstract | Not established in the verified abstract |
| Khamaru et al. [L16] | Theoretical policy/value evaluation | Instance-dependent confidence regions and data-dependent early stopping | Not the present training-seed selection/test estimand | Not the present benchmark family control | Theoretical stopping rule, not the present empirical resolution-cost frontier |
| This work | Conditional selected-procedure comparison | Bounded unpaired interval with predeclared finite looks | Validation-only selection followed by sealed test seeds | Family-wise alpha allocation across fixed looks and comparisons | Observed stopping/resolution cost under frozen tasks and budgets |

### 2.1 Evaluation failure modes addressed by this study

The protocol separates four failure modes that are often conflated in RL
benchmark reports. **Seed uncertainty** makes a single training run an
unreliable proxy for the distribution of outcomes. **Selection optimism**
occurs when the same observations are used to choose a configuration and to
make the final comparison. **Optional stopping** can make a favorable result
appear more likely when new seeds are inspected without a predeclared error
budget. **Family expansion** occurs when additional tasks or algorithm pairs
are added after early results are seen. Sealed test seeds address selection
optimism, fixed looks address optional stopping, and the explicit 15-cell
family addresses family expansion. The design does not remove training
nondeterminism or guarantee that the candidate grid contains a good
configuration.

### 2.2 Positioning and scope of the contribution

This work is a protocol characterization rather than an algorithm proposal.
The concentration inequality and alpha-spending construction are established
statistical tools; this manuscript does not claim to have invented either one.
The contribution is the explicit combination of a conditional post-validation
estimand, a sealed-test workflow, finite-look family allocation, and an
auditable RL execution that records when a conservative bound fails to resolve
a practical question. The exact novelty relative to all prior RL evaluation
studies remains `[待核实]`. This conservative positioning allows the negative
result to be evaluated on its estimand, protocol, and evidence rather than on
an unsupported claim of a new optimizer.

## 3. Estimand and Statistical Protocol


For task `$e$`, algorithm `$a$`, configuration `$c(e,a)$` selected using only
validation data, and training budget `$T$`, define

\[
 Z_{e,a,s}=\frac{1}{4}\sum_{t\in\{1024,2048,3072,4096\}}
 \operatorname{NormReturn}_{e,a,s,t}\in[0,1].
\]

The primary estimand for an unordered pair `$a,b$` is the conditional marginal
difference

\[
 \Delta_{e,a,b}=\mathbb{E}[Z_{e,a,S}\mid D_{\mathrm{val}}]
 -\mathbb{E}[Z_{e,b,S'}\mid D_{\mathrm{val}}],
\]

where `$S$` and `$S'$` are separate training-seed draws and
`$D_{\mathrm{val}}$` contains all validation observations used to select the
configurations. Equal integer seed labels do not imply common random numbers;
therefore the primary interval does not pair seed labels.

The family contains five tasks and three unordered algorithm pairs, hence 15
comparisons. Family alpha is 0.05 and each comparison receives

\[
 \alpha_{\mathrm{cmp}}=0.05/15=0.0033333333333333335.
\]

At look `$k\in\{1,2,3,4\}$`, after `$n_k\in\{5,10,15,20\}$` test seeds,
the comparison-level spending is

\[
 \alpha_k=\alpha_{\mathrm{cmp}}\frac{6}{\pi^2 k^2}.
\]

For independent within-algorithm bounded sequences `$X_i,Y_j\in[0,1]$`,

\[
 r_{A,k}=\sqrt{\frac{\log(4/\alpha_k)}{2n_{A,k}}},\qquad
 r_{B,k}=\sqrt{\frac{\log(4/\alpha_k)}{2n_{B,k}}},
\]

and the interval is

\[
 I_k=\left[\bar X_k-\bar Y_k-r_{A,k}-r_{B,k},
 \bar X_k-\bar Y_k+r_{A,k}+r_{B,k}\right]\cap[-1,1].
\]

The practical superiority margin is 0.05 and the target interval width is
0.10. A comparison is declared superior only when the interval excludes the
opposite side beyond the predeclared practical margin. A precision decision
requires width at most 0.10. Otherwise the runner continues to the next
predeclared look; unresolved comparisons at 20 seeds are labelled
`max_budget_inconclusive`. Terminal decisions are locked and cannot be
overwritten by later batches.

### 3.1 Interpretation of the conditional estimand

Conditioning on `$D_{\mathrm{val}}$` means that the target is the expected test
metric of the configuration actually selected by the frozen validation rule,
conditional on the observed validation data. It is narrower than a claim about
the best configuration in an unbounded hyperparameter space and differs from
an unconditional average over all candidates. The interval answers how
different the two frozen selected procedures are under a new training-seed
draw; it does not answer which algorithm would win after unlimited tuning.

The same distinction applies to the task family. The family-wise statement is
conditional on the 15 predeclared task--algorithm comparisons. It does not
license adding a task after observing the v3 intervals, and it does not turn
the five tasks into a random sample from all possible RL environments.

### Proposition 0 (selection invariance under sealed testing)

Let `G` be any measurable configuration-selection rule that maps validation
data `$D_{\mathrm{val}}$` to one frozen configuration for each task--algorithm
cell. Suppose that, for every configuration that `G` can select, conditional on
the validation data and that selected configuration, the sealed test metrics
satisfy the bounded within-algorithm seed assumptions used by Proposition 1.
Also suppose that the metric, look schedule, alpha spending, and family are
fixed before sealed testing. Then the finite-look interval has the same
conditional coverage after selection:

\[
 \Pr\!\left(\Delta_{e,a,b}(G(D_{\mathrm{val}}))\in
 \bigcap_{k=1}^{K} I_k\ \middle|\ D_{\mathrm{val}}\right)
 \ge 1-\alpha_{\mathrm{cmp}}
 \quad\text{almost surely}.
\]

**Proof.** Fix a validation realization `$d$` for which the conditional
distribution is defined. The value `$G(d)$` is then fixed before any sealed
test row is opened, and the stated conditional test assumptions hold for that
selected configuration. Proposition 1 applies to this fixed pair, because its
concentration constants do not depend on the configuration labels. Hence the
conditional failure probability is at most
`\alpha_{\mathrm{cmp}}` for almost every `$d$`. Integrating this pointwise
conditional bound over the validation distribution gives the corresponding
unconditional statement for the random selected procedure. The argument does
not require a union bound over candidate configurations because candidate rows
are used only for selection and never enter the sealed-test interval.

This proposition does not target the best configuration in an unbounded search
space. It also fails if the selection rule, metric, look schedule, or family is
changed after sealed test data are inspected. Its role is to make explicit why
the primary estimand is conditional on the observed validation data rather
than silently treating the selected configuration as fixed by design.

### Corollary 0 (family control after validation-only selection)

Suppose Proposition 0 holds for each of `$m$` predeclared task--algorithm
comparisons, with comparison-level error allocations `$\alpha_{\mathrm{cmp},j}``.
Conditional on the complete validation data, a union bound gives

\[
 \Pr\!\left(\text{all selected-procedure intervals cover their targets}
 \ \middle|\ D_{\mathrm{val}}\right)
 \ge 1-\sum_{j=1}^{m}\alpha_{\mathrm{cmp},j}.
\]

Thus the v3 choice `$\alpha_{\mathrm{cmp}}=0.05/15$` controls the declared
15-comparison family at 0.05 even though each cell considered four candidate
configurations during validation. The candidate count does not enter this
union bound because candidate observations are not treated as sealed-test
comparisons. Adding a new task, algorithm pair, metric, or post-selection
analysis would define a new family and require a new allocation.

### 3.2 Decision rule as an auditable state machine

For each unordered pair, the runner starts with an empty sealed-test record. At
look `$k$`, it appends exactly five new seeds, computes the two sample means,
constructs `$I_k$`, and applies this mutually exclusive order:

1. If the lower endpoint is greater than the practical margin, declare the
   first algorithm practically superior.
2. If the upper endpoint is less than the negative practical margin, declare
   the second algorithm practically superior.
3. If the width is at most 0.10, declare the comparison precise but not
   superior.
4. Otherwise continue to the next fixed look.

The first terminal state is locked. A comparison that reaches the final look
without a terminal state is recorded as `max_budget_inconclusive`. This order
prevents a later descriptive update from overwriting a decision made under the
predeclared rule. Implementation tests cover terminal locking and order
invariance of the unpaired interval.

Training metrics are collected once per task--algorithm cell and are reused by
each applicable unordered pair. Pair-level state records determine whether a
cell must receive another batch; they do not duplicate an already observed
training run.

**Algorithm 1. Sealed-test finite-look evaluator.** The following pseudocode
specifies the executable state machine independently of the implementation
language. `Select` uses validation rows only; `Evaluate` appends one new batch
of sealed test seeds and returns one bounded metric per seed.

```text
Input: task family E, algorithms A, candidate grid C, validation seeds V,
       sealed seed schedule S, look sizes n[1:K], alpha spending alpha[1:K],
       practical margin m, width target w
For each task e in E and algorithm a in A:
    c[e,a] <- Select(argmax validation mean over C using V)
    freeze c[e,a] before opening any row in S
For each task e and algorithm a: rows[e,a] <- {}
For k = 1,...,K while at least one pair is open:
    For each task--algorithm cell used by an open pair:
        append exactly n[k]-n[k-1] fresh seeds to rows[e,a]
    For each open unordered pair (a,b) and task e:
        d <- mean(rows[e,a]) - mean(rows[e,b])
        I <- clip([d-r_a(k)-r_b(k), d+r_a(k)+r_b(k)], [-1,1])
        If lower(I) > m: status <- a_superior; lock status
        Else if upper(I) < -m: status <- b_superior; lock status
        Else if width(I) <= w: status <- precise_inconclusive; lock status
        If status remains open at look K: status <- max_budget_inconclusive
        emit status, stop look, raw rows, d, I, and configuration identifiers
Output: one immutable decision record per task--pair cell
```

The `precise_inconclusive` branch is evaluated after both superiority branches,
so a practically superior result is never relabelled as merely precise. Rows
after a locked decision are not used for that decision record. The output
schema retains the raw seed rows and the exact stop trace, allowing every
reported interval to be recomputed without rerunning training.

### 3.3 Why the primary interval is unpaired

Training runs labelled with the same integer seed do not necessarily share the
same environment transitions, framework random-number stream, or optimization
trajectory. Pairing algorithms by seed label would impose a common-random-
number interpretation that is not established by the artifacts. The primary
estimate therefore uses separate marginal means and remains valid for unequal
sample sizes. Paired procedures are diagnostic comparators only; their behavior
under arbitrary re-pairing is not promoted as a primary result.

### 3.4 Minimax alpha spending as a design diagnostic

The summable power-series spending rule is valid but does not optimize a stated
resolution objective. For equal sample sizes at look `k`, define

\[
 q_k=\frac{\log(4/\alpha_k)}{n_k},
 \qquad R_k=\sqrt{2q_k},
\]

where `R_k` is the sum of the two unpaired Hoeffding radii. Given look sizes
`n_1,\ldots,n_K` and a comparison-level budget `alpha_cmp`, the minimax design
that minimizes `max_k R_k` is obtained from the unique positive solution `tau`
of

\[
 4\sum_{k=1}^{K}\exp(-n_k\tau)=\alpha_{\mathrm{cmp}},
 \qquad \alpha_k^*=4\exp(-n_k\tau).
\]

This follows because `q_k <= tau` requires
`alpha_k >= 4 exp(-n_k tau)` for every look. Thus a smaller threshold is
infeasible under the total alpha budget, while the displayed allocation makes
all `q_k` equal. The result is a planning lemma for the bounded interval, not a
new coverage theorem and not an empirical RL power claim.

For the v3 look sizes and comparison alpha, the minimax schedule equalizes the
radius sum at 1.684151, whereas the preregistered power-series schedule has a
worst-case radius sum of 1.742157. The tradeoff is deliberate: the minimax
schedule gives up final-look sharpness (1.684151 versus 1.017859) to reduce the
earliest-look radius. Neither schedule can reach the 0.05 superiority margin
or 0.10 width target at 20 seeds, so the v3 confirmatory analysis retains its
preregistered spending rule. Full values and deterministic code are in
`MINIMAX_ALPHA_SPENDING.md`, `MINIMAX_ALPHA_SPENDING.json`, and
`minimax_alpha_spending.py`; unit tests verify budget exhaustion and
equalization.

### Proposition 1 (conditional finite-look coverage)

Conditional on validation data and selected configurations, suppose each
algorithm's sealed metrics are independent across its own training seeds and
bounded in `$[0,1]$`. At any `$K$` predeclared finite looks whose spending
weights satisfy `sum_k alpha_k <= alpha_cmp`, `$I_k$` covers
`$\Delta_{e,a,b}$` simultaneously with probability at least
`$1-\alpha_{\mathrm{cmp}}$`. Across the 15 predeclared comparisons, the union
bound gives family-wise coverage at least 0.95. Independence between the two
algorithm sequences or between comparisons is not required for this
union-bound step. The v3 analysis is the special case `$K=4$` with look sizes
`$n_k in {5,10,15,20}$` and the power-series spending schedule.

**Proof.** At look `$k$`, Hoeffding's inequality gives a two-sided
failure probability at most `$\alpha_k/2$` for each sample mean. A union bound
over the two means gives failure at most `$\alpha_k$`. A second union bound over
the `$K$` looks gives failure at most

\[
\sum_{k=1}^{K}\alpha_{\mathrm{cmp}}6/(\pi^2k^2)
\leq\alpha_{\mathrm{cmp}}.
\]

Allocating `$0.05/15$` to each comparison and applying another union bound
gives the family statement. The result is conditional: it does not cover
test-data reuse, post-hoc metric or look selection, data-dependent task-family
expansion, or environment drift. It is a finite-look result, not an anytime
confidence sequence.

More explicitly, for algorithm `$A$`,

\[
 2\exp\{-2n_{A,k}r_{A,k}^{2}\}=\alpha_k/2,
\]

and the same identity holds for algorithm `$B$`. On the event that both sample
mean bounds hold at every look, subtracting the two inequalities gives
`$\Delta_{e,a,b}\in I_k$` for every `$k$`; endpoint clipping cannot remove the
target because the difference of two `[0,1]` means lies in `[-1,1]`. The event's
complement is bounded by `\sum_{k=1}^{4}\alpha_k` for one comparison and by
`15\sum_{k=1}^{4}\alpha_k` for the predeclared family. Conditioning is valid
because the selected configurations and the look schedule are measurable with
respect to validation data and the sealed test sequences are not used until
after selection.

### Proposition 2 (validity under locked finite-look stopping)

For one comparison, let `$\tau$` be the first terminal look produced by the
predeclared state machine. If no terminal decision occurs, set `$\tau=K+1$`
for the maximum-budget-inconclusive status and define the reported-look index
`$\bar\tau=\min(\tau,K)$`. Thus the reported interval is always `$I_{\bar\tau}$`.
Suppose Proposition 1 holds on the event

\[
 \mathcal E=\{\Delta\in I_k\text{ for every }k=1,\ldots,K\}.
\]

Then the interval reported at the terminal or final look covers the same
conditional estimand with probability at least `$1-\alpha_{\mathrm{cmp}}$`, and the family-wise
statement remains valid when different comparisons stop at different looks.

**Proof.** The stopping time `$\tau$` is measurable with respect to the test
rows revealed through the selected look. On `$\mathcal E$`, every one of the
predeclared intervals contains `$\Delta$`; therefore the reported interval
indexed by `$\bar\tau$` contains `$\Delta$` as well. Consequently,

\[
 \{\Delta\notin I_{\bar\tau}\}\subseteq\mathcal E^{c},
 \qquad
 \Pr(\Delta\notin I_{\bar\tau}\mid D_{\mathrm{val}})
 \leq \Pr(\mathcal E^{c}\mid D_{\mathrm{val}})
 \leq \alpha_{\mathrm{cmp}}.
\]

If a comparison is locked, later rows are not needed for this inclusion and
cannot overwrite its record. Applying the same argument to each member of the
predeclared family and taking one union bound gives family-wise error at most
`$\sum_j \alpha_{\mathrm{cmp},j}$`, even though the stopping looks differ across
comparisons. This is a finite-look argument; it does not permit unregistered
looks, post-hoc thresholds, or a family chosen after seeing the test data.

This proposition is the formal link between the interval construction and the
runner's terminal-locking implementation. The deterministic locking test
checks the state transition, while the proposition supplies the statistical
reason that a locked record may be reported without appending later rows.

### Proposition 3 (known-block dependence fallback)

Suppose that, conditional on the validation data and selected configurations,
each arm's observations can be partitioned into known non-overlapping blocks.
Let the mean of each complete block lie in `[0,1]`, and assume that the block
means are independent within each arm with a common arm-level mean. At look
`k`, retain only the `q_A,k` and `q_B,k` complete blocks available in the two
arms and define

\[
 J_k = [\bar U_{A,k}-\bar U_{B,k}-s_{A,k}-s_{B,k},
          \bar U_{A,k}-\bar U_{B,k}+s_{A,k}+s_{B,k}]\cap[-1,1],
\]

where `$s_{A,k}=\sqrt{\log(4/\alpha_k)/(2q_{A,k})}$` and `$s_{B,k}` is
defined analogously. Then the finite-look and family-wise coverage statements
of Proposition 1 hold for `$J_k$`, with the number of complete blocks replacing
the raw row count.

**Proof.** Apply Proposition 1 to the block means `$U_{A,l}$` and
`$U_{B,l}$`. They are bounded in `[0,1]` and are independent within each arm
under the proposition's assumption, so the same two-arm, finite-look and
family-wise union bounds apply. Discarding a partial trailing block avoids
treating one dependent fragment as a separate independent observation.

This fallback requires a known partition and independent block means. It does
not cover unknown or overlapping blocks, residual dependence between blocks,
or dependence induced by an unmodelled RL process. Its price is a smaller
effective sample size and wider intervals; it is therefore a diagnostic
response to a specified dependence structure, not a general correction.

### Definition 1 (reliability--cost frontier)

For a fixed comparison protocol, define the analytic reliability--cost points

\[
 \mathcal F=\{(C_k,R_k): k=1,\ldots,K\},
\]

where `$C_k$` is the cumulative recorded cost of reaching look `$k$` and
`$R_k=r_{A,k}+r_{B,k}$` is the worst-case unpaired radius at that look. The
analytic coordinate `$R_k$` is distribution-free under the stated bound;
the empirical coordinate `$C_k$` is machine-, implementation-, and
configuration-specific. A terminal run selects one point by its stopping look,
but the full frontier must be computed from the predeclared looks so that an
early stop is not confused with a post-hoc cost curve.

The frontier is therefore a reporting object, not a power curve. A smaller
`$R_k$` represents a tighter worst-case certificate, whereas a smaller
`$C_k$` represents lower observed execution cost only for the disclosed
machine and run. The v3 artifact reports both coordinates separately and
audits their monotonicity and raw-runtime totals.

### Corollary 1 (equal-sample width planning)

With `$n_{A,k}=n_{B,k}=n$`, the unclipped interval width is

\[
 W_k(n)=4\sqrt{\frac{\log(4/\alpha_k)}{2n}},
 \qquad
 n\geq\left\lceil\frac{8\log(4/\alpha_k)}{w^2}\right\rceil
 \ \Longrightarrow\ W_k(n)\leq w.
\]

For the width target `$w=0.10$`, the first-look requirement is 3,904 seeds
per algorithm at single-comparison alpha `0.05`, but 6,071 seeds per algorithm
at the v3 comparison alpha `0.05/15`. At the final primary look `$k=4$`, the
corresponding requirements are 6,122 and 8,289 seeds, respectively. Under the
formal v3 allocation, the unclipped width at 20 seeds is 1.7422 at the first
look and 2.0357 at the final look (the reported interval is clipped to
`[-1,1]`). These are analytic properties of the bound, not observed RL sample
requirements or lower bounds. They explain why the v3 study tests a boundary
of conservative resolution rather than a claim of efficient early stopping.

The four planning values are separated below because the single-comparison
diagnostic and the formal family allocation answer different questions. The
width column is the unclipped worst-case width at 20 seeds per algorithm; it is
not an observed width from the RL runs.

| Error allocation | Look | Seeds per algorithm for width <= 0.10 | Unclipped width at 20 seeds |
|---|---:|---:|---:|
| Single comparison, alpha = 0.05 | 1 | 3,904 | 1.3971 |
| Single comparison, alpha = 0.05 | 4 | 6,122 | 1.7496 |
| Formal v3 family, alpha_cmp = 0.05/15 | 1 | 6,071 | 1.7422 |
| Formal v3 family, alpha_cmp = 0.05/15 | 4 | 8,289 | 2.0357 |

### Corollary 2 (formal-budget non-resolution)

Under the formal v3 allocation at the final look, equal samples of size 20
give a radius sum

\[
 R_4=r_{A,4}+r_{B,4}=1.0178588242.
\]

For any observed bounded mean difference `$d\in[-1,1]$`, the clipped interval
`$[d-R_4,d+R_4]\cap[-1,1]$` cannot declare the first algorithm superior because
its largest possible lower endpoint is `$1-R_4=-0.0178588242<0.05$`; the
second direction is symmetric. Its smallest possible clipped width is
`$\min(2,R_4)=1.0178588242>0.10$`, so the precision rule is also impossible.
The earlier looks have larger radius sums and therefore cannot resolve either
rule either. Consequently, under the exact formal v3 rule, every bounded
dataset is forced to `max_budget_inconclusive` by 20 seeds. This is a
protocol-resolution result, not evidence that the compared algorithms are
equal and not a universal lower bound on RL seed requirements.

### Corollary 3 (necessary threshold for possible bounded-data superiority)

The same radius argument yields a reusable design threshold. At look `k`, with
equal sample size `n` per algorithm and practical margin `m`, the largest
possible bounded mean difference is one. A first-direction superiority
decision is therefore impossible whenever

\[
R_k(n)=2\sqrt{\frac{\log(4/\alpha_k)}{2n}}\geq 1-m.
\]

Equivalently, any bounded data can possibly cross the margin only if

\[
n>\frac{2\log(4/\alpha_k)}{(1-m)^2}.
\]

The smallest integer satisfying this strict inequality is a necessary
resolution threshold, not a sufficient power calculation. Under the formal v3
comparison alpha `0.05/15` and `m=0.05`, the thresholds at looks 1--4 are 17,
20, 22, and 23 seeds per algorithm. The v3 looks are 5, 10, 15, and 20, so
none can possibly cross the margin; Corollary 2 follows as a special case.
The deterministic implementation is `seeds_for_possible_superiority` in
`unpaired_budget_requirements.py` and is covered by
`test_possible_superiority_threshold_matches_v3_boundary`.

### Corollary 4 (validation-selected alpha spending)

Let `\mathcal{H}` be a finite set of predeclared finite-look alpha-spending
schedules. For every schedule `h\in\mathcal{H}`, suppose
`\sum_k\alpha_{h,k}\leq\alpha_{\mathrm{cmp}}` and the interval construction
satisfies Proposition 1. Let `H(D_{\mathrm{val}})` select one schedule using
only validation data, and keep the selected schedule fixed before any sealed
test row is opened. Then, conditional on the validation data, the interval
sequence produced by the selected schedule covers its conditional target with
probability at least `1-\alpha_{\mathrm{cmp}}`.

**Proof.** Fix a validation realization. The selected schedule is then a
constant, so Proposition 1 applies to that schedule's fixed look levels. The
conditional failure probability is at most `\alpha_{\mathrm{cmp}}`; integrating
over validation realizations gives the result for the random selected
schedule. A union bound over the predeclared comparison family is unchanged.
No additional union bound over `\mathcal{H}` is needed because schedules are
selected before sealed testing and are not used as separate test comparisons.
This result does not make an invalid candidate interval valid, and it does not
support a universal cost-saving claim.

### Corollary 5 (balanced allocation minimizes the two-arm radius)

At a fixed look and fixed comparison-level spending `\alpha_k`, let the total
number of sealed seeds be `N=n_A+n_B`. The unpaired radius sum is

\[
 R(n_A,n_B)=\sqrt{\frac{\log(4/\alpha_k)}{2}}
 \left(n_A^{-1/2}+n_B^{-1/2}\right).
\]

For fixed `N`, this expression is minimized at the balanced allocation
`n_A=n_B=N/2`, by convexity of `x\mapsto x^{-1/2}`. Consequently, a width
target `w` requires at least
`N\geq\lceil16\log(4/\alpha_k)/w^2\rceil` total seeds under the
radius-minimizing allocation. Likewise, any bounded-data superiority decision
with margin `m` is impossible whenever
`N\leq\lfloor4\log(4/\alpha_k)/(1-m)^2\rfloor`.

This is a worst-case allocation result for the stated interval. It does not
require cross-algorithm independence, does not establish empirical RL power,
and does not imply that equal computational cost or equal training time is
optimal for every implementation.

### 3.5 Pre-study budget feasibility audit

The preceding corollaries can be used before any sealed test run to detect a
budget that is structurally unable to answer the registered question. We
operationalize this check as Algorithm 2. For each predeclared look, it computes
the radius sum, the largest lower endpoint that any bounded observed
difference could produce (`1 - R_k`), and the smallest clipped interval width
that any bounded difference could produce (`min(2, R_k)`). It then reports two
feasibility flags: whether superiority beyond margin `m` is possible, and
whether the target width `w` is possible. The audit also reports the necessary
seed thresholds from Corollaries 1 and 3.

**Algorithm 2. Pre-study bounded-resolution feasibility audit.** Given the
metric range, closed comparison family, alpha-spending schedule, look sizes,
practical margin, and target width:

1. Compute the comparison-level alpha and `R_k` at every registered look.
2. Set `possible_superiority_k` to true only when `1 - R_k > m`.
3. Set `possible_precision_k` to true only when `min(2, R_k) <= w`.
4. Report the necessary seed thresholds and stop data collection if the
   registered cap is below the chosen design objective, unless the study is
   explicitly intended to characterize non-resolution.

For the frozen v3 inputs, both feasibility flags are false at all four looks.
The necessary superiority thresholds are 17, 20, 22, and 23 seeds per arm,
whereas the target-width thresholds are 6,071, 7,180, 7,829, and 8,289 seeds
per arm. These values are exact deterministic consequences of the registered
bound. They do not estimate power, prove that a real effect exists, or imply a
universal seed requirement. The machine-readable audit is
`BUDGET_FEASIBILITY_AUDIT_V3.json`; its generator and deterministic tests are
`generate_budget_feasibility_audit.py` and `test_budget_feasibility_audit.py`.

### 3.6 Assumption registry and falsification checks

The coverage statement is useful only when its assumptions are visible. The
following registry links each assumption to the strongest check available in
the current package and identifies what the check cannot establish.

| ID | Assumption required by the interval | Current check | Residual failure mode |
|---|---|---|---|
| A1 | Configuration selection and all metric choices are measurable with respect to validation data, not sealed test data. | Disjoint validation/test seed ranges, frozen selected configurations, and the 600-row split audit. | An unrecorded manual change or hidden test reuse would invalidate the conditional interpretation. |
| A2 | Conditional on the selected configuration, each algorithm's sealed seed metrics are independent draws with a common marginal mean. | Unique seed ranges, explicit seed derivation, and run metadata; no test can prove independence from one installation alone. | Correlated seeds, shared hidden state, or software-level coupling can make the nominal coverage statement inapplicable. |
| A3 | The normalized metric is fixed in advance and lies in `[0,1]`. | Predeclared task bounds, range checks, raw-return retention, and normalization sensitivity diagnostics. | Post-hoc bounds or metric changes alter the estimand and invalidate the recorded interval. |
| A4 | Look sizes, alpha spending, practical margin, and precision rule are fixed before sealed testing. | Frozen preregistration, state-machine tests, and recomputed stop traces. | Additional unregistered looks or thresholds would require a new error allocation. |
| A5 | The 15-comparison family is closed for the primary claim. | Preregistration and artifact manifest enumerate five tasks and three unordered pairs. | Adding tasks, algorithms, or pairs after observing results breaks the stated family-wise control. |
| A6 | The task implementation and software environment remain stable over the reported sequence. | Version lock, source hashes, environment metadata, and same-machine replay. | Hardware drift, package changes, or environment-version changes can alter the target procedure; an external rerun is still required. |

Only A1, A3, A4, and A5 have direct artifact-level checks in the current
package. A2 and A6 remain partly empirical assumptions, which is why the
coverage claim is conditional and why same-machine repeatability is not called
external reproducibility. The registry is a disclosure and falsification
guide, not a claim that one run can verify every assumption.

### 3.7 Family-size planning sensitivity

Family-wise control has a direct cost consequence that is easy to miss when
the number of comparisons is treated as a reporting detail. Holding the total
family error at 0.05, the per-comparison allocation is `0.05/m` for a family
of `m` comparisons. The table below recomputes the bounded interval geometry
for five plausible family sizes while keeping the v3 look schedule, practical
margin, and width target fixed. It is an analytic planning diagnostic: it uses
no RL observations and does not estimate power.

| Comparisons | Comparison alpha | First-look radius | Final-look radius | Necessary seeds/algorithm for possible superiority (final) | Seeds/algorithm for width <= 0.10 (final) |
|---:|---:|---:|---:|---:|---:|
| 1 | 0.05000000 | 1.397101 | 0.874775 | 17 | 6,122 |
| 3 | 0.01666667 | 1.546394 | 0.935464 | 20 | 7,001 |
| 9 | 0.00555556 | 1.682492 | 0.992448 | 22 | 7,880 |
| 15 | 0.00333333 | 1.742157 | 1.017859 | 23 | 8,289 |
| 30 | 0.00166667 | 1.819992 | 1.051357 | 25 | 8,843 |

The monotone increase in the radius is a consequence of the union-bound
allocation, not a property of any particular RL task. It provides a practical
planning rule: the task, algorithm, metric, and look family should be closed
before data collection, because adding comparisons after observing results
changes the error budget and the required seed scale. The machine-readable
derivation and audit are `DESIGN_PLANNING_SENSITIVITY_V3.json`,
`DESIGN_PLANNING_SENSITIVITY_V3.md`,
`generate_design_planning_sensitivity.py`, and
`audit_design_planning_sensitivity.py`.

## 4. Experimental Design


### 4.1 Tasks and normalization

The frozen task family is `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`,
`Taxi-v4`, and `NonstationaryQueue-v0`. Gymnasium is version 1.4.0. The
primary raw-return bounds are, respectively, `[0,500]`, `[-500,0]`,
`[-200,0]`, `[-2000,20]`, and `[-2050,0]`; normalization maps each bound to
`[0,1]` and raw returns are retained. `Taxi-v4` is used because `Taxi-v3` is
deprecated in this installed Gymnasium version. The queue is a controlled,
self-built diagnostic with capacity 10, horizon 200, an arrival-rate switch at
step 100, arrival probabilities 0.25 and 0.85, and service cost 0.25. It is
not presented as a standard external benchmark.

### 4.2 Algorithms and equal candidate grid

PPO [L7], DQN [L8], and A2C [L9] are Stable-Baselines3 2.9.2 implementations
with software provenance documented in [L12]. All use `MlpPolicy` and CPU
execution; PPO and DQN use batch size 64, whereas A2C uses its declared
`n_steps` rollout setting and does not expose a batch-size parameter in this
implementation. Each algorithm--task cell is
given the same four-candidate grid and five validation seeds per candidate:

| ID | Learning rate | `n_steps` | DQN buffer | DQN learning starts |
|---|---:|---:|---:|---:|
| `lr3e4_long` | 0.0003 | 256 | 5000 | 100 |
| `lr1e4_long` | 0.0001 | 256 | 5000 | 100 |
| `lr3e4_short` | 0.0003 | 128 | 10000 | 200 |
| `lr1e4_short` | 0.0001 | 128 | 10000 | 200 |

For PPO and A2C, the buffer and learning-start fields are not used by the
algorithm. The validation mean over the five seeds selects the candidate;
ties use deterministic first insertion order. The selected configuration is
frozen before any sealed test metric is used.

### 4.3 Seeds, training, and evaluation

Validation training seeds are 10000--10004 for every candidate. Sealed test
training seeds are 20000--20019. Training runs for 4096 environment steps and
is evaluated at 1024, 2048, 3072, and 4096 steps. Each checkpoint uses five
evaluation episodes. Evaluation seeds are deterministic functions of the
training seed and checkpoint and are stored in the run artifact. The runner
executes batches of five test seeds at looks 5, 10, 15, and 20.

### 4.4 Software and compute

The formal run used Python 3.11.7 on Apple Silicon arm64 macOS, Gymnasium [L10]
1.4.0, Stable-Baselines3 2.9.2, PyTorch 2.14.1, and NumPy 2.2.6. MPS was not
used (`mps_available=false`); execution was on CPU. The exact platform string,
runner hash, configuration, and raw outputs are in `sb3_formal_v3/` and
`REPRODUCTION_MANIFEST_V3.md`.

### 4.5 Compute accounting and reproducibility boundary

The primary family contains 15 algorithm--task cells and 20 selected test
seeds per cell, so the sealed-test component contains 300 algorithm--task
training runs. Validation contributes 15 cells × 4 candidates × 5 seeds = 300
additional runs, giving 600 rows in the primary CSV. Each run trains for 4096
environment steps and evaluates four checkpoints with five episodes per
checkpoint. These counts describe the executed study; they are not a claim
that the same budget is sufficient for another task family.

The runner records actual sequential execution rather than replaying a full
20-seed run and pretending that it stopped early. In v3 every comparison used
all four batches because none reached a terminal state. The formal study thus
demonstrates the cost of an unresolved conservative decision, not an observed
compute saving. The independent replay regenerates the sealed summaries with
a separate script on the same machine. That check tests repeatability of the
disclosed software state; it does not test a second installation, a different
CPU, or an external operator.

The following protocol invariants are checked before the package is treated as
submission-ready. They are execution constraints, not additional statistical
assumptions.

| Invariant | Required condition | Audit evidence |
|---|---|---|
| Selection boundary | Every selected configuration is determined from validation rows only. | Disjoint split labels, frozen configuration fields, and the 600-row v3 audit. |
| Seed disjointness | Validation, v3 sealed tests, and extension sequences have no overlapping seed ranges. | Run manifests and range checks in the v3, v4, and v5 audits. |
| Look schedule | Each look appends the declared batch and uses the declared alpha allocation. | Stop traces, recomputed intervals, and state-machine tests. |
| Terminal locking | A first terminal decision cannot be overwritten by later rows. | Unit tests and recomputed decision summaries. |
| Metric provenance | Normalized metrics are traceable to retained raw returns and fixed bounds. | Raw-return table, normalization manifest, and range checks. |
| Artifact completeness | Source hashes, raw rows, summaries, environment metadata, and commands are co-located. | Submission archive and SHA-256 sidecar. |

### 4.6 Registration status and analysis provenance

The v3 protocol was frozen before the sealed test analysis in
`FINAL_PREREGISTRATION_V3.md`. The continuous-control and partial-observation
scope components have separate preregistration files and are not silently
pooled into the v3 family. The larger queue follow-up was initiated after the
v3 result and is therefore labelled post-v3. The v4 extension was preregistered
before opening seeds 30000--30399, but its motivation and task family are
inherited from v3; it is reported as a prospective new-seed extension rather
than an independent replication. Post-hoc interval, normalization, training
budget, evaluation-episode, tuning-stability, and pairing analyses are marked
diagnostic throughout. This provenance rule prevents later analyses from
changing the primary estimand or silently upgrading exploratory evidence.

## 5. Results


### 5.1 Data accounting and decisions


The v3 CSV contains 600 rows: 300 validation rows (four candidates, five
seeds, 15 algorithm--task cells) and 300 sealed-test rows (one selected
candidate, 20 seeds, 15 cells). All 15 comparisons reached 20 test seeds and
all 15 remained `max_budget_inconclusive`. Corollary 2 shows that this
all-15 outcome is structurally implied by the formal bound and budget, rather
than being a task-specific estimate of low empirical power. No formal
superiority or precision decision was made.

The pre-study feasibility audit reached the same conclusion before the sealed
test rows were opened: none of the four registered looks could possibly cross
the 0.05 practical margin or the 0.10 target width for any metric sequence in
`[0,1]`. The observed 15/15 terminal states therefore provide an execution
check against a design prediction; they do not turn the prediction into an
empirical power estimate.

### 5.2 Descriptive test means


The following are normalized test means for the selected configurations. They
are descriptive and must not be read as a general algorithm ranking.

| Environment | PPO | DQN | A2C |
|---|---:|---:|---:|
| CartPole-v1 | 0.214320 | 0.024900 | 0.201375 |
| Acrobot-v1 | 0.108690 | 0.182475 | 0.084515 |
| MountainCar-v0 | 0.000000 | 0.005688 | 0.000000 |
| Taxi-v4 | 0.891089 | 0.891089 | 0.673519 |
| NonstationaryQueue-v0 | 0.792553 | 0.922569 | 0.622952 |

The selected configurations are recorded per cell in
`sb3_formal_v3/summary.json`; all candidate validation values are retained.
MountainCar is at or near the reward floor under this fixed budget, so its
descriptive values provide little discrimination.

### 5.2.1 Raw-return summaries


To make the normalization transparent, the same selected-test seeds are also
reported on their task-specific raw-return scales. These summaries are
descriptive and are not pooled across tasks: a one-unit change has different
meaning in CartPole, Taxi, and the queue environment. The raw table is
generated from `metric_raw` by `generate_raw_return_table.py` and is therefore
not an independently selected result.

| Environment | Algorithm | Mean raw return | Sample SD | Median | Minimum | Maximum |
|---|---|---:|---:|---:|---:|---:|
| CartPole-v1 | PPO | 107.160000 | 30.539003 | 97.050000 | 75.650000 | 219.250000 |
| CartPole-v1 | DQN | 12.450000 | 7.511080 | 9.725000 | 9.050000 | 39.450000 |
| CartPole-v1 | A2C | 100.687500 | 30.487875 | 90.750000 | 58.200000 | 162.700000 |
| Acrobot-v1 | PPO | -445.655000 | 100.347583 | -500.000000 | -500.000000 | -134.800000 |
| Acrobot-v1 | DQN | -408.762500 | 124.334260 | -500.000000 | -500.000000 | -170.950000 |
| Acrobot-v1 | A2C | -457.742500 | 81.882243 | -500.000000 | -500.000000 | -193.000000 |
| MountainCar-v0 | PPO | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| MountainCar-v0 | DQN | -198.862500 | 4.669917 | -200.000000 | -200.000000 | -179.100000 |
| MountainCar-v0 | A2C | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | PPO | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | DQN | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | A2C | -639.492500 | 443.534378 | -559.325000 | -1636.850000 | -200.000000 |
| NonstationaryQueue-v0 | PPO | -425.265625 | 460.855138 | -161.418750 | -1797.200000 | -158.550000 |
| NonstationaryQueue-v0 | DQN | -158.733750 | 4.147479 | -159.475000 | -168.512500 | -150.950000 |
| NonstationaryQueue-v0 | A2C | -772.948750 | 645.308638 | -644.543750 | -1796.862500 | -154.512500 |

The machine-generated copy is `RAW_RETURN_TABLE_V3.md`, produced by
`generate_raw_return_table.py`.

### 5.3 Formal intervals


| Task | Comparison | Estimate | Family-adjusted interval | Decision |
|---|---|---:|---:|---|
| CartPole-v1 | PPO − DQN | 0.1894 | [−0.8284, 1.0000] | Inconclusive |
| CartPole-v1 | PPO − A2C | 0.0129 | [−1.0000, 1.0000] | Inconclusive |
| CartPole-v1 | DQN − A2C | −0.1765 | [−1.0000, 0.8414] | Inconclusive |
| Acrobot-v1 | PPO − DQN | −0.0738 | [−1.0000, 0.9441] | Inconclusive |
| Acrobot-v1 | PPO − A2C | 0.0242 | [−0.9937, 1.0000] | Inconclusive |
| Acrobot-v1 | DQN − A2C | 0.0980 | [−0.9199, 1.0000] | Inconclusive |
| MountainCar-v0 | PPO − DQN | −0.0057 | [−1.0000, 1.0000] | Inconclusive |
| MountainCar-v0 | PPO − A2C | 0.0000 | [−1.0000, 1.0000] | Inconclusive |
| MountainCar-v0 | DQN − A2C | 0.0057 | [−1.0000, 1.0000] | Inconclusive |
| Taxi-v4 | PPO − DQN | 0.0000 | [−1.0000, 1.0000] | Inconclusive |
| Taxi-v4 | PPO − A2C | 0.2176 | [−0.8003, 1.0000] | Inconclusive |
| Taxi-v4 | DQN − A2C | 0.2176 | [−0.8003, 1.0000] | Inconclusive |
| Queue-v0 | PPO − DQN | −0.1300 | [−1.0000, 0.8878] | Inconclusive |
| Queue-v0 | PPO − A2C | 0.1696 | [−0.8483, 1.0000] | Inconclusive |
| Queue-v0 | DQN − A2C | 0.2996 | [−0.7182, 1.0000] | Inconclusive |

`Queue-v0` in this table abbreviates `NonstationaryQueue-v0`. Values are
rounded from `familywise_cost_summary.json`; the JSON file is authoritative.
The wide intervals demonstrate a cost boundary for this bounded method at
this budget. They do not establish equality between algorithms.

### 5.3.1 Descriptive effect sizes


To complement the bounded intervals, we report descriptive effect sizes for
the same 20-seed samples. `Mean difference` is mean(A) minus mean(B);
Cliff's delta is the number of pairwise wins minus losses divided by 400,
with ties contributing zero; `standardized difference` uses the pooled sample
standard deviation. These quantities are descriptive and do not replace the
primary family-wise interval or establish algorithm rankings.

| Environment | Comparison | Mean difference | Cliff delta | Standardized difference | Pooled SD |
|---|---|---:|---:|---:|---:|
| CartPole-v1 | PPO - DQN | 0.189420 | 1.000000 | 4.258948 | 0.044476 |
| CartPole-v1 | PPO - A2C | 0.012945 | 0.210000 | 0.212120 | 0.061027 |
| CartPole-v1 | DQN - A2C | -0.176475 | -1.000000 | -3.974165 | 0.044406 |
| Acrobot-v1 | PPO - DQN | -0.073785 | -0.115000 | -0.326542 | 0.225959 |
| Acrobot-v1 | PPO - A2C | 0.024175 | 0.020000 | 0.131986 | 0.183163 |
| Acrobot-v1 | DQN - A2C | 0.097960 | 0.135000 | 0.465278 | 0.210541 |
| MountainCar-v0 | PPO - DQN | -0.005687 | -0.100000 | -0.344475 | 0.016511 |
| MountainCar-v0 | PPO - A2C | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| MountainCar-v0 | DQN - A2C | 0.005687 | 0.100000 | 0.344475 | 0.016511 |
| Taxi-v4 | PPO - DQN | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| Taxi-v4 | PPO - A2C | 0.217571 | 0.650000 | 1.401326 | 0.155260 |
| Taxi-v4 | DQN - A2C | 0.217571 | 0.650000 | 1.401326 | 0.155260 |
| NonstationaryQueue-v0 | PPO - DQN | -0.130016 | -0.575000 | -0.817866 | 0.158969 |
| NonstationaryQueue-v0 | PPO - A2C | 0.169602 | 0.312500 | 0.620067 | 0.273521 |
| NonstationaryQueue-v0 | DQN - A2C | 0.299617 | 0.747500 | 1.346043 | 0.222591 |

The machine-generated copy is `EFFECT_SIZE_TABLE_V3.md`, produced by
`generate_effect_size_table.py`.

### 5.4 Same-machine repeatability


The separate reproduction script regenerated all 20 sealed seeds for each of
the 15 algorithm--task cells. Every cell has mean absolute normalized-metric
difference 0.0 between stored and reproduced summaries. This supports
same-machine cross-script repeatability for the disclosed software state.
The sealed Windows AMD64 rerun below provides separate evidence about
different-machine reproducibility.

### 5.4.1 Different-machine sealed rerun


After the primary analysis was frozen, an operator executed the sealed
protocol on a Windows 10 AMD64 machine. The returned metadata recorded Python
3.11.18, NumPy 2.2.6, PyTorch 2.14.1, Gymnasium 1.4.0, and
Stable-Baselines3 2.9.2, with neither CUDA nor MPS available. The returned
archive contains 600 raw rows (300 validation and 300 test), the output
checksum manifest and all runtime-source hashes match the frozen run. The
audit separately classifies `REPRODUCTION_MANIFEST_V3.md` as a post-rerun
documentation update rather than a runtime-source mismatch.

The Windows run selected the same configuration in all 15 task--algorithm
cells and reproduced all 15 terminal decisions as
`max_budget_inconclusive`. Fourteen cells have zero seed-level normalized
metric difference from the macOS reference. The only nonzero cell is
`Acrobot-v1:DQN`, with mean absolute difference 0.00105 and maximum absolute
difference 0.01640. We retain these differences rather than rounding them
away. The handoff reports no access to the author reference directory and no
failed experiment rows; its historical installation-blocker logs are archived
separately from the successful final metadata.

This is evidence of different-machine reproducibility for the disclosed
software and frozen task family. It does not verify the operator's independent
institutional identity, replicate the conclusion on a new task family, or
establish universal RL reproducibility. The complete audit is in
`复跑结果/EXTERNAL_RERUN_AUDIT.md` and the raw returned files are in
`复跑结果/external_rerun_output/`.

### 5.5 Seed-level distribution and configuration selection


The stored test metrics show why point estimates alone are insufficient. For
example, the selected CartPole PPO cell has mean 0.214320 and sample standard
deviation 0.061078, whereas the selected Acrobot PPO cell has mean 0.108690
and sample standard deviation 0.200695. These are descriptive summaries of
the recorded 20-seed samples, not population variance estimates with a claim
of external validity. The raw minimum, median, maximum, and every seed-level
metric remain available in `sb3_formal_v3/raw_seed_metrics.csv`.

The complete selected-test distribution is reported below. The standard
deviation is the sample standard deviation across the 20 training seeds; these
statistics are descriptive and are not interval estimates for a broader task
population.

| Environment | Algorithm | Mean | Sample SD | Median | Minimum | Maximum |
|---|---|---:|---:|---:|---:|---:|
| CartPole-v1 | PPO | 0.214320 | 0.061078 | 0.194100 | 0.151300 | 0.438500 |
| CartPole-v1 | DQN | 0.024900 | 0.015022 | 0.019450 | 0.018100 | 0.078900 |
| CartPole-v1 | A2C | 0.201375 | 0.060976 | 0.181500 | 0.116400 | 0.325400 |
| Acrobot-v1 | PPO | 0.108690 | 0.200695 | 0.000000 | 0.000000 | 0.730400 |
| Acrobot-v1 | DQN | 0.182475 | 0.248669 | 0.000000 | 0.000000 | 0.658100 |
| Acrobot-v1 | A2C | 0.084515 | 0.163764 | 0.000000 | 0.000000 | 0.614000 |
| MountainCar-v0 | PPO | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| MountainCar-v0 | DQN | 0.005687 | 0.023350 | 0.000000 | 0.000000 | 0.104500 |
| MountainCar-v0 | A2C | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| Taxi-v4 | PPO | 0.891089 | 0.000000 | 0.891089 | 0.891089 | 0.891089 |
| Taxi-v4 | DQN | 0.891089 | 0.000000 | 0.891089 | 0.891089 | 0.891089 |
| Taxi-v4 | A2C | 0.673519 | 0.219571 | 0.713205 | 0.179777 | 0.891089 |
| NonstationaryQueue-v0 | PPO | 0.792553 | 0.224807 | 0.921259 | 0.123317 | 0.922659 |
| NonstationaryQueue-v0 | DQN | 0.922569 | 0.002023 | 0.922207 | 0.917799 | 0.926366 |
| NonstationaryQueue-v0 | A2C | 0.622952 | 0.314785 | 0.685588 | 0.123482 | 0.924628 |

The machine-generated copy of this table is
`SEED_DISTRIBUTION_TABLE_V3.md`, produced by
`generate_seed_distribution_table.py`.

Configuration selection also changes the interpretation of the test means. The
validation grid is part of the procedure, not a nuisance detail: a different
grid can select a different frozen procedure and hence a different conditional
estimand. The tuning-strength diagnostic found selection changes in 6 of 15
algorithm--task cells when the expanded four-candidate grid was compared with
the earlier two-candidate equivalent. Because that diagnostic used separate
seeds and was not the v3 sealed analysis, it is reported as sensitivity
evidence, not pooled performance evidence.

### 5.5.1 Validation-selection resampling diagnostic


As a second description of selection uncertainty, we resampled the five
validation-seed rows jointly across all four candidates 20,000 times per
algorithm--task cell. The row-level resampling preserves the fact that the
candidates were evaluated on the same seed labels. The resulting frequencies
describe instability in this observed validation sample; they are not
population probabilities, estimates of global optimality, or confirmatory
evidence.

| Environment | Algorithm | v3 selected | Selected frequency | Runner-up frequency | Entropy (nats) | Observed top-two gap |
|---|---|---|---:|---:|---:|---:|
| CartPole-v1 | PPO | `lr3e4_short` | 0.4758 | 0.4559 | 0.8949 | 0.000080 |
| CartPole-v1 | DQN | `lr3e4_long` | 0.5579 | 0.4421 | 0.6864 | 0.000160 |
| CartPole-v1 | A2C | `lr3e4_short` | 0.5366 | 0.2780 | 1.1149 | 0.003180 |
| Acrobot-v1 | PPO | `lr1e4_long` | 0.3963 | 0.3610 | 1.0783 | 0.014240 |
| Acrobot-v1 | DQN | `lr1e4_short` | 0.6526 | 0.2571 | 0.8449 | 0.036600 |
| Acrobot-v1 | A2C | `lr1e4_long` | 0.6856 | 0.1973 | 0.8638 | 0.050700 |
| MountainCar-v0 | PPO | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| MountainCar-v0 | DQN | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| MountainCar-v0 | A2C | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | PPO | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | DQN | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | A2C | `lr3e4_long` | 0.7968 | 0.2031 | 0.5047 | 0.052931 |
| NonstationaryQueue-v0 | PPO | `lr1e4_short` | 0.4919 | 0.3156 | 1.0301 | 0.023963 |
| NonstationaryQueue-v0 | DQN | `lr3e4_short` | 0.7022 | 0.2979 | 0.6090 | 0.000398 |
| NonstationaryQueue-v0 | A2C | `lr1e4_short` | 0.4217 | 0.3302 | 1.0785 | 0.047257 |

The generated report is `VALIDATION_SELECTION_UNCERTAINTY_V3.md`, with the
machine-readable output in `validation_selection_uncertainty_v3.json` and the
generator in `validation_selection_uncertainty.py`.

### 5.5.2 Execution-time accounting


#### Validation-stage tuning cost

The validation grid used the same number of candidate-seed runs for each
algorithm: five environments x four candidates x five validation seeds = 100
runs per algorithm, or 300 successful validation rows overall. The recorded
validation runtime was 208.671 seconds (0.058 hours) on the Apple Silicon CPU
environment. The algorithm totals were 65.027 seconds for A2C, 76.821 seconds
for DQN, and 66.822 seconds for PPO. These values document the executed tuning
budget and show equal row counts; they do not establish equal computational
difficulty or hardware-independent efficiency. The machine-readable source and
audit are `VALIDATION_TUNING_COST_V3.json`,
`generate_validation_tuning_cost.py`, and `audit_validation_tuning_cost.py`.

| Algorithm | Candidate-seed runs | Total runtime (hours) | Mean seconds/run | Sample SD | Median seconds/run |
|---|---:|---:|---:|---:|---:|
| A2C | 100 | 0.018 | 0.650 | 0.226 | 0.577 |
| DQN | 100 | 0.021 | 0.768 | 0.196 | 0.705 |
| PPO | 100 | 0.019 | 0.668 | 0.215 | 0.602 |

The raw CSV also records wall-clock duration for each successful selected test
run. Across the 300 sealed test rows, the recorded total was 210.345 seconds
(0.058 hours) on the Apple Silicon CPU environment. The algorithm-level means
were 0.659 seconds for A2C, 0.758 seconds for DQN, and 0.686 seconds for PPO.
These values describe this implementation, hardware, training horizon, and
runtime state; they are not cross-hardware efficiency measurements and do not
support an algorithm cost ranking.

| Algorithm | Test runs | Total runtime (hours) | Mean seconds/run | Sample SD | Median seconds/run |
|---|---:|---:|---:|---:|---:|
| A2C | 100 | 0.018 | 0.659 | 0.231 | 0.568 |
| DQN | 100 | 0.021 | 0.758 | 0.190 | 0.696 |
| PPO | 100 | 0.019 | 0.686 | 0.228 | 0.598 |

This accounting excludes validation runs, post-v3 extensions, and any
unrecorded queueing or evaluation overhead. It is included to make the cost
axis auditable and to prevent the phrase “reliability--cost frontier” from
being interpreted as a hardware-independent compute benchmark. The complete
cell-level table and machine-readable derivation are in
`RUNTIME_COST_TABLE_V3.md` and `RUNTIME_COST_TABLE_V3.json`; the audit is
`audit_runtime_cost_table.py`.

### 5.5.3 Reliability--cost frontier


To make the title's frontier explicit, we combine the analytic interval
geometry with the cumulative recorded cost of reaching each predeclared look.
At 5, 10, 15, and 20 seeds per algorithm, the family runtime for the open v3
comparisons was 0.014674, 0.029352, 0.043992, and 0.058429 hours,
respectively. These are cumulative sums over the first rows in each of the 15
selected test cells. The corresponding worst-case radius sums decreased from
1.742157 to 1.017859, while the minimum possible clipped widths remained well
above the 0.10 target. The necessary per-algorithm seed count for any bounded
data to possibly cross the 0.05 margin increased from 17 at the first listed
look to 23 at the final listed look because the alpha spending becomes more
stringent at later looks.

| Look | Seeds/algorithm | Radius sum | Minimum clipped width | Necessary seeds for possible superiority | Family test rows | Cumulative runtime (hours) |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 5 | 1.742157 | 1.742157 | 17 | 75 | 0.014674 |
| 2 | 10 | 1.339707 | 1.339707 | 20 | 150 | 0.029352 |
| 3 | 15 | 1.142220 | 1.142220 | 22 | 225 | 0.043992 |
| 4 | 20 | 1.017859 | 1.017859 | 23 | 300 | 0.058429 |

The table is a protocol frontier, not a power curve: the radius and necessary
thresholds are distribution-free design quantities, and the runtime is tied to
the recorded Apple Silicon CPU environment. Since no v3 comparison terminated
early, these cumulative values describe the cost of reaching each look with
all cells open; they do not claim compute savings on another implementation.
The machine-readable artifact and audit are `RELIABILITY_COST_FRONTIER_V3.json`,
`generate_reliability_cost_frontier.py`, and
`audit_reliability_cost_frontier.py`.

## 6. Discussion


The primary result is negative but operationally useful: under a conservative
bounded interval, four predeclared looks, family alpha 0.05, and 20 test seeds,
none of the 15 comparisons reaches a formal superiority or target-precision
decision. Corollary 2 sharpens this observation: for the formal v3 allocation,
the absence of a decision is mathematically forced for every bounded dataset at
this budget. The RL runs therefore validate the execution and estimand on the
chosen task family, but they do not estimate empirical power at 20 seeds. This
is a protocol-resolution result, not a universal lower bound on RL seed counts.

### 6.1 What the negative result means

An inconclusive interval is not evidence that the algorithms are equal. It
means that the chosen bounded procedure cannot separate the conditional
estimand from the practical decision thresholds at the stated family error
budget and sample size. A practitioner who needs a defensible superiority
claim would have to increase the information in the study, change the
estimand, or use a less conservative procedure with a separately validated
error guarantee. Simply repeating the same 20-seed comparison after inspecting
the result would violate the predeclared evidence boundary.

The pre-study feasibility audit turns this observation into a planning step:
before training sealed test seeds, an evaluator can determine whether the
registered cap could possibly cross the margin or width target under the
chosen bounded interval. If both flags are false, the study should either
increase its registered information budget or explicitly declare that it is
measuring a non-resolution boundary. This prevents a structurally impossible
decision from being described as an empirical power failure. The audit remains
specific to the interval, alpha allocation, metric bound, and thresholds that
are supplied to it; it does not replace power analysis for another procedure.

The result is also informative about protocol design. The formal interval is
not a promise of early stopping; it exposes when the available test budget is
too small for a distribution-free decision. Here the non-resolution is implied
by the radius calculation before any RL outcome is observed. The fact that all
15 comparisons reach the maximum budget verifies that the implementation
follows that boundary; it is not a failed attempt to produce a positive
algorithm ranking.

The queue budget follow-up adds the complementary observation that the same
validity-preserving state machine can eventually resolve a large observed
effect when the test budget is increased. It does not contradict the v3
corollary: the v3 corollary applies to the 20-seed cap, whereas the follow-up
uses a different, post-v3 budget and a different diagnostic scope. The two
results together separate three quantities that are often conflated: interval
validity under assumptions, resolution at a fixed budget, and the empirical
cost of resolving one observed task comparison.

The prospective v4 extension adds new seeds rather than only appending to the
original prefix. It reaches the same queue direction at the first 200-seed
look, while 14 other comparisons remain unresolved at 400 seeds. This reduces
the concern that the queue observation is solely a consequence of reusing the
v3 prefix, but it does not create independent task-family sampling or external
reproducibility. The terminal event remains conditional on one controlled task,
two frozen procedures, and the stated metric.

The v5 extension provides the broadest within-family cost diagnostic in the
current package. Four comparisons resolved at 200 or 800 new seeds, whereas
eleven remained unresolved at 1,000. Because the extension uses the same
machine, task family, and selected configurations and was motivated by earlier
results, it is a budget-resolution observation rather than independent
replication or a prospective power curve. Its value is to show that the
resolution cost is not a single number that can be transferred to another RL
task or algorithm pair.

### 6.2 Practical implications for RL benchmarking

The study supports three reporting practices for fixed-budget RL comparisons.
First, report the validation-selection rule and sealed-test boundary so readers
can identify whether test data influenced configuration choice. Second, report
seed-level distributions and interval widths rather than only a mean and a best
run. Third, state the stopping rule and maximum budget before collecting test
data. These practices do not require the Hoeffding interval; they make the
assumptions of alternative intervals visible.

For authors considering a narrower interval, the next step is not to replace
the baseline silently. A stronger study would preregister a candidate
interval, simulate its simultaneous coverage under a distribution family
motivated by the target RL tasks, compare its power and stopping cost, and then
evaluate it on sealed tasks. The current package provides the bounded baseline
and stored artifacts needed for that follow-up, but does not claim that the
follow-up has been completed.

The expanded four-candidate grid addresses the v2 tuning limitation, but it is
still a modest search compared with broad algorithm-specific optimization. The
study therefore supports equal-budget protocol analysis, not a claim that the
selected configurations are globally optimal. Validation selection is kept
separate from test inference, but any hyperparameter grid can affect the
conditional estimand.

The primary task family mixes three standard discrete-control tasks, a discrete
Taxi diagnostic, and a self-built queue. The queue has an exact finite-state
oracle and switch-time sanity check, but remains a controlled diagnostic rather
than a standard benchmark. A separate one-task Pendulum
continuous-control supplement is reported in `CONTINUOUS_SUPPLEMENT_REPORT.md`;
it is not pooled with the primary family and contains only PPO/A2C. The primary
family still contains no visual task. The reward floor in MountainCar and the
deterministic-looking Taxi means reduce the informativeness of those cells. The
queue's external validity remains limited because the task is self-built and
does not represent the full RL environment space.

The larger-budget queue result does not remove this external-validity
limitation. It is a single controlled task and a single pair of frozen
configurations, and its post-v3 timing means that it cannot substitute for an
independent preregistered budget study across the task family.

A separately preregistered scope expansion adds `MountainCarContinuous-v0` with
PPO and A2C. It contains 80 rows and is reported outside the primary family.
Both algorithms selected `lr1e4_short`; the 20-seed normalized means were
0.499982 for PPO and 0.499859 for A2C. The PPO-minus-A2C estimate was 0.0001233
with interval `[-0.8747, 0.8749]`, and all four looks were inconclusive. A
separate same-machine replay reproduced both means with zero mean absolute
metric difference. This adds a second continuous-action execution diagnostic,
not evidence of continuous-control algorithm ranking or external
reproducibility. Details are in `CONTINUOUS_SCOPE_EXPANSION_REPORT.md`.

Normal, bootstrap, or empirical-Bernstein alternatives are not promoted here
as universally valid sequential procedures. They would require predeclared
error-rate simulations under distributions representative of the intended RL
use cases. Likewise, a full-data replay of all 20 seeds is not evidence of
actual compute savings; the v3 runner records actual sequential execution,
which used all batches because every comparison was unresolved.

The queue follow-up is an actual sequential run through the 400-seed look, but
it was initiated after the v3 result and reuses the first 20 v3 metrics. It is
therefore reported as a fixed-configuration budget diagnostic. It should not be
used to estimate prospective power or to select a future margin after seeing
the outcome.

The evidence hierarchy is therefore explicit: the proposition supplies a
conditional finite-look guarantee; simulations supply scenario-specific
calibration diagnostics; v3 supplies observed RL outcomes; and the same-machine
replay supplies repeatability evidence. No level is silently substituted for
another. In particular, a high simulation coverage estimate cannot upgrade a
same-machine replay into independent reproducibility, and an exact replay
cannot prove the coverage proposition without its assumptions.

### 6.3 Theorem-supported evaluation design recommendations

The formal results are most useful as design constraints before a new RL
comparison is run. The following recommendations are limited to the bounded,
finite-look, two-arm construction studied here; they are not universal rules
for every confidence procedure or benchmark.

1. **Close the comparison family and alpha allocation before sealed testing.**
   The family-control corollary and Proposition 0 require the compared cells,
   look set, and validation-only selection rule to be fixed before test data are
   opened. A practical protocol should therefore register the task--algorithm
   family, candidate configurations, per-cell alpha allocation, and stopping
   thresholds in advance. This protects the conditional interpretation of the
   interval; it does not protect a family expanded after seeing test outcomes.

2. **Compute the necessary resolution threshold before collecting test seeds.**
   Corollary 2 and the necessary-superiority threshold identify budgets at which
   any bounded data could possibly cross a practical margin or width target.
   If the chosen cap is below that threshold, an inconclusive result is forced by
   the bound and should be reported as a design limitation rather than treated
   as evidence of equivalence. The threshold is a necessary analytic condition,
   not a power calculation or a universal seed requirement.

3. **Use balanced arm allocation when the total seed budget is fixed.**
   Corollary 5 shows that equal allocation minimizes the worst-case sum of the
   two Hoeffding radii for a fixed total number of independent seeds. This is a
   planning rule for the stated unpaired interval. It does not imply equal wall
   clock time, equal variance under other intervals, or higher empirical RL
   power when training costs differ between algorithms.

4. **Keep configuration selection, validation, and sealed testing as separate
   evidence stages.** Proposition 0 supports conditioning on a measurable rule
   chosen from validation data while preserving the test-sequence statement.
   The implementation should therefore retain every candidate's validation
   record, freeze the selected configuration, and prohibit test-informed tuning.
   The proposition does not justify selecting a configuration from the sealed
   test outcomes or claiming that the selected grid is globally optimal.

5. **Report the complete reliability--cost frontier, including unresolved
   looks.** Proposition 2 justifies locked terminal decisions at predeclared
   looks, while the v3/v5 diagnostics show why a terminal decision count alone
   is incomplete. A report should include each look's radius, width target,
   necessary threshold, decision counts, and observed runtime, including the
   maximum-budget unresolved state. Runtime must be labelled with the machine
   and collection policy; the frontier is not automatically a hardware-
   independent compute-savings claim.

6. **Label repeatability and reproducibility as different evidence.** The
   same-machine replay checks implementation repeatability, whereas the returned
   Windows AMD64 sealed rerun checks different-machine reproducibility for the
   frozen protocol. Neither is supplied by the coverage proof. A complete
   submission should disclose the tested level and leave independent-team
   identity and new-family scientific replication unresolved.

7. **Diagnose dependence before using the known-block fallback.** The block
   fallback in Proposition 3 may be used only when the block partition is
   specified before analysis, complete block means are bounded, and those block
   means are independently sampled under the stated model. A dependence stress
   test can reveal that the raw-seed interval is vulnerable, but it cannot infer
   a block structure from RL traces. When the dependence structure is unknown,
   overlapping, or plausibly residual across blocks, the fallback must not be
   presented as a correction; the result should instead be labelled conditional
   on an unverified independence assumption and the effective sample size
   uncertainty should be reported.

These recommendations are deductions about protocol construction and reporting
under the stated assumptions. They are not claims that the present study has
established a universally optimal evaluator, a minimum seed count for RL, or a
general algorithm ranking.

## 7. Limitations and Threats to Validity


**External validity.** Seven discrete-action tasks still cannot represent the
full RL benchmark space. The queue is controlled and self-built, and the v6
CliffWalking/FrozenLake extension is a same-machine scope diagnostic whose
short-budget CliffWalking results are at the normalized floor. The separate
Pendulum, MountainCarContinuous, and fixed-mask partial-observation diagnostics
broaden execution scope, but they do not supply a visual task, a general POMDP
family, or larger-scale evidence.

**Tuning strength.** Four candidates and five validation seeds per candidate
are stronger than v2 but remain limited. Increasing validation seeds to ten
changed 4/15 selections, and a separate twenty-seed extension changed 7/15
relative to v3. These are fixed-family selection-sensitivity diagnostics, not
population probabilities or evidence that twenty seeds is universally enough.
The v3 configuration must therefore be reported as part of the conditional
estimand rather than as a generally stable tuning standard.

**Metric dependence.** Normalization uses predeclared task-specific return
bounds. A different scientifically justified bound changes the normalized
estimand even when raw returns are unchanged. Raw returns are retained, and a
post-hoc sensitivity analysis across 11 boundary schemes left all 15
comparisons maximum-budget inconclusive; those alternative bounds are not
confirmatory estimands.

**Decision thresholds.** The practical margin 0.05 and target width 0.10 are
design choices frozen before the v3 test analysis. They are not universal
definitions of a meaningful RL improvement or adequate precision. A future
study should preregister a task-specific margin and report decisions across a
small sensitivity grid.

**Evaluation horizon.** The 4096-step budget and four-checkpoint average define
the estimand studied here. MountainCar remains near its reward floor under
this budget, so a longer-horizon result could answer a different question. In
the separate 16,384-step fixed-configuration diagnostic, all 15 comparisons
were still maximum-budget inconclusive, while several descriptive means
changed materially. This supports treating horizon as part of the estimand;
the diagnostic is not pooled into the primary family.

**Evaluation episodes.** The primary metric averages five episodes at each
checkpoint. The ten-episode fixed-configuration diagnostic retained all 15
maximum-budget inconclusive decisions and changed the normalized cell means
only slightly in aggregate, but it does not establish an episode-count rule
for other tasks or policies.

**Statistical assumptions.** The proof is conditional on validation selection,
fixed looks, bounded metrics, and independence across each algorithm's own
sealed seed sequence. Environment drift, hidden test reuse, or data-dependent
family expansion are outside the guarantee.

**Unobserved dependence structure.** The block stress and fallback diagnostics
use controlled surrogate data. They do not identify the dependence structure of
RL training seeds, evaluation episodes, or environment trajectories. Proposition
3 is therefore available only when an independent-block partition is known and
declared before analysis; it cannot repair unknown, overlapping, or residual
cross-block dependence. Without that information, the effective sample size is
uncertain and the nominal finite-look interval must remain conditional on the
unverified seed-independence assumption.

**Reproducibility.** The zero-difference replay is same-machine cross-script
repeatability. The returned Windows AMD64 run provides different-machine
reproducibility for the disclosed software and frozen task family: all 15
selected configurations and terminal decisions match, with 14/15 cells having
zero seed-level differences and one cell showing a reported platform
difference. The operator's independent institutional identity is not verified,
and the rerun does not test a new task family. Hardware and package metadata
are disclosed, but this does not remove all nondeterminism risks.

**Prospective extension scope.** The v4 extension uses new seeds and was frozen
before those seeds were opened, but it was motivated by the v3 result and keeps
the v3 task family and selected configurations. Its single terminal queue
comparison and fourteen unresolved cells cannot support a universal budget or
algorithm claim.

**v5 resolution-cost scope.** The v5 extension uses seeds 30400--31399 and
looks at 200, 400, 600, 800, and 1,000 seeds. Four comparisons reached a
terminal decision at 200 or 800 new seeds, while eleven remained unresolved at
1,000. This is an observed same-machine cost diagnostic for the frozen task
family and configurations; it is not a power curve, a universal seed rule,
independent reproducibility, or an algorithm ranking.

**v6 task-family scope.** The v6 extension adds two standard discrete tasks and
uses 1,440 rows with ten validation seeds per candidate and 200 test seeds per
cell. All six comparisons remain unresolved under its separately allocated
family alpha. The extension therefore tests execution and scope, not
cross-family power or algorithm performance; the untrained CliffWalking floor
also shows that adding task IDs without changing the training budget does not
guarantee informative task coverage.

**Novelty and venue.** Prior work already includes RL reliability metrics and
statistical comparison tools [L15]. The exact distinction of the present
finite-look, conditional, sealed-test protocol, and the suitability of any
particular SCI venue, require a complete current literature and venue review
`[待核实]`. This draft does not claim acceptance or guarantee publication.

**Multiple layers of uncertainty.** The interval covers the conditional seed
distribution under its stated assumptions. It does not quantify uncertainty
from task-family choice, normalization bounds, algorithm implementation,
software version, or hyperparameter grid. Those layers are handled by design
disclosure and sensitivity analysis, not by silently widening the same
interval.

## 8. Reproducibility and Open Materials


The package includes the preregistration, runner source, controlled environment
source, raw CSV, JSON summaries, reproduction outputs, source hashes, and
software metadata. The primary files are:

- `FINAL_PREREGISTRATION_V3.md`;
- `sequential_sb3_runner_v3.py` (SHA-256
  `e2ac2b731827ad251778f2420dd14f5664ca7d4f89b4436489bc183a919b574c`);
- `independent_reproduction.py` (SHA-256
  `01ed66528f64d8283d15d84789f3900fb8eb8cec33c69f0cbb83cae24d6e930a`);
- `sb3_formal_v3/raw_seed_metrics.csv`;
- `sb3_formal_v3/familywise_cost_summary.json`;
- `FINAL_PREREGISTRATION_V6_TASK_FAMILY.md`;
- `sb3_v6_task_family/raw_seed_metrics.csv` and
  `sb3_v6_task_family/V6_TASK_FAMILY_AUDIT.json`;
- `sb3_v6_task_family_extension.py` and `audit_v6_task_family.py`;
- `sb3_formal_v3/independent_reproduction_summary.json`;
- `DEPENDENCY_STRESS_DIAGNOSTIC.md` and `DEPENDENCY_STRESS_DIAGNOSTIC.json`;
- `DEPENDENCY_ROBUST_FALLBACK.md` and `DEPENDENCY_ROBUST_FALLBACK.json`;
- `INDEPENDENT_THEORY_CHECK.md` and `INDEPENDENT_THEORY_CHECK.json`;
- `INDEPENDENT_V3_RECOMPUTE.md` and `INDEPENDENT_V3_RECOMPUTE.json`;
- `REPRODUCTION_MANIFEST_V3.md`.

The post-v3 budget diagnostic is independently auditable from
`followup_budget_queue.py`, `sb3_queue_budget_followup_v1/raw_seed_metrics.csv`,
`QUEUE_BUDGET_FOLLOWUP_AUDIT.json`, and
`QUEUE_BUDGET_FOLLOWUP_REPORT.md`. The audit command is:

```bash
./.rl-arm64-venv/bin/python audit_queue_budget_followup.py
```

The continuous supplement has its own preregistration, runner, raw outputs,
and replay manifest; it is reported as external-validity evidence with the
same distinction between repeatability and reproducibility.

The returned external artifact is audited in `复跑结果/EXTERNAL_RERUN_AUDIT.md`
and `复跑结果/EXTERNAL_RERUN_AUDIT.json`. It contains the Windows raw CSV,
summary, final metadata, execution log, and output checksum manifest. The
external audit is reported separately and does not replace the macOS v3 raw
analysis.

### 8.1 Reproducibility tiers

The package uses three deliberately different labels. **Repeatability** means
the same team can regenerate the reported summaries with the disclosed scripts
and machine; this is supported for all 15 primary cells with zero recorded
mean absolute metric difference. **Different-machine reproducibility** means
that the frozen materials produce comparable raw metrics on a machine with a
different operating system and hardware platform; this is demonstrated for
the returned Windows AMD64 rerun. The operator's institutional independence is
not verified, so this result is not labelled independent-team reproducibility.
**Replicability of the scientific conclusion** would
require a new sealed study showing the same reliability--cost pattern under a
new installation or task family; this is also not demonstrated. The labels are
kept separate because exact replay of one software state cannot test all three
properties.

An internal second implementation independently recomputes the deterministic
theory values and matches the reference audit. This reduces formula-
transcription risk within the package, but it remains same-workspace evidence
and does not replace external statistical review or independent reproducibility.

### 8.2 Submission-facing disclosure items

Before submission, the author record must add the repository or archive URL,
license, author contributions, funding statement, conflict-of-interest
statement, and data-availability statement `[待补充]`. The current package
contains source hashes and local wheel hashes but does not itself constitute a
public archive. The journal's current policy for code, data, supplementary
files, and article type must be checked on the submission date `[待核实]`.

An external rerun should use the sealed test seeds, the pinned package
versions, the exact runner hashes, and the commands in the manifest. Its
deviations and raw metric differences should be added without changing the
primary v3 analysis.

## 9. Claim--Evidence Table


| Claim | Evidence | Status |
|---|---|---|
| Validation-only configuration selection preserves the conditional finite-look coverage statement. | Proposition 0, its pointwise conditioning proof, the preregistered validation/test split, and the 600-row audit. | Supported conditionally; not a guarantee for test-informed selection or an unbounded best-configuration claim. |
| The finite-look interval has conditional family-wise coverage under the stated assumptions. | Proposition 1, `METHOD_AUDIT.md`, implementation tests. | Conditional methodological result; independent statistical audit recommended. |
| Under the formal v3 allocation, 20 seeds cannot trigger superiority or 0.10-width precision for any bounded data. | Corollary 2, `ANALYTIC_NONRESOLUTION_NOTE_V3.md`, equal-sample radius calculation, and `test_formal_v3_budget_is_structurally_non_resolving`. | Analytic protocol-resolution result; not a universal RL sample-size lower bound. |
| The v3 family contains 15 comparisons with equal four-candidate validation selection and sealed testing. | `FINAL_PREREGISTRATION_V3.md`, `run_config.json`, 600-row CSV. | Supported for this run. |
| No formal v3 superiority or precision decision occurred. | `familywise_cost_summary.json`; 15/15 maximum-budget inconclusive. | Supported. |
| The fixed v3-selected queue DQN--A2C comparison resolves at 400 seeds under the same family-level interval. | `sb3_queue_budget_followup_v1/`, `QUEUE_BUDGET_FOLLOWUP_AUDIT.json`, and the 200/400 stop trace. | Supported only as a post-v3, single-task resolution-cost diagnostic; not a universal seed rule or general ranking. |
| The prospective v4 extension reaches one terminal queue decision at 200 new seeds while 14/15 comparisons remain unresolved at 400. | `FINAL_PREREGISTRATION_V4_EXTENSION.md`, `sb3_v4_extension/`, `V4_EXTENSION_AUDIT.json`, `V4_EXTENSION_REPORT.md`. | Supported as a new-seed, same-family budget observation; not external reproducibility, a universal seed rule, or a general algorithm ranking. |
| The v5 extension observes four terminal decisions by 1,000 new seeds while 11/15 cells remain unresolved. | `FINAL_PREREGISTRATION_V5_EXTENSION.md`, `sb3_v5_extension/`, `V5_EXTENSION_AUDIT.json`, `V5_EXTENSION_AUDIT.md`. | Supported as an observed same-machine resolution-cost diagnostic; not prospective power, universal seed requirements, external reproducibility, or algorithm ranking. |
| The v6 workflow executes on two additional fixed discrete tasks. | `FINAL_PREREGISTRATION_V6_TASK_FAMILY.md`, 1,440-row `sb3_v6_task_family/raw_seed_metrics.csv`, `V6_TASK_FAMILY_AUDIT.json`, and all 24 recomputed finite-look decisions. | Supported as a same-machine scope diagnostic; all six comparisons remain unresolved and the result does not establish cross-family power, rankings, or replication. |
| Descriptive means differ by task and selected configuration. | `descriptive_summary.json`. | Supported as descriptive, not ranking evidence. |
| The selected v3 test execution has a recorded wall-clock cost. | `RUNTIME_COST_TABLE_V3.json`, raw CSV consistency audit, and the recorded CPU/software environment. | Supported only as machine-specific execution accounting; not cross-hardware efficiency or algorithm-cost evidence. |
| The stored v3 summaries are repeatable across two scripts on one machine. | `independent_reproduction_summary.json`; 15 zero differences. | Supported. |
| The independence assumption has a concrete failure-mode diagnostic. | `DEPENDENCY_STRESS_DIAGNOSTIC.json`, its generator and report, and the six-condition Section 5.6.1 stress test. | Supported as a controlled surrogate diagnostic; it does not estimate dependence in RL environments or correct dependent training runs. |
| A known independent-block structure has a conservative fallback. | Proposition 3, the paired raw-count/block-aware 5,000-replicate diagnostic in Section 5.6.2, and `DEPENDENCY_ROBUST_FALLBACK.json`. | Supported only for the stated known-block surrogate; it is not a correction for unknown RL dependence. |
| The deterministic theory values are reproduced by a separate implementation. | `INDEPENDENT_THEORY_CHECK.json`, `INDEPENDENT_THEORY_CHECK.md`, and `test_independent_theory_reimplementation.py`. | Supported as same-workspace formula cross-check; not an external statistical review or proof of probabilistic assumptions. |
| The 15 primary v3 decisions are reproducible from raw CSV by a separate implementation. | `INDEPENDENT_V3_RECOMPUTE.json`, its standard-library recomputer, and 15/15 matched means, intervals, and decisions. | Supported as same-workspace data recomputation; not external reproducibility or an independent team. |
| The same protocol executes on one continuous-action task. | Continuous supplement preregistration, 80-row artifact, and separate replay. | Supported as a one-task scope diagnostic. |
| The same workflow executes on a second continuous-action task. | `FINAL_PREREGISTRATION_CONTINUOUS_SCOPE_EXPANSION.md`, 80-row artifact, and separate replay. | Supported as a second-task scope diagnostic only. |
| The v3 decision family is driven solely by five evaluation episodes per checkpoint. | Same v3 selections/seeds and budget, ten-episode fixed-configuration diagnostic, same decision rule. | Not supported as a sole explanation: all 15 decisions remain maximum-budget inconclusive; episode-count generalization remains untested. |
| PPO and A2C differ on the continuous supplement. | Valid interval excluding the practical margin. | Not supported; estimate `-0.0009`, interval `[-0.8757, 0.8739]`, maximum-budget inconclusive. |
| A different machine reproduces the frozen protocol. | Returned Windows AMD64 sealed rerun, source/output hashes, raw metrics, metadata, and 15/15 matched selections and decisions. | Supported for this task family and protocol; one cell has a small reported platform difference. |
| An independent team reproduces the study or the conclusion transfers to a new task family. | Independent operator identity plus a new sealed task-family study. | Not demonstrated. |
| The protocol universally saves compute or ranks PPO/DQN/A2C. | Broad calibrated evidence across tasks and budgets. | Not supported. |

## 10. Conclusion


The v3 study provides a preregistered, auditable test of a conservative
sequential comparison protocol for RL evaluation. With equal expanded-grid
validation, sealed test seeds, and family-wise finite-look control, all 15
comparisons remain inconclusive at 20 test seeds. The formal-budget corollary
shows that this outcome is forced for any bounded data under the stated rule;
the RL runs validate execution on the selected task family rather than
estimating 20-seed empirical power. The result identifies a reliability--cost
boundary for this protocol and benchmark family. It does not establish a
universal seed budget, algorithm ranking, computational saving, or external
reproducibility. The separate Pendulum supplement shows that the
workflow executes on one continuous-action task, but its single-task,
two-algorithm scope does not establish continuous-control generalization.
Those broader claims require additional experiments and an independent rerun.
The separate 16,384-step diagnostic shows that increasing training horizon
alone does not resolve the same conservative family-level comparisons at 20
seeds, while changing several descriptive means; this reinforces that horizon
is part of the reported estimand.

The fixed-configuration queue follow-up supplies a complementary resolution-cost
observation: under the same family-level interval, the disclosed DQN--A2C
queue comparison was inconclusive at 200 seeds and resolved at 400 seeds. That
observation is scoped to the controlled task and post-v3 diagnostic; it is not
a universal seed rule or an algorithm ranking. The combined evidence supports
reporting both unresolved fixed-budget comparisons and the larger budget needed
to resolve one observed effect, with their different evidential status stated
explicitly.

The seed-dependence stress diagnostic adds a direct boundary check: when
within-arm observations are made block-correlated while preserving the same
marginal means, the nominal finite-look interval loses coverage and produces
false-superiority decisions. This does not measure dependence in the RL tasks,
but it shows why a successful replay cannot be treated as evidence that the
independence assumption holds.

The known-block fallback diagnostic completes the response only for a narrower
case: when the block partition and block independence are known, applying the
interval to complete block means restores the bounded construction in the
surrogate model, while reducing the effective sample size. Unknown dependence
still requires a separate dependence model or an external design check; the
fallback is not an RL correction.

The prospective v4 extension adds a new-seed check of this resolution pattern:
the queue DQN--A2C comparison crosses the margin at 200 new seeds, whereas the
other 14 cells remain unresolved at 400. This is useful evidence about the
cost of resolving one disclosed effect under frozen procedures, but it does
not change the primary v3 estimand or establish a general seed budget.

The v5 extension broadens that diagnostic to the full frozen task family:
four comparisons resolve at 200 or 800 new seeds, while eleven remain
unresolved at 1,000. This supports the narrower conclusion that conservative
resolution cost varies across task and algorithm pairs. It does not support a
general superiority claim, a universal 1,000-seed sufficiency statement, or
external reproducibility.

The v6 extension tests execution on two additional discrete tasks under a
separate family allocation. All six comparisons remain unresolved at 200
seeds, and CliffWalking is at the normalized floor under the short training
budget. This broadens the implementation audit while also showing why adding
tasks without changing the training horizon cannot be treated as evidence of
task-family generalization.

Finally, the feasibility audit provides a reproducible pre-data decision point.
For v3 it would have flagged the 20-seed cap as unable to reach either
registered threshold before any RL result was observed. The audit therefore
adds a protocol-design contribution to the empirical record: it makes the
cost of the chosen certificate visible before the experiment begins, while
leaving empirical power, task-family validity, and independence assumptions as
separate questions.

## 11. Declarations


**Author contributions.** Conceptualization, methodology, software,
investigation, formal analysis, visualization, and writing: [author
information to be completed].

**Funding.** Funding information: [to be completed]. No funding source is
asserted by the current workspace records.

**Competing interests.** The authors declare [to be completed].

**Data and code availability.** Source scripts, preregistration files, raw
seed-level CSV files, JSON summaries, the returned Windows raw output and
metadata, archived arm64 wheels, and audit commands are organized in this
research workspace. A public repository DOI or URL has not yet been assigned
and must be added before submission `[待补充]`. The package distinguishes
same-machine cross-script repeatability, different-machine reproducibility of
the frozen protocol, and scientific replication on a new task family.

**Ethics and broader impact.** The study uses simulated control environments
and contains no human participants, personal data, or animal subjects. The
custom queue is explicitly a controlled diagnostic and is not presented as a
real-world deployment or policy recommendation. The main foreseeable impact
is methodological: readers may overgeneralize a conservative interval or the
fixed task family if the stated estimand and limitations are ignored.


## Supplementary material boundary

The full audited v3 manuscript and post-v3 diagnostics remain in `MANUSCRIPT_DRAFT_V3.md` and the submission archive. The following items are supplementary, exploratory, or scope diagnostics and are not pooled into the primary v3 estimand: calibration-grid results, alternative intervals, normalization and threshold sensitivity, training-budget and evaluation-episode changes, partial-observation and continuous-control extensions, the queue follow-up, and v4/v5 new-seed resolution-cost extensions. Their raw data, preregistrations, and audits remain available for peer review.
## References


Citation keys `[L1]`--`[L16]` refer to the verified records in
`REFERENCES_VERIFIED.bib` and `LITERATURE_VERIFICATION.md`. Stable-Baselines3
software citation metadata is verified as [L12]; any venue or indexing claim
not present in those records remains `[待核实]`.

[L1] Henderson, P., Islam, R., Bachman, P., Pineau, J., Precup, D., & Meger,
D. (2018). Deep Reinforcement Learning That Matters. *Proceedings of the AAAI
Conference on Artificial Intelligence*, 32(1). DOI:
10.1609/aaai.v32i1.11694.

[L2] Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2018). How Many Random Seeds?
Statistical Power Analysis in Deep Reinforcement Learning Experiments.
arXiv:1806.08295. DOI: 10.48550/arXiv.1806.08295.

[L3] Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2019). A Hitchhiker's Guide to
Statistical Comparisons of Reinforcement Learning Algorithms. arXiv:1904.06979.
DOI: 10.48550/arXiv.1904.06979.

[L4] Agarwal, R., Schwarzer, M., Castro, P. S., Courville, A., & Bellemare,
M. G. (2021). Deep Reinforcement Learning at the Edge of the Statistical
Precipice. arXiv:2108.13264. DOI: 10.48550/arXiv.2108.13264. Final venue
status `[待核实]`.

[L5] Hoeffding, W. (1963). Probability Inequalities for Sums of Bounded Random
Variables. *Journal of the American Statistical Association*, 58(301), 13--30.
DOI: 10.1080/01621459.1963.10500830.

[L6] Lan, K. K. G., & DeMets, D. L. (1983). Discrete Sequential Boundaries for
Clinical Trials. *Biometrika*, 70(3), 659--663. DOI: 10.1093/biomet/70.3.659.

[L7] Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017).
Proximal Policy Optimization Algorithms. arXiv:1707.06347.

[L8] Mnih, V., et al. (2015). Human-level control through deep reinforcement
learning. *Nature*, 518, 529--533. DOI: 10.1038/nature14236.

[L9] Mnih, V., et al. (2016). Asynchronous Methods for Deep Reinforcement
Learning. *Proceedings of the 33rd International Conference on Machine
Learning*. arXiv:1602.01783.

[L10] Towers, M., et al. (2025). Gymnasium: A Standard Interface for
Reinforcement Learning Environments. *Advances in Neural Information
Processing Systems 38*, 163114--163129. DOI: 10.52202/085713-4916.

[L11] Whiteson, S., Tanner, B., Taylor, M. E., & Stone, P. (2011). Protecting
against evaluation overfitting in empirical reinforcement learning. *2011 IEEE
Symposium on Adaptive Dynamic Programming and Reinforcement Learning (ADPRL)*,
120--127. DOI: 10.1109/ADPRL.2011.5967363. Full-text method comparison
`[待核实]`.

[L12] Raffin, A., Hill, A., Gleave, A., Kanervisto, A., Ernestus, M., & Dorman,
N. (2021). Stable-Baselines3: Reliable Reinforcement Learning Implementations.
*Journal of Machine Learning Research*, 22(268), 1--8.
https://jmlr.org/papers/v22/20-1364.html.

[L13] Zhang, C., Vinyals, O., Munos, R., & Bengio, S. (2018). A Study on
Overfitting in Deep Reinforcement Learning. arXiv:1804.06893v2. DOI:
10.48550/arXiv.1804.06893.

[L14] Nagarajan, P., Warnell, G., & Stone, P. (2018). Deterministic
Implementations for Reproducibility in Deep Reinforcement Learning.
arXiv:1809.05676v5. DOI: 10.48550/arXiv.1809.05676.

[L15] Chan, S. C. Y., Fishman, S., Canny, J., Korattikara, A., & Guadarrama,
S. (2019). Measuring the Reliability of Reinforcement Learning Algorithms.
arXiv:1912.05663v2. DOI: 10.48550/arXiv.1912.05663.

[L16] Khamaru, K., Xia, E., Wainwright, M. J., & Jordan, M. I. (2022).
Instance-Dependent Confidence and Early Stopping for Reinforcement Learning.
arXiv:2201.08536. DOI: 10.48550/arXiv.2201.08536.

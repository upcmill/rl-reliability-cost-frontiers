#!/usr/bin/env python3
"""Audit the analytic family-size planning artifact."""

from __future__ import annotations

import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    payload = json.loads((ROOT / "DESIGN_PLANNING_SENSITIVITY_V3.json").read_text(encoding="utf-8"))
    assert payload["status"] == "analytic_family_size_sensitivity_only"
    assumptions = payload["assumptions"]
    sizes = assumptions["family_sizes"]
    looks = assumptions["looks"]
    rows = payload["rows"]
    assert len(rows) == len(sizes) * len(looks)
    assert all(0.0 < row["comparison_alpha"] < 1.0 for row in rows)
    for look in looks:
        values = [row["radius_sum"] for row in rows if row["look"] == look]
        assert values == sorted(values)
    for size in sizes:
        values = [row["radius_sum"] for row in rows if row["comparisons"] == size]
        assert values == sorted(values, reverse=True)
    final = [row for row in rows if row["look"] == looks[-1] and row["comparisons"] == 15][0]
    expected_alpha = 0.05 / 15.0 * 6.0 / (math.pi * math.pi * looks[-1] ** 2)
    expected_radius = 2.0 * math.sqrt(math.log(4.0 / expected_alpha) / (2.0 * (looks[-1] * 5)))
    assert abs(final["comparison_alpha"] - 0.05 / 15.0) < 1e-15
    assert abs(final["radius_sum"] - expected_radius) < 1e-12
    assert (ROOT / "DESIGN_PLANNING_SENSITIVITY_V3.md").read_text(encoding="utf-8").count("| ") >= 6
    print("design planning sensitivity audit: PASS")
    print(f"family_sizes={sizes} looks={looks} rows={len(rows)}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Check the planned public archive for local paths and credential markers."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import build_submission_bundle


ROOT = Path(__file__).resolve().parent
TEXT_SUFFIXES = {
    ".md", ".txt", ".json", ".csv", ".py", ".yaml", ".yml", ".toml",
    ".bib", ".cff", ".html", ".xml", ".log", ".sha256", ".tsv",
}
PATTERNS = {
    "absolute_user_path": re.compile(b"/" + b"Users/"),
    "absolute_private_path": re.compile(b"/" + b"private/"),
    "private_key": re.compile(rb"BEGIN (?:RSA|OPENSSH|EC|DSA) PRIVATE KEY"),
    "aws_access_key": re.compile(rb"AKIA[0-9A-Z]{16}"),
}
GENERATED_OUTPUTS = {
    "PUBLIC_ARCHIVE_SANITIZATION_AUDIT.md",
    "PUBLIC_ARCHIVE_SANITIZATION_AUDIT.json",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    hits: list[dict[str, str]] = []
    missing: list[str] = []
    scanned = 0
    for relative in build_submission_bundle.INCLUDE:
        path = ROOT / relative
        if not path.is_file() and relative not in GENERATED_OUTPUTS:
            missing.append(relative)
            continue
        if not path.is_file():
            continue
        if path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        scanned += 1
        data = path.read_bytes()
        for name, pattern in PATTERNS.items():
            if pattern.search(data):
                hits.append({"file": relative, "pattern": name})

    result = {
        "schema": "public-archive-safety-audit-v1",
        "status": "PASS" if not hits and not missing else "FAIL",
        "planned_archive_member_count": len(build_submission_bundle.INCLUDE),
        "text_files_scanned": scanned,
        "missing_members": missing,
        "sensitive_hits": hits,
        "builder_sha256": sha256(ROOT / "build_submission_bundle.py"),
    }
    (ROOT / "PUBLIC_ARCHIVE_SANITIZATION_AUDIT.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    lines = [
        "# Public Archive Sanitization Audit",
        "",
        "This audit scans the exact member list used by `build_submission_bundle.py`.",
        "It checks text files for local absolute paths, private-key markers, and a",
        "common AWS access-key pattern. It does not prove that an external host",
        "has no credentials or that the archive is legally publishable.",
        "",
        f"- Planned members: {len(build_submission_bundle.INCLUDE)}",
        f"- Text files scanned: {scanned}",
        f"- Missing members: {len(missing)}",
        f"- Sensitive hits: {len(hits)}",
        f"- Status: **{result['status']}**",
        "",
        "The current planned member set contains no detected local path, private",
        "key marker, or AWS access-key marker. Author, license, and public-archive",
        "metadata remain separate submission gates.",
    ]
    (ROOT / "PUBLIC_ARCHIVE_SANITIZATION_AUDIT.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))
    if result["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()

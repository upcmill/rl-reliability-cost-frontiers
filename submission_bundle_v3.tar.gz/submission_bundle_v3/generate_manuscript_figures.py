"""Create publication-ready, data-derived figures without external plotting packages."""

from __future__ import annotations

import csv
import html
import json
import math
import subprocess
import struct
import zlib
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "manuscript_figures"
FIG.mkdir(exist_ok=True)


# Small built-in bitmap font keeps figure generation dependency-free.
FONT = {
    " ": ["00000"] * 7,
    "-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
    ".": ["00000", "00000", "00000", "00000", "00000", "01100", "01100"],
}
for ch, rows in {
    "0":"01110 10001 10011 10101 11001 10001 01110", "1":"00100 01100 00100 00100 00100 00100 01110",
    "2":"01110 10001 00001 00010 00100 01000 11111", "3":"11110 00001 00001 01110 00001 00001 11110",
    "4":"00010 00110 01010 10010 11111 00010 00010", "5":"11111 10000 10000 11110 00001 00001 11110",
    "6":"00110 01000 10000 11110 10001 10001 01110", "7":"11111 00001 00010 00100 01000 01000 01000",
    "8":"01110 10001 10001 01110 10001 10001 01110", "9":"01110 10001 10001 01111 00001 00010 11100",
}.items(): FONT[ch] = rows.split()
for ch, rows in {
    "A":"01110 10001 10001 11111 10001 10001 10001", "B":"11110 10001 10001 11110 10001 10001 11110",
    "C":"01111 10000 10000 10000 10000 10000 01111", "D":"11110 10001 10001 10001 10001 10001 11110",
    "E":"11111 10000 10000 11110 10000 10000 11111", "F":"11111 10000 10000 11110 10000 10000 10000",
    "G":"01111 10000 10000 10111 10001 10001 01111", "H":"10001 10001 10001 11111 10001 10001 10001",
    "I":"11111 00100 00100 00100 00100 00100 11111", "J":"00111 00010 00010 00010 10010 10010 01100",
    "K":"10001 10010 10100 11000 10100 10010 10001", "L":"10000 10000 10000 10000 10000 10000 11111",
    "M":"10001 11011 10101 10101 10001 10001 10001", "N":"10001 11001 10101 10011 10001 10001 10001",
    "O":"01110 10001 10001 10001 10001 10001 01110", "P":"11110 10001 10001 11110 10000 10000 10000",
    "Q":"01110 10001 10001 10001 10101 10010 01101", "R":"11110 10001 10001 11110 10100 10010 10001",
    "S":"01111 10000 10000 01110 00001 00001 11110", "T":"11111 00100 00100 00100 00100 00100 00100",
    "U":"10001 10001 10001 10001 10001 10001 01110", "V":"10001 10001 10001 10001 10001 01010 00100",
    "W":"10001 10001 10001 10101 10101 11011 10001", "X":"10001 10001 01010 00100 01010 10001 10001",
    "Y":"10001 10001 01010 00100 00100 00100 00100", "Z":"11111 00001 00010 00100 01000 10000 11111",
}.items(): FONT[ch] = rows.split()


class Raster:
    def __init__(self, width: int, height: int, bg=(255, 255, 255)):
        self.width, self.height = width, height
        self.px = [[list(bg) for _ in range(width)] for _ in range(height)]

    def color(self, value):
        if isinstance(value, str) and value.startswith("#"):
            return tuple(int(value[i:i+2], 16) for i in (1, 3, 5))
        return value

    def set(self, x, y, color):
        if 0 <= x < self.width and 0 <= y < self.height: self.px[y][x] = list(self.color(color))

    def line(self, x1, y1, x2, y2, color="#30343b", width=1):
        dx, dy = abs(x2-x1), abs(y2-y1); sx = 1 if x1 < x2 else -1; sy = 1 if y1 < y2 else -1; err = dx-dy
        while True:
            for ox in range(-width//2, width//2+1):
                for oy in range(-width//2, width//2+1): self.set(x1+ox, y1+oy, color)
            if x1 == x2 and y1 == y2: break
            e2 = 2*err
            if e2 > -dy: err -= dy; x1 += sx
            if e2 < dx: err += dx; y1 += sy

    def rect(self, x, y, w, h, fill, outline=None):
        for yy in range(max(0, y), min(self.height, y+h)):
            for xx in range(max(0, x), min(self.width, x+w)): self.set(xx, yy, fill)
        if outline:
            self.line(x, y, x+w-1, y, outline); self.line(x, y+h-1, x+w-1, y+h-1, outline)
            self.line(x, y, x, y+h-1, outline); self.line(x+w-1, y, x+w-1, y+h-1, outline)

    def circle(self, cx, cy, radius, fill):
        r2 = radius * radius
        for y in range(cy-radius, cy+radius+1):
            for x in range(cx-radius, cx+radius+1):
                if (x-cx)**2 + (y-cy)**2 <= r2: self.set(x, y, fill)

    def text(self, x, y, value, color="#20242b", scale=2, center=False):
        value = value.upper(); advance = 6 * scale
        if center: x -= len(value) * advance // 2
        for ch in value:
            glyph = FONT.get(ch, FONT[" "])
            for gy, row in enumerate(glyph):
                for gx, bit in enumerate(row):
                    if bit == "1":
                        for sy in range(scale):
                            for sx in range(scale): self.set(x + gx*scale + sx, y + gy*scale + sy, color)
            x += advance

    def save(self, path: Path):
        raw = b"".join(b"\x00" + bytes(sum(row, [])) for row in self.px)
        def chunk(kind, data):
            return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)
        png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", self.width, self.height, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
        path.write_bytes(png)


def svg(name: str, width: int, height: int, body: str, title: str) -> Path:
    path = FIG / f"{name}.svg"
    content = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<title>{html.escape(title)}</title><rect width="100%" height="100%" fill="white"/>
<style>text{{font-family:Arial,sans-serif;fill:#20242b}} .axis{{stroke:#30343b;stroke-width:1}} .grid{{stroke:#d9dee5;stroke-width:1}} .small{{font-size:12px}} .label{{font-size:13px}} .title{{font-size:17px;font-weight:bold}} .note{{font-size:11px;fill:#5b6572}}</style>
{body}</svg>'''
    path.write_text(content, encoding="utf-8")
    png = FIG / f"{name}.png"
    try:
        subprocess.run(["sips", "-s", "format", "png", str(path), "--out", str(png)], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except (FileNotFoundError, subprocess.CalledProcessError):
        pass
    return png if png.exists() else path


def text(x: float, y: float, value: str, cls: str = "small", anchor: str = "start") -> str:
    return f'<text x="{x:.1f}" y="{y:.1f}" class="{cls}" text-anchor="{anchor}">{html.escape(value)}</text>'


def line(x1: float, y1: float, x2: float, y2: float, cls: str = "axis") -> str:
    return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" class="{cls}"/>'


def rect(x: float, y: float, w: float, h: float, fill: str, stroke: str = "none", opacity: float = 1) -> str:
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{fill}" stroke="{stroke}" opacity="{opacity}"/>'


def circle(x: float, y: float, r: float, fill: str, stroke: str = "none") -> str:
    return f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" fill="{fill}" stroke="{stroke}"/>'


def protocol() -> Path:
    boxes = [
        (55, 100, 220, 62, "Candidate grid\n4 configurations"),
        (335, 100, 220, 62, "Validation\n5 seeds per candidate"),
        (615, 100, 220, 62, "Freeze selected\nconfiguration"),
        (895, 100, 220, 62, "Sealed test\nseeds 20000–20019"),
    ]
    body = [text(585, 45, "Preregistered nested evaluation protocol", "title", "middle")]
    for x, y, w, h, label in boxes:
        body.append(rect(x, y, w, h, "#eaf2fb", "#3c6eaa"))
        for j, part in enumerate(label.split("\n")):
            body.append(text(x + w / 2, y + 27 + j * 18, part, "label", "middle"))
    for x1, x2 in [(275, 335), (555, 615), (835, 895)]:
        body.append(line(x1, 131, x2, 131, "axis"))
        body.append(f'<polygon points="{x2-8},125 {x2},131 {x2-8},137" fill="#30343b"/>')
    body.append(rect(235, 240, 230, 68, "#f7f3df", "#9a7b18"))
    body.append(text(350, 267, "Looks: 5, 10, 15, 20", "label", "middle"))
    body.append(text(350, 288, "finite-look alpha spending", "small", "middle"))
    body.append(rect(645, 240, 230, 68, "#f7f3df", "#9a7b18"))
    body.append(text(760, 267, "Hoeffding unpaired interval", "label", "middle"))
    body.append(text(760, 288, "family alpha = 0.05 / 15", "small", "middle"))
    body.append(line(465, 274, 645, 274, "axis"))
    body.append(text(585, 355, "Terminal outcomes: superiority, target precision, or max_budget_inconclusive", "note", "middle"))
    return svg("fig_protocol", 1170, 390, "".join(body), "Preregistered nested evaluation protocol")


def intervals() -> Path:
    data = json.loads((ROOT / "sb3_formal_v3/familywise_cost_summary.json").read_text())['rows']
    left, right, top, bottom = 205, 1110, 62, 560
    body = [text(585, 28, "15 primary comparisons: estimate and family-adjusted interval", "title", "middle")]
    for tick in [-1, -0.5, 0, 0.5, 1]:
        x = left + (tick + 1) / 2 * (right - left)
        body += [line(x, top, x, bottom, "grid"), text(x, bottom + 23, f"{tick:.1f}", "small", "middle")]
    body.append(line(left, bottom, right, bottom, "axis"))
    body.append(text((left + right) / 2, 610, "Normalized difference (A − B)", "label", "middle"))
    row_h = (bottom - top - 20) / len(data)
    colors = {"PPO_vs_DQN": "#2a6fbb", "PPO_vs_A2C": "#2a9d8f", "DQN_vs_A2C": "#d97732"}
    for i, row in enumerate(data):
        y = top + 20 + i * row_h
        label = f"{row['env_id'].replace('NonstationaryQueue','Queue')} {row['comparison'].replace('_vs_', '−')}"
        body.append(text(left - 10, y + 4, label, "small", "end"))
        x1 = left + (max(-1, row['lower']) + 1) / 2 * (right - left)
        x2 = left + (min(1, row['upper']) + 1) / 2 * (right - left)
        xm = left + (row['estimate'] + 1) / 2 * (right - left)
        color = colors.get(row['comparison'], "#555")
        body += [line(x1, y, x2, y, "axis"), line(x1, y - 5, x1, y + 5, "axis"), line(x2, y - 5, x2, y + 5, "axis"), circle(xm, y, 4, color)]
    body.append(line(left + (0 + 1) / 2 * (right - left), top, left + (0 + 1) / 2 * (right - left), bottom, "axis"))
    body.append(text(585, 645, "All 15 decisions were max_budget_inconclusive at n = 20; intervals are clipped to [−1, 1].", "note", "middle"))
    return svg("fig_intervals", 1170, 680, "".join(body), "Primary comparison intervals")


def heatmap() -> Path:
    rows = json.loads((ROOT / "sb3_formal_v3/descriptive_summary.json").read_text())['rows']
    envs = ["CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "Queue-v0"]
    algos = ["PPO", "DQN", "A2C"]
    vals = {(r['env_id'].replace('NonstationaryQueue-v0', 'Queue-v0'), r['algorithm']): r['test']['mean'] for r in rows}
    left, top, cell_w, cell_h = 280, 80, 205, 68
    body = [text(585, 30, "Descriptive normalized test means (n = 20 per cell)", "title", "middle")]
    body.append(text(585, 560, "Fixed-budget descriptive display; not an algorithm ranking.", "note", "middle"))
    for j, a in enumerate(algos):
        body.append(text(left + cell_w * j + cell_w / 2, top - 20, a, "label", "middle"))
    for i, e in enumerate(envs):
        y = top + i * cell_h
        body.append(text(left - 14, y + cell_h / 2 + 5, e, "label", "end"))
        for j, a in enumerate(algos):
            v = vals[(e, a)]
            fill = f"rgb({int(245 - 145*v)},{int(247 - 90*v)},{int(250 - 35*v)})"
            body.append(rect(left + j * cell_w, y, cell_w - 4, cell_h - 4, fill, "#ffffff"))
            body.append(text(left + j * cell_w + cell_w / 2 - 2, y + cell_h / 2 + 5, f"{v:.3f}", "label", "middle"))
    return svg("fig_heatmap", 1170, 590, "".join(body), "Descriptive normalized test means")


def budget_frontier() -> Path:
    rows = json.loads((ROOT / "unpaired_budget_requirements.json").read_text())['rows']
    left, right, top, bottom = 100, 1110, 60, 430
    xs = [5, 10, 15, 20, 50, 100]
    widths = []
    # Analytic equal-sample width using the recorded alpha schedule at each look.
    for n in xs:
        k = min(4, max(1, n // 5))
        alpha_look = 0.05 / 15 * 6 / (math.pi ** 2 * k ** 2)
        widths.append(2 * math.sqrt(math.log(4 / alpha_look) / (2 * n)) * 2)
    ymax = max(widths) * 1.08
    body = [text(585, 28, "Analytic Hoeffding width versus test seeds per algorithm", "title", "middle")]
    def px(n): return left + (n - 5) / 95 * (right - left)
    def py(w): return bottom - w / ymax * (bottom - top)
    for w in [0, 0.5, 1.0, 1.5, 2.0]:
        y = py(w); body += [line(left, y, right, y, "grid"), text(left - 10, y + 4, f"{w:.1f}", "small", "end")]
    body += [line(left, bottom, right, bottom, "axis"), line(left, top, left, bottom, "axis")]
    points = []
    for n, w in zip(xs, widths):
        points.append(f"{px(n):.1f},{py(w):.1f}")
        body.append(circle(px(n), py(w), 4, "#2a6fbb"))
        body.append(text(px(n), bottom + 22, str(n), "small", "middle"))
    body.append(f'<polyline points="{" ".join(points)}" fill="none" stroke="#2a6fbb" stroke-width="3"/>')
    body.append(line(left, py(0.1), right, py(0.1), "axis"))
    body.append(text(right - 4, py(0.1) - 8, "target width = 0.10", "small", "end"))
    body.append(text(585, 485, "Planning diagnostic under [0,1] bounded metrics; not an observed requirement or lower bound.", "note", "middle"))
    body.append(text(585, 515, "The plotted curve uses the predeclared finite-look spending schedule and equal sample sizes.", "note", "middle"))
    return svg("fig_budget_frontier", 1170, 540, "".join(body), "Analytic Hoeffding width")


def tuning_stability() -> Path:
    """Show which cells changed after doubling validation seeds."""
    primary = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text())["summary"]
    diagnostic = json.loads((ROOT / "sb3_tuning_strength_v3/summary.json").read_text())["summary"]
    envs = ["CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "Queue-v0"]
    algos = ["PPO", "DQN", "A2C"]
    left, top, cell_w, cell_h = 250, 90, 270, 70
    body = [text(585, 30, "Tuning selection stability: 5 versus 10 validation seeds", "title", "middle")]
    body.append(text(585, 56, "Post-hoc diagnostic; red cells changed selected configuration (4/15).", "note", "middle"))
    for j, algo in enumerate(algos):
        body.append(text(left + j * cell_w + cell_w / 2, top - 22, algo, "label", "middle"))
    changed = 0
    for i, env in enumerate(envs):
        key_env = "NonstationaryQueue-v0" if env == "Queue-v0" else env
        y = top + i * cell_h
        body.append(text(left - 16, y + cell_h / 2 + 5, env, "label", "end"))
        for j, algo in enumerate(algos):
            key = f"{key_env}:{algo}"
            before = primary[key]["selected_config"]
            after = diagnostic[key]["selected_config"]
            is_changed = before != after
            changed += int(is_changed)
            fill = "#f7d7d2" if is_changed else "#e6f2e8"
            stroke = "#a83c32" if is_changed else "#4d8b5a"
            x = left + j * cell_w
            body.append(rect(x, y, cell_w - 8, cell_h - 8, fill, stroke))
            body.append(text(x + (cell_w - 8) / 2, y + 26, before, "small", "middle"))
            body.append(text(x + (cell_w - 8) / 2, y + 47, "-> " + after, "small", "middle"))
    body.append(text(585, 485, f"Changed cells: {changed}/15 = {changed / 15:.4f}; selection is part of the conditional estimand.", "note", "middle"))
    return svg("fig_tuning_stability", 1170, 525, "".join(body), "Tuning selection stability")


def normalization_sensitivity() -> Path:
    """Show the maximum-budget inconclusive count for each raw-return scale."""
    payload = json.loads((ROOT / "v3_normalization_sensitivity.json").read_text())
    entries = list(payload["results"].items())
    left, right, top, bottom = 105, 1110, 70, 430
    body = [text(585, 30, "Normalization sensitivity: unresolved comparisons", "title", "middle")]
    body.append(text(585, 52, "Post-hoc diagnostic; each bar is the number of 15 comparisons at maximum-budget inconclusive.", "note", "middle"))
    def px(i): return left + (i + 0.5) / len(entries) * (right - left)
    def py(v): return bottom - v / 15 * (bottom - top)
    for tick in [0, 5, 10, 15]:
        y = py(tick)
        body += [line(left, y, right, y, "grid"), text(left - 10, y + 4, str(tick), "small", "end")]
    body += [line(left, bottom, right, bottom, "axis"), line(left, top, left, bottom, "axis")]
    for i, (name, row) in enumerate(entries):
        count = row["decision_counts"].get("max_budget_inconclusive", 0)
        x = px(i)
        y = py(count)
        body.append(rect(x - 28, y, 56, bottom - y, "#6b8fb3", "#3d6389"))
        short = "BASE" if name == "baseline" else name.replace("NonstationaryQueue-v0", "QUEUE").replace("-v1", "").replace("-v0", "").replace(":", " ")
        body.append(text(x, bottom + 22, short, "small", "middle"))
        body.append(text(x, y - 8, str(count), "small", "middle"))
    body.append(text(585, 485, "All 11 schemes produced 15/15 maximum-budget inconclusive decisions.", "note", "middle"))
    return svg("fig_normalization_sensitivity", 1170, 525, "".join(body), "Normalization sensitivity")


def budget_scaling() -> Path:
    """Compare descriptive means at the v3 and 16,384-step budgets."""
    primary = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text())["summary"]
    scaled = json.loads((ROOT / "sb3_budget_scaling_v3/summary.json").read_text())["summary"]
    envs = ["CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "Queue-v0"]
    algos = ["PPO", "DQN", "A2C"]
    colors = {"PPO": "#2a6fbb", "DQN": "#d97732", "A2C": "#2a9d8f"}
    left, right, top, bottom = 125, 1110, 72, 440
    body = [text(585, 30, "Descriptive means at 4,096 versus 16,384 training steps", "title", "middle")]
    body.append(text(585, 54, "Fixed v3 selections; supplementary budget diagnostic, not a pooled comparison.", "note", "middle"))
    for i, (algo, color) in enumerate(colors.items()):
        x = 450 + i * 105
        body.append(rect(x, 62, 12, 12, color, "none"))
        body.append(text(x + 18, 73, algo, "small"))
    def py(v): return bottom - v * (bottom - top)
    for tick in [0, 0.25, 0.5, 0.75, 1.0]:
        y = py(tick)
        body += [line(left, y, right, y, "grid"), text(left - 10, y + 4, f"{tick:.2f}", "small", "end")]
    body += [line(left, bottom, right, bottom, "axis"), line(left, top, left, bottom, "axis")]
    group_w = (right - left) / len(envs)
    bar_w = 18
    for i, env in enumerate(envs):
        key_env = "NonstationaryQueue-v0" if env == "Queue-v0" else env
        gx = left + i * group_w + group_w / 2
        body.append(text(gx, bottom + 24, env, "small", "middle"))
        for j, algo in enumerate(algos):
            key = f"{key_env}:{algo}"
            v0 = sum(primary[key]["test_metrics"]) / len(primary[key]["test_metrics"])
            v1 = sum(scaled[key]["test_metrics"]) / len(scaled[key]["test_metrics"])
            x = gx - 44 + j * 44
            body.append(rect(x - bar_w / 2, py(v0), bar_w, bottom - py(v0), colors[algo], "none", 0.45))
            body.append(rect(x + bar_w / 2, py(v1), bar_w, bottom - py(v1), colors[algo], "none", 1.0))
    body.append(text(585, 495, "Faint bars: 4,096 steps; solid bars: 16,384 steps. Values are descriptive means.", "note", "middle"))
    body.append(text(585, 518, "All 15 family-level decisions remained max_budget_inconclusive at both budgets.", "note", "middle"))
    return svg("fig_budget_scaling", 1170, 545, "".join(body), "Training budget scaling")


def eval_episode_sensitivity() -> Path:
    """Show matched-seed metric changes when evaluation episodes double."""
    primary = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text())["summary"]
    diagnostic = json.loads((ROOT / "sb3_eval_episode_sensitivity_v3/summary.json").read_text())["summary"]
    entries = []
    for key, row in diagnostic.items():
        before = primary[key]["test_metrics"]
        after = row["test_metrics"]
        entries.append((key.replace("NonstationaryQueue-v0", "Queue-v0"), sum(abs(x-y) for x, y in zip(before, after)) / len(before)))
    entries.sort()
    env_short = {"CartPole-v1": "CP", "Acrobot-v1": "AC", "MountainCar-v0": "MC", "Taxi-v4": "TX", "Queue-v0": "Q"}
    left, right, top, bottom = 255, 1110, 60, 490
    body = [text(585, 28, "Matched-seed sensitivity to evaluation episodes", "title", "middle")]
    body.append(text(585, 50, "Mean absolute normalized-metric change: 5 versus 10 episodes per checkpoint.", "note", "middle"))
    ymax = max(v for _, v in entries) * 1.18
    def px(i): return left + (i + 0.5) / len(entries) * (right - left)
    def py(v): return bottom - v / ymax * (bottom - top)
    body += [line(left, bottom, right, bottom, "axis"), line(left, top, left, bottom, "axis")]
    for i, (label, value) in enumerate(entries):
        x = px(i)
        y = py(value)
        body.append(rect(x - 15, y, 30, bottom - y, "#6b8fb3", "#3d6389"))
        env, algo = label.split(":")
        body.append(text(x, bottom + 22, f"{env_short.get(env, env)}-{algo}", "small", "middle"))
        body.append(text(x, y - 8, f"{value:.3f}", "small", "middle"))
    body.append(text(585, 535, "All 15 family-level decisions remained max_budget_inconclusive.", "note", "middle"))
    return svg("fig_eval_episode_sensitivity", 1170, 565, "".join(body), "Evaluation-episode sensitivity")


def png_protocol() -> Path:
    r = Raster(1170, 390); r.text(585, 20, "PREREGISTERED NESTED EVALUATION PROTOCOL", scale=3, center=True)
    boxes = [(55, 100, "CANDIDATE GRID", "4 CONFIGURATIONS"), (335, 100, "VALIDATION", "5 SEEDS / CANDIDATE"),
             (615, 100, "FREEZE SELECTED", "CONFIGURATION"), (895, 100, "SEALED TEST", "SEEDS 20000-20019")]
    for x, y, a, b in boxes:
        r.rect(x, y, 220, 62, "#eaf2fb", "#3c6eaa"); r.text(x+110, y+18, a, scale=2, center=True); r.text(x+110, y+38, b, scale=1, center=True)
    for x in (275, 555, 835): r.line(x, 131, x+60, 131); r.line(x+52, 125, x+60, 131); r.line(x+52, 137, x+60, 131)
    r.rect(235, 240, 230, 68, "#f7f3df", "#9a7b18"); r.text(350, 260, "LOOKS: 5 10 15 20", scale=2, center=True); r.text(350, 282, "FINITE-LOOK ALPHA", scale=1, center=True)
    r.rect(645, 240, 230, 68, "#f7f3df", "#9a7b18"); r.text(760, 260, "HOEFFDING INTERVAL", scale=2, center=True); r.text(760, 282, "FAMILY ALPHA 0.05 / 15", scale=1, center=True)
    r.line(465, 274, 645, 274); r.text(585, 350, "TERMINAL: SUPERIORITY / PRECISION / MAX BUDGET INCONCLUSIVE", scale=1, center=True)
    out = FIG / "fig_protocol.png"; r.save(out); return out


def png_intervals() -> Path:
    data = json.loads((ROOT / "sb3_formal_v3/familywise_cost_summary.json").read_text())['rows']; r = Raster(1170, 680)
    left, right, top, bottom = 285, 1110, 62, 560; r.text(585, 18, "15 PRIMARY COMPARISONS: ESTIMATE AND FAMILY-ADJUSTED INTERVAL", scale=2, center=True)
    for tick in [-1, -.5, 0, .5, 1]:
        x = int(left + (tick+1)/2*(right-left)); r.line(x, top, x, bottom, "#d9dee5"); r.text(x-10, bottom+15, f"{tick:.1f}", scale=1, center=True)
    rh=(bottom-top-20)/len(data)
    colors={"PPO_vs_DQN":"#2a6fbb", "PPO_vs_A2C":"#2a9d8f", "DQN_vs_A2C":"#d97732"}
    for i,row in enumerate(data):
        y=int(top+20+i*rh); label=f"{row['env_id'].replace('NonstationaryQueue','Queue')} {row['comparison'].replace('_vs_','-')}"; r.text(8, y-4, label, scale=1, center=False)
        x1=int(left+(max(-1,row['lower'])+1)/2*(right-left)); x2=int(left+(min(1,row['upper'])+1)/2*(right-left)); xm=int(left+(row['estimate']+1)/2*(right-left)); r.line(x1,y,x2,y); r.line(x1,y-5,x1,y+5); r.line(x2,y-5,x2,y+5); r.circle(xm,y,4,colors[row['comparison']])
    x0=int(left+(right-left)/2); r.line(x0,top,x0,bottom); r.text(585, 615, "NORMALIZED DIFFERENCE (A - B)", scale=2, center=True); r.text(585, 650, "All 15 decisions were max_budget_inconclusive at n = 20; intervals clipped to [-1, 1].", scale=1, center=True)
    out=FIG/"fig_intervals.png"; r.save(out); return out


def png_heatmap() -> Path:
    rows=json.loads((ROOT/"sb3_formal_v3/descriptive_summary.json").read_text())['rows']; vals={(x['env_id'].replace('NonstationaryQueue-v0','Queue-v0'),x['algorithm']):x['test']['mean'] for x in rows}; envs=['CartPole-v1','Acrobot-v1','MountainCar-v0','Taxi-v4','Queue-v0']; algos=['PPO','DQN','A2C']; r=Raster(1170,590); left,top,cw,ch=330,80,190,68
    r.text(585,20,"DESCRIPTIVE NORMALIZED TEST MEANS (N = 20 PER CELL)",scale=2,center=True)
    for j,a in enumerate(algos): r.text(left+j*cw+cw//2-2, top-25, a, scale=2, center=True)
    for i,e in enumerate(envs):
        y=top+i*ch; r.text(10,y+ch//2-6,e,scale=1)
        for j,a in enumerate(algos):
            v=vals[(e,a)]; fill=(int(245-145*v),int(247-90*v),int(250-35*v)); r.rect(left+j*cw,y,cw-4,ch-4,fill,"#ffffff"); r.text(left+j*cw+cw//2-2,y+ch//2-6,f"{v:.3f}",scale=2,center=True)
    r.text(585,555,"FIXED-BUDGET DESCRIPTIVE DISPLAY; NOT AN ALGORITHM RANKING.",scale=1,center=True); out=FIG/"fig_heatmap.png"; r.save(out); return out


def png_budget_frontier() -> Path:
    r=Raster(1170,540); left,right,top,bottom=100,1110,60,430; xs=[5,10,15,20,50,100]; widths=[]
    for n in xs:
        k=min(4,max(1,n//5)); a=.05/15*6/(math.pi**2*k**2); widths.append(4*math.sqrt(math.log(4/a)/(2*n)))
    ymax=max(widths)*1.08; px=lambda n:int(left+(n-5)/95*(right-left)); py=lambda w:int(bottom-w/ymax*(bottom-top)); r.text(585,18,"ANALYTIC HOEFFDING WIDTH VERSUS TEST SEEDS",scale=2,center=True)
    for w in [0,.5,1,1.5,2]: y=py(w); r.line(left,y,right,y,"#d9dee5"); r.text(left-12,y-5,f"{w:.1f}",scale=1)
    r.line(left,bottom,right,bottom); r.line(left,top,left,bottom); prev=None
    for n,w in zip(xs,widths):
        x,y=px(n),py(w); r.circle(x,y,4,"#2a6fbb"); r.text(x,bottom+15,str(n),scale=1,center=True); r.line(prev[0],prev[1],x,y,"#2a6fbb",3) if prev else None; prev=(x,y)
    r.line(left,py(.1),right,py(.1)); r.text(right-5,py(.1)-12,"TARGET WIDTH 0.10",scale=1,center=False); r.text(585,485,"PLANNING DIAGNOSTIC UNDER [0,1] BOUNDED METRICS; NOT AN OBSERVED REQUIREMENT.",scale=1,center=True); r.text(585,515,"PREDECLARED FINITE-LOOK SPENDING AND EQUAL SAMPLE SIZES.",scale=1,center=True); out=FIG/"fig_budget_frontier.png"; r.save(out); return out


def png_tuning_stability() -> Path:
    primary = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text())["summary"]
    diagnostic = json.loads((ROOT / "sb3_tuning_strength_v3/summary.json").read_text())["summary"]
    envs = ["CARTPOLE", "ACROBOT", "MOUNTAINCAR", "TAXI", "QUEUE"]
    env_keys = ["CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0"]
    algos = ["PPO", "DQN", "A2C"]
    r = Raster(1170, 525); r.text(585, 18, "TUNING STABILITY: 5 VERSUS 10 VALIDATION SEEDS", scale=2, center=True)
    r.text(585, 45, "POST-HOC DIAGNOSTIC: RED CELLS CHANGED SELECTION (4 OF 15)", scale=1, center=True)
    left, top, cw, ch = 250, 90, 270, 70
    for j, algo in enumerate(algos): r.text(left + j*cw + cw//2, top-25, algo, scale=2, center=True)
    changed = 0
    for i, env_key in enumerate(env_keys):
        y = top + i*ch; r.text(10, y+27, envs[i], scale=1)
        for j, algo in enumerate(algos):
            key = f"{env_key}:{algo}"; is_changed = primary[key]["selected_config"] != diagnostic[key]["selected_config"]
            changed += int(is_changed); fill = "#f0b8b0" if is_changed else "#cfe6d2"; outline = "#a83c32" if is_changed else "#4d8b5a"
            x = left + j*cw; r.rect(x, y, cw-8, ch-8, fill, outline)
            r.text(x+(cw-8)//2, y+22, "CHANGED" if is_changed else "STABLE", scale=2 if is_changed else 1, center=True)
    r.text(585, 485, f"CHANGED CELLS: {changed} OF 15 = {changed/15:.4f}", scale=1, center=True)
    out = FIG / "fig_tuning_stability.png"; r.save(out); return out


def png_normalization_sensitivity() -> Path:
    payload = json.loads((ROOT / "v3_normalization_sensitivity.json").read_text())
    entries = list(payload["results"].items())
    r = Raster(1170, 525); left, right, top, bottom = 100, 1110, 70, 430
    r.text(585, 18, "NORMALIZATION SENSITIVITY: UNRESOLVED COMPARISONS", scale=2, center=True)
    r.text(585, 45, "POST-HOC DIAGNOSTIC; EACH BAR COUNTS MAX-BUDGET INCONCLUSIVE COMPARISONS", scale=1, center=True)
    def px(i): return int(left + (i+0.5)/len(entries)*(right-left))
    def py(v): return int(bottom - v/15*(bottom-top))
    for tick in [0, 5, 10, 15]:
        y=py(tick); r.line(left,y,right,y,"#d9dee5"); r.text(left-18,y-4,str(tick),scale=1)
    r.line(left,bottom,right,bottom); r.line(left,top,left,bottom)
    for i,(name,row) in enumerate(entries):
        count=row["decision_counts"].get("max_budget_inconclusive",0); x=px(i); y=py(count)
        r.rect(x-24,y,48,bottom-y,"#6b8fb3","#3d6389"); r.text(x,y-16,str(count),scale=1,center=True)
        r.text(x,bottom+16,"BASE" if name == "baseline" else str(i),scale=1,center=True)
    r.text(585,485,"ALL 11 SCHEMES: 15 OF 15 MAX-BUDGET INCONCLUSIVE",scale=1,center=True)
    out=FIG/"fig_normalization_sensitivity.png"; r.save(out); return out


def png_budget_scaling() -> Path:
    primary = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text())["summary"]
    scaled = json.loads((ROOT / "sb3_budget_scaling_v3/summary.json").read_text())["summary"]
    env_keys = ["CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0"]
    env_labels = ["CARTPOLE", "ACROBOT", "MOUNTAINCAR", "TAXI", "QUEUE"]
    algos = ["PPO", "DQN", "A2C"]
    colors = {"PPO": "#2a6fbb", "DQN": "#d97732", "A2C": "#2a9d8f"}
    r = Raster(1170, 545); left, right, top, bottom = 125, 1110, 72, 440
    r.text(585, 18, "DESCRIPTIVE MEANS: 4,096 VERSUS 16,384 TRAINING STEPS", scale=2, center=True)
    r.text(585, 45, "FIXED V3 SELECTIONS; SUPPLEMENTARY DIAGNOSTIC, NOT A POOLED COMPARISON", scale=1, center=True)
    for i, (algo, color) in enumerate(colors.items()):
        x = 450 + i * 105; r.rect(x, 58, 12, 12, color, None); r.text(x + 22, 58, algo, scale=1)
    def py(v): return int(bottom - v * (bottom-top))
    for tick in [0, .25, .5, .75, 1]:
        y=py(tick); r.line(left,y,right,y,"#d9dee5"); r.text(left-18,y-4,f"{tick:.2f}",scale=1)
    r.line(left,bottom,right,bottom); r.line(left,top,left,bottom)
    group_w=(right-left)/len(env_keys); bar_w=18
    for i,key_env in enumerate(env_keys):
        gx=left+i*group_w+group_w/2; r.text(int(gx),bottom+20,env_labels[i],scale=1,center=True)
        for j,algo in enumerate(algos):
            key=f"{key_env}:{algo}"; v0=sum(primary[key]["test_metrics"])/len(primary[key]["test_metrics"]); v1=sum(scaled[key]["test_metrics"])/len(scaled[key]["test_metrics"]); x=int(gx-44+j*44)
            r.rect(x-bar_w//2,py(v0),bar_w,bottom-py(v0),colors[algo],None); r.rect(x+bar_w//2,py(v1),bar_w,bottom-py(v1),colors[algo],None)
    r.text(585,495,"FAINT: 4,096 STEPS; SOLID: 16,384 STEPS. VALUES ARE DESCRIPTIVE MEANS.",scale=1,center=True); r.text(585,518,"ALL 15 FAMILY DECISIONS REMAINED MAX-BUDGET INCONCLUSIVE.",scale=1,center=True)
    out=FIG/"fig_budget_scaling.png"; r.save(out); return out


def png_eval_episode_sensitivity() -> Path:
    primary = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text())["summary"]
    diagnostic = json.loads((ROOT / "sb3_eval_episode_sensitivity_v3/summary.json").read_text())["summary"]
    entries=[]
    for key,row in diagnostic.items():
        before=primary[key]["test_metrics"]; after=row["test_metrics"]
        entries.append((key.replace("NonstationaryQueue-v0","Queue-v0"),sum(abs(x-y) for x,y in zip(before,after))/len(before)))
    entries.sort(); env_short={"CartPole-v1":"CP","Acrobot-v1":"AC","MountainCar-v0":"MC","Taxi-v4":"TX","Queue-v0":"Q"}; r=Raster(1170,565); left,right,top,bottom=255,1110,60,490; ymax=max(v for _,v in entries)*1.18
    r.text(585,18,"EVALUATION-EPISODE SENSITIVITY: 5 VERSUS 10 EPISODES",scale=2,center=True); r.text(585,42,"MEAN ABSOLUTE NORMALIZED-METRIC CHANGE ACROSS MATCHED TRAINING SEEDS",scale=1,center=True)
    r.line(left,bottom,right,bottom); r.line(left,top,left,bottom)
    for i,(label,value) in enumerate(entries):
        x=int(left+(i+.5)/len(entries)*(right-left)); y=int(bottom-value/ymax*(bottom-top)); env,algo=label.split(":"); r.rect(x-15,y,30,bottom-y,"#6b8fb3","#3d6389"); r.text(x,bottom+18,f"{env_short.get(env,env)}-{algo}",scale=1,center=True); r.text(x,y-14,f"{value:.3f}",scale=1,center=True)
    r.text(585,535,"ALL 15 FAMILY DECISIONS REMAINED MAX-BUDGET INCONCLUSIVE.",scale=1,center=True); out=FIG/"fig_eval_episode_sensitivity.png"; r.save(out); return out


def png_selection_uncertainty() -> Path:
    payload = json.loads((ROOT / "validation_selection_uncertainty_v3.json").read_text())
    env_short = {"CartPole-v1": "CP", "Acrobot-v1": "AC", "MountainCar-v0": "MC", "Taxi-v4": "TX", "NonstationaryQueue-v0": "Q"}
    algos = ["PPO", "DQN", "A2C"]
    rows = sorted(payload["rows"], key=lambda row: (list(env_short).index(row["environment"]), algos.index(row["algorithm"])))
    r = Raster(1170, 575); left, right, top, bottom = 115, 1110, 78, 455
    r.text(585, 18, "VALIDATION-SELECTION UNCERTAINTY", scale=2, center=True)
    r.text(585, 45, "20,000 JOINT ROW-BOOTSTRAP REPLICATES; FREQUENCIES ARE DESCRIPTIVE", scale=1, center=True)
    for tick in [0, .25, .5, .75, 1.0]:
        y = int(bottom - tick * (bottom - top)); r.line(left, y, right, y, "#d9dee5"); r.text(left - 18, y - 4, f"{tick:.2f}", scale=1)
    r.line(left, bottom, right, bottom); r.line(left, top, left, bottom); r.line(left, int(bottom - .5 * (bottom - top)), right, int(bottom - .5 * (bottom - top)), "#9a7b18")
    bar_w = 48
    for i, row in enumerate(rows):
        x = int(left + (i + .5) / len(rows) * (right - left))
        value = row["bootstrap_selection_frequency"][row["observed_selected"]]
        y = int(bottom - value * (bottom - top))
        fill = "#2a6fbb" if value >= .5 else "#d97732"
        r.rect(x - bar_w // 2, y, bar_w, bottom - y, fill, "#3d6389")
        label = f"{env_short[row['environment']]}-{row['algorithm']}"
        r.text(x, bottom + 20, label, scale=1, center=True)
        r.text(x, y - 14, f"{value:.2f}", scale=1, center=True)
    r.text(585, 505, "Gold line: 0.50 selection frequency. Values do not estimate global optimality.", scale=1, center=True)
    r.text(585, 535, "The v3 selected configuration remains part of the conditional estimand.", scale=1, center=True)
    out = FIG / "fig_selection_uncertainty.png"; r.save(out); return out


def png_queue_budget_followup() -> Path:
    """Plot the two predeclared looks in the post-v3 queue follow-up."""
    payload = json.loads((ROOT / "QUEUE_BUDGET_FOLLOWUP_AUDIT.json").read_text())
    trace = payload["stop_trace"]
    r = Raster(1170, 520)
    left, right, top, bottom = 150, 1080, 75, 390
    r.text(585, 18, "QUEUE FOLLOW-UP: RESOLUTION COST", scale=2, center=True)
    r.text(585, 43, "FIXED V3 CONFIGURATIONS; DQN - A2C; POST-V3 DIAGNOSTIC", scale=1, center=True)
    ymin, ymax = -0.25, 0.65
    def px(n): return int(left + (n - 150) / 300 * (right - left))
    def py(v): return int(bottom - (v - ymin) / (ymax - ymin) * (bottom - top))
    for tick in [-0.2, 0.0, 0.05, 0.2, 0.4, 0.6]:
        y = py(tick); r.line(left, y, right, y, "#d9dee5"); r.text(left - 14, y - 4, f"{tick:.2f}", scale=1)
    r.line(left, bottom, right, bottom); r.line(left, top, left, bottom)
    # Practical margin is a reference line; the zero line remains visible.
    r.line(left, py(0.05), right, py(0.05), "#9a7b18", 2)
    r.text(right - 4, py(0.05) - 14, "MARGIN 0.05", scale=1)
    prev = None
    for item in trace:
        row = item["decision"]
        x = px(row["n"])
        lo, hi, est = py(row["lower"]), py(row["upper"]), py(row["estimate"])
        r.line(x, lo, x, hi, "#2a6fbb", 3); r.line(x - 8, lo, x + 8, lo, "#2a6fbb", 2); r.line(x - 8, hi, x + 8, hi, "#2a6fbb", 2)
        r.circle(x, est, 6, "#d97732")
        r.text(x, bottom + 18, str(row["n"]), scale=1, center=True)
        r.text(x, bottom + 37, row["decision"].replace("max_budget_inconclusive", "INCONCLUSIVE").replace("a_superior", "DQN SUPERIOR"), scale=1, center=True)
        if prev:
            r.line(prev[0], prev[1], x, est, "#d97732", 2)
        prev = (x, est)
    r.text(585, 460, "Dots: estimate; whiskers: clipped family-adjusted interval. Stop at n = 400 after lower endpoint = 0.1265.", scale=1, center=True)
    out = FIG / "fig_queue_budget_followup.png"; r.save(out); return out


def png_v4_extension() -> Path:
    """Plot the prospective v4 extension intervals and decision states."""
    payload = json.loads((ROOT / "V4_EXTENSION_AUDIT.json").read_text())
    rows = []
    for key, item in payload["recomputed_decisions"].items():
        environment, comparison = key.split(":", 1)
        rows.append((environment, comparison, item))
    env_order = ["CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0"]
    rows.sort(key=lambda row: (env_order.index(row[0]), row[1]))
    r = Raster(1300, 620)
    left, right, top, bottom = 120, 1240, 78, 470
    r.text(650, 18, "PROSPECTIVE V4 EXTENSION: 400-SEED INTERVALS", scale=2, center=True)
    r.text(650, 45, "FROZEN V3 CONFIGURATIONS; NEW SEEDS 30000-30399; ONE TERMINAL QUEUE DECISION AT N = 200", scale=1, center=True)
    ymin, ymax = -0.7, 0.7
    def px(i): return int(left + (i + 0.5) / len(rows) * (right - left))
    def py(value): return int(bottom - (value - ymin) / (ymax - ymin) * (bottom - top))
    for tick in [-0.6, -0.3, 0.0, 0.05, 0.3, 0.6]:
        y = py(tick)
        r.line(left, y, right, y, "#d9dee5")
        r.text(left - 16, y - 4, f"{tick:.2f}", scale=1)
    r.line(left, bottom, right, bottom)
    r.line(left, top, left, bottom)
    r.line(left, py(0.05), right, py(0.05), "#9a7b18", 2)
    r.text(right - 4, py(0.05) - 14, "MARGIN 0.05", scale=1)
    labels = {"CartPole-v1": "CP", "Acrobot-v1": "AC", "MountainCar-v0": "MC", "Taxi-v4": "TX", "NonstationaryQueue-v0": "Q"}
    for i, (environment, comparison, item) in enumerate(rows):
        x = px(i)
        lo, hi, estimate = item["lower"], item["upper"], item["estimate"]
        r.line(x, py(lo), x, py(hi), "#2a6fbb", 3)
        r.line(x - 7, py(lo), x + 7, py(lo), "#2a6fbb", 2)
        r.line(x - 7, py(hi), x + 7, py(hi), "#2a6fbb", 2)
        color = "#2a9d8f" if item["decision"] == "a_superior" else "#d97732"
        r.circle(x, py(estimate), 6, color)
        short_comparison = comparison.replace("_vs_", "-")
        r.text(x, bottom + 18, f"{labels[environment]} {short_comparison}", scale=1, center=True)
        if item["decision"] == "a_superior":
            r.text(x, top + 8, "A SUPERIOR", scale=1, center=True)
    r.text(650, 520, "Dots: estimate; whiskers: clipped family-adjusted intervals. Orange = cap inconclusive; green = terminal superiority.", scale=1, center=True)
    r.text(650, 548, "The extension is separate from the v3 20-seed confirmatory family and does not establish a universal seed budget.", scale=1, center=True)
    out = FIG / "fig_v4_extension.png"
    r.save(out)
    return out


def png_v5_extension() -> Path:
    """Plot v5 terminal decisions and interval states at the observed stop/cap."""
    payload = json.loads((ROOT / "V5_EXTENSION_AUDIT.json").read_text())
    rows = []
    for key, item in payload["recomputed_decisions"].items():
        environment, comparison = key.split(":", 1)
        rows.append((environment, comparison, item))
    env_order = ["CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0"]
    rows.sort(key=lambda row: (env_order.index(row[0]), row[1]))
    r = Raster(1300, 650)
    left, right, top, bottom = 120, 1240, 78, 485
    r.text(650, 18, "V5 RESOLUTION-COST EXTENSION: UP TO 1,000 NEW SEEDS", scale=2, center=True)
    r.text(650, 45, "FROZEN V3 CONFIGURATIONS; SEEDS 30400-31399; SAME-MACHINE DIAGNOSTIC", scale=1, center=True)
    ymin, ymax = -0.5, 0.7
    def px(i): return int(left + (i + 0.5) / len(rows) * (right - left))
    def py(value): return int(bottom - (value - ymin) / (ymax - ymin) * (bottom - top))
    for tick in [-0.4, -0.2, 0.0, 0.05, 0.2, 0.4, 0.6]:
        y = py(tick); r.line(left, y, right, y, "#d9dee5"); r.text(left - 16, y - 4, f"{tick:.2f}", scale=1)
    r.line(left, bottom, right, bottom); r.line(left, top, left, bottom)
    r.line(left, py(0.05), right, py(0.05), "#9a7b18", 2); r.text(right - 4, py(0.05) - 14, "MARGIN 0.05", scale=1)
    labels = {"CartPole-v1": "CP", "Acrobot-v1": "AC", "MountainCar-v0": "MC", "Taxi-v4": "TX", "NonstationaryQueue-v0": "Q"}
    colors = {"a_superior": "#2a9d8f", "b_superior": "#8b5cf6", "max_budget_inconclusive": "#d97732"}
    for i, (environment, comparison, item) in enumerate(rows):
        x = px(i)
        r.line(x, py(item["lower"]), x, py(item["upper"]), "#2a6fbb", 3)
        r.line(x - 7, py(item["lower"]), x + 7, py(item["lower"]), "#2a6fbb", 2)
        r.line(x - 7, py(item["upper"]), x + 7, py(item["upper"]), "#2a6fbb", 2)
        r.circle(x, py(item["estimate"]), 6, colors[item["decision"]])
        r.text(x, bottom + 18, f"{labels[environment]} {comparison.replace('_vs_', '-')}", scale=1, center=True)
        r.text(x, bottom + 36, f"n={item['n']}", scale=1, center=True)
    r.text(650, 530, "Dots: estimate; whiskers: clipped family-adjusted intervals. Teal/purple = terminal; orange = cap inconclusive.", scale=1, center=True)
    r.text(650, 558, "Four comparisons resolve at n = 200 or 800; eleven remain unresolved at n = 1,000.", scale=1, center=True)
    out = FIG / "fig_v5_extension.png"; r.save(out); return out


def prefer_svg_renderings(names: list[str]) -> None:
    """Use font-rendered PNGs when the host provides the SVG converter.

    The Raster functions above remain the dependency-free fallback for hosts
    without `sips`. On macOS, retaining the SVG rendering avoids replacing
    publication figures with the smaller bitmap-font fallback.
    """
    for name in names:
        svg_path = FIG / f"{name}.svg"
        png_path = FIG / f"{name}.png"
        if not svg_path.exists():
            continue
        rendered = False
        try:
            subprocess.run(
                ["sips", "-s", "format", "png", str(svg_path), "--out", str(png_path)],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            rendered = True
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
        if rendered:
            continue
        try:
            subprocess.run(
                ["wkhtmltoimage", "--quiet", str(svg_path), str(png_path)],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
        if png_path.exists():
            try:
                subprocess.run(
                    ["sips", "-s", "format", "png", str(png_path), "--out", str(png_path)],
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except (FileNotFoundError, subprocess.CalledProcessError):
                pass


if __name__ == "__main__":
    paths = [protocol(), intervals(), heatmap(), budget_frontier(), tuning_stability(), normalization_sensitivity(), budget_scaling(), eval_episode_sensitivity(), png_protocol(), png_intervals(), png_heatmap(), png_budget_frontier(), png_tuning_stability(), png_normalization_sensitivity(), png_budget_scaling(), png_eval_episode_sensitivity(), png_selection_uncertainty(), png_queue_budget_followup(), png_v4_extension(), png_v5_extension()]
    prefer_svg_renderings([
        "fig_protocol",
        "fig_intervals",
        "fig_heatmap",
        "fig_budget_frontier",
        "fig_tuning_stability",
        "fig_normalization_sensitivity",
        "fig_budget_scaling",
        "fig_eval_episode_sensitivity",
    ])
    print("\n".join(str(p) for p in paths))

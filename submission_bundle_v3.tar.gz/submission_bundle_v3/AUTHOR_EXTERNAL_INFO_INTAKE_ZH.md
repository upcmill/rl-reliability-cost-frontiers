# 作者与外部投稿信息收集表

本表用于在正式投稿前收集工作区之外的信息。方括号内容不是事实，必须由
作者、仓储平台、数据库或期刊官方页面确认后替换。未完成时，投稿审计应
继续保持 `submission_candidate_with_blockers`。

## A. 作者和声明

| 字段 | 填写内容 | 来源/确认人 |
|---|---|---|
| 通讯作者姓名 | `赵海龙` | 作者本人 |
| 所有作者及顺序 | `穆浩然；赵海龙` | 全体作者 |
| 单位与国家/地区 | `北京建筑大学，中国` | 作者所在机构 |
| 通讯邮箱 | `[待补充]` | 通讯作者 |
| ORCID | `[待补充]` | ORCID 账户或作者本人 |
| 英文姓名拼写 | `[待补充]` | 作者本人确认投稿系统使用的拉丁字母拼写 |
| CRediT 贡献 | `[待补充]` | 全体作者逐项确认 |
| 基金 | `[待补充]` 或 `No external funding` | 基金批准文件/作者确认 |
| 利益冲突 | `[待补充]` 或 `No competing interests` | 全体作者确认 |
| 伦理声明 | `No human participants, personal data, or animal subjects; simulated environments only.` | 当前研究设计；投稿前由作者确认 |

## B. 公开代码和数据归档

建议采用 GitHub + Zenodo，也可以使用 OSF、Figshare 或机构仓储。

| 字段 | 填写内容 | 来源/核验方式 |
|---|---|---|
| 公开仓库 URL | `[待补充]` | 仓库页面，无需登录访问 |
| 永久 DOI | `[待补充]` | Zenodo/OSF/Figshare/机构仓储 |
| Release 或 tag | `[待补充]` | 不可变版本标签 |
| 代码许可证 | `[待补充]` | 仓库许可证文件，使用 SPDX 标识 |
| 数据/文档许可证 | `[待补充]` | 仓储平台或归档说明 |
| 发布日期 | `[待补充]` | 平台记录 |
| 下载归档 SHA-256 | `[待补充]` | 下载后重新计算并与本地侧车文件比较 |
| Data Availability Statement | `[待补充]` | 使用 DOI/URL 和访问条件写成完整句子 |

发布后必须用无登录窗口下载一次归档，并运行：

```bash
python3 audit_public_archive_safety.py
python3 submission_readiness_audit.py
```

## C. 独立文献筛选

通过学校图书馆或机构账号保存以下数据库的原始导出文件：Web of Science、
Scopus、IEEE Xplore、ACM Digital Library；Google Scholar 若受访问限制，
需保存检索日期、检索式、结果页记录和不可用原因。

| 字段 | 填写内容 |
|---|---|
| 检索日期、时区 | `[待补充]` |
| 数据库和网址 | `[待补充]` |
| 完整检索式 | `[待补充]` |
| 时间、语言和文献类型过滤器 | `[待补充]` |
| 返回记录数 | `[待补充]` |
| 原始导出文件路径和 SHA-256 | `[待补充]` |
| DOI/标题去重规则 | `[待补充]` |
| 去重后记录数 | `[待补充]` |
| 第二筛选者标识 | `[待补充]` |
| 冲突仲裁规则 | `[待补充]` |

第二位筛选者应在看到第一位决定前，独立标记 `include`、`exclude` 或
`uncertain`，并记录 `direct_method_overlap`、`RL_reliability`、
`sequential_inference`、`reproducibility`、`application_only`、
`not_relevant` 或 `full_text_needed` 等理由代码。完成后更新
`LITERATURE_SEARCH_LOG.md`、`LITERATURE_SCREENING_TABLE.md` 和
`SYSTEMATIC_NOVELTY_REVIEW.md`。

## D. Windows 复跑身份

| 字段 | 填写内容 |
|---|---|
| 实际操作者或团队 | `[待补充]` |
| 单位 | `[待补充]` |
| 复跑日期 | `[待补充]` |
| 与原作者关系 | `[同一作者/同一团队/独立团队/其他]` |
| 是否访问原始参考结果目录 | `[是/否]` |
| 是否允许使用“独立团队科学复制”表述 | `[作者确认]` |

若操作者属于原作者团队，稿件应继续使用“不同机器复现冻结协议”，不应写
成独立团队科学复制。

## E. 期刊官方核验

投稿前从 Springer 的 *Machine Learning* 官方页面和 Clarivate 官方渠道
保存带日期的页面或 PDF，并填写：

| 字段 | 填写内容 |
|---|---|
| 当前文章类型 | `[待补充]` |
| Data Availability 要求 | `[待补充]` |
| 代码/数据/补充材料政策 | `[待补充]` |
| SCI/SCIE 状态 | `[待补充]` |
| JCR 类别和分区 | `[待补充]` |
| APC/Open Choice 条款 | `[待补充]` |
| 核验日期和官方 URL | `[待补充]` |

不要从第三方排名网站填入 SCI、JCR 或 APC 信息。

## 回填与最终检查

完成 A--E 后，回填 `SUBMISSION_METADATA_TEMPLATE.md`、中英文主稿、投稿信、
`CITATION_CFF_TEMPLATE.yml` 和期刊贡献信息表，然后运行：

```bash
python3 audit_submission_placeholders.py
python3 audit_public_archive_safety.py
python3 audit_manuscript_numeric_claims.py
python3 audit_manuscript_structure.py
python3 audit_word_manuscript_parity.py
python3 submission_readiness_audit.py
python3 generate_reproduction_hashes.py
python3 build_submission_bundle.py --output submission_bundle_v3.tar.gz
./.rl-arm64-venv/bin/python -m unittest -q
```

只有公开归档、文献筛选和声明字段三个闸门均有外部证据后，才可把状态从
`submission_candidate_with_blockers` 改为正式投稿准备完成。该状态仍不等于
SCI 接收或录用保证。

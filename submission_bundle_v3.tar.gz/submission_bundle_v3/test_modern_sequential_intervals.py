"""Deterministic checks for the separate post-hoc comparison implementation."""
import importlib.util
import math
import unittest

import numpy as np

from modern_sequential_intervals import (COMPARISON_ALPHA, METHODS, arm_radii,
    gamma_boundary, gamma_log_mixture, locked_decisions, normal_rho, pair_intervals,
    shared_arm_prefixes, spending, stitched_boundary, sufficient_statistics)
from reference_sequential_interval import alpha_spend, unpaired_hoeffding_interval

HAS_SCIPY = importlib.util.find_spec('scipy') is not None


class ModernIntervalTests(unittest.TestCase):
    def test_original_matches_frozen_reference(self):
        looks = [5, 10, 15, 20]
        rng = np.random.default_rng(301)
        x = rng.uniform(size=(5, 3, 20))
        estimate, lower, upper = pair_intervals(sufficient_statistics(x, looks), looks, 'H-original')
        for t in range(5):
            for p, (a, b) in enumerate(((0, 1), (0, 2), (1, 2))):
                for k, n in enumerate(looks):
                    expected = unpaired_hoeffding_interval(x[t, a, :n].tolist(), x[t, b, :n].tolist(), alpha_spend(COMPARISON_ALPHA, k + 1))
                    np.testing.assert_allclose([estimate[t, p, k], lower[t, p, k], upper[t, p, k]], expected, atol=1e-14)

    def test_error_accounting(self):
        for k in [1, 2, 4, 5, 20]:
            self.assertLess(spending('H-original', k).sum(), COMPARISON_ALPHA)
            for method in ('H-finite', 'H-uniform', 'EB-uniform'):
                self.assertAlmostEqual(spending(method, k).sum() * 15, .05)
        self.assertAlmostEqual(15 * 2 * 2 * (COMPARISON_ALPHA / 4), .05)

    def test_bernstein_four_tail_factor_and_ddof(self):
        x = np.array([0., .5, 1.])
        stat = sufficient_statistics(x, [3])
        self.assertAlmostEqual(float(stat['variance'][0]), .25)
        log_term = math.log(8 / COMPARISON_ALPHA)
        expected = math.sqrt(2 * .25 * log_term / 3) + 7 * log_term / 6
        self.assertAlmostEqual(float(arm_radii(stat, [3], 'EB-uniform')[0]), expected)

    def test_prediction_excludes_current_and_future_samples(self):
        x = np.array([.2, .9, .4, .1])
        stat = sufficient_statistics(x, [1, 2, 3, 4])
        pred = [.5, .2, .55, .5]
        np.testing.assert_allclose(stat['intrinsic'], np.cumsum((x - pred) ** 2))
        y = x.copy(); y[3] = 1.
        np.testing.assert_array_equal(stat['intrinsic'][:3], sufficient_statistics(y, [1, 2, 3, 4])['intrinsic'][:3])

    def test_constant_boundary_and_single_sample(self):
        for value in [0., .5, 1.]:
            stat = sufficient_statistics(np.full(20, value), [1, 5, 20])
            np.testing.assert_allclose(stat['variance'], 0.)
            np.testing.assert_allclose(stat['intrinsic'], (value - .5) ** 2)
            self.assertTrue(np.isinf(arm_radii(stat, [1, 5, 20], 'EB-uniform')[0]))
        self.assertGreater(float(stitched_boundary(0)), 0.)

    def test_invalid_inputs_rejected(self):
        for data, looks in [([np.nan], [1]), ([-.01], [1]), ([1.01], [1]), ([0, 1], [2, 1]), ([0], [2])]:
            with self.assertRaises(ValueError): sufficient_statistics(data, looks)
        with self.assertRaises(ValueError): spending('H-uniform', 0)
        with self.assertRaises(ValueError): normal_rho(0)
        with self.assertRaises(ValueError): stitched_boundary(-1)

    def test_normal_rho_stationary_point(self):
        for n in [20, 400, 1000]:
            rho = normal_rho(n)
            q = n / 4 / rho
            self.assertAlmostEqual(q - math.log1p(q), 2 * math.log(2 / COMPARISON_ALPHA), places=12)

    def test_strict_margin_precision_priority_and_lock(self):
        lower = np.array([[.05, .051, -.8], [-.15, -.8, -.9], [-.01, -.8, .8]])
        upper = np.array([[.8, .8, -.2], -.05 * np.ones(3), [.02, -.2, .9]])
        terminal, n, _ = locked_decisions(lower, upper, [5, 10, 20])
        np.testing.assert_array_equal(terminal, [1, 3, 3])
        np.testing.assert_array_equal(n, [10, 5, 5])
        # At exactly -m no strict B superiority; precision can still stop.

    def test_shared_cost_uses_maxima_and_does_not_double_count(self):
        result = shared_arm_prefixes([[200, 400, 800], [200, 200, 200]])
        np.testing.assert_array_equal(result, [[400, 800, 800], [200, 200, 200]])
        self.assertEqual(int(result[0].sum()), 2000)
        self.assertNotEqual(int(result[0].sum()), 2 * (200 + 400 + 800))

    @unittest.skipUnless(HAS_SCIPY, 'requires the separate pinned SciPy analysis environment')
    def test_gamma_root_is_upper_bracket(self):
        v = np.array([0., .0001, .25, 1., 10., 100., 1000.])
        for n in [20, 400, 1000]:
            for factor in [.1, 1., 10.]:
                rho = normal_rho(n) * factor
                u = gamma_boundary(v, rho)
                threshold = math.log(4 / COMPARISON_ALPHA)
                self.assertTrue(np.all(gamma_log_mixture(u, v, rho) >= threshold - 1e-11))
                self.assertTrue(np.all(gamma_log_mixture(u - 1e-6, v, rho) < threshold))
                self.assertTrue(np.all(np.diff(u) > 0))

    @unittest.skipUnless(HAS_SCIPY, 'requires the separate pinned SciPy analysis environment')
    def test_all_methods_constant_and_extreme_data(self):
        looks = [200, 400, 600, 800, 1000]
        x = np.stack([np.zeros(1000), np.ones(1000), np.full(1000, .5)])
        stat = sufficient_statistics(x, looks)
        for method in METHODS:
            estimate, lo, hi = pair_intervals(stat, looks, method)
            self.assertTrue(np.all(lo <= estimate))
            self.assertTrue(np.all(hi >= estimate))
            self.assertTrue(np.all((lo >= -1) & (hi <= 1)))


if __name__ == '__main__':
    unittest.main()

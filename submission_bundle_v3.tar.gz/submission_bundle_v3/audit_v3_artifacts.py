#!/usr/bin/env python3
"""Deterministic consistency audit for the formal v3 artifact package."""

from __future__ import annotations

import csv
import json
import math
import statistics
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "sb3_formal_v3"
TASKS = {
    "CartPole-v1",
    "Acrobot-v1",
    "MountainCar-v0",
    "Taxi-v4",
    "NonstationaryQueue-v0",
}
ALGORITHMS = {"PPO", "DQN", "A2C"}


def main() -> None:
    rows = list(csv.DictReader((RUN / "raw_seed_metrics.csv").open(newline="")))
    assert len(rows) == 600, len(rows)
    assert sum(row["split"] == "validation" for row in rows) == 300
    assert sum(row["split"] == "test" for row in rows) == 300
    assert {row["env_id"] for row in rows} == TASKS
    assert {row["algorithm"] for row in rows} == ALGORITHMS
    assert all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows)

    decisions = json.loads((RUN / "familywise_cost_summary.json").read_text())
    assert decisions["primary_comparisons"] == 15
    assert decisions["all_max_budget_inconclusive"] is True
    assert len(decisions["rows"]) == 15
    assert all(item["n"] == 20 for item in decisions["rows"])
    assert all(item["decision"] == "max_budget_inconclusive" for item in decisions["rows"])

    reproduction = json.loads(
        (RUN / "independent_reproduction_summary.json").read_text()
    )
    assert len(reproduction["rows"]) == 15
    assert reproduction["all_zero_mean_absolute_difference"] is True
    assert all(
        float(item["mean_absolute_metric_difference"]) == 0.0
        for item in reproduction["rows"]
    )

    manuscript = (ROOT / "MANUSCRIPT_DRAFT_V3.md").read_text().replace("−", "-")
    # Check the numerical claims that are manually rendered in the manuscript
    # against the authoritative JSON artifacts. This is intentionally a
    # presence check: the JSON files remain the source of truth for precision.
    for item in decisions["rows"]:
        for value in (item["estimate"], item["lower"], item["upper"]):
            assert f"{float(value):.4f}" in manuscript, value
    descriptive = json.loads((RUN / "descriptive_summary.json").read_text())
    assert len(descriptive["rows"]) == 15
    for item in descriptive["rows"]:
        expected = Decimal(str(item["test"]["mean"])).quantize(
            Decimal("0.000001"), rounding=ROUND_HALF_UP
        )
        assert f"{expected:.6f}" in manuscript
    assert "600 rows" in manuscript
    assert "300 validation rows" in manuscript
    assert "300 sealed-test rows" in manuscript
    assert "15 zero differences" in manuscript

    # The formal family allocation and 20-seed budget imply a deterministic
    # non-resolution boundary; keep the derivation tied to the manuscript.
    comparison_alpha = 0.05 / 15.0
    final_look_alpha = comparison_alpha * 6.0 / (math.pi * math.pi * 4.0 * 4.0)
    radius_sum = 2.0 * math.sqrt(math.log(4.0 / final_look_alpha) / (2.0 * 20.0))
    assert abs(radius_sum - 1.0178588242230167) < 1e-12
    assert 1.0 - radius_sum <= 0.05
    assert min(2.0, radius_sum) > 0.10
    assert "1.0178588242" in manuscript

    raw_values = defaultdict(list)
    for row in rows:
        if row["split"] == "test":
            raw_values[(row["env_id"], row["algorithm"])].append(float(row["metric_raw"]))
    raw_table = (ROOT / "RAW_RETURN_TABLE_V3.md").read_text(encoding="utf-8")
    for key, values in raw_values.items():
        assert len(values) == 20, key
        formatted = f"{statistics.mean(values):.6f}"
        assert formatted in manuscript, (key, formatted)
        assert formatted in raw_table, (key, formatted)

    selection = json.loads(
        (ROOT / "validation_selection_uncertainty_v3.json").read_text(encoding="utf-8")
    )
    assert selection["status"] == "descriptive_validation_selection_diagnostic"
    assert selection["replicates"] == 20_000
    assert len(selection["rows"]) == 15
    for item in selection["rows"]:
        frequencies = item["bootstrap_selection_frequency"]
        assert set(frequencies) == {
            "lr3e4_long", "lr1e4_long", "lr3e4_short", "lr1e4_short"
        }
        assert abs(sum(frequencies.values()) - 1.0) < 1e-9
    assert "Validation-selection resampling diagnostic" in manuscript

    runtime = json.loads((ROOT / "RUNTIME_COST_TABLE_V3.json").read_text(encoding="utf-8"))
    assert runtime["status"] == "descriptive_runtime_cost_only"
    assert runtime["rows"] == 300
    assert len(runtime["cell_summaries"]) == 15
    expected_runtime = sum(
        float(row["runtime_seconds"])
        for row in rows
        if row["split"] == "test" and row["status"] == "ok"
    )
    assert abs(float(runtime["total_seconds"]) - expected_runtime) < 1e-10
    frontier = json.loads((ROOT / "RELIABILITY_COST_FRONTIER_V3.json").read_text(encoding="utf-8"))
    assert frontier["status"] == "audited_reliability_cost_frontier"
    assert [item["seeds_per_algorithm"] for item in frontier["looks"]] == [5, 10, 15, 20]
    assert [item["family_test_rows"] for item in frontier["looks"]] == [75, 150, 225, 300]
    assert abs(frontier["looks"][-1]["family_runtime_seconds"] - expected_runtime) < 1e-10
    assert "Reliability--cost frontier" in manuscript
    assert "0.058429" in manuscript

    planning = json.loads(
        (ROOT / "DESIGN_PLANNING_SENSITIVITY_V3.json").read_text(encoding="utf-8")
    )
    assert planning["status"] == "analytic_family_size_sensitivity_only"
    assert planning["assumptions"]["family_sizes"] == [1, 3, 9, 15, 30]
    assert len(planning["rows"]) == 20
    planning_row = next(
        row for row in planning["rows"] if row["comparisons"] == 15 and row["look"] == 4
    )
    assert abs(planning_row["radius_sum"] - radius_sum) < 1e-12
    assert planning_row["necessary_seeds_for_possible_superiority"] == 23
    assert "Family-size planning sensitivity" in manuscript
    assert "8,843" in manuscript

    print("v3 artifact audit: PASS")
    print("rows=600 validation=300 test=300 decisions=15 reproduction_diffs=15x0.0 raw_return_facts=checked selection_diagnostic=checked nonresolution=checked family_size_planning=checked manuscript_facts=checked")


if __name__ == "__main__":
    main()

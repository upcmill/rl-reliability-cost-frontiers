#!/usr/bin/env python3
"""Generate validation-stage tuning-cost accounting from the v3 raw CSV."""

from __future__ import annotations

import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "sb3_formal_v3/raw_seed_metrics.csv"
OUTPUT_JSON = ROOT / "VALIDATION_TUNING_COST_V3.json"
OUTPUT_MD = ROOT / "VALIDATION_TUNING_COST_V3.md"


def summarize(values: list[float]) -> dict[str, float | int]:
    if not values:
        raise ValueError("cannot summarize an empty group")
    return {
        "n": len(values),
        "total_seconds": sum(values),
        "mean_seconds": statistics.mean(values),
        "sample_sd_seconds": statistics.stdev(values) if len(values) > 1 else 0.0,
        "median_seconds": statistics.median(values),
        "minimum_seconds": min(values),
        "maximum_seconds": max(values),
    }


def build() -> dict[str, object]:
    with INPUT.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    validation_rows = [row for row in rows if row["split"] == "validation" and row["status"] == "ok"]
    if len(validation_rows) != 300:
        raise ValueError(f"expected 300 successful v3 validation rows, found {len(validation_rows)}")

    by_algorithm: dict[str, list[float]] = defaultdict(list)
    by_environment_algorithm: dict[tuple[str, str], list[float]] = defaultdict(list)
    by_candidate: dict[str, list[float]] = defaultdict(list)
    for row in validation_rows:
        seconds = float(row["runtime_seconds"])
        algorithm = row["algorithm"]
        by_algorithm[algorithm].append(seconds)
        by_environment_algorithm[(row["env_id"], algorithm)].append(seconds)
        by_candidate[row["config_id"]].append(seconds)

    algorithm_rows = [
        {"algorithm": algorithm, **summarize(values)}
        for algorithm, values in sorted(by_algorithm.items())
    ]
    cell_rows = [
        {"env_id": env_id, "algorithm": algorithm, **summarize(values)}
        for (env_id, algorithm), values in sorted(by_environment_algorithm.items())
    ]
    candidate_rows = [
        {"config_id": config_id, **summarize(values)}
        for config_id, values in sorted(by_candidate.items())
    ]
    payload = {
        "status": "descriptive_validation_tuning_cost_only",
        "warning": (
            "Wall-clock values describe this Apple Silicon CPU run and do not "
            "establish cross-hardware efficiency or algorithm superiority."
        ),
        "source": "sb3_formal_v3/raw_seed_metrics.csv",
        "split": "validation",
        "unit": "one candidate-configuration training seed",
        "rows": len(validation_rows),
        "environments": 5,
        "algorithms": 3,
        "candidate_configurations_per_algorithm_environment": 4,
        "validation_seeds_per_candidate": 5,
        "algorithm_summaries": algorithm_rows,
        "cell_summaries": cell_rows,
        "candidate_summaries": candidate_rows,
        "total_seconds": sum(float(row["runtime_seconds"]) for row in validation_rows),
    }
    return payload


def render(payload: dict[str, object]) -> str:
    lines = [
        "# v3 Validation Tuning Cost Table",
        "",
        "This table reports the recorded validation-stage tuning cost for the",
        "four-candidate grid. Every algorithm--environment cell used four",
        "candidate configurations and five validation seeds, giving 100",
        "successful validation rows per algorithm and 300 rows overall.",
        "",
        "The runtime is wall-clock time on the recorded Apple Silicon CPU",
        "environment. It documents the executed tuning budget; it is not a",
        "cross-hardware benchmark, a claim of equal computational difficulty,",
        "or evidence that one algorithm is generally more efficient.",
        "",
        f"- Source: `{payload['source']}`",
        f"- Successful validation rows: `{payload['rows']}`",
        f"- Total recorded validation runtime: `{payload['total_seconds'] / 3600:.3f}` hours",
        "",
        "## Algorithm-level summaries",
        "",
        "| Algorithm | Candidate-seed runs | Total hours | Mean seconds | Sample SD | Median seconds | Min | Max |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in payload["algorithm_summaries"]:
        lines.append(
            f"| {row['algorithm']} | {row['n']} | {row['total_seconds'] / 3600:.3f} | "
            f"{row['mean_seconds']:.3f} | {row['sample_sd_seconds']:.3f} | "
            f"{row['median_seconds']:.3f} | {row['minimum_seconds']:.3f} | {row['maximum_seconds']:.3f} |"
        )
    lines.extend([
        "",
        "## Accounting rule",
        "",
        "The validation cost is 5 environments × 3 algorithms × 4 candidate",
        "configurations × 5 seeds = 300 training-seed runs. The same number of",
        "candidate-seed rows is allocated to each algorithm. The selected test",
        "runs and post-v3 extensions are excluded and reported separately.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    payload = build()
    OUTPUT_JSON.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    OUTPUT_MD.write_text(render(payload), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "rows": payload["rows"], "total_seconds": payload["total_seconds"]}, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Analyze the frozen V7 seed sequence after all registered runs complete."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from modern_sequential_intervals import (COMPARISON_ALPHA, METHODS, PAIRS, SENSITIVITY,
    locked_decisions, pair_intervals, shared_arm_prefixes, sufficient_statistics)
from sb3_pilot import ALGORITHMS, ADDITIONAL_ENV_IDS, DEFAULT_ENV_IDS, QUEUE_ENV_ID

ROOT = Path(__file__).resolve().parent
ENVS = (*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)
SEED_START, N = 31_400, 1000
LOOKS = (200, 400, 600, 800, 1000)
DECISIONS = ("unresolved", "a_superior", "b_superior", "precision_only")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_values(path: Path) -> np.ndarray:
    values = np.empty((len(ENVS), len(ALGORITHMS), N), dtype=float)
    selected = json.loads((ROOT/'sb3_v5_extension/run_config.json').read_text())["selected_configurations"]
    seen = set()
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            env, algo, seed = row["env_id"], row["algorithm"], int(row["train_seed"])
            if env not in ENVS or algo not in ALGORITHMS or not SEED_START <= seed < SEED_START + N:
                raise ValueError(f"out-of-scope row: {row}")
            k = (env, algo, seed)
            if k in seen:
                raise ValueError(f"duplicate row: {k}")
            if row["status"] != "ok" or row["split"] != "v7_confirmation":
                raise ValueError(f"non-success row: {k}")
            if row["config_id"] != selected[f"{env}:{algo}"]:
                raise ValueError(f"configuration drift: {k}")
            val = float(row["metric_normalized"])
            if not np.isfinite(val) or not 0 <= val <= 1:
                raise ValueError(f"invalid normalized metric: {k}")
            values[ENVS.index(env), ALGORITHMS.index(algo), seed - SEED_START] = val
            seen.add(k)
    expected = len(ENVS) * len(ALGORITHMS) * N
    if len(seen) != expected:
        raise ValueError(f"incomplete data: {len(seen)} of {expected} rows")
    return values


def analyze(values: np.ndarray) -> tuple[list[dict], dict]:
    if values.shape != (5, 3, N):
        raise ValueError("values must have shape (5, 3, 1000)")
    stats = sufficient_statistics(values, LOOKS)
    interval_rows, summaries = [], []
    all_results = {}
    for method in METHODS + SENSITIVITY:
        estimate, lower, upper = pair_intervals(stats, LOOKS, method)
        terminal, stops, stop_idx = locked_decisions(lower, upper, LOOKS)
        prefixes = shared_arm_prefixes(stops)
        all_results[method] = {"estimate": estimate, "lower": lower, "upper": upper,
                               "terminal": terminal, "stops": stops, "prefixes": prefixes}
        for t, env in enumerate(ENVS):
            for p, (a, b) in enumerate(PAIRS):
                label = f"{ALGORITHMS[a]} - {ALGORITHMS[b]}"
                for k, n in enumerate(LOOKS):
                    interval_rows.append({"method": method, "environment": env, "comparison": label,
                        "look": k+1, "n_per_arm": n, "estimate": float(estimate[t,p,k]),
                        "lower": float(lower[t,p,k]), "upper": float(upper[t,p,k]),
                        "width": float(upper[t,p,k]-lower[t,p,k]),
                        "terminal": DECISIONS[int(terminal[t,p])], "stop_n": int(stops[t,p]),
                        "first_terminal_look": int(stop_idx[t,p])+1})
        widths = upper - lower
        summaries.append({"method": method,
            "decision_counts_at_1000": {name: int(np.sum(terminal == i)) for i,name in enumerate(DECISIONS)},
            "mean_pair_width_by_look": np.mean(widths, axis=(0,1)).tolist(),
            "median_pair_width_by_look": np.median(widths, axis=(0,1)).tolist(),
            "counterfactual_deduplicated_shared_runs": int(prefixes.sum()),
            "complete_observed_training_runs": int(values.size)})
    base, gamma = all_results["H-original"], all_results["CS-EB-gamma"]
    diffs = (gamma["upper"] - gamma["lower"]) - (base["upper"] - base["lower"])
    pair_rows = []
    for t, env in enumerate(ENVS):
        for p, (a,b) in enumerate(PAIRS):
            pair_rows.append({"environment": env, "comparison": f"{ALGORITHMS[a]} - {ALGORITHMS[b]}",
                "original_final_width": float((base["upper"]-base["lower"])[t,p,-1]),
                "gamma_final_width": float((gamma["upper"]-gamma["lower"])[t,p,-1]),
                "paired_width_difference_gamma_minus_original": float(diffs[t,p,-1]),
                "original_terminal": DECISIONS[int(base["terminal"][t,p])],
                "gamma_terminal": DECISIONS[int(gamma["terminal"][t,p])],
                "original_stop_n": int(base["stops"][t,p]), "gamma_stop_n": int(gamma["stops"][t,p])})
    summary = {"status": "prospective_new_seed_validation_descriptive",
        "not_independent_team_reproduction": True, "not_coverage_validation_on_unknown_RL_distribution": True,
        "seed_range": [SEED_START, SEED_START + N - 1], "looks": list(LOOKS),
        "family_alpha": 0.05, "comparison_alpha": COMPARISON_ALPHA,
        "primary_fixed_panel_outcome": {"mean_final_width_difference_gamma_minus_original": float(diffs[:,:,-1].mean()),
            "median_final_width_difference_gamma_minus_original": float(np.median(diffs[:,:,-1])),
            "comparisons_gamma_narrower": int(np.sum(diffs[:,:,-1] < 0)),
            "comparisons_total": int(diffs[:,:,-1].size)},
        "method_summaries": summaries, "pairwise_primary_results": pair_rows}
    return interval_rows, summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("sb3_v7_confirmation"))
    parser.add_argument("--output-dir", type=Path, default=Path("sb3_v7_confirmation/analysis"))
    args = parser.parse_args()
    data_dir = args.data_dir if args.data_dir.is_absolute() else ROOT / args.data_dir
    metadata = json.loads((data_dir / "run_config.json").read_text())
    if metadata.get("status") != "COMPLETED" or metadata.get("completed_rows") != 15000:
        parser.error("analysis requires a completed 15,000-row run")
    values = load_values(data_dir / "raw_seed_metrics.csv")
    intervals, summary = analyze(values)
    output = args.output_dir if args.output_dir.is_absolute() else ROOT / args.output_dir
    output.mkdir(parents=True, exist_ok=False)
    with (output / "intervals.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(intervals[0]))
        writer.writeheader(); writer.writerows(intervals)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    manifest = {"status": summary["status"], "input_sha256": sha(data_dir / "raw_seed_metrics.csv"),
        "run_config_sha256": sha(data_dir / "run_config.json"),
        "outputs": {p.name: sha(p) for p in output.iterdir() if p.is_file()}}
    (output / "ANALYSIS_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(summary["primary_fixed_panel_outcome"], indent=2))


if __name__ == "__main__":
    main()

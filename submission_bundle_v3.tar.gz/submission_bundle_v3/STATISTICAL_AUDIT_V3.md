# Statistical Audit of the Formal v3 Package

This file separates the mathematical guarantee, simulation diagnostics, and
observed RL outcomes. Simulation results are not proofs and the formal RL
results are not evidence of universal algorithm rankings.

## 1. Estimand and guarantee

The primary estimand is the conditional difference between two marginal
expected normalized learning-curve metrics after validation-only configuration
selection. Each sealed metric is in `[0,1]`. For a comparison-level spending
amount `alpha_k`, the implementation uses

```text
r_A,k = sqrt(log(4 / alpha_k) / (2 n_A,k))
r_B,k = sqrt(log(4 / alpha_k) / (2 n_B,k))
I_k = [mean(A) - mean(B) +/- (r_A,k + r_B,k)] intersect [-1, 1]
```

with `alpha_k = alpha_cmp * 6 / (pi^2 k^2)` at looks 5, 10, 15, and 20.
Conditional on validation data, fixed looks, a fixed metric, bounded metrics,
and independence across each algorithm's own sealed seed sequence, Hoeffding's
inequality plus union bounds gives simultaneous coverage at least
`1 - alpha_cmp` for one comparison. Equal allocation of `0.05 / 15` gives
family-wise coverage at least 0.95. Cross-algorithm independence is not used
by this union-bound argument.

The guarantee is finite-look and conditional. It does not cover post-hoc look
or metric selection, test reuse, data-dependent task expansion, environment
drift, or arbitrary dependence among repeated runs of one algorithm.

## 2. Implementation checks

The v3 code path was checked by the repository's 30 unit tests. The tests cover
alpha spending, bounded intervals, unequal unpaired sample sizes, order
invariance of the unpaired method, terminal decision locking, queue seed
reproducibility, and Taxi scalar-action conversion. The deterministic artifact
audit additionally checks 600 rows, 15 final decisions, 20 test seeds per
selected cell, bounded normalized metrics, and 15 zero-difference replay rows.

Commands:

```bash
./.rl-arm64-venv/bin/python -m unittest -v
./.rl-arm64-venv/bin/python audit_v3_artifacts.py
```

## 3. Coverage diagnostics

`coverage_results_round2_with_mc_ci.json` contains 5,000 Monte Carlo replicates
per method and scenario with the 5/10/15/20 look schedule. The table reports
the empirical simultaneous coverage and its Wilson 95% interval across the
simulation replicates.

| Method | Scenario | Replicates | Coverage | Wilson 95% interval |
|---|---|---:|---:|---:|
| Normal | Symmetric | 5,000 | 0.9178 | [0.9099, 0.9251] |
| Normal | Skewed | 5,000 | 0.8770 | [0.8676, 0.8858] |
| Normal | Mixture | 5,000 | 0.4160 | [0.4024, 0.4297] |
| Paired bootstrap | Symmetric | 5,000 | 0.9178 | [0.9099, 0.9251] |
| Paired bootstrap | Skewed | 5,000 | 0.9072 | [0.8988, 0.9149] |
| Paired bootstrap | Mixture | 5,000 | 0.3944 | [0.3809, 0.4080] |
| Empirical Bernstein candidate | Symmetric | 5,000 | 1.0000 | [0.9992, 1.0000] |
| Empirical Bernstein candidate | Skewed | 5,000 | 1.0000 | [0.9992, 1.0000] |
| Empirical Bernstein candidate | Mixture | 5,000 | 1.0000 | [0.9992, 1.0000] |
| Paired Hoeffding | Symmetric | 5,000 | 1.0000 | [0.9992, 1.0000] |
| Paired Hoeffding | Skewed | 5,000 | 0.9998 | [0.9989, 1.0000] |
| Paired Hoeffding | Mixture | 5,000 | 1.0000 | [0.9992, 1.0000] |

These distributions are controlled simulation scenarios, not a representative
sample of all RL seed distributions. They support the limited statement that
the tested normal and bootstrap diagnostics can lose simultaneous coverage in
the mixture scenario, while the tested bounded baselines are conservative in
these scenarios.

### 3.1 Fixed calibration grid

After the v3 primary analysis, `calibration_grid.py` evaluated the unpaired
Hoeffding procedure on eight bounded distribution families, five true
differences (`-0.20` through `0.20`), and 3,000 replicates per cell. Both a
single-comparison alpha of `0.05` and the v3 comparison allocation `0.05/15`
were evaluated, giving 80 cells and 240,000 replicates in total. The minimum
simultaneous coverage was 1.0000 and no false-superiority decision occurred in
any cell; all replicates reached the 20-seed maximum. The pooled Wilson 95%
upper bound for the observed false-superiority rate was 0.000032. These are
finite-grid Monte Carlo diagnostics, not a proof, an arbitrary-distribution
coverage estimate, or a power guarantee. The full cell table is in
`CALIBRATION_GRID_REPORT.md` and the raw machine-readable output is in
`calibration_grid.json`.

## 4. False-superiority and cost diagnostics

`unpaired_tradeoff_results_round1_with_mc_ci.json` contains 5,000 replicates
for 11 cells: Bernoulli, wide two-point, and narrow two-point bounded samples,
with true differences from 0.00 to 0.20. The unpaired Hoeffding procedure made
zero false-superiority decisions in every cell and used all 20 seeds in every
replicate. For a zero estimate over 5,000 replicates, the Wilson upper bound is
0.0008. This is a simulation estimate with Monte Carlo uncertainty, not a
general error-rate proof.

The 100-seed extension (`unpaired_tradeoff_results_100seeds.json`) also used
the full 100-seed budget in all 2,000 replicates for each stored cell. It does
not imply that 100 seeds are universally insufficient; it only shows that this
bound and spending schedule did not reach a terminal decision in those tested
scenarios.

## 5. Analytic budget planning

`unpaired_budget_requirements.json` is a legacy planning artifact. It uses a
single-comparison alpha of 0.05 and the labels `1, 2, 4, 10, 20` as look
indices; those labels are not the formal v3 four-look schedule. Its first row
therefore reports 3,904 seeds per algorithm for width 0.10 and an unclipped
width of 1.3971 at 20 seeds, while its row labelled `20` reports 8,697 seeds
and width 2.0853. Those values are properties of that legacy bound calculation,
not observed RL requirements or necessary lower bounds, and the row labelled
`20` must not be read as the v3 final look.

The formal v3 schedule uses four looks with 5, 10, 15, and 20 seeds per arm
and comparison alpha `0.05/15`. Under this allocation, the first-look width
target requires 6,071 seeds per algorithm and the fourth-look requirement is
8,289 seeds; the unclipped widths at 20 seeds are 1.7422 and 2.0357,
respectively. The authoritative v3 values are in
`BUDGET_FEASIBILITY_AUDIT_V3.json` and are the values reported in the
manuscript. This distinction is why the legacy planning file is not presented
as a direct estimate of the v3 RL sample requirement.

For the formal v3 allocation, the final-look radius sum at 20 seeds is
`1.0178588242`. Since any observed bounded mean difference is in `[-1,1]`, the
largest possible lower endpoint is `-0.0178588242`, below the practical margin
`0.05`; the opposite direction is symmetric. The minimum clipped interval
width is `1.0178588242`, above the target `0.10`. Earlier looks are wider.
Therefore the formal state machine cannot reach superiority or precision at any
bounded data sequence within 20 seeds. The observed 15/15 maximum-budget
outcome is consequently a deterministic protocol-resolution result, not an
empirical estimate of 20-seed power.

## 5.1 Minimax alpha-spending design diagnostic

`MINIMAX_ALPHA_SPENDING.md` and `MINIMAX_ALPHA_SPENDING.json` solve the finite
look allocation problem of minimizing the maximum equal-sample radius sum. The
solution equalizes the radius over the four looks; it is a planning diagnostic
and does not alter the v3 preregistered power-series allocation. The
deterministic implementation is covered by `test_minimax_alpha_spending.py`.
It does not establish a new coverage theorem, optimize every stopping-cost
objective, or provide empirical RL power.

## 5.2 Validation-selected alpha-spending diagnostic

Corollary 4 extends the same pointwise conditioning proof to a finite set of
valid alpha-spending schedules selected using validation data only. The
diagnostic in `ADAPTIVE_SPENDING_DIAGNOSTIC.md` evaluates four schedules at
50/100/150/200 observations with validation size 200, alpha 0.05, and 2,000
Monte Carlo repetitions per scenario. The four bounded scenarios produced no
observed simultaneous-coverage failure or false-superiority decision. Selected
mean cost was not uniformly below the best fixed schedule, so this result is
evidence for conditional validity rather than a universal efficiency claim.
`audit_adaptive_spending.py` checks the recorded budgets and outcomes. The
diagnostic is post-v3 and is not pooled with the RL family.

## 6. Relation to v3 RL results

The v3 RL study has 15 comparisons, all at 20 test seeds, all
`max_budget_inconclusive`, as forced by the preceding calculation. The RL run
checks that the implementation, task execution, and stored estimand follow the
declared boundary; it does not estimate empirical 20-seed power. This does not
establish that a different interval is invalid, that more seeds always solve
the problem, or that any algorithm is superior.

## 6.1 v5 resolution-cost diagnostic

The post-v4 v5 extension opens a disjoint sequence of seeds 30400--31399,
freezes the v3-selected configurations, and evaluates the same unpaired
Hoeffding rule at 200, 400, 600, 800, and 1,000 seeds. The raw artifact has
15,000 rows. Four comparisons reach terminal superiority decisions at 200 or
800 seeds and eleven remain `max_budget_inconclusive` at 1,000. This is an
observed same-machine resolution-cost diagnostic. It does not estimate
prospective power, a task-population distribution, a universal seed
requirement, or an algorithm ranking, and it is not pooled into the v3 family.

## 7. Audit conclusion

The mathematical result is conditional and finite-look. The simulations are
diagnostic evidence with explicit Monte Carlo uncertainty. The v3 RL results
are observations from one pinned software/hardware installation. These three
levels must remain separate in the manuscript and in any submission cover
letter.

## 8. Evaluation-aggregation sensitivity

The supplementary ten-episode run keeps the v3 selected configurations,
training seeds, 4,096-step budget, checkpoints, normalization, and decision
rule fixed while changing only the number of evaluation episodes per
checkpoint. It contains 300 test rows and 15 comparisons. All 15 comparisons
remain `max_budget_inconclusive`; final clipped widths range from 1.7172 to
2.0000, with median 1.9124. The mean absolute change in the 15 cell means is
0.0013, and the largest matched-seed cell mean absolute difference is 0.0345.
This supports a bounded sensitivity statement for the disclosed task family,
not a universal episode-count rule or an additional coverage guarantee.

## 9. Practical-margin sensitivity

`MARGIN_SENSITIVITY_V3.md` reuses the frozen v3 test rows while varying only
the practical margin from 0.00 to 0.50. The necessary-threshold calculation
and the observed decision counts are kept separate: the former is an analytic
condition for any bounded data to possibly cross the margin, while the latter
is a post-hoc sample diagnostic. All seven tested margins produced 15
`max_budget_inconclusive` states within the 20-seed cap at target width 0.10.
This does not establish a universal margin or prospective power.

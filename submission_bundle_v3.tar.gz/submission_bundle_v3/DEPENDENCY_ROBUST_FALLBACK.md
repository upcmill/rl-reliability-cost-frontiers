# Known-Block Dependence Fallback Diagnostic

This supplementary diagnostic pairs the seed-dependence stress test
with a narrowly scoped mitigation. When the block partition is known
and block values are independent, complete block means are treated as
the bounded observations in the same finite-look Hoeffding construction.
Partial trailing blocks are discarded. The fallback is not valid merely
because observations appear correlated, and this experiment is not an
RL dependence estimate or a change to the preregistered v3 analysis.

- Replicates per condition: `5000`
- Looks: `[50, 100, 150, 200]`; family alpha: `0.05`
- True difference: `0.0`; practical margin: `0.1`

## Results

| Block size | Effective blocks by look | Naive coverage | Fallback coverage | Naive false superiority | Fallback false superiority | Naive mean terminal n | Fallback mean terminal n |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | [50, 100, 150, 200] | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 200.00 | 200.00 |
| 2 | [25, 50, 75, 100] | 0.9982 | 1.0000 | 0.0002 | 0.0000 | 199.97 | 200.00 |
| 5 | [10, 20, 30, 40] | 0.9376 | 1.0000 | 0.0124 | 0.0000 | 198.25 | 200.00 |
| 10 | [5, 10, 15, 20] | 0.7706 | 1.0000 | 0.1370 | 0.0000 | 181.58 | 200.00 |
| 20 | [2, 5, 7, 10] | 0.4646 | 1.0000 | 0.3338 | 0.0000 | 158.16 | 200.00 |
| 50 | [1, 2, 3, 4] | 0.1264 | 1.0000 | 0.7812 | 0.0000 | 99.66 | 200.00 |

The naive interval keeps counting correlated observations as if they
were independent, so its coverage deteriorates as block size grows.
The fallback restores the intended bounded-data guarantee in this
synthetic model by reducing the sample size to the number of complete
independent blocks; the price is wider intervals and later or absent
decisions. This result supports a diagnostic response to a known block
structure, not a general correction for unknown RL dependence.

Machine-readable output: `DEPENDENCY_ROBUST_FALLBACK.json`; source:
`dependency_robust_fallback_diagnostic.py`.

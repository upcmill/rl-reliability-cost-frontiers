#!/usr/bin/env python3
"""Audit high-risk manuscript claim boundaries and cross-document anchors."""

from __future__ import annotations

import json
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent


def read_docx_text(path: Path) -> str:
    with ZipFile(path) as archive:
        return archive.read("word/document.xml").decode("utf-8")


def require(text: str, phrases: tuple[str, ...], label: str) -> None:
    missing = [phrase for phrase in phrases if phrase not in text]
    if missing:
        raise AssertionError(f"{label} missing: {missing}")


def main() -> None:
    full = (ROOT / "MANUSCRIPT_DRAFT_V3.md").read_text(encoding="utf-8")
    core = (ROOT / "MANUSCRIPT_SUBMISSION_CORE_EN.md").read_text(encoding="utf-8")
    require(
        full,
        (
            "not a universal seed rule",
            "same-machine cross-script repeatability",
            "external reproducibility",
            "[待核实]",
            "Family-size planning sensitivity",
            "8,843",
            "15/15",
            "1.0178588242",
            "Four comparisons resolved at 200 or 800",
            "eleven remained unresolved at 1,000",
            "V5_RELIABILITY_COST_FRONTIER.json",
        ),
        "full manuscript",
    )
    require(
        core,
        (
            "not a universal seed rule",
            "same-machine cross-script repeatability",
            "different-machine reproducibility",
            "[待核实]",
            "Family-size planning sensitivity",
            "8,843",
            "15/15",
            "1.0178588242",
        ),
        "core manuscript",
    )
    require(
        read_docx_text(ROOT / "MANUSCRIPT_MACHINE_LEARNING_EN.docx"),
        ("Family-size planning sensitivity", "8,843", "V5_RELIABILITY_COST_FRONTIER.json", "[待核实]"),
        "English Word manuscript",
    )
    require(
        read_docx_text(ROOT / "MANUSCRIPT_MACHINE_LEARNING_ZH.docx"),
        ("比较族规模的规划敏感性", "8,843", "V5_RELIABILITY_COST_FRONTIER.json", "待核实"),
        "Chinese Word manuscript",
    )
    audit = json.loads((ROOT / "SUBMISSION_READINESS_AUDIT.json").read_text(encoding="utf-8"))
    assert audit["status"] == "submission_candidate_with_blockers"
    assert audit["blocked_gate_count"] == 3
    declarations = full[full.index("## 11. Declarations") :]
    require(declarations, ("Author-specific CRediT roles", "[待补充]"), "declarations")
    print("submission claim-boundary audit: PASS")
    print("checked=full/core/English Word/Chinese Word/readiness/declarations")


if __name__ == "__main__":
    main()

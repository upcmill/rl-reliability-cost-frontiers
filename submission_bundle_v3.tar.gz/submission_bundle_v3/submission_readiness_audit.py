#!/usr/bin/env python3
"""Audit the evidence gates for the current submission candidate."""

from __future__ import annotations

import csv
import hashlib
import json
import tarfile
from zipfile import ZipFile
from pathlib import Path


ROOT = Path(__file__).resolve().parent


ARCHIVE_REQUIRED = {
    "submission_bundle_v3/README.md",
    "submission_bundle_v3/AUTHOR_EXTERNAL_INFO_INTAKE_ZH.md",
    "submission_bundle_v3/unpaired_budget_requirements.py",
    "submission_bundle_v3/MANUSCRIPT_SUBMISSION_CORE_EN.md",
    "submission_bundle_v3/MANUSCRIPT_MACHINE_LEARNING_CORE_EN.docx",
    "submission_bundle_v3/SUPPLEMENTARY_INFORMATION_V3.md",
    "submission_bundle_v3/SUPPLEMENTARY_INFORMATION_V3.docx",
    "submission_bundle_v3/THEORY_AUDIT_V3.json",
    "submission_bundle_v3/MANUSCRIPT_MACHINE_LEARNING_EN.docx",
    "submission_bundle_v3/MANUSCRIPT_MACHINE_LEARNING_ZH.docx",
    "submission_bundle_v3/EFFECT_SIZE_TABLE_V3.md",
    "submission_bundle_v3/RAW_RETURN_TABLE_V3.md",
    "submission_bundle_v3/VALIDATION_SELECTION_UNCERTAINTY_V3.md",
    "submission_bundle_v3/validation_selection_uncertainty_v3.json",
    "submission_bundle_v3/SEED_DISTRIBUTION_TABLE_V3.md",
    "submission_bundle_v3/FORMAL_V3_REPORT.md",
    "submission_bundle_v3/ENVIRONMENT_VALIDATION.md",
    "submission_bundle_v3/LITERATURE_VERIFICATION.md",
    "submission_bundle_v3/OPENALEX_FIRST_SCREEN.md",
    "submission_bundle_v3/OPENALEX_DEDUPLICATED_CANDIDATES.csv",
    "submission_bundle_v3/LITERATURE_UPDATE_2026-10-31.md",
    "submission_bundle_v3/literature_search_raw/2026-10-31_update/SHA256SUMS.txt",
    "submission_bundle_v3/literature_search_raw/2026-10-31_update/RETRIEVAL_METADATA.md",
    "submission_bundle_v3/literature_search_raw/2026-10-31_update/springer_machine_learning_submission_guidelines.html",
    "submission_bundle_v3/literature_search_raw/2026-10-31_update/openalex_confidence_sequences.json",
    "submission_bundle_v3/literature_search_raw/2026-10-31_update/openalex_rl_statistical_comparison.json",
    "submission_bundle_v3/literature_search_raw/2026-10-31_update/crossref_rl_evaluation_confidence.json",
    "submission_bundle_v3/RUNTIME_COST_TABLE_V3.md",
    "submission_bundle_v3/RUNTIME_COST_TABLE_V3.json",
    "submission_bundle_v3/VALIDATION_TUNING_COST_V3.md",
    "submission_bundle_v3/VALIDATION_TUNING_COST_V3.json",
    "submission_bundle_v3/generate_validation_tuning_cost.py",
    "submission_bundle_v3/audit_validation_tuning_cost.py",
    "submission_bundle_v3/RELIABILITY_COST_FRONTIER_V3.md",
    "submission_bundle_v3/RELIABILITY_COST_FRONTIER_V3.json",
    "submission_bundle_v3/audit_runtime_cost_table.py",
    "submission_bundle_v3/audit_reliability_cost_frontier.py",
    "submission_bundle_v3/MLJ_CONTRIBUTION_INFORMATION_SHEET.md",
    "submission_bundle_v3/MLJ_CONTRIBUTION_INFORMATION_SHEET.docx",
    "submission_bundle_v3/CALIBRATION_GRID_REPORT.md",
    "submission_bundle_v3/DEPENDENCY_STRESS_DIAGNOSTIC.md",
    "submission_bundle_v3/DEPENDENCY_STRESS_DIAGNOSTIC.json",
    "submission_bundle_v3/dependency_stress_diagnostic.py",
    "submission_bundle_v3/test_dependency_stress_diagnostic.py",
    "submission_bundle_v3/DEPENDENCY_ROBUST_FALLBACK.md",
    "submission_bundle_v3/DEPENDENCY_ROBUST_FALLBACK.json",
    "submission_bundle_v3/dependency_robust_fallback_diagnostic.py",
    "submission_bundle_v3/test_dependency_robust_fallback_diagnostic.py",
    "submission_bundle_v3/INDEPENDENT_THEORY_CHECK.md",
    "submission_bundle_v3/INDEPENDENT_THEORY_CHECK.json",
    "submission_bundle_v3/independent_theory_reimplementation.py",
    "submission_bundle_v3/test_independent_theory_reimplementation.py",
    "submission_bundle_v3/INDEPENDENT_V3_RECOMPUTE.md",
    "submission_bundle_v3/INDEPENDENT_V3_RECOMPUTE.json",
    "submission_bundle_v3/independent_v3_recompute.py",
    "submission_bundle_v3/test_independent_v3_recompute.py",
    "submission_bundle_v3/MARGIN_SENSITIVITY_V3.md",
    "submission_bundle_v3/margin_sensitivity_v3.json",
    "submission_bundle_v3/calibration_grid.json",
    "submission_bundle_v3/CONTINUOUS_SUPPLEMENT_REPORT.md",
    "submission_bundle_v3/CONTINUOUS_SCOPE_EXPANSION_REPORT.md",
    "submission_bundle_v3/sb3_continuous_pendulum/raw_seed_metrics.csv",
    "submission_bundle_v3/sb3_continuous_mountaincar/raw_seed_metrics.csv",
    "submission_bundle_v3/manuscript_figures/fig_selection_uncertainty.png",
    "submission_bundle_v3/PARTIAL_OBSERVABILITY_SCOPE_REPORT.md",
    "submission_bundle_v3/sb3_partial_observable_scope/raw_seed_metrics.csv",
    "submission_bundle_v3/QUEUE_BUDGET_FOLLOWUP_REPORT.md",
    "submission_bundle_v3/QUEUE_BUDGET_FOLLOWUP_AUDIT.json",
    "submission_bundle_v3/followup_budget_queue.py",
    "submission_bundle_v3/audit_queue_budget_followup.py",
    "submission_bundle_v3/sb3_queue_budget_followup_v1/raw_seed_metrics.csv",
    "submission_bundle_v3/manuscript_figures/fig_queue_budget_followup.png",
    "submission_bundle_v3/FINAL_PREREGISTRATION_V4_EXTENSION.md",
    "submission_bundle_v3/V4_EXTENSION_REPORT.md",
    "submission_bundle_v3/V4_EXTENSION_AUDIT.json",
    "submission_bundle_v3/audit_v4_extension.py",
    "submission_bundle_v3/V4_SEQUENCE_CONSISTENCY.md",
    "submission_bundle_v3/V4_SEQUENCE_CONSISTENCY.json",
    "submission_bundle_v3/v4_sequence_consistency.py",
    "submission_bundle_v3/MINIMAX_ALPHA_SPENDING.md",
    "submission_bundle_v3/MINIMAX_ALPHA_SPENDING.json",
    "submission_bundle_v3/minimax_alpha_spending.py",
    "submission_bundle_v3/test_margin_sensitivity_v3.py",
    "submission_bundle_v3/test_minimax_alpha_spending.py",
    "submission_bundle_v3/sb3_v4_extension/raw_seed_metrics.csv",
    "submission_bundle_v3/sb3_v4_extension/run_config.json",
    "submission_bundle_v3/sb3_v4_extension/summary.json",
    "submission_bundle_v3/manuscript_figures/fig_v4_extension.png",
    "submission_bundle_v3/FINAL_PREREGISTRATION_V5_EXTENSION.md",
    "submission_bundle_v3/REPRODUCTION_MANIFEST_V5.md",
    "submission_bundle_v3/V5_EXTENSION_AUDIT.md",
    "submission_bundle_v3/V5_EXTENSION_AUDIT.json",
    "submission_bundle_v3/v5_budget_extension.py",
    "submission_bundle_v3/audit_v5_extension.py",
    "submission_bundle_v3/V5_RELIABILITY_COST_FRONTIER.md",
    "submission_bundle_v3/V5_RELIABILITY_COST_FRONTIER.json",
    "submission_bundle_v3/generate_v5_reliability_cost_frontier.py",
    "submission_bundle_v3/audit_v5_reliability_cost_frontier.py",
    "submission_bundle_v3/test_v5_reliability_cost_frontier.py",
    "submission_bundle_v3/sb3_v5_extension/raw_seed_metrics.csv",
    "submission_bundle_v3/sb3_v5_extension/run_config.json",
    "submission_bundle_v3/sb3_v5_extension/summary.json",
    "submission_bundle_v3/manuscript_figures/fig_v5_extension.png",
    "submission_bundle_v3/FINAL_PREREGISTRATION_V6_TASK_FAMILY.md",
    "submission_bundle_v3/sb3_v6_task_family/raw_seed_metrics.csv",
    "submission_bundle_v3/sb3_v6_task_family/run_config.json",
    "submission_bundle_v3/sb3_v6_task_family/summary.json",
    "submission_bundle_v3/sb3_v6_task_family/V6_TASK_FAMILY_AUDIT.json",
    "submission_bundle_v3/sb3_v6_task_family/V6_TASK_FAMILY_EXTENSION_REPORT.md",
    "submission_bundle_v3/manuscript_figures/fig_v6_extension.png",
    "submission_bundle_v3/EXTERNAL_RERUN_PROTOCOL.md",
    "submission_bundle_v3/EXTERNAL_RERUN_HANDOFF_ZH.md",
    "submission_bundle_v3/validate_external_rerun.py",
    "submission_bundle_v3/test_external_rerun_validator.py",
    "submission_bundle_v3/audit_external_rerun.py",
    "submission_bundle_v3/复跑结果/EXTERNAL_RERUN_AUDIT.md",
    "submission_bundle_v3/复跑结果/EXTERNAL_RERUN_AUDIT.json",
    "submission_bundle_v3/audit_word_manuscript_parity.py",
    "submission_bundle_v3/adaptive_spending_diagnostic.py",
    "submission_bundle_v3/ADAPTIVE_SPENDING_DIAGNOSTIC.md",
    "submission_bundle_v3/adaptive_spending_diagnostic.json",
    "submission_bundle_v3/audit_adaptive_spending.py",
    "submission_bundle_v3/test_adaptive_spending_diagnostic.py",
    "submission_bundle_v3/DESIGN_PLANNING_SENSITIVITY_V3.md",
    "submission_bundle_v3/DESIGN_PLANNING_SENSITIVITY_V3.json",
    "submission_bundle_v3/generate_design_planning_sensitivity.py",
    "submission_bundle_v3/audit_design_planning_sensitivity.py",
    "submission_bundle_v3/test_design_planning_sensitivity.py",
    "submission_bundle_v3/audit_submission_claim_boundaries.py",
    "submission_bundle_v3/audit_manuscript_structure.py",
    "submission_bundle_v3/MANUSCRIPT_STRUCTURE_AUDIT.json",
    "submission_bundle_v3/audit_manuscript_numeric_claims.py",
    "submission_bundle_v3/MANUSCRIPT_NUMERIC_CLAIM_AUDIT.md",
    "submission_bundle_v3/MANUSCRIPT_NUMERIC_CLAIM_AUDIT.json",
    "submission_bundle_v3/test_manuscript_numeric_claims.py",
    "submission_bundle_v3/SUBMISSION_READINESS_AUDIT.md",
    "submission_bundle_v3/SUBMISSION_READINESS_AUDIT.json",
    "submission_bundle_v3/submission_readiness_audit.py",
    "submission_bundle_v3/BUDGET_FEASIBILITY_AUDIT_V3.md",
    "submission_bundle_v3/BUDGET_FEASIBILITY_AUDIT_V3.json",
    "submission_bundle_v3/generate_budget_feasibility_audit.py",
    "submission_bundle_v3/test_budget_feasibility_audit.py",
}


def archive_is_current() -> tuple[bool, str]:
    archive = ROOT / "submission_bundle_v3.tar.gz"
    sidecar = ROOT / "submission_bundle_v3.tar.gz.sha256"
    if not archive.is_file() or not sidecar.is_file():
        return False, "submission bundle or SHA-256 sidecar is missing"
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    recorded = sidecar.read_text(encoding="utf-8").split()[0]
    if digest != recorded:
        return False, "submission bundle SHA-256 sidecar does not match archive bytes"
    with tarfile.open(archive, "r:gz") as handle:
        all_names = handle.getnames()
    names = set(all_names)
    missing = sorted(ARCHIVE_REQUIRED - names)
    if missing:
        return False, "archive missing: " + ", ".join(missing)
    return True, f"current archive with {len(names)} unique paths ({len(all_names)} tar members) and matching SHA-256 sidecar"


def word_artifacts_are_complete() -> tuple[bool, str]:
    details = []
    for filename in ("MANUSCRIPT_MACHINE_LEARNING_EN.docx", "MANUSCRIPT_MACHINE_LEARNING_ZH.docx"):
        path = ROOT / filename
        if not path.is_file():
            return False, f"missing {filename}"
        with ZipFile(path) as archive:
            media = [name for name in archive.namelist() if name.startswith("word/media/")]
            xml = archive.read("word/document.xml").decode("utf-8")
        table_count = xml.count("<w:tbl>")
        if (
            len(media) != 13
            or table_count < 16
            or "EFFECT_SIZE_TABLE_V3.md" not in xml
            or "CALIBRATION_GRID_REPORT.md" not in xml
            or "QUEUE_BUDGET_FOLLOWUP_AUDIT.json" not in xml
            or "V4_EXTENSION_AUDIT.json" not in xml
            or "V5_EXTENSION_AUDIT.json" not in xml
            or "V5_RELIABILITY_COST_FRONTIER.json" not in xml
            or "V6_TASK_FAMILY_AUDIT.json" not in xml
            or "margin_sensitivity_v3.json" not in xml
        ):
            return False, f"{filename}: expected 13 figures, at least 16 tables, effect-size/calibration/margin provenance, and v4/v5/v6/queue provenance"
        details.append(f"{filename}=13 figures/{table_count} tables")
    return True, "; ".join(details)


def check(name: str, passed: bool, evidence: str, blocker: bool = False) -> dict:
    return {"name": name, "status": "pass" if passed else "blocked" if blocker else "open", "evidence": evidence}


def main() -> None:
    results = []
    required = [
        "MANUSCRIPT_DRAFT_V3.md",
        "MANUSCRIPT_SUBMISSION_CORE_EN.md",
        "MANUSCRIPT_MACHINE_LEARNING_EN.docx",
        "MANUSCRIPT_MACHINE_LEARNING_CORE_EN.docx",
        "MANUSCRIPT_MACHINE_LEARNING_ZH.docx",
        "SUPPLEMENTARY_INFORMATION_V3.md",
        "SUPPLEMENTARY_INFORMATION_V3.docx",
        "THEORY_AUDIT_V3.json",
        "FINAL_PREREGISTRATION_V3.md",
        "REPRODUCTION_MANIFEST_V3.md",
        "ENVIRONMENT_VALIDATION.md",
        "CLAIM_EVIDENCE_MATRIX.md",
        "SUBMISSION_METADATA_TEMPLATE.md",
        "EXTERNAL_INFO_COLLECTION_GUIDE.md",
        "AUTHOR_EXTERNAL_INFO_INTAKE_ZH.md",
        "PUBLIC_DEPOSITION_README.md",
        "CITATION_CFF_TEMPLATE.yml",
        "SUBMISSION_PLACEHOLDER_AUDIT.md",
        "SUBMISSION_PLACEHOLDER_AUDIT.json",
        "audit_submission_placeholders.py",
        "SUBMISSION_READINESS_AUDIT.md",
        "SUBMISSION_READINESS_AUDIT.json",
        "submission_readiness_audit.py",
        "BUDGET_FEASIBILITY_AUDIT_V3.md",
        "BUDGET_FEASIBILITY_AUDIT_V3.json",
        "generate_budget_feasibility_audit.py",
        "test_budget_feasibility_audit.py",
        "MLJ_CONTRIBUTION_INFORMATION_SHEET.md",
        "MLJ_CONTRIBUTION_INFORMATION_SHEET.docx",
        "SUBMISSION_GAP_CLOSURE_CHECKLIST.md",
        "FINAL_SUBMISSION_HANDOFF_ZH.md",
        "CALIBRATION_GRID_REPORT.md",
        "calibration_grid.json",
        "calibration_grid.py",
        "DEPENDENCY_STRESS_DIAGNOSTIC.md",
        "DEPENDENCY_STRESS_DIAGNOSTIC.json",
        "dependency_stress_diagnostic.py",
        "test_dependency_stress_diagnostic.py",
        "INDEPENDENT_THEORY_CHECK.md",
        "INDEPENDENT_THEORY_CHECK.json",
        "independent_theory_reimplementation.py",
        "test_independent_theory_reimplementation.py",
        "INDEPENDENT_V3_RECOMPUTE.md",
        "INDEPENDENT_V3_RECOMPUTE.json",
        "independent_v3_recompute.py",
        "test_independent_v3_recompute.py",
        "SYSTEMATIC_NOVELTY_REVIEW.md",
        "LITERATURE_SEARCH_LOG.md",
        "LITERATURE_UPDATE_2026-10-31.md",
        "TUNING_STABILITY_V3_REPORT.md",
        "FINAL_PREREGISTRATION_TUNING_EXTENSION_V1.md",
        "TUNING_STABILITY_V20_REPORT.md",
        "TUNING_STABILITY_V20_PROVENANCE.md",
        "TUNING_STABILITY_V20_AUDIT.json",
        "audit_tuning_stability_v20.py",
        "test_tuning_stability_v20.py",
        "audit_public_archive_safety.py",
        "test_public_archive_safety.py",
        "PUBLIC_ARCHIVE_SANITIZATION_AUDIT.md",
        "PUBLIC_ARCHIVE_SANITIZATION_AUDIT.json",
        "sb3_tuning_stability_v20/summary.json",
        "sb3_tuning_stability_v20/raw_rows.json",
        "V3_NORMALIZATION_SENSITIVITY.md",
        "MARGIN_SENSITIVITY_V3.md",
        "margin_sensitivity_v3.json",
        "BUDGET_SCALING_DIAGNOSTIC.md",
        "EVAL_EPISODE_SENSITIVITY_DIAGNOSTIC.md",
        "margin_sensitivity_v3.py",
        "SUPPLEMENTARY_DIAGNOSTIC_AUDIT.json",
        "EXTERNAL_RERUN_PROTOCOL.md",
        "EXTERNAL_RERUN_HANDOFF_ZH.md",
        "validate_external_rerun.py",
        "test_external_rerun_validator.py",
        "audit_external_rerun.py",
        "复跑结果/EXTERNAL_RERUN_AUDIT.md",
        "复跑结果/EXTERNAL_RERUN_AUDIT.json",
        "复跑结果/external_rerun_output/raw_seed_metrics.csv",
        "复跑结果/external_rerun_output/run_config.json",
        "复跑结果/external_rerun_output/summary.json",
        "复跑结果/external_rerun_output/final_metadata.json",
        "复跑结果/external_rerun_output/EXTERNAL_RERUN_OUTPUT_SHA256SUMS.txt",
        "复跑结果/external_rerun_output/external_rerun.log",
        "复跑结果/handoff_windows/preflight_metadata.json",
        "复跑结果/handoff_windows/handoff_manifest.txt",
        "SEED_DISTRIBUTION_TABLE_V3.md",
        "RUNTIME_COST_TABLE_V3.md",
        "RUNTIME_COST_TABLE_V3.json",
        "VALIDATION_TUNING_COST_V3.md",
        "VALIDATION_TUNING_COST_V3.json",
        "generate_validation_tuning_cost.py",
        "audit_validation_tuning_cost.py",
        "generate_runtime_cost_table.py",
        "audit_runtime_cost_table.py",
        "RELIABILITY_COST_FRONTIER_V3.md",
        "RELIABILITY_COST_FRONTIER_V3.json",
        "generate_reliability_cost_frontier.py",
        "audit_reliability_cost_frontier.py",
        "test_reliability_cost_frontier.py",
        "requirements-rl-lock.txt",
        "unpaired_budget_requirements.py",
        "EFFECT_SIZE_TABLE_V3.md",
        "RAW_RETURN_TABLE_V3.md",
        "VALIDATION_SELECTION_UNCERTAINTY_V3.md",
        "FINAL_PREREGISTRATION_PARTIAL_OBSERVABILITY.md",
        "PARTIAL_OBSERVABILITY_SCOPE_REPORT.md",
        "PARTIAL_OBSERVABILITY_SCOPE_AUDIT.json",
        "QUEUE_BUDGET_FOLLOWUP_REPORT.md",
        "QUEUE_BUDGET_FOLLOWUP_AUDIT.json",
        "followup_budget_queue.py",
        "audit_queue_budget_followup.py",
        "FINAL_PREREGISTRATION_V4_EXTENSION.md",
        "FINAL_PREREGISTRATION_V5_EXTENSION.md",
        "REPRODUCTION_MANIFEST_V5.md",
        "V4_EXTENSION_REPORT.md",
        "V4_EXTENSION_AUDIT.json",
        "audit_v4_extension.py",
        "V4_SEQUENCE_CONSISTENCY.md",
        "V4_SEQUENCE_CONSISTENCY.json",
        "v4_sequence_consistency.py",
        "V5_EXTENSION_AUDIT.md",
        "V5_EXTENSION_AUDIT.json",
        "v5_budget_extension.py",
        "audit_v5_extension.py",
        "V5_RELIABILITY_COST_FRONTIER.md",
        "V5_RELIABILITY_COST_FRONTIER.json",
        "generate_v5_reliability_cost_frontier.py",
        "audit_v5_reliability_cost_frontier.py",
        "test_v5_reliability_cost_frontier.py",
        "MINIMAX_ALPHA_SPENDING.md",
        "MINIMAX_ALPHA_SPENDING.json",
        "minimax_alpha_spending.py",
        "DESIGN_PLANNING_SENSITIVITY_V3.md",
        "DESIGN_PLANNING_SENSITIVITY_V3.json",
        "generate_design_planning_sensitivity.py",
        "audit_design_planning_sensitivity.py",
        "test_design_planning_sensitivity.py",
        "audit_submission_claim_boundaries.py",
        "audit_manuscript_structure.py",
        "MANUSCRIPT_STRUCTURE_AUDIT.json",
        "audit_manuscript_numeric_claims.py",
        "MANUSCRIPT_NUMERIC_CLAIM_AUDIT.md",
        "MANUSCRIPT_NUMERIC_CLAIM_AUDIT.json",
        "test_manuscript_numeric_claims.py",
        "test_margin_sensitivity_v3.py",
        "test_minimax_alpha_spending.py",
        "test_v5_extension.py",
        "sb3_v4_extension/raw_seed_metrics.csv",
        "sb3_v4_extension/run_config.json",
        "sb3_v4_extension/summary.json",
        "sb3_v5_extension/raw_seed_metrics.csv",
        "sb3_v5_extension/run_config.json",
        "sb3_v5_extension/summary.json",
    "test_queue_budget_followup.py",
    ]
    results.append(check("required manuscript and audit files", all((ROOT / name).exists() for name in required), ", ".join(required)))
    archive_ok, archive_evidence = archive_is_current()
    results.append(check("submission archive completeness", archive_ok, archive_evidence, blocker=False))
    word_ok, word_evidence = word_artifacts_are_complete()
    results.append(check("Word artifact completeness", word_ok, word_evidence, blocker=False))

    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    results.append(check("v3 row and split counts", len(rows) == 600 and sum(row["split"] == "validation" for row in rows) == 300 and sum(row["split"] == "test" for row in rows) == 300, "sb3_formal_v3/raw_seed_metrics.csv: 600 rows, 300 validation, 300 test"))

    summary = json.loads((ROOT / "sb3_formal_v3/familywise_cost_summary.json").read_text(encoding="utf-8"))
    decisions = [row.get("decision", row.get("final_decision")) for row in summary.get("comparisons", [])]
    if not decisions:
        decisions = [row.get("decision") for row in summary.get("rows", [])]
    results.append(check("primary v3 decision family", len(decisions) == 15 and all(value == "max_budget_inconclusive" for value in decisions), "sb3_formal_v3/familywise_cost_summary.json: 15/15 maximum-budget inconclusive"))

    partial_rows = list(csv.DictReader((ROOT / "sb3_partial_observable_scope/raw_seed_metrics.csv").open(newline="", encoding="utf-8")))
    partial = json.loads((ROOT / "sb3_partial_observable_scope/summary.json").read_text(encoding="utf-8"))
    partial_audit = json.loads((ROOT / "PARTIAL_OBSERVABILITY_SCOPE_AUDIT.json").read_text(encoding="utf-8"))
    partial_ok = (
        len(partial_rows) == 240
        and len(partial["comparisons"]) == 6
        and all(item["decision"]["decision"] == "max_budget_inconclusive" for item in partial["comparisons"])
        and partial_audit.get("all_replay_differences_zero") is True
    )
    results.append(check("partial-observability diagnostic integrity", partial_ok, "240 rows, six inconclusive comparisons, six zero-difference same-machine replay rows"))

    v4_audit = json.loads((ROOT / "V4_EXTENSION_AUDIT.json").read_text(encoding="utf-8"))
    v4_ok = (
        v4_audit.get("status") == "PASS"
        and v4_audit.get("rows") == 6000
        and v4_audit.get("cell_count") == 15
        and v4_audit.get("decision_counts", {}).get("a_superior") == 1
        and v4_audit.get("decision_counts", {}).get("max_budget_inconclusive") == 14
    )
    results.append(check("prospective v4 extension integrity", v4_ok, "6,000 rows, 15 cells, one queue superiority decision at 200 and 14 maximum-budget inconclusive comparisons"))

    consistency = json.loads((ROOT / "V4_SEQUENCE_CONSISTENCY.json").read_text(encoding="utf-8"))
    consistency_rows = consistency.get("rows", [])
    consistency_ok = (
        consistency.get("status") == "PASS"
        and len(consistency_rows) == 4
        and all(row.get("estimate", 0) > 0 for row in consistency_rows)
        and consistency.get("scope") == "descriptive cross-sequence consistency; no pooled inference"
    )
    results.append(check("v4 queue sequence consistency integrity", consistency_ok, "Four non-pooled 200/400-seed rows, all positive estimates, descriptive scope locked"))

    v5_audit = json.loads((ROOT / "V5_EXTENSION_AUDIT.json").read_text(encoding="utf-8"))
    v5_ok = (
        v5_audit.get("status") == "PASS"
        and v5_audit.get("rows") == 15000
        and v5_audit.get("cell_count") == 15
        and v5_audit.get("decision_counts") == {"a_superior": 3, "b_superior": 1, "max_budget_inconclusive": 11}
    )
    results.append(check("v5 resolution-cost extension integrity", v5_ok, "15,000 rows, 15 cells, four terminal decisions by 1,000 seeds, 11 maximum-budget inconclusive"))

    v6_audit_path = ROOT / "sb3_v6_task_family/V6_TASK_FAMILY_AUDIT.json"
    v6_audit = json.loads(v6_audit_path.read_text(encoding="utf-8")) if v6_audit_path.exists() else {}
    v6_ok = (
        v6_audit.get("status") == "PASS"
        and v6_audit.get("rows") == 1440
        and v6_audit.get("decision_checks") == 24
        and all(v6_audit.get("checks", {}).values())
    )
    results.append(check("v6 task-family extension integrity", v6_ok, "1,440 rows, fixed two-task scope, and 24 raw-CSV decision recomputations pass" if v6_ok else "v6 task-family artifact is missing or incomplete", blocker=False))

    results.append(check("internal repeatability", (ROOT / "sb3_formal_v3/independent_reproduction_summary.json").exists(), "same-machine cross-script replay artifact", blocker=False))
    results.append(check("external rerun handoff", (ROOT / "EXTERNAL_RERUN_PROTOCOL.md").exists(), "sealed operator protocol and deviation template", blocker=False))
    runtime_audit = False
    runtime_evidence = "Runtime-cost table is missing or has not passed its raw-CSV consistency audit"
    runtime_json = ROOT / "RUNTIME_COST_TABLE_V3.json"
    if runtime_json.exists():
        runtime = json.loads(runtime_json.read_text(encoding="utf-8"))
        runtime_audit = runtime.get("status") == "descriptive_runtime_cost_only" and runtime.get("rows") == 300
        runtime_evidence = "300 selected test rows, 15 cells, and raw-CSV total-runtime match" if runtime_audit else runtime_evidence
    results.append(check("runtime-cost accounting", runtime_audit, runtime_evidence, blocker=False))
    frontier_json = ROOT / "RELIABILITY_COST_FRONTIER_V3.json"
    frontier = json.loads(frontier_json.read_text(encoding="utf-8")) if frontier_json.exists() else {}
    frontier_ok = frontier.get("status") == "audited_reliability_cost_frontier" and len(frontier.get("looks", [])) == 4
    results.append(check("reliability-cost frontier", frontier_ok, "four audited looks combine analytic interval geometry with recorded cumulative runtime" if frontier_ok else "Reliability-cost frontier artifact is missing or incomplete", blocker=False))
    v5_frontier = json.loads((ROOT / "V5_RELIABILITY_COST_FRONTIER.json").read_text(encoding="utf-8")) if (ROOT / "V5_RELIABILITY_COST_FRONTIER.json").exists() else {}
    v5_frontier_ok = (
        v5_frontier.get("status") == "audited_v5_reliability_cost_frontier"
        and len(v5_frontier.get("looks", [])) == 5
        and v5_frontier.get("decision_counts") == {"a_superior": 3, "b_superior": 1, "max_budget_inconclusive": 11}
    )
    results.append(check("v5 reliability-cost frontier", v5_frontier_ok, "five audited looks, raw-runtime match, and 3/1/11 decision classes" if v5_frontier_ok else "v5 reliability-cost frontier artifact is missing or incomplete", blocker=False))
    structure_audit = json.loads((ROOT / "MANUSCRIPT_STRUCTURE_AUDIT.json").read_text(encoding="utf-8")) if (ROOT / "MANUSCRIPT_STRUCTURE_AUDIT.json").exists() else {}
    structure_ok = structure_audit.get("status") == "PASS" and all(structure_audit.get("checks", {}).values())
    results.append(check("manuscript structure audit", structure_ok, "chapter order, claim-boundary anchors, final-look convention, and Word dimensions pass" if structure_ok else "manuscript structure audit is missing or incomplete", blocker=False))
    external_audit = ROOT / "复跑结果/EXTERNAL_RERUN_AUDIT.json"
    external_payload = json.loads(external_audit.read_text(encoding="utf-8")) if external_audit.exists() else {}
    external_ok = (
        external_payload.get("status") == "PASS"
        and external_payload.get("evidence_boundary", {}).get("different_machine_rerun") is True
        and external_payload.get("comparison", {}).get("all_selected_configurations_match") is True
        and external_payload.get("comparison", {}).get("all_decisions_match") is True
        and external_payload.get("output_checksums", {}).get("all_match") is True
        and external_payload.get("source_hashes", {}).get("runtime_source_match") is True
    )
    external_evidence = (
        "Windows AMD64 sealed rerun: 600 raw rows, output checksum and runtime-source hash checks pass; 15/15 selections and decisions match; the rerun manifest is classified as a post-rerun documentation update and independent-team identity remains unverified"
        if external_ok
        else "No passing different-machine sealed-rerun audit is present"
    )
    results.append(check("external reproducibility", external_ok, external_evidence, blocker=not external_ok))
    results.append(check("public data/code archive", False, "No public repository DOI or URL is present", blocker=True))
    results.append(check("independent literature screening", False, "Scoping review exists, but database exports and second-reviewer screening are absent", blocker=True))
    manuscript_text = (ROOT / "MANUSCRIPT_DRAFT_V3.md").read_text(encoding="utf-8")
    declarations_present = "## 11. Declarations" in manuscript_text
    unresolved_declarations = any(token in manuscript_text for token in ("[author information to be completed]", "[to be completed]", "[待补充]"))
    results.append(check("declaration fields", declarations_present and not unresolved_declarations, "Declarations section exists, but author/funding/conflict/archive placeholders remain" if unresolved_declarations else "Declarations complete" , blocker=unresolved_declarations))

    blocked = [row for row in results if row["status"] == "blocked"]
    payload = {
        "status": "submission_candidate_with_blockers" if blocked else "submission_ready_pending_editorial_check",
        "blocked_gate_count": len(blocked),
        "results": results,
        "interpretation": "Passing internal audits does not prove SCI acceptance. Blocked gates must be resolved or explicitly accepted by the authors before submission.",
    }
    (ROOT / "SUBMISSION_READINESS_AUDIT.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    lines = ["# Submission Readiness Audit", "", f"Status: **{payload['status']}**", "", "| Gate | Status | Evidence |", "|---|---|---|"]
    lines.extend(f"| {row['name']} | {row['status']} | {row['evidence']} |" for row in results)
    lines.extend(["", "This audit distinguishes internal completion from publication readiness. It does not guarantee acceptance or indexing."])
    (ROOT / "SUBMISSION_READINESS_AUDIT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

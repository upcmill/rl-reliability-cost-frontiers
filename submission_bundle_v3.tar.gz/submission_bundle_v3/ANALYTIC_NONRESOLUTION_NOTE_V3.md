# Analytic Non-Resolution Note for v3

This note records a deterministic consequence of the already frozen v3
protocol. It does not alter the preregistration, raw data, decision rule,
alpha allocation, or primary estimand, and it uses no observed RL outcome.

## Frozen inputs

- Family alpha: `0.05`
- Predeclared comparisons: `15`
- Comparison alpha: `0.05/15`
- Looks: `n = 5, 10, 15, 20` per algorithm
- Look spending: `alpha_k = alpha_cmp * 6/(pi^2 k^2)`
- Metric range: `[0, 1]`
- Superiority margin: `0.05`
- Precision target: width `0.10`
- Interval: unpaired Hoeffding, clipped to `[-1, 1]`

## Derivation

At the final look with equal sample sizes of 20, the sum of the two Hoeffding
radii is

```text
R_4 = 2 sqrt(log(4 / alpha_4) / (2 * 20)) = 1.0178588242230167.
```

For any observed mean difference `d` in `[-1, 1]`, the largest possible lower
endpoint is `1 - R_4 = -0.0178588242230167`, which is below the superiority
margin `0.05`. The opposite superiority direction is symmetric. After clipping
to `[-1, 1]`, the minimum possible interval width over `d in [-1, 1]` is
`min(2, R_4) = 1.0178588242230167`, which exceeds the precision target `0.10`.
The radius sums at the earlier looks are larger: `1.7421569548`,
`1.3397067962`, and `1.1422201607`.

Therefore, the exact v3 state machine cannot declare superiority or precision
for any bounded data sequence at or before 20 seeds. The observed 15/15
maximum-budget outcomes are consistent with this deterministic boundary, but
they are not empirical power estimates and do not imply algorithm equality.

## Audit link

The numerical boundary is covered by
`test_formal_v3_budget_is_structurally_non_resolving` in
`test_pilot_protocol.py`. This note is an analytical supplement to Corollary 2
in `MANUSCRIPT_DRAFT_V3.md`, not a replacement for the conditional coverage
proof or for external reproduction.

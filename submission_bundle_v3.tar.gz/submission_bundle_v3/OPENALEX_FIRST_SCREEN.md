# OpenAlex First-Screener Record

This file documents the deterministic first-pass processing of the OpenAlex
discovery export. It is not an independent second screening and does not close
the systematic-review gate.

## Export and deduplication

- Input directory: `literature_search_raw/2026-10-30_openalex_screening/`
- Query files: six concept searches, each requesting 50 records.
- Deduplication script: `deduplicate_openalex_screening.py`
- Output: `OPENALEX_DEDUPLICATED_CANDIDATES.csv`
- Result: 249 unique candidates after DOI-first and normalized-title fallback
  deduplication.
- Duplicate rule: DOI values are lower-cased and stripped of the DOI URL prefix;
  records without DOI use a lower-cased alphanumeric normalized title.

## First-pass handling of directly relevant records

The following records were retained for source-level comparison. “Retain” does
not mean that the paper is methodologically overlapping; it means that its
abstract or metadata is relevant enough to prevent an unsupported novelty claim.

| Record | First-pass status | Reason |
|---|---|---|
| Chan et al. (2019), *Measuring the Reliability of Reinforcement Learning Algorithms* [L15] | Retain and verify | RL reliability metrics, statistical comparison tools, and reporting recommendations. |
| Khamaru et al. (2022), *Instance-Dependent Confidence and Early Stopping for Reinforcement Learning* [L16] | Retain and verify | Confidence regions and data-dependent stopping for policy/value evaluation. |
| Zhang et al. (2018), *A Study on Overfitting in Deep Reinforcement Learning* [L13] | Retain and verify | Train/test overfitting and generalization gap. |
| Nagarajan et al. (2018), *Deterministic Implementations for Reproducibility in Deep Reinforcement Learning* [L14] | Retain and verify | Training nondeterminism and reproducibility. |
| Colas et al. (2018, 2019) [L2, L3] | Retain and verify | Seed counts, power, effect sizes, and statistical comparisons. |
| Shi et al. (2021), *Statistical Inference of the Value Function for Reinforcement Learning in Infinite-Horizon Settings* | Retain as adjacent theory | Confidence intervals for policy/value functions; different estimand and data setting. |
| Cobbe et al. (2018), *Quantifying Generalization in Reinforcement Learning* | Retain as adjacent evaluation work | Train/test generalization and procedural environments; not the present sequential inference protocol. |
| Hagmann et al. (2023), *Towards Inferential Reproducibility of Machine Learning Research* | Retain as adjacent methodology | Variance sources and inferential reproducibility; broader ML setting. |

Full-text comparison, database-wide deduplication, and an independent second
screener remain required before removing `[待核实]` from any literature-wide
novelty claim.

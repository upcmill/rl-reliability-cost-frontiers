#!/usr/bin/env python3
"""Generate an analytic sensitivity table for comparison-family size.

The table is a planning diagnostic for the bounded finite-look interval.  It
does not use RL observations and must not be interpreted as empirical power.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def look_alpha(family_alpha: float, comparisons: int, look: int) -> float:
    comparison_alpha = family_alpha / comparisons
    return comparison_alpha * 6.0 / (math.pi * math.pi * look * look)


def radius_sum(family_alpha: float, comparisons: int, look: int, n: int) -> float:
    alpha = look_alpha(family_alpha, comparisons, look)
    return 2.0 * math.sqrt(math.log(4.0 / alpha) / (2.0 * n))


def possible_superiority_seeds(
    family_alpha: float, comparisons: int, look: int, margin: float
) -> int:
    alpha = look_alpha(family_alpha, comparisons, look)
    return math.floor(2.0 * math.log(4.0 / alpha) / (1.0 - margin) ** 2) + 1


def width_seeds(
    family_alpha: float, comparisons: int, look: int, target_width: float
) -> int:
    alpha = look_alpha(family_alpha, comparisons, look)
    return math.ceil(8.0 * math.log(4.0 / alpha) / target_width**2)


def build_payload(
    family_alpha: float,
    family_sizes: list[int],
    looks: list[int],
    margin: float,
    target_width: float,
    reference_n: int,
) -> dict:
    rows = []
    for comparisons in family_sizes:
        for look in looks:
            radius = radius_sum(family_alpha, comparisons, look, look * 5)
            rows.append(
                {
                    "comparisons": comparisons,
                    "comparison_alpha": family_alpha / comparisons,
                    "look": look,
                    "seeds_per_algorithm": look * 5,
                    "radius_sum": radius,
                    "minimum_clipped_width": min(2.0, radius),
                    "largest_possible_lower_endpoint": 1.0 - radius,
                    "necessary_seeds_for_possible_superiority": possible_superiority_seeds(
                        family_alpha, comparisons, look, margin
                    ),
                    "seeds_per_algorithm_for_width_target": width_seeds(
                        family_alpha, comparisons, look, target_width
                    ),
                    "radius_at_reference_n": radius_sum(
                        family_alpha, comparisons, look, reference_n
                    ),
                }
            )
    return {
        "status": "analytic_family_size_sensitivity_only",
        "warning": "Planning calculations from the bounded interval; no RL observations, power estimate, or universal seed requirement.",
        "assumptions": {
            "family_alpha": family_alpha,
            "family_sizes": family_sizes,
            "looks": looks,
            "margin": margin,
            "target_width": target_width,
            "metric_range": "[0, 1]",
            "equal_samples_per_algorithm": True,
            "reference_n": reference_n,
        },
        "rows": rows,
    }


def markdown(payload: dict) -> str:
    assumptions = payload["assumptions"]
    rows = payload["rows"]
    first = {row["comparisons"]: row for row in rows if row["look"] == assumptions["looks"][0]}
    final = {row["comparisons"]: row for row in rows if row["look"] == assumptions["looks"][-1]}
    lines = [
        "# Family-Size Planning Sensitivity",
        "",
        "This table is an analytic planning diagnostic for the bounded finite-look interval.",
        "It contains no RL observations and is not an empirical power curve or a universal seed rule.",
        "The comparison family receives `family_alpha / comparisons`; equal samples are used for the radius calculations.",
        "",
        "| Comparisons | Comparison alpha | First-look radius | Final-look radius | Necessary seeds/algorithm for possible superiority (final) | Seeds/algorithm for width <= 0.10 (final) |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for comparisons in sorted(first):
        early = first[comparisons]
        late = final[comparisons]
        lines.append(
            f"| {comparisons} | {late['comparison_alpha']:.8f} | {early['radius_sum']:.6f} | "
            f"{late['radius_sum']:.6f} | {late['necessary_seeds_for_possible_superiority']:,} | "
            f"{late['seeds_per_algorithm_for_width_target']:,} |"
        )
    lines.extend(
        [
            "",
            f"The reference practical margin is `{assumptions['margin']}` and the target width is `{assumptions['target_width']}`.",
            f"The displayed first and final looks are `{assumptions['looks'][0]}` and `{assumptions['looks'][-1]}`; the full machine-readable table includes every listed look.",
            "Increasing the number of comparisons tightens the per-comparison error allocation and increases the worst-case radius. These values guide preregistered budget planning; they do not describe the observed v3 decisions.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--family-alpha", type=float, default=0.05)
    parser.add_argument("--family-sizes", default="1,3,9,15,30")
    parser.add_argument("--looks", default="1,2,3,4")
    parser.add_argument("--margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    parser.add_argument("--reference-n", type=int, default=20)
    parser.add_argument("--json-output", default="DESIGN_PLANNING_SENSITIVITY_V3.json")
    parser.add_argument("--markdown-output", default="DESIGN_PLANNING_SENSITIVITY_V3.md")
    args = parser.parse_args()
    family_sizes = [int(value) for value in args.family_sizes.split(",") if value]
    looks = [int(value) for value in args.looks.split(",") if value]
    if not family_sizes or not looks or any(value <= 0 for value in family_sizes + looks):
        parser.error("family sizes and looks must be positive")
    if not 0.0 < args.family_alpha < 1.0 or not 0.0 <= args.margin < 1.0:
        parser.error("family alpha must be in (0,1) and margin in [0,1)")
    if args.target_width <= 0.0 or args.reference_n <= 0:
        parser.error("target width and reference n must be positive")
    payload = build_payload(
        args.family_alpha,
        family_sizes,
        looks,
        args.margin,
        args.target_width,
        args.reference_n,
    )
    Path(args.json_output).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    Path(args.markdown_output).write_text(markdown(payload), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

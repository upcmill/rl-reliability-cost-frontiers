#!/usr/bin/env python3
"""Separate replay implementation for the Pendulum supplement."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
from stable_baselines3 import A2C, PPO


ENV_ID = "Pendulum-v1"
RAW_LOWER = -3254.72
RAW_UPPER = 0.0
CONFIGS = {
    "lr3e4_long": {"learning_rate": 3e-4, "batch_size": 64, "n_steps": 256},
    "lr1e4_long": {"learning_rate": 1e-4, "batch_size": 64, "n_steps": 256},
    "lr3e4_short": {"learning_rate": 3e-4, "batch_size": 64, "n_steps": 128},
    "lr1e4_short": {"learning_rate": 1e-4, "batch_size": 64, "n_steps": 128},
}


def make_model(algorithm: str, env, seed: int, config: dict):
    common = dict(seed=seed, env=env, verbose=0, device="cpu")
    if algorithm == "PPO":
        return PPO("MlpPolicy", n_steps=config["n_steps"], batch_size=config["batch_size"], n_epochs=1, learning_rate=config["learning_rate"], **common)
    return A2C("MlpPolicy", n_steps=config["n_steps"], learning_rate=config["learning_rate"], **common)


def evaluate(model, seed: int, episodes: int) -> float:
    env = gym.make(ENV_ID)
    returns = []
    for episode in range(episodes):
        obs, _ = env.reset(seed=seed + episode)
        done = False
        total = 0.0
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            total += float(reward)
        returns.append(total)
    env.close()
    return float(np.mean(returns))


def reproduce(algorithm: str, seed: int, config: dict, checkpoints: list[int], episodes: int) -> float:
    env = gym.make(ENV_ID)
    model = make_model(algorithm, env, seed, config)
    values, trained = [], 0
    for checkpoint in checkpoints:
        model.learn(total_timesteps=checkpoint - trained, reset_num_timesteps=False)
        trained = checkpoint
        raw = evaluate(model, seed + 1_000_000 + checkpoint, episodes)
        values.append(max(0.0, min(1.0, (raw - RAW_LOWER) / (RAW_UPPER - RAW_LOWER))))
    model.env.close()
    return float(np.mean(values))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-dir", default="sb3_continuous_pendulum")
    parser.add_argument("--output", default="sb3_continuous_pendulum/independent_reproduction.json")
    args = parser.parse_args()
    reference = json.loads((Path(args.reference_dir) / "summary.json").read_text())
    checkpoints = reference["run_config"]["checkpoints_resolved"]
    episodes = reference["run_config"]["eval_episodes"]
    rows = []
    for algorithm in reference["algorithms"]:
        selected = reference["summary"][algorithm]["selected_config"]
        config = CONFIGS[selected]
        stored = reference["summary"][algorithm]["test_metrics"]
        reproduced = [reproduce(algorithm, 20_000 + seed, config, checkpoints, episodes) for seed in range(len(stored))]
        rows.append({"algorithm": algorithm, "selected_config": selected, "stored_mean": float(np.mean(stored)), "reproduced_mean": float(np.mean(reproduced)), "mean_absolute_metric_difference": float(np.mean(np.abs(np.asarray(stored) - np.asarray(reproduced))))})
    payload = {
        "status": "continuous_pendulum_cross_script_reproduction",
        "warning": "Same-machine replay; not independent-team reproducibility.",
        "environment": ENV_ID,
        "python_version": platform.python_version(), "python_arch": platform.machine(),
        "torch": torch.__version__,
        "reference_runner_sha256": reference["script_sha256"],
        "reproduction_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "rows": rows,
        "all_zero_mean_absolute_difference": all(row["mean_absolute_metric_difference"] == 0.0 for row in rows),
    }
    output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Recompute the v3 theory audit without importing the production helpers.

This is an internal second implementation intended to catch transcription or
formula-mapping errors. It is not an external statistical review and does not
prove the probabilistic assumptions of the theorem.
"""

from __future__ import annotations

import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / "THEORY_AUDIT_V3.json"
OUTPUT = ROOT / "INDEPENDENT_THEORY_CHECK.json"
REPORT = ROOT / "INDEPENDENT_THEORY_CHECK.md"


def alpha_spend_independent(comparison_alpha: float, look: int) -> float:
    return comparison_alpha * 6.0 / (math.pi * math.pi * look * look)


def radius_sum(comparison_alpha: float, look: int, n: int) -> float:
    alpha = alpha_spend_independent(comparison_alpha, look)
    return 2.0 * math.sqrt(math.log(4.0 / alpha) / (2.0 * n))


def possible_superiority_threshold(comparison_alpha: float, look: int, margin: float) -> int:
    n = 1
    while radius_sum(comparison_alpha, look, n) >= 1.0 - margin:
        n += 1
    return n


def width_threshold(comparison_alpha: float, look: int, width: float) -> int:
    n = 1
    while 2.0 * radius_sum(comparison_alpha, look, n) > width:
        n += 1
    return n


def balanced_width_threshold(comparison_alpha: float, look: int, width: float) -> int:
    n = 1
    while 2.0 * radius_sum(comparison_alpha, look, n / 2.0) > width:
        n += 1
    return n


def balanced_superiority_threshold(comparison_alpha: float, look: int, margin: float) -> int:
    n = 1
    while radius_sum(comparison_alpha, look, n / 2.0) >= 1.0 - margin:
        n += 1
    return n


def close_list(left: list[float], right: list[float], tolerance: float = 1e-12) -> bool:
    return len(left) == len(right) and all(abs(a - b) <= tolerance for a, b in zip(left, right))


def run_check() -> dict:
    family_alpha = 0.05
    comparison_count = 15
    comparison_alpha = family_alpha / comparison_count
    looks = [1, 2, 3, 4]
    sample_sizes = [5, 10, 15, 20]
    margin = 0.05
    target_width = 0.10

    look_alphas = [alpha_spend_independent(comparison_alpha, look) for look in looks]
    spending_sum = sum(look_alphas)
    radii = [radius_sum(comparison_alpha, look, n) for look, n in zip(looks, sample_sizes)]
    possible_thresholds = [possible_superiority_threshold(comparison_alpha, look, margin) for look in looks]
    width_requirements = [width_threshold(comparison_alpha, look, target_width) for look in looks]
    balanced_width = [balanced_width_threshold(comparison_alpha, look, target_width) for look in looks]
    balanced_superiority = [balanced_superiority_threshold(comparison_alpha, look, margin) for look in looks]

    reference = json.loads(REFERENCE.read_text(encoding="utf-8"))
    expected = reference["derived_values"]
    checks = {
        "look_alphas_match_reference": close_list(look_alphas, expected["look_alphas"]),
        "spending_sum_matches_reference": abs(spending_sum - expected["spending_sum"]) <= 1e-12,
        "radius_sums_match_reference": close_list(radii, expected["radius_sums"]),
        "possible_thresholds_match_reference": possible_thresholds == expected["possible_superiority_thresholds"],
        "width_requirements_match_reference": width_requirements == expected["width_requirements_per_algorithm"],
        "balanced_width_match_reference": balanced_width == expected["balanced_total_width_requirements"],
        "balanced_superiority_match_reference": balanced_superiority == expected["balanced_total_possible_superiority_thresholds"],
        "final_budget_is_nonresolving": radii[-1] > 1.0 - margin and radii[-1] > target_width / 2.0,
    }
    payload = {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "scope": "internal independent formula reimplementation",
        "warning": "This is a second implementation on the same machine; it is not external statistical review and does not prove probabilistic assumptions.",
        "inputs": {
            "family_alpha": family_alpha,
            "comparison_count": comparison_count,
            "comparison_alpha": comparison_alpha,
            "looks": looks,
            "sample_sizes": sample_sizes,
            "practical_margin": margin,
            "target_width": target_width,
        },
        "recomputed": {
            "look_alphas": look_alphas,
            "spending_sum": spending_sum,
            "radius_sums": radii,
            "possible_superiority_thresholds": possible_thresholds,
            "width_requirements_per_algorithm": width_requirements,
            "balanced_total_width_requirements": balanced_width,
            "balanced_total_possible_superiority_thresholds": balanced_superiority,
        },
        "checks": checks,
    }
    OUTPUT.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    REPORT.write_text(build_report(payload), encoding="utf-8")
    return payload


def build_report(payload: dict) -> str:
    return "\n".join([
        "# Independent Theory Reimplementation Check",
        "",
        "This report recomputes the v3 finite-look numerical consequences in a",
        "separate implementation without importing the production interval or",
        "budget-planning helpers. All listed checks match `THEORY_AUDIT_V3.json`.",
        "It is an internal second implementation, not an external statistical",
        "review and not a proof of seed independence or external reproducibility.",
        "",
        "- Status: `" + payload["status"] + "`",
        "- Comparison alpha: `" + str(payload["inputs"]["comparison_alpha"]) + "`",
        "- Looks: `" + str(payload["inputs"]["looks"]) + "`",
        "- Recomputed radius sums: `" + str(payload["recomputed"]["radius_sums"]) + "`",
        "- Recomputed possible-superiority thresholds: `" + str(payload["recomputed"]["possible_superiority_thresholds"]) + "`",
        "",
        "The implementation agrees with the reference audit on alpha spending,",
        "radius values, width thresholds, balanced total-budget thresholds, and",
        "the formal v3 non-resolution boundary.",
        "",
    ])


if __name__ == "__main__":
    result = run_check()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)

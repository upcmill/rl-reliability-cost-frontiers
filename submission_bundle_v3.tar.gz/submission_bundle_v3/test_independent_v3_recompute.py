import unittest

from independent_v3_recompute import run


class IndependentV3RecomputeTests(unittest.TestCase):
    def test_all_primary_decisions_match_reference(self):
        payload = run()
        self.assertEqual(payload["status"], "PASS")
        self.assertEqual(payload["matching_count"], 15)


if __name__ == "__main__":
    unittest.main()

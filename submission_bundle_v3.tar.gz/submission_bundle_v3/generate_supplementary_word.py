"""Render the audited supplementary-information Markdown as a Word file."""

from __future__ import annotations

import re
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "SUPPLEMENTARY_INFORMATION_V3.md"
OUTPUT = ROOT / "SUPPLEMENTARY_INFORMATION_V3.docx"


def clean_inline(text: str) -> str:
    text = re.sub(r"!\[([^]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", text)
    text = text.replace("**", "").replace("__", "").replace("`", "")
    text = text.replace("$", "")
    return text.strip()


def set_cell_text(cell, text: str, bold: bool = False) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run(clean_inline(text))
    run.bold = bold
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(9)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def shade(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    element = OxmlElement("w:shd")
    element.set(qn("w:fill"), fill)
    tc_pr.append(element)


def parse_table(lines: list[str]) -> tuple[list[str], list[list[str]]]:
    rows = []
    for line in lines:
        if not line.strip() or set(line.strip()) <= {"|", "-", ":", " "}:
            continue
        rows.append([clean_inline(part.strip()) for part in line.strip().strip("|").split("|")])
    return (rows[0], rows[1:]) if rows else ([], [])


def add_table(doc: Document, headers: list[str], rows: list[list[str]], index: int) -> None:
    caption = doc.add_paragraph(f"Table S{index}. {headers[0] if headers else 'Supplementary summary'}")
    caption.style = "Caption"
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    for column, header in enumerate(headers):
        set_cell_text(table.rows[0].cells[column], header, bold=True)
        shade(table.rows[0].cells[column], "D9E2F3")
    for row in rows:
        cells = table.add_row().cells
        for column in range(len(headers)):
            set_cell_text(cells[column], row[column] if column < len(row) else "")
    doc.add_paragraph()


def configure(doc: Document) -> None:
    section = doc.sections[0]
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(2.54)
    section.right_margin = Cm(2.54)
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.line_spacing = 1.15
    normal.paragraph_format.space_after = Pt(5)
    for style_name, size in (("Title", 16), ("Heading 1", 13), ("Heading 2", 11)):
        style = doc.styles[style_name]
        style.font.name = "Times New Roman"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(31, 31, 31)


def render() -> None:
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    doc = Document()
    configure(doc)
    i = 0
    table_index = 1
    in_code = False
    code_lines: list[str] = []
    while i < len(lines):
        line = lines[i]
        if line.startswith("```"):
            if not in_code:
                in_code = True
                code_lines = []
            else:
                paragraph = doc.add_paragraph()
                paragraph.paragraph_format.left_indent = Cm(0.7)
                paragraph.paragraph_format.first_line_indent = Cm(0)
                run = paragraph.add_run("\n".join(code_lines))
                run.font.name = "Menlo"
                run.font.size = Pt(8)
                in_code = False
            i += 1
            continue
        if in_code:
            code_lines.append(line)
            i += 1
            continue
        if line.startswith("# "):
            paragraph = doc.add_paragraph(clean_inline(line[2:]), style="Title")
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            i += 1
            continue
        if line.startswith("## "):
            doc.add_paragraph(clean_inline(line[3:]), style="Heading 1")
            i += 1
            continue
        if line.startswith("### "):
            doc.add_paragraph(clean_inline(line[4:]), style="Heading 2")
            i += 1
            continue
        if line.startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i])
                i += 1
            headers, rows = parse_table(block)
            add_table(doc, headers, rows, table_index)
            table_index += 1
            continue
        if line.startswith("- "):
            paragraph = doc.add_paragraph(style="List Bullet")
            paragraph.paragraph_format.first_line_indent = Cm(0)
            paragraph.add_run(clean_inline(line[2:]))
            i += 1
            continue
        if re.match(r"^\d+\. ", line):
            paragraph = doc.add_paragraph(style="List Number")
            paragraph.paragraph_format.first_line_indent = Cm(0)
            paragraph.add_run(clean_inline(re.sub(r"^\d+\. ", "", line)))
            i += 1
            continue
        if not line.strip():
            i += 1
            continue
        paragraph_lines = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip():
            next_line = lines[i]
            if (next_line.startswith(("#", "|", "- ", "```"))
                    or re.match(r"^\d+\. ", next_line)):
                break
            paragraph_lines.append(next_line.strip())
            i += 1
        paragraph = doc.add_paragraph(clean_inline(" ".join(paragraph_lines)))
        paragraph.paragraph_format.first_line_indent = Cm(0.4)
    doc.save(OUTPUT)
    print(f"Generated {OUTPUT.name} with {table_index - 1} tables")


if __name__ == "__main__":
    render()

"""Fifth-review reporting corrections, derived from unchanged experiment records."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from fourth_review_revision import replace_once, replace_section, section

ROOT = Path(__file__).resolve().parent
V5_PAIRS = 'sequential_comparison_v1/results_v2/real_pair_decisions.csv'
V7_INTERVALS = 'sb3_v7_confirmation/analysis/intervals.csv'


def read_csv(name):
    with (ROOT/name).open(newline='') as handle:
        return list(csv.DictReader(handle))


def table(caption, headers, rows):
    return ('**'+caption+'**\n\n| '+' | '.join(headers)+' |\n|'
            +'|'.join(['---']*len(headers))+'|\n'
            +'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)+'\n\n')


def comparison_payload():
    old = [r for r in read_csv(V5_PAIRS) if r['dataset']=='extension1000']
    new = [r for r in read_csv(V7_INTERVALS) if int(r['n_per_arm'])==1000]
    key = lambda r:(r['method'],r['environment'],r['comparison'])
    a,b = {key(r):r for r in old},{key(r):r for r in new}
    assert a.keys()==b.keys() and len(a)==135
    raw_names = ['sb3_v5_extension/raw_seed_metrics.csv','sb3_v7_confirmation/raw_seed_metrics.csv']
    seed_sets,means = [],[]
    for name in raw_names:
        raw=read_csv(name)
        cells=defaultdict(list)
        for r in raw:
            cells[r['env_id'],r['algorithm']].append(r)
        assert len(cells)==15 and all(len(v)==1000 for v in cells.values())
        seeds={int(r['train_seed']) for r in raw}
        assert all({int(r['train_seed']) for r in v}==seeds for v in cells.values())
        seed_sets.append(seeds)
        means.append({k:statistics.fmean(float(r['metric_normalized']) for r in v) for k,v in cells.items()})
    assert not seed_sets[0]&seed_sets[1]
    assert seed_sets[0]==set(range(30400,31400)) and seed_sets[1]==set(range(31400,32400))
    rows=[]
    for k in a:
        method,env,pair=k
        arm_a,arm_b=pair.split(' - ')
        e5,e7=(m[env,arm_a]-m[env,arm_b] for m in means)
        assert math.isclose(e5,float(a[k]['final_estimate']),abs_tol=1e-12)
        assert math.isclose(e7,float(b[k]['estimate']),abs_tol=1e-12)
        rows.append(dict(method=method,environment=env,comparison=pair,
            v5_terminal=a[k]['terminal'],v7_terminal=b[k]['terminal'],
            v5_stop_n=int(a[k]['stop_n']),v7_stop_n=int(b[k]['stop_n']),
            v5_estimate=e5,v7_estimate=e7,
            v7_final_width=float(b[k]['width']),
            category_matches=a[k]['terminal']==b[k]['terminal'],
            category_and_stop_match=(a[k]['terminal'],a[k]['stop_n'])==(b[k]['terminal'],b[k]['stop_n'])))
    counts={}
    for method in sorted({r['method'] for r in rows}):
        selected=[r for r in rows if r['method']==method]
        counts[method]={
            'category_and_stop_matches':sum(r['category_and_stop_match'] for r in selected),
            'final_estimates_differ':sum(abs(r['v5_estimate']-r['v7_estimate'])>1e-12 for r in selected),
            'category_counts_equal':Counter(r['v5_terminal'] for r in selected)==Counter(r['v7_terminal'] for r in selected),
        }
    for method in ('H-original','CS-EB-gamma'):
        assert counts[method]['category_and_stop_matches']==15
        assert counts[method]['final_estimates_differ']==15
    names=[V5_PAIRS,V7_INTERVALS,*raw_names]
    return dict(status='PASS',seed_ranges=[[min(s),max(s)] for s in seed_sets],
        seed_overlap=0,raw_means_recomputed=True,methods=counts,rows=rows,
        source_sha256={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names})


def version_rows():
    specs=[('V1','三任务先导','sb3_formal_v1','先导执行，不作发表证据'),
           ('V2','五任务先导','sb3_formal_v2','两候选网格先导'),
           ('V3','主研究','sb3_formal_v3','四候选网格；预注册运行与回顾性审计'),
           ('V4','新种子扩展','sb3_v4_extension','主研究启发后冻结；固定面板'),
           ('V5','大预算扩展','sb3_v5_extension','固定面板分辨成本诊断'),
           ('V6','新任务族扩展','sb3_v6_task_family','两项新增离散任务的独立六比较族'),
           ('V7','新种子验证','sb3_v7_confirmation','查看 V1–V6 后冻结；固定面板方法对照')]
    rows=[]
    for label,name,path,status in specs:
        records=read_csv(path+'/raw_seed_metrics.csv')
        groups=defaultdict(set)
        for r in records: groups['验证' if r['split']=='validation' else '测试'].add(int(r['train_seed']))
        pieces=[]
        for split in ('验证','测试'):
            if split not in groups:continue
            seeds=groups[split];assert seeds==set(range(min(seeds),max(seeds)+1))
            pieces.append(f'{split} {min(seeds):,}–{max(seeds):,}')
        if label in ('V4','V5','V7'):pieces.insert(0,'沿用 V3 配置')
        rows.append([label,name,'；'.join(pieces),status])
    return rows


def comparison_tables(payload):
    lookup={(r['method'],r['environment'],r['comparison']):r for r in payload['rows']}
    order=json.loads((ROOT/'sb3_v7_confirmation/analysis/summary.json').read_text())['pairwise_primary_results']
    labels={'a_superior':'A 优越','b_superior':'B 优越','precision_only':'仅精度','unresolved':'未决'}
    short={'CartPole-v1':'CartPole','Acrobot-v1':'Acrobot','MountainCar-v0':'MountainCar',
           'Taxi-v4':'Taxi','NonstationaryQueue-v0':'Queue'}
    decisions,widths=[],[]
    for row in order:
        env,pair=row['environment'],row['comparison']
        h=lookup['H-original',env,pair];g=lookup['CS-EB-gamma',env,pair]
        cell=lambda r,v:f"{labels[r[v+'_terminal']]} / {r[v+'_stop_n']}"
        decisions.append([short[env],pair,cell(h,'v5'),cell(h,'v7'),cell(g,'v5'),cell(g,'v7')])
        widths.append([short[env],pair,f"{h['v5_estimate']:.8f}",f"{h['v7_estimate']:.8f}",
            f"{h['v7_final_width']:.4f}",f"{g['v7_final_width']:.4f}",
            f"{g['v7_final_width']-h['v7_final_width']:.4f}"])
    return (table('表 S22-1。V5 与 V7 的逐比较终止类别及停止种子数',
        ['任务','A − B','Hoeffding V5','Hoeffding V7','Gamma CS V5','Gamma CS V7'],decisions)
        +'注：每格为“终止类别 / 每臂停止种子数”；未决项的 1,000 表示预算上限，不表示产生了决定。Queue 为 NonstationaryQueue-v0，其余任务版本同表 S17-1。两种方法各 15 项类别及停止检查点均一致。\n\n'
        +table('表 S22-2。V5/V7 最终点估计及 V7 最终区间宽度',
        ['任务','A − B','V5 点估计','V7 点估计','V7 Hoeffding 宽度','V7 Gamma 宽度','宽度差'],widths)
        +'注：点估计均使用每臂全部 1,000 个测试种子；终止类别在首次达到规则时锁定。两序列 15 项点估计均不同，与表 S22-1 的终止分类一致性是不同层面的描述。\n\n')


def canonical_names(text):
    # Preserve file names, URLs, environment IDs and literature version identifiers.
    replacements=[('前瞻性新种子扩展','V4 新种子扩展'),('大预算分辨成本扩展','V5 大预算扩展'),
        ('400 种子扩展','V4 新种子扩展'),('1,000 种子扩展','V5 大预算扩展'),
        ('新种子上的事后前瞻验证','V7 新种子验证'),('未披露新种子的前瞻验证','V7 新种子验证')]
    lines=[]
    for line in text.splitlines():
        if re.match(r'^\[\d+\]',line):lines.append(line);continue
        parts=re.split(r'(`[^`]*`|https?://\S+)',line)
        for i in range(0,len(parts),2):
            for old,new in replacements:parts[i]=parts[i].replace(old,new)
            parts[i]=re.sub(r'(?<![\w/.-])v([1-7])(?![\w/.-])',r'V\1',parts[i])
            parts[i]=re.sub(r'(?<!V4 )(?<!增)新种子扩展', 'V4 新种子扩展',parts[i])
            parts[i]=parts[i].replace('V4 V4','V4').replace('V5 V5','V5')
            parts[i]=re.sub(r'([\u3400-\u9fff])(?=V[1-7]\b)',r'\1 ',parts[i])
        lines.append(''.join(parts))
    text='\n'.join(lines)+'\n'
    return text.replace('| V4 | V4 新种子扩展 |','| V4 | 新种子扩展 |')


def revise(main, supp):
    payload=comparison_payload()
    dest=ROOT/'round5_analysis';dest.mkdir(exist_ok=True)
    (dest/'V5_V7_COMPARISON.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    main=replace_once(main,'下表使用与前一压力测试相同的 5,000 次重复，对比按原始计数计算的区间和块感知区间。',
        '下表采用与前一压力测试相同的生成设计，但独立生成各条件的 5,000 次重复：表 16 的随机种子基数为 931000，表 17 为 932000，均按块条件序号递增。因此两表朴素覆盖率的差异来自不同 Monte Carlo 样本，而非复用了同一批重复。表 17 内，朴素与块感知区间使用同一批序列作配对比较。')
    supp=replace_once(supp,'## S8 依赖性压力测试与块回退\n\n',
        '## S8 依赖性压力测试与块回退\n\n表 16 与表 17 的生成设计相同，随机流分别使用 `931000 + 条件序号` 和 `932000 + 条件序号`，每条件各 5,000 次重复；两表朴素列差异反映 Monte Carlo 样本差异。仅表 17 内朴素与回退方法配对使用相同序列。详见 `dependency_stress_diagnostic.py` 和 `dependency_robust_fallback_diagnostic.py`。\n\n')

    sentence=('与 V5 逐项对照，原 Hoeffding 和主设 Gamma CS 各 15 项比较的终止类别及停止检查点均完全一致，'
              '但 1,000 种子最终点估计在 15 项上均不同。V5 使用 30,400–31,399，V7 使用 31,400–32,399，'
              '训练种子无重叠；两组点估计已分别从各自原始 CSV 复算。逐项对照见补充材料 S22 表 S22-1、S22-2。'
              '这一一致性仅针对当前面板的这两种方法，不表示所有替代方法的停止点相同。')
    main=replace_once(main,'这些结果为当前五任务固定面板上的区间宽度差异提供新种子支持；',sentence+'\n\n这些结果为当前五任务固定面板上的区间宽度差异提供新种子支持；')
    supp=replace_section(supp,'**表 S22-1。','输入 CSV 共 15,000 行',comparison_tables(payload))
    supp=replace_once(supp,'输入 CSV 共 15,000 行',
        'V5 与 V7 的 CSV 分别复算得到 15 项不同的最终点估计，且两序列训练种子集合无交集。逐项类别/停止点对照及原始文件 SHA-256 见 `round5_analysis/V5_V7_COMPARISON.json`；复算入口为 `fifth_review_revision.py`。\n\n输入 CSV 共 15,000 行')
    main=replace_once(main,'7. 事前预算可行性审计把有界半径公式转化为密封测试前的可执行检查；该审计是协议设计工具，不是经验功效或普遍种子要求。',
        '7. 事前预算可行性审计把有界半径公式转化为密封测试前的可执行检查；该审计是协议设计工具，不是经验功效或普遍种子要求。\n8. 查看 V1–V6 后冻结的 V7 新种子验证在固定五任务面板上重现了 V5 中原 Hoeffding 与主设 Gamma CS 的逐比较终止类别及停止检查点；V7 最终区间中 Gamma CS 的 15 项均更窄，11/15 项达到停止规则，原方法为 4/15。成本按反事实共享臂前缀核算，未实际提前终止训练。')
    row='| 协议普遍节省计算或能够对 PPO/DQN/A2C 排名。 | 跨任务和预算的校准证据。 | 不支持。 |'
    main=replace_once(main,row,
        '| V7 重现 V5 中原 Hoeffding 与主设 Gamma CS 的逐项终止类别及停止检查点，且 Gamma CS 的 15 项最终区间均更窄。 | 第 5.22 节；补充材料 S22 表 S22-1、S22-2；各序列原始 CSV 独立复算。 | 查看 V1–V6 后冻结的固定面板新种子验证；成本为反事实前缀，非新任务族或独立团队复现。 |\n'+row)

    old=section(main,'为避免内部版本标签造成歧义，','主研究在打开密封测试分析前')
    intro=('实验序列统一用大写 V1–V7 标记，名称、训练种子范围和证据地位见表 8。'
           '文件名保留原始小写标签；实验标签与软件发布版本（如 v3.0.4）是不同标识。\n\n')
    version_table=table('表 8。实验序列标签、名称与证据地位',['标签','名称','训练种子范围','证据地位'],version_rows())
    # Renumber existing Table 8 onward before inserting the new Table 8.
    bump=lambda t:re.sub(r'表 (\d+)(?!\d)',lambda m:'表 '+str(int(m[1])+1) if int(m[1])>=8 else m[0],t)
    main=bump(main);supp=bump(supp)
    main=replace_once(main,old,intro+version_table+
        'V1–V3 的训练种子标签相同，不能视作三个独立新种子样本；V3 改用了四候选网格。V4、V5、V7 沿用 V3 的选定配置，测试种子区间互不重叠。连续动作与观测掩码补充各有独立预注册，按第 4.7 节另列，不全部归入 V6。\n\n')

    proof=section(main,'**证明。** Hoeffding 不等式给出','### 命题 2')
    newproof='''**证明。** 给定验证数据及选定配置，Hoeffding 不等式对算法 A 给出 `2 exp(-2 n_A,k r_A,k^2) = alpha_k/2` 的双侧失败概率，算法 B 同理。对两个均值及全部预定 K 个检查点使用并集界，失败概率至多为 `sum_k alpha_k <= alpha_cmp`。在所有均值界同时成立时，相减得到每个 `I_k` 覆盖 `Delta_{e,a,b}`；真实差异属于 `[-1,1]`，端点截断不会移除目标。再对十五个预先声明的比较分配 `alpha_cmp=0.05/15` 并使用并集界，族级失败概率至多为 0.05；这些并集界不要求算法之间或比较之间独立。配置选择仅依赖验证数据，指标、比较族和检查方案在密封测试使用前冻结，因而上述条件化成立。该结论不覆盖测试复用、事后选择检查点、数据依赖的任务族扩展或环境漂移，且是有限检查点结果，不是任意时刻置信序列。\n\n'''
    main=replace_once(main,proof,newproof)
    main=replace_once(main,'完整数值见补充材料 S5，表 S5-1。\n\n完整重采样规格和逐单元结果见补充材料 S5。',
        '完整重采样规格及逐单元结果见补充材料 S5 表 S5-1。')
    paragraph=section(main,'配置选择也改变了测试均值的解释。','### 5.5.1')
    main=replace_once(main,paragraph,'验证网格是程序的一部分；更换网格可能改变冻结配置及条件估计对象。配置选择敏感性结果统一见第 5.9 节。\n\n')
    main=replace_section(main,'单独预注册的范围扩展加入 `MountainCarContinuous-v0`，','### 6.2.1',
        'MountainCarContinuous-v0 补充的配置、均值和区间详见附录 B。')
    main=replace_once(main,'### 推论 3（正式预算下的非分辨区）',
        '表 4 的宽度列是假设每臂 n=20、分别使用第 1 或第 4 次检查 alpha 的规划量，并非主研究实际检查点的宽度。正式族级第 1 行的 1.7422 恰与表 16 在每臂 n=5 时的半径和 1.742157 相等：未截断宽度为半径和的两倍，而样本量增至四倍使半径和减半；两列不能混用。\n\n### 推论 3（正式预算下的非分辨区）')
    main=main.replace('非分辨性在观察任何 RL 结果之前就由半径计算决定','非分辨性仅由设计参数决定，不依赖任何 RL 观测')
    main=main.replace('0.550180`','0.550181`').replace('0.550180]','0.550181]')
    main=replace_once(main,'将训练预算增至 16,384 步。15 项仍未决',
        '将训练预算增至 16,384 步，并将四个评估步数同比例调整为 4,096、8,192、12,288、16,384；种子级指标仍为四检查点评估回报的平均值。15 项仍未决')
    main=main.replace('本文现已在','本文在').replace('队列现已通过','队列通过').replace('新增的同估计对象、同错误预算重分析','同估计对象、同错误预算重分析')
    main=main.replace('一个离散 Taxi 诊断任务','一个近似确定性的离散 Taxi 任务')
    main=replace_once(main,'主要任务族混合了三个标准离散控制任务',
        '范围扩展还包括 CliffWalking 与 FrozenLake 两项新增离散环境，完整设置见表 9。主要任务族混合了三个标准离散控制任务')
    main=main.replace('单独的 Pendulum、MountainCarContinuous 和固定掩码部分可观测诊断扩展了执行范围',
        'Pendulum、MountainCarContinuous、CliffWalking、FrozenLake 及两个固定掩码部分可观测诊断扩展了执行范围')
    # Describe the existing public release accurately without publishing a new one.
    main=main.replace('本文对应的 v3.0.4 版本 DOI 为', '既有归档 v3.0.4 的版本 DOI 为')
    main=main.replace('Zenodo 记录标示的许可证为 CC BY 4.0。',
        '该归档包含 V7 数据，但所附稿件早于本轮修订，不代表当前定稿版本；本稿更新尚未发布。Zenodo 记录标示的许可证为 CC BY 4.0。')
    main=canonical_names(main);supp=canonical_names(supp)
    supp=supp.replace('前瞻性 V4 新种子扩展', 'V4 新种子扩展').replace('V5 分辨成本扩展', 'V5 大预算扩展')
    supp=supp.replace('L3 V2 更新', 'L3 v2 更新').replace('arXiv V2', 'arXiv v2')
    supp=supp.replace('python3 generate_formal_chinese_manuscript.py', 'python3 generate_round3_manuscript.py')
    main=main.replace('## 附录 C。任务族范围扩展','## 附录 C。V6 新任务族扩展')
    main=main.replace('任务族范围扩展加入 CliffWalking-v1','V6 新任务族扩展加入 CliffWalking-v1')
    main=re.sub(r'([。；，：]) +(?![A-Za-z0-9`$|])',r'\1',main)
    return main,supp

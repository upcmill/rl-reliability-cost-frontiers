#!/usr/bin/env python3
"""Generate the auditable v6 task-family extension report."""

from __future__ import annotations

import csv
import json
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "sb3_v6_task_family"


def f(value: float) -> str:
    return f"{value:.6f}"


def main() -> None:
    rows = list(csv.DictReader((OUTPUT / "raw_seed_metrics.csv").open(encoding="utf-8", newline="")))
    config = json.loads((OUTPUT / "run_config.json").read_text(encoding="utf-8"))
    metrics: dict[tuple[str, str], list[float]] = {}
    for row in rows:
        if row["split"] == "extension_test":
            metrics.setdefault((row["env_id"], row["algorithm"]), []).append(float(row["metric_normalized"]))
    lines = [
        "# v6 Task-Family Extension Report",
        "",
        "This report is generated from `sb3_v6_task_family/raw_seed_metrics.csv`.",
        "The extension is a prospective same-machine scope diagnostic and is not",
        "pooled with the v3 primary family.",
        "",
        "## Frozen execution",
        "",
        f"- Tasks: `{', '.join(config['environment_ids'])}`.",
        "- FrozenLake options: `map_name=4x4`, `is_slippery=True`.",
        f"- Algorithms: `{', '.join(config['algorithm_ids'])}`; test seeds per cell: {config['run_config']['test_seeds_per_algorithm']}.",
        f"- Validation seeds: {config['run_config']['validation_seeds_per_candidate']} per candidate; training budget: {config['run_config']['timesteps']} steps; five evaluation episodes.",
        f"- Test looks: `{config['run_config']['look_sizes']}`; comparison alpha: `{config['run_config']['comparison_alpha']:.12g}`.",
        "- CliffWalking evaluation episodes are explicitly capped at 100 steps because its Gymnasium spec has no TimeLimit wrapper.",
        "",
        "## Descriptive test metrics",
        "",
        "| Environment | Algorithm | Selected configuration | Mean | SD | Median | Minimum | Maximum |",
        "|---|---|---|---:|---:|---:|---:|---:|",
    ]
    selected = config["selected_configurations"]
    for env_id in config["environment_ids"]:
        for algorithm in config["algorithm_ids"]:
            values = metrics[(env_id, algorithm)]
            lines.append(f"| {env_id} | {algorithm} | `{selected[f'{env_id}:{algorithm}']}` | {f(statistics.mean(values))} | {f(statistics.stdev(values))} | {f(statistics.median(values))} | {f(min(values))} | {f(max(values))} |")
    lines.extend([
        "",
        "## Finite-look decisions",
        "",
        "The following table reports the final 200-seed look. Every decision is",
        "`max_budget_inconclusive`; the interval is a protocol result and does not",
        "support an algorithm ranking.",
        "",
        "| Environment | Comparison | Estimate | Lower | Upper | Decision |",
        "|---|---|---:|---:|---:|---|",
    ])
    final = config["stop_traces"][-1]["decisions"]
    for key, decision in final.items():
        lines.append(f"| {key.split(':', 1)[0]} | {key.split(':', 1)[1]} | {f(decision['estimate'])} | {f(decision['lower'])} | {f(decision['upper'])} | `{decision['decision']}` |")
    lines.extend([
        "",
        "## Interpretation boundary",
        "",
        "The extension demonstrates that the disclosed runner, validation/test",
        "separation, bounded metric, and finite-look audit execute on two additional",
        "discrete Gymnasium tasks. It does not establish universal PPO/DQN/A2C",
        "rankings, a universal seed requirement, prospective power, external",
        "reproducibility, or scientific replication. The six comparisons remain",
        "unresolved at the registered 200-seed cap under the conservative family",
        "allocation.",
        "",
        "The raw data, run metadata, independent audit, and generator are archived",
        "with this report.",
        "",
    ])
    (OUTPUT / "V6_TASK_FAMILY_EXTENSION_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUTPUT / 'V6_TASK_FAMILY_EXTENSION_REPORT.md'}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Package an external v3 rerun without adding reference results."""

from __future__ import annotations

import argparse
import hashlib
import tarfile
from pathlib import Path


FORBIDDEN_NAMES = {
    "sb3_formal_v3",
    "raw_seed_metrics.csv.reference",
    "familywise_cost_summary.json",
}
REQUIRED_FILES = {"raw_seed_metrics.csv", "run_config.json", "summary.json"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check_input(directory: Path) -> None:
    missing = sorted(name for name in REQUIRED_FILES if not (directory / name).is_file())
    if missing:
        raise SystemExit(f"missing required rerun files: {', '.join(missing)}")
    for path in directory.rglob("*"):
        if path.name in FORBIDDEN_NAMES or "sb3_formal_v3" in path.parts:
            raise SystemExit(f"refusing to package forbidden reference path: {path}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--external-dir", required=True)
    parser.add_argument("--archive", required=True)
    parser.add_argument("--metadata")
    parser.add_argument("--log")
    args = parser.parse_args()

    directory = Path(args.external_dir).resolve()
    archive = Path(args.archive).resolve()
    check_input(directory)

    checksum_path = directory / "EXTERNAL_RERUN_OUTPUT_SHA256SUMS.txt"
    files = sorted(path for path in directory.rglob("*") if path.is_file() and path != checksum_path)
    lines = [f"{sha256_file(path)}  {path.relative_to(directory)}" for path in files]
    extras: list[tuple[Path, str]] = []
    for argument, label in ((args.metadata, "metadata"), (args.log, "log")):
        if not argument:
            continue
        path = Path(argument).resolve()
        if not path.is_file():
            raise SystemExit(f"{label} file does not exist: {path}")
        try:
            relative = path.relative_to(directory)
        except ValueError:
            extras.append((path, path.name))
            lines.append(f"{sha256_file(path)}  {path.name}")
        else:
            # Files already inside the result directory are included once by
            # the directory walk below.
            if path not in files:
                lines.append(f"{sha256_file(path)}  {relative}")
    checksum_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "w:gz") as handle:
        handle.add(directory, arcname="external_rerun_output")
        for path, arcname in extras:
            handle.add(path, arcname=arcname)
    print(f"wrote {archive} ({archive.stat().st_size} bytes)")
    print(f"output checksum manifest: {checksum_path}")


if __name__ == "__main__":
    main()

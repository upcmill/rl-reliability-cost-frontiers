# v3 Runtime Cost Table

This table is descriptive execution accounting for the selected v3
test rows. Runtime is wall-clock time on the recorded Apple Silicon CPU
environment. It is not a cross-hardware benchmark, a compute-efficiency
claim, or evidence that one algorithm is generally cheaper.

- Source: `sb3_formal_v3/raw_seed_metrics.csv`
- Unit: `one selected-configuration training seed`
- Successful test rows: `300`
- Total recorded test runtime: `0.058` hours

## Algorithm-level summaries

| Algorithm | n | Total hours | Mean seconds | Sample SD | Median seconds | Min | Max |
|---|---:|---:|---:|---:|---:|---:|---:|
| A2C | 100 | 0.018 | 0.659 | 0.231 | 0.568 | 0.417 | 1.207 |
| DQN | 100 | 0.021 | 0.758 | 0.190 | 0.696 | 0.543 | 1.223 |
| PPO | 100 | 0.019 | 0.686 | 0.228 | 0.598 | 0.459 | 1.250 |

## Environment-by-algorithm summaries

| Environment | Algorithm | n | Total hours | Mean seconds | Sample SD | Median seconds |
|---|---|---:|---:|---:|---:|---:|
| Acrobot-v1 | A2C | 20 | 0.006 | 1.096 | 0.122 | 1.149 |
| Acrobot-v1 | DQN | 20 | 0.006 | 1.072 | 0.143 | 1.163 |
| Acrobot-v1 | PPO | 20 | 0.006 | 1.107 | 0.148 | 1.177 |
| CartPole-v1 | A2C | 20 | 0.003 | 0.465 | 0.035 | 0.452 |
| CartPole-v1 | DQN | 20 | 0.003 | 0.548 | 0.006 | 0.546 |
| CartPole-v1 | PPO | 20 | 0.003 | 0.493 | 0.034 | 0.482 |
| MountainCar-v0 | A2C | 20 | 0.003 | 0.569 | 0.005 | 0.567 |
| MountainCar-v0 | DQN | 20 | 0.004 | 0.703 | 0.029 | 0.696 |
| MountainCar-v0 | PPO | 20 | 0.003 | 0.600 | 0.006 | 0.597 |
| NonstationaryQueue-v0 | A2C | 20 | 0.003 | 0.559 | 0.004 | 0.558 |
| NonstationaryQueue-v0 | DQN | 20 | 0.004 | 0.660 | 0.006 | 0.658 |
| NonstationaryQueue-v0 | PPO | 20 | 0.003 | 0.580 | 0.007 | 0.579 |
| Taxi-v4 | A2C | 20 | 0.003 | 0.608 | 0.010 | 0.604 |
| Taxi-v4 | DQN | 20 | 0.004 | 0.809 | 0.018 | 0.804 |
| Taxi-v4 | PPO | 20 | 0.004 | 0.649 | 0.019 | 0.639 |

The total covers only selected test-seed training runs. Validation runs,
extensions, and evaluation episode time are not combined into this table.
The values should be used to reproduce this execution record, not to
rank algorithms by hardware-independent efficiency.

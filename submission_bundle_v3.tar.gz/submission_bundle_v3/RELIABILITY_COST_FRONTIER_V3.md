# v3 Reliability--Cost Frontier

The table combines the distribution-free interval geometry with the
recorded cumulative wall-clock cost of the v3 selected test rows. The
radius, width, and necessary-threshold columns are analytic; the runtime
column is machine-specific execution accounting. No column is an empirical
power estimate or a cross-hardware efficiency claim.

- Source rows: `raw_seed_metrics.csv`
- Family: `15` comparisons; family alpha `0.05`
- Practical margin: `0.05`; width target: `0.1`

| Look | Seeds/algorithm | Comparison alpha | Radius sum | Minimum clipped width | Largest possible lower endpoint | Necessary seeds for possible superiority | Seeds for width target | Family test rows | Cumulative runtime (hours) |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 5 | 0.0020264237 | 1.742157 | 1.742157 | -0.742157 | 17 | 6071 | 75 | 0.014674 |
| 2 | 10 | 0.00050660592 | 1.339707 | 1.339707 | -0.339707 | 20 | 7180 | 150 | 0.029352 |
| 3 | 15 | 0.00022515819 | 1.142220 | 1.142220 | -0.142220 | 22 | 7829 | 225 | 0.043992 |
| 4 | 20 | 0.00012665148 | 1.017859 | 1.017859 | -0.017859 | 23 | 8289 | 300 | 0.058429 |

At the v3 cap, the largest possible lower endpoint remains below the
0.05 practical margin and the minimum possible width remains above 0.10.
Thus the formal state machine cannot resolve the v3 family at any listed
look, regardless of the observed bounded values. The runtime values show
the recorded cost of reaching each look when every primary comparison
remains open; they do not claim that another machine or implementation
would have the same duration.

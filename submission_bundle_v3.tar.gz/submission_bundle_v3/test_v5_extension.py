import json
import unittest
from pathlib import Path


class V5ExtensionArtifactTest(unittest.TestCase):
    def test_audit_locks_counts_and_scope(self):
        root = Path(__file__).resolve().parent
        payload = json.loads((root / "V5_EXTENSION_AUDIT.json").read_text(encoding="utf-8"))
        self.assertEqual(payload["status"], "PASS")
        self.assertEqual(payload["rows"], 15000)
        self.assertEqual(payload["new_seed_range"], "30400-31399")
        self.assertEqual(payload["decision_counts"], {
            "a_superior": 3,
            "b_superior": 1,
            "max_budget_inconclusive": 11,
        })
        self.assertIn("prospective power", " ".join(payload["interpretation"]["not_supported"]))


if __name__ == "__main__":
    unittest.main()

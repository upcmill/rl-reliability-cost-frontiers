# Journal Selection Memo

## Recommendation

**Recommended first submission: _Machine Learning_ (Springer, ISSN
0885-6125; electronic ISSN 1573-0565).**

This is the closest fit for the current manuscript because the paper is an
evaluation-methodology study: it defines an estimand, gives a conditional
finite-look argument, compares uncertainty procedures, and reports a
reproducible RL experiment. It is not a policy-learning algorithm paper and
should not be presented as one.

The current manuscript should be submitted as a full research article with the
following positioning:

> A reliability--cost characterization of sequential RL evaluation under a
> conservative bounded interval, with a preregistered validation/test split,
> finite-look family control, and explicit repeatability limits.

The manuscript must keep the negative result as the main result. A reviewer
should not be led to expect a new PPO, DQN, or A2C algorithm.

## Fit assessment

| Criterion | Assessment for this manuscript |
|---|---|
| Topic fit | Strong: statistical methodology and empirical machine-learning evaluation. |
| Methodological depth | Moderate: the finite-look result is rigorous under explicit assumptions, but the inequality itself is established rather than new. |
| Empirical breadth | Moderate: five primary discrete tasks, two continuous-action scope diagnostics, and fixed-mask partial-observation execution diagnostics. |
| Novelty risk | High: prior work already includes RL reliability metrics and statistical comparison tools; the exact finite-look, sealed-test distinction remains `[待核实]`. |
| Reproducibility | Strong internal repeatability plus a returned Windows AMD64 different-machine rerun; independent-team identity and new-family replication remain unverified. |
| Acceptance confidence | `[待核实]`; no journal guarantees acceptance. |

## Official metadata checked

On 2026-10-29, the Springer journal homepage identified the journal as
“Machine Learning” (journal id 10994), showed the publishing model as “Hybrid
Access,” and classified its content under Machine Learning, Control/Robotics,
Artificial Intelligence, Computer Modelling, and Natural Language Processing.
Crossref's journal record reports Springer-Verlag and ISSNs `0885-6125` and
`1573-0565`. Sources:

- Springer journal homepage: <https://link.springer.com/journal/10994>
- Crossref journal record: <https://api.crossref.org/journals/0885-6125>

Current SCI/SCIE indexing, JCR category/quartile, APC, and review-time
statistics were not asserted because they require a current Web of
Science/JCR or official submission-page check `[待核实]`.

On 2026-10-31, a direct retrieval attempt for the official Springer
submission-guidelines page (`https://link.springer.com/journal/10994/submission-guidelines`)
returned HTTP 200 and was archived as
`literature_search_raw/2026-10-31_update/springer_machine_learning_submission_guidelines.html`.
The saved page confirms the journal title, journal id `10994`, hybrid publishing
model, scope labels, and the Springer submission entry point. The same page
also states that submissions must include a 1--2 page “MLJ Contribution
Information Sheet”, that original research articles must include a Data
Availability Statement, and that funding, competing interests, ethics/data/code
availability, and author-contribution declarations are expected where
applicable. It reports that first decisions are aimed at in less than three
months, while noting that timing varies. APC amount, current SCI/SCIE indexing,
and JCR metrics remain `[待核实]`; the official page only states that APCs vary
by journal and links to the Open Choice information.

## Why other obvious choices are weaker

| Journal type | Reason it is not the first choice |
|---|---|
| IEEE TNNLS / IEEE TETCI | Usually expects a substantial new learning algorithm, theory, or computational-intelligence contribution; the current paper explicitly does not make that claim. |
| Control Engineering Practice | The paper has no real control-system application or engineering deployment study. |
| Expert Systems with Applications / Applied Intelligence | The current contribution is evaluation methodology rather than an expert-system application. |
| JMLR / Artificial Intelligence Journal | Possible ambitious targets, but the current protocol's literature-wide novelty and external validity are likely too weak for their broad foundational bar. `[待核实]` |
| IEEE Access | A practical fallback if rapid broad-scope publication and APC are acceptable, but it is a weaker methodological signal and its current indexing/APC status must be checked. `[待核实]` |

## Required checks before submission

The following information is intentionally not asserted without a current
authoritative check:

- whether _Machine Learning_ is currently indexed in the required SCI/SCIE
  list;
- current JCR quartile, impact factor, review-time statistics, and APC;
- current article-type and data/code policy;
- whether the paper is considered sufficiently novel after the complete
  literature review;
- the journal's current software-citation and data/code policy; the
  peer-reviewed Stable-Baselines3 citation is now verified as L12, while the
  installed implementation version 2.9.2 and official project URL are recorded.

Check the journal's official Springer aims/scope, submission guidelines, open
access/APC page, and the institution's current Web of Science/JCR list on the
day of submission. These fields remain `[待核实]` in this workspace because a
journal metric or indexing status can change and must not be copied from an
unverified ranking website.

## Submission adaptation

Before sending to _Machine Learning_:

1. Keep the title as “Reliability--Cost Frontiers for Sequential Evaluation of
   Reinforcement Learning Algorithms”; it describes the contribution without
   promising an algorithmic improvement.
2. Keep the abstract's first contribution as the conditional statistical
   construction and the second as the observed 15/15 inconclusive boundary.
3. Move the Pendulum experiment to a clearly labelled supplementary section;
   do not pool it into the primary family-wise analysis.
4. Include `STATISTICAL_AUDIT_V3.md`, raw CSV/JSON artifacts, source hashes,
   and the same-machine replay in the data/code supplement.
5. State the external-reproduction gap in the limitations and cover letter.
6. Replace every `[待核实]` only after checking the journal and citation
   records from authoritative sources.
7. Complete `MLJ_CONTRIBUTION_INFORMATION_SHEET.md` and upload it as the
   journal-required 1--2 page contribution information sheet.

## Decision

Use _Machine Learning_ as the first target, subject to the official scope and
indexing checks above. If its editor rejects the paper for insufficient
algorithmic novelty, use the reviewer feedback to decide whether a broader
methods venue is appropriate; do not retitle the current negative evaluation
study as a new RL algorithm.

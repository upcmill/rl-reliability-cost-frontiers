#!/usr/bin/env python3
"""Audit structural invariants of the full and concise manuscripts."""

from __future__ import annotations

import re
import json
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
FULL = ROOT / "MANUSCRIPT_DRAFT_V3.md"
CORE = ROOT / "MANUSCRIPT_SUBMISSION_CORE_EN.md"
OUTPUT = ROOT / "MANUSCRIPT_STRUCTURE_AUDIT.json"

EXPECTED_TOP_LEVEL = [
    "Abstract",
    "1. Introduction",
    "2. Related Work",
    "3. Estimand and Statistical Protocol",
    "4. Experimental Design",
    "5. Results",
    "6. Discussion",
    "7. Limitations and Threats to Validity",
    "8. Reproducibility and Open Materials",
    "9. Claim--Evidence Table",
    "10. Conclusion",
    "11. Declarations",
    "12. Recommended follow-up study",
    "References",
]


def top_level_headings(text: str) -> list[str]:
    result = []
    title_seen = False
    for line in text.splitlines():
        if line.startswith("# "):
            if not title_seen:
                title_seen = True
            else:
                result.append(line[2:].strip())
        elif line.startswith("## "):
            result.append(line[3:].strip())
    return result


def docx_counts(path: Path) -> tuple[int, int]:
    with ZipFile(path) as archive:
        names = archive.namelist()
        xml = archive.read("word/document.xml").decode("utf-8")
    return sum(name.startswith("word/media/") for name in names), xml.count("<w:tbl>")


def abstract_word_count(text: str) -> int:
    try:
        abstract = text.split("## Abstract", 1)[1].split("## 1. Introduction", 1)[0]
    except IndexError:
        return -1
    return len(abstract.split())


def citation_reference_consistent(text: str) -> bool:
    citations = sorted(set(re.findall(r"\[L(\d+)\]", text)), key=int)
    references = sorted(set(re.findall(r"^\[L(\d+)\]", text, flags=re.MULTILINE)), key=int)
    expected = [str(index) for index in range(1, 17)]
    return citations == expected and references == expected


def main() -> None:
    full = FULL.read_text(encoding="utf-8")
    core = CORE.read_text(encoding="utf-8")
    full_headings = top_level_headings(full)
    full_abstract_words = abstract_word_count(full)
    core_abstract_words = abstract_word_count(core)
    checks = {
        "full_file_present": FULL.is_file(),
        "core_file_present": CORE.is_file(),
        "full_top_level_order": full_headings == EXPECTED_TOP_LEVEL,
        "no_nul_bytes": b"\x00" not in FULL.read_bytes() and b"\x00" not in CORE.read_bytes(),
        "locked_stopping_final_look_convention": "bar\\tau=\\min(\\tau,K)" in full and "I_{\\bar\\tau}" in full,
        "no_nonexistent_final_interval": "I_{K+1}" not in full,
        "family_and_external_boundaries": all(
            marker in full
            for marker in (
                "15/15",
                "same-machine cross-script repeatability",
                "external reproducibility",
                "[待核实]",
            )
        ),
        "core_contains_primary_theory": all(
            marker in core
            for marker in (
                "Proposition 0",
                "Proposition 1",
                "Proposition 2",
                "Proposition 3",
                "Definition 1",
                "15/15",
            )
        ),
        "abstract_length_under_300_words": (
            0 < full_abstract_words <= 300 and 0 < core_abstract_words <= 300
        ),
        "citation_reference_consistency": (
            citation_reference_consistent(full)
            and citation_reference_consistent(core)
        ),
        "word_artifact_dimensions": all(
            docx_counts(ROOT / filename) == (13, 26)
            for filename in ("MANUSCRIPT_MACHINE_LEARNING_EN.docx",)
        ) and docx_counts(ROOT / "MANUSCRIPT_MACHINE_LEARNING_ZH.docx") == (9, 26)
        and docx_counts(ROOT / "MANUSCRIPT_FORMAL_ZH.docx") == (16, 22),
        "core_word_artifact_dimensions": docx_counts(ROOT / "MANUSCRIPT_MACHINE_LEARNING_CORE_EN.docx") == (5, 17),
    }
    payload = {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "abstract_word_count": {
            "full": full_abstract_words,
            "core": core_abstract_words,
        },
    }
    OUTPUT.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(payload)
    raise SystemExit(0 if payload["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Post-review diagnostics; never modifies preregistrations or experimental inputs."""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import platform
import statistics
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def wilson(successes: int, total: int) -> list[float]:
    z = 1.959963984540054
    p = successes / total
    d = 1 + z*z/total
    center = (p + z*z/(2*total))/d
    half = z*math.sqrt(p*(1-p)/total + z*z/(4*total*total))/d
    return [max(0., center-half), min(1., center+half)]


def spendings(k: int, comparison_alpha: float, schedule: str) -> list[float]:
    if k < 1 or not 0 < comparison_alpha < 1:
        raise ValueError('invalid error budget or number of looks')
    if schedule == 'original_summable':
        return [comparison_alpha*6/(math.pi**2*j*j) for j in range(1,k+1)]
    weights = {'front_loaded': [1/(j*j) for j in range(1,k+1)],
               'uniform': [1.]*k, 'back_loaded': [float(j*j) for j in range(1,k+1)]}[schedule]
    return [comparison_alpha*w/sum(weights) for w in weights]


def radius(n: int, alpha: float) -> float:
    return 2*math.sqrt(math.log(4/alpha)/(2*n))


def holm(p_values: list[float]) -> list[float]:
    ordered = sorted(range(len(p_values)), key=lambda i: p_values[i])
    result = [1.]*len(p_values)
    last = 0.
    for rank, index in enumerate(ordered):
        last = min(1., max(last, (len(p_values)-rank)*p_values[index]))
        result[index] = last
    return result


def comb(n: int, k: int) -> int:
    return math.comb(n,k) if n >= 0 and 0 <= k <= n else 0


def exact_runs(values: list[float]) -> dict:
    median = statistics.median(values)
    signs = [int(x>median) for x in values if x != median]
    n1, n0 = sum(signs), len(signs)-sum(signs)
    if n1 == 0 or n0 == 0:
        return {'status': 'undefined_degenerate', 'ties_dropped': len(values)-len(signs), 'p': 1.0}
    runs = 1+sum(a != b for a,b in zip(signs,signs[1:]))
    mean = 1+2*n1*n0/(n1+n0)
    denom = math.comb(n1+n0,n1)
    counts = {}
    for r in range(2,n1+n0+1):
        k = r//2
        count = (2*comb(n1-1,k-1)*comb(n0-1,k-1) if r%2 == 0 else
                 comb(n1-1,k)*comb(n0-1,k-1)+comb(n1-1,k-1)*comb(n0-1,k))
        counts[r] = count
    assert sum(counts.values()) == denom
    p = sum(c for r,c in counts.items() if abs(r-mean) >= abs(runs-mean)-1e-12)/denom
    return {'status': 'computed', 'ties_dropped': len(values)-len(signs), 'n_above':n1,
            'n_below':n0, 'runs':runs, 'expected_runs':mean, 'p':p}


def lag1_permutation(values, permutations, rng):
    x = np.asarray(values,dtype=float)
    x = x-x.mean()
    ss = float(np.dot(x,x))
    if ss <= 1e-30:
        return {'status':'undefined_constant', 'r1':None,'p':1.0, 'permutations':permutations}
    r1 = float(np.dot(x[:-1],x[1:])/ss)
    perm = rng.permuted(np.tile(x,(permutations,1)),axis=1)
    scores = np.sum(perm[:,:-1]*perm[:,1:],axis=1)/ss
    extreme = int(np.count_nonzero(np.abs(scores) >= abs(r1)-1e-12))
    return {'status':'computed','r1':r1,'extreme_permutations':extreme,
            'p':(extreme+1)/(permutations+1),'permutations':permutations}


def source_rows(path):
    with path.open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))


def sequential_counts(ca, cb, looks, alphas, true_delta, margin=.05, width=.10):
    count = len(ca)
    terminal = np.zeros(count,dtype=np.int8)
    stop_n = np.full(count,looks[-1],dtype=int)
    covered = np.ones(count,dtype=bool)
    for n,a in zip(looks,alphas):
        estimate = (ca[:,n-1]-cb[:,n-1])/n
        rad = radius(n,a)
        lower, upper = np.maximum(-1,estimate-rad),np.minimum(1,estimate+rad)
        covered &= (lower <= true_delta+1e-12)&(upper >= true_delta-1e-12)
        decision = np.where(lower>margin,1,np.where(upper < -margin,2,np.where(upper-lower<=width,3,0)))
        new = (terminal == 0)&(decision != 0)
        terminal[new] = decision[new]
        stop_n[new] = n
    wrong = ((terminal==1)&(true_delta <= margin+1e-12))|((terminal==2)&(true_delta >= -margin-1e-12))
    return {'a_superior':int(np.sum(terminal==1)), 'b_superior':int(np.sum(terminal==2)),
            'precision_only':int(np.sum(terminal==3)), 'unresolved':int(np.sum(terminal==0)),
            'simultaneous_covered':int(np.sum(covered)), 'false_superiority':int(np.sum(wrong)),
            'sum_terminal_n':int(stop_n.sum())}


def synthetic(replicates,seed):
    scenarios = [('null',.50,.50),('margin_boundary',.55,.50),('moderate',.70,.50),
                 ('large',.90,.50),('very_large',.90,.10)]
    plans = [(5,10,15,20),(50,100,150,200),(200,400,600,800,1000)]
    result = []
    streams = np.random.SeedSequence(seed).spawn(len(scenarios))
    for (name,pa,pb), stream in zip(scenarios,streams):
        rng = np.random.default_rng(stream)
        totals = [None for _ in plans]
        for start in range(0,replicates,500):
            batch = min(500,replicates-start)
            ca = np.cumsum(rng.binomial(1,pa,(batch,1000)),axis=1)
            cb = np.cumsum(rng.binomial(1,pb,(batch,1000)),axis=1)
            for j,looks in enumerate(plans):
                row = sequential_counts(ca,cb,looks,spendings(len(looks),.05/15,'original_summable'),pa-pb)
                if totals[j] is None: totals[j] = row
                else:
                    for key,val in row.items(): totals[j][key] += val
        for looks,counts in zip(plans,totals):
            row = {'scenario':name,'p_a':pa,'p_b':pb,'true_difference':pa-pb,
                   'looks':list(looks),'replicates':replicates,'counts':counts,
                   'mean_terminal_n':counts['sum_terminal_n']/replicates}
            row['rates'] = {k:{'estimate':v/replicates,'wilson95':wilson(v,replicates)}
                            for k,v in counts.items() if k != 'sum_terminal_n'}
            result.append(row)
    return {'status':'post_review_diagnostic_not_primary_preregistration','rng':'NumPy PCG64',
            'seed':seed,'comparison_alpha':.05/15,'margin':.05,'target_width':.10,
            'scope':'single comparison simultaneous coverage; not simulated 15-comparison family coverage',
            'rows':result}


def order_diagnostics(rows,permutations,seed):
    cells = sorted({(r['env_id'],r['algorithm']) for r in rows if r['split']=='test'})
    streams = np.random.SeedSequence(seed).spawn(len(cells))
    result,ps = [],[]
    for (env,algo), stream in zip(cells,streams):
        selected = [r for r in rows if (r['env_id'],r['algorithm'])==(env,algo) and r['split']=='test']
        x = [float(r['metric_normalized']) for r in selected]
        runs = exact_runs(x)
        lag = lag1_permutation(x,permutations,np.random.default_rng(stream))
        result.append({'env_id':env,'algorithm':algo,'n':len(x),
                       'train_seed_order':[int(r['train_seed']) for r in selected],
                       'runs':runs,'lag1':lag})
        ps.extend([runs['p'],lag['p']])
    adj = holm(ps)
    for i,row in enumerate(result):
        for j,key in enumerate(('runs','lag1')):
            row[key]['holm_p_30_tests'] = adj[2*i+j]
            row[key]['reject_holm_05'] = adj[2*i+j] < .05
    return {'status':'exploratory_recorded_order_diagnostic','seed':seed,'rows':result,
            'order':'within-cell CSV row order; not verified wall-clock order',
            'null':'random order conditional on the observed multiset (exchangeability)',
            'limitations':'non-rejection does not prove independence; rejection may reflect distribution drift',
            'rejected_tests_holm_05':sum(p<.05 for p in adj)}


def planning():
    result=[]
    for looks in ((5,10,15,20),(100,200),(50,100,150,200),(25,50,75,100,125,150,175,200)):
        for name in ('original_summable','front_loaded','uniform','back_loaded'):
            alphas=spendings(len(looks),.05/15,name)
            radii=[radius(n,a) for n,a in zip(looks,alphas)]
            result.append({'looks':list(looks),'schedule':name,'alpha_per_look':alphas,
                           'spent_fraction':sum(alphas)/(.05/15), 'radii':radii,
                           'max_radius':max(radii),'last_radius':radii[-1],
                           'necessary_superiority_n_by_look':[math.floor(2*math.log(4/a)/(.95**2))+1 for a in alphas],
                           'untruncated_precision_n_last':{str(w):math.ceil(8*math.log(4/alphas[-1])/w**2) for w in (.05,.1,.2)}})
    return {'status':'analytic_design_sensitivity_not_empirical_power','rows':result}


def threshold_scale(rows):
    result=[]
    for env in sorted({r['env_id'] for r in rows}):
        data={a:[float(r['metric_normalized']) for r in rows if r['env_id']==env and r['algorithm']==a and r['split']=='test']
              for a in ('PPO','DQN','A2C')}
        for a,b in itertools.combinations(data,2):
            pooled=math.sqrt((statistics.variance(data[a])+statistics.variance(data[b]))/2)
            result.append({'environment':env,'comparison':a+' - '+b,'pooled_sd':pooled,
                           'margin_over_pooled_sd':.05/pooled if pooled else None})
    return {'status':'post_hoc_scale_description_not_practical_utility','margin':.05,'rows':result}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--replicates',type=int,default=10000)
    parser.add_argument('--permutations',type=int,default=9999)
    parser.add_argument('--seed',type=int,default=20261103)
    parser.add_argument('--output',type=Path,default=ROOT/'round3_analysis')
    args=parser.parse_args()
    if args.replicates<1 or args.permutations<1: parser.error('counts must be positive')
    args.output.mkdir(exist_ok=True,parents=True)
    destinations=['synthetic_calibration.json','order_diagnostics.json','planning_sensitivity.json','threshold_scale.json','ANALYSIS_MANIFEST.json']
    if any((args.output/p).exists() for p in destinations):
        raise SystemExit('Output exists; use a new --output directory to preserve prior results.')
    raw=ROOT/'sb3_formal_v3/raw_seed_metrics.csv'
    rows=source_rows(raw)
    payloads={'synthetic_calibration.json':synthetic(args.replicates,args.seed),
              'order_diagnostics.json':order_diagnostics(rows,args.permutations,args.seed+1),
              'planning_sensitivity.json':planning(), 'threshold_scale.json':threshold_scale(rows)}
    for name,payload in payloads.items():
        (args.output/name).write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (raw,Path(__file__),ROOT/'round3_analysis/ANALYSIS_PLAN.md')}
    manifest={'command':f'./.rl-arm64-venv/bin/python round3_diagnostics.py --replicates {args.replicates} --permutations {args.permutations} --seed {args.seed} --output {args.output.name}',
              'python':platform.python_version(),'numpy':np.__version__,'platform':platform.platform(),
              'source_hashes':hashes, 'output_hashes':{p:hashlib.sha256((args.output/p).read_bytes()).hexdigest() for p in payloads}}
    (args.output/'ANALYSIS_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'outputs':list(payloads),'order_rejections':payloads['order_diagnostics.json']['rejected_tests_holm_05']},ensure_ascii=False))


if __name__ == '__main__':
    main()

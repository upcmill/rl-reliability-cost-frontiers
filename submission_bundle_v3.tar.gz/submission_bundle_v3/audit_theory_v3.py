#!/usr/bin/env python3
"""Audit the deterministic numerical consequences of the v3 theory section."""

from __future__ import annotations

import json
import math
from pathlib import Path

from pilot_protocol import alpha_spend
from unpaired_budget_requirements import (
    seeds_for_possible_superiority,
    seeds_for_width,
    total_seeds_for_possible_superiority,
    total_seeds_for_width,
)


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "THEORY_AUDIT_V3.json"
MANUSCRIPT = ROOT / "MANUSCRIPT_DRAFT_V3.md"
THEORY_NOTES = ROOT / "THEORY_NOTES.md"


def run_audit() -> dict:
    family_alpha = 0.05
    comparison_count = 15
    comparison_alpha = family_alpha / comparison_count
    looks = [1, 2, 3, 4]
    sample_sizes = [5, 10, 15, 20]
    margin = 0.05
    target_width = 0.10

    look_alphas = [alpha_spend(comparison_alpha, look) for look in looks]
    spending_sum = sum(look_alphas)
    radius_sums = [
        2.0 * math.sqrt(math.log(4.0 / alpha) / (2.0 * n))
        for alpha, n in zip(look_alphas, sample_sizes)
    ]
    final_radius = radius_sums[-1]
    minimum_clipped_width = min(2.0, final_radius)
    possible_lower_endpoint = 1.0 - final_radius
    possible_thresholds = [
        seeds_for_possible_superiority(comparison_alpha, look, margin)
        for look in looks
    ]
    width_requirements = [
        seeds_for_width(comparison_alpha, look, target_width) for look in looks
    ]
    total_width_requirements = [
        total_seeds_for_width(comparison_alpha, look, target_width) for look in looks
    ]
    total_possible_thresholds = [
        total_seeds_for_possible_superiority(comparison_alpha, look, margin)
        for look in looks
    ]
    manuscript_text = MANUSCRIPT.read_text(encoding="utf-8")
    theory_text = THEORY_NOTES.read_text(encoding="utf-8")

    checks = {
        "spending_sum_within_comparison_alpha": spending_sum <= comparison_alpha,
        "spending_positive": all(value > 0.0 for value in look_alphas),
        "final_radius_matches_recorded_value": abs(final_radius - 1.0178588242230167) < 1e-12,
        "superiority_impossible_at_final_look": possible_lower_endpoint <= margin,
        "precision_impossible_at_final_look": minimum_clipped_width > target_width,
        "radius_nonincreasing_with_sample_size": all(
            left >= right for left, right in zip(radius_sums, radius_sums[1:])
        ),
        "possible_superiority_thresholds_match_v3": possible_thresholds == [17, 20, 22, 23],
        "width_requirements_match_recorded_values": width_requirements == [6071, 7180, 7829, 8289],
        "balanced_total_width_requirements_match_v3": total_width_requirements == [12141, 14359, 15657, 16577],
        "balanced_total_superiority_thresholds_match_v3": total_possible_thresholds == [34, 40, 44, 46],
        "locked_stopping_proposition_present": "Proposition 2 (validity under locked finite-look stopping)" in manuscript_text and "Locked-stopping lemma" in theory_text,
        "frontier_definition_present": "Definition 1 (reliability--cost frontier)" in manuscript_text and "Reliability--cost frontier definition" in theory_text,
    }
    payload = {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "scope": "deterministic numerical audit of the v3 finite-look construction",
        "warning": "This artifact checks algebraic and implementation values; it does not prove probabilistic independence or external reproducibility.",
        "inputs": {
            "family_alpha": family_alpha,
            "comparison_count": comparison_count,
            "comparison_alpha": comparison_alpha,
            "looks": looks,
            "sample_sizes": sample_sizes,
            "practical_margin": margin,
            "target_width": target_width,
        },
        "derived_values": {
            "look_alphas": look_alphas,
            "spending_sum": spending_sum,
            "radius_sums": radius_sums,
            "final_radius_sum": final_radius,
            "minimum_clipped_width_at_final_look": minimum_clipped_width,
            "largest_possible_lower_endpoint": possible_lower_endpoint,
            "possible_superiority_thresholds": possible_thresholds,
            "width_requirements_per_algorithm": width_requirements,
            "balanced_total_width_requirements": total_width_requirements,
            "balanced_total_possible_superiority_thresholds": total_possible_thresholds,
        },
        "checks": checks,
    }
    OUTPUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload


if __name__ == "__main__":
    result = run_audit()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)

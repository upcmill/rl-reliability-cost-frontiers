#!/usr/bin/env python3
"""Audit the two fixed-configuration v3 sensitivity diagnostics."""

from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REFERENCE = json.loads((ROOT / "sb3_formal_v3/summary.json").read_text(encoding="utf-8"))["summary"]
ALGORITHMS = ("PPO", "DQN", "A2C")
ENVIRONMENTS = (
    "CartPole-v1",
    "Acrobot-v1",
    "MountainCar-v0",
    "Taxi-v4",
    "NonstationaryQueue-v0",
)


def audit_directory(name: str, expected_episodes: int | None, expected_timesteps: int) -> dict:
    directory = ROOT / name
    summary = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
    with (directory / "raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 300, (name, len(rows))
    assert all(row["split"].startswith("test_") for row in rows), name
    assert {row["env_id"] for row in rows} == set(ENVIRONMENTS), name
    assert {row["algorithm"] for row in rows} == set(ALGORITHMS), name
    assert {int(row["train_seed"]) for row in rows} == set(range(20000, 20020)), name
    assert summary["run_config"]["timesteps"] == expected_timesteps, name
    if expected_episodes is not None:
        assert summary["run_config"]["eval_episodes"] == expected_episodes, name
    assert len(summary["comparisons"]) == 15, name
    assert all(item["decision"]["decision"] == "max_budget_inconclusive" for item in summary["comparisons"]), name
    for env_id in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            key = f"{env_id}:{algorithm}"
            assert summary["summary"][key]["selected_config"] == REFERENCE[key]["selected_config"], key
    return {
        "directory": name,
        "rows": len(rows),
        "comparisons": len(summary["comparisons"]),
        "all_max_budget_inconclusive": True,
        "selected_configurations_match_v3": True,
        "timesteps": expected_timesteps,
        "eval_episodes": expected_episodes,
    }


def main() -> None:
    results = [
        audit_directory("sb3_budget_scaling_v3", expected_episodes=5, expected_timesteps=16384),
        audit_directory("sb3_eval_episode_sensitivity_v3", expected_episodes=10, expected_timesteps=4096),
    ]
    supplement = (ROOT / "SUPPLEMENTARY_INFORMATION_V3.md").read_text(encoding="utf-8")
    normalized_supplement = " ".join(supplement.split())
    fallback = json.loads((ROOT / "DEPENDENCY_ROBUST_FALLBACK.json").read_text(encoding="utf-8"))
    expected_blocks = [1, 2, 5, 10, 20, 50]
    expected_looks = [50, 100, 150, 200]
    assert fallback["status"] == "supplementary_known_block_fallback_only"
    assert fallback["config"]["replicates"] == 5000
    assert fallback["config"]["block_sizes"] == expected_blocks
    assert fallback["config"]["looks"] == expected_looks
    assert len(fallback["results"]) == len(expected_blocks)
    for row, block_size in zip(fallback["results"], expected_blocks):
        assert row["block_size"] == block_size
        assert row["effective_blocks_by_look"] == [look // block_size for look in expected_looks]
        assert row["replicates"] == 5000
        assert row["known_block_fallback"]["simultaneous_coverage"] == 1.0
        assert row["known_block_fallback"]["false_superiority_rate"] == 0.0
        assert row["known_block_fallback"]["mean_terminal_n"] == 200.0
    required_document_facts = (
        "### S3.1 Alternative intervals and pairing dependence",
        "| Paired normal | 16 | 121 | 4,863 | 9.867 |",
        "| Paired bootstrap | 143 | 222 | 4,635 | 9.642 |",
        "| Paired empirical Bernstein | 0 | 0 | 5,000 | 10.000 |",
        "| Paired Hoeffding | 0 | 0 | 5,000 | 10.000 |",
        "false-positive estimate:",
        "do not justify replacing the preregistered unpaired Hoeffding interval",
        "### S2.2 Known-block dependence fallback",
        "| 10 | [5, 10, 15, 20] | 0.7706 | 1.0000 | 0.1370 | 0.0000 | 181.58 | 200.00 |",
        "known independent-block model",
        "dependency_robust_fallback_diagnostic.py",
    )
    assert all(fact in normalized_supplement for fact in required_document_facts)
    document_checks = {
        "status": "PASS",
        "sections": ["S2.2 Known-block dependence fallback", "S3.1 Alternative intervals and pairing dependence"],
        "required_facts_checked": len(required_document_facts),
    }
    fallback_check = {
        "status": "PASS",
        "conditions": len(fallback["results"]),
        "replicates_per_condition": fallback["config"]["replicates"],
        "all_fallback_coverages_equal_one": True,
        "all_fallback_false_superiority_rates_equal_zero": True,
    }
    payload = {"status": "PASS", "results": results, "fallback": fallback_check, "document_checks": document_checks}
    (ROOT / "SUPPLEMENTARY_DIAGNOSTIC_AUDIT.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

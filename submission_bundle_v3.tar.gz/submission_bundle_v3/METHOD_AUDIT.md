# Formal Method Audit

This audit maps the manuscript's primary statistical construction to the
implementation and states exactly what is, and is not, established.

## Estimand and conditioning

The primary estimand is conditional on the validation data and the selected
configuration for each task and algorithm. Test metrics are then treated as
bounded observations in `[0, 1]`, independent across seeds within each
algorithm's sequence. This conditioning is essential:
the test data cannot be used to select the configuration, metric, look schedule,
or stopping rule.

The manuscript states this as a separate selection-invariance proposition: for
any measurable validation-only selection rule, the fixed-configuration
finite-look bound applies pointwise after conditioning on the validation
realization and the selected configuration. The proposition retains the same
conditional boundedness and within-algorithm seed assumptions as the primary
result. It is not a guarantee for the best
configuration in an unbounded search space and does not permit test-informed
selection.

## Formula-to-code mapping

| Component | Manuscript | Implementation | Check |
|---|---|---|---|
| Bounded metric | Normalized metric in `[0, 1]` | `normalize_returns` in `sb3_pilot.py`; range validation in `hoeffding_unpaired_interval` | Stored primary metrics are bounded; raw returns are retained separately. |
| Unpaired estimate | `mean(X) - mean(Y)` | `pilot_protocol.py:hoeffding_unpaired_interval` | Supports unequal sample sizes and does not pair seed labels. |
| Mean radius | `sqrt(log(4/alpha_k)/(2n))` | `radius_a`, `radius_b` in `hoeffding_unpaired_interval` | Splits the look error budget across the two means. |
| Difference interval | Estimate plus/minus two radii, clipped to `[-1,1]` | Return value of `hoeffding_unpaired_interval` | Matches the manuscript formula. |
| Equal-sample width planning | `W_k(n)=4 sqrt(log(4/alpha_k)/(2n))`; `n >= ceil(8 log(4/alpha_k)/w^2)` | `unpaired_budget_requirements.py` and planning unit test | Matches Corollary 1; planning values are analytic, not empirical requirements. |
| Balanced total-budget planning | `N >= ceil(16 log(4/alpha_k)/w^2)` under `n_A=n_B=N/2`; necessary superiority threshold `N > 4 log(4/alpha_k)/(1-m)^2` | `total_seeds_for_width`, `total_seeds_for_possible_superiority`, and `test_pilot_protocol.py` | Matches Corollary 5; a worst-case allocation result, not an RL power or wall-clock optimum. |
| Formal-budget non-resolution | At v3 `alpha_cmp=0.05/15` and `n=20`, radius sum `1.0178588242`; no bounded mean difference can exceed the superiority threshold after subtraction, and the minimum clipped width exceeds `0.10` | `test_formal_v3_budget_is_structurally_non_resolving` | Matches Corollary 2; this is a protocol-resolution result, not a universal RL sample-size lower bound. |
| Pre-study feasibility audit | At every registered v3 look, compare `1-R_k` with the practical margin and `min(2,R_k)` with the target width before collecting sealed rows | `generate_budget_feasibility_audit.py`, `BUDGET_FEASIBILITY_AUDIT_V3.json`, and `test_budget_feasibility_audit.py` | Deterministic design audit for the stated bounded interval; not power, a seed lower bound, or a universal RL rule. |
| Look spending | `alpha * 6/(pi^2 k^2)` | `alpha_spend` | Sum over all positive looks is at most alpha. |
| Minimax spending diagnostic | `4 sum exp(-n_k tau)=alpha`, `alpha_k*=4 exp(-n_k tau)` | `minimax_alpha_spending.py` | Equalizes and minimizes the worst-case equal-sample radius sum for the listed finite looks; it is not the v3 primary rule. |
| Validation-selected spending | Any finite set of schedules with `sum alpha_h,k <= alpha_cmp`, selected using validation data only | Corollary 4, `adaptive_spending_diagnostic.py`, and `audit_adaptive_spending.py` | Conditional coverage selection argument; the diagnostic does not establish universal cost improvement. |
| Known-block fallback | Apply the same radii to complete independent block means, using block count as the sample size | Proposition 3, `dependency_robust_fallback_diagnostic.py`, and its deterministic tests | Valid only when the block partition and block independence are known; not a correction for unknown RL dependence. |
| Look schedule | 5, 10, 15, 20 test seeds | `initial_test_seeds=5`, `test_batch_size=5`, `test_seeds=20` | Frozen in `FINAL_PREREGISTRATION.md`. |
| Family allocation | `0.05 / 15` | `args.comparison_alpha = family_alpha / comparison_count` | Fifteen v3 comparisons receive total family alpha `0.05`. |
| Practical decision | Interval beyond margin `0.05` | `sequential_decision` | No formal superiority decision occurred in v3. |
| Precision decision | Width at most `0.10` | `sequential_decision` | No formal precision decision occurred in v3. |
| Locking | Terminal decision cannot be overwritten | `lock_resolved_decisions` | Covered by `test_sequential_runner_locks_terminal_pair_decisions`. |

## Coverage argument

At a fixed look, Hoeffding's inequality gives a failure probability at most
`alpha_k/2` for each two-sided mean bound. A union bound over the two means gives
failure probability at most `alpha_k`. A union bound over the predeclared looks
gives at most `sum_k alpha_k <= alpha`. Allocating `family_alpha / m` to each of
`m` comparisons and applying one more union bound gives family-wise coverage at
least `1 - family_alpha`; comparison independence is not needed for this last
step.

The statement is conditional on validation-selected configurations and assumes
within-algorithm independence of bounded test samples, fixed looks, and a fixed
metric. Cross-algorithm independence is not required for the union-bound step.
It does not
cover data-dependent task aggregation, post-hoc metric changes, test reuse, or
environment drift. The proof is a finite-look union-bound proof, not a general
anytime confidence sequence.

The same simultaneous event also justifies the runner's locked stopping rule.
If `tau` is the first terminal look, with `bar_tau=min(tau,K)` for the final
maximum-budget-inconclusive status, the event that the reported interval
`I_bar_tau` misses the conditional target is contained in the event that at least
one predeclared interval misses. Thus pairwise stopping at different looks and
discarding rows after a locked decision do not add an error term. This is the
locked-stopping lemma in the manuscript; it relies on the finite predeclared
look set and does not authorize unregistered looks or post-hoc thresholds.

## Empirical checks

- `test_pilot_protocol.py` covers alpha spending, bounded intervals, unequal
  sample sizes, order invariance for the unpaired method, terminal locking, and
  the formal v3 non-resolution boundary at the 20-seed budget.
- `test_nonstationary_queue.py` covers registration, bounds, and seed
  reproducibility for the controlled environment.
- The v3 artifact audit confirms 15 comparisons, 300 test rows, 300 validation
  rows, and 15/15 `max_budget_inconclusive` decisions at 20 seeds.
- The formal non-resolution test confirms that the 15/15 outcome is forced by
  the v3 bound and budget for every bounded data sequence, independent of the
  observed RL values.
- `test_budget_feasibility_audit.py` confirms the pre-study feasibility flags,
  necessary superiority thresholds, target-width thresholds, and final-look
  radius independently of the stored RL rows.
- The same-machine independent runner matches all fifteen stored test summaries
  with mean absolute metric difference `0.0`.
- `test_minimax_alpha_spending.py` verifies that the analytical alternative
  spends the full comparison-level alpha budget and equalizes the radius sum
  across the finite looks.
- `test_adaptive_spending_diagnostic.py` verifies that all candidate schedules
  spend the same comparison-level alpha and are generated deterministically.
- `test_dependency_robust_fallback_diagnostic.py` verifies complete-block
  aggregation and deterministic raw-count versus block-aware diagnostics;
  `DEPENDENCY_ROBUST_FALLBACK.json` reports 5,000 replicates per block
  condition.
- `test_pilot_protocol.py::test_sequential_runner_locks_terminal_pair_decisions`
  verifies the state transition used by the locked-stopping lemma; the
  probabilistic inclusion itself is supplied by the finite-look proof.

## Remaining proof and design risks

1. A submission should have an independent statistical review of the
   conditional estimand and family-level interpretation.
2. The four-candidate grid and five validation seeds are a bounded tuning
   budget; they do not establish equal-strength hyperparameter optimization
   across all RL implementations.
3. The family result controls the predeclared fifteen-comparison v3 family; it
   does not license post-hoc expansion of the task or comparison family.
4. Same-machine cross-script repeatability is not different-machine or
   independent-team reproducibility.


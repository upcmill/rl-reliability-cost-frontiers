#!/usr/bin/env python3
"""Consistency audit for the continuous-control supplement."""

from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "sb3_continuous_pendulum"


def main() -> None:
    rows = list(csv.DictReader((RUN / "raw_seed_metrics.csv").open(newline="")))
    assert len(rows) == 80, len(rows)
    assert sum(row["split"] == "validation" for row in rows) == 40
    assert sum(row["split"] == "test" for row in rows) == 40
    assert {row["algorithm"] for row in rows} == {"PPO", "A2C"}
    assert all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows)
    payload = json.loads((RUN / "summary.json").read_text())
    assert payload["environment_id"] == "Pendulum-v1"
    assert payload["comparison"]["final"]["PPO_vs_A2C"]["n"] == 20
    assert payload["comparison"]["final"]["PPO_vs_A2C"]["decision"] == "max_budget_inconclusive"
    replay = json.loads((RUN / "independent_reproduction.json").read_text())
    assert len(replay["rows"]) == 2
    assert replay["all_zero_mean_absolute_difference"] is True
    assert all(float(row["mean_absolute_metric_difference"]) == 0.0 for row in replay["rows"])
    print("continuous supplement audit: PASS")
    print("rows=80 validation=40 test=40 comparison=1 reproduction_diffs=2x0.0")


if __name__ == "__main__":
    main()

import unittest

from audit_theory_v3 import run_audit


class TheoryAuditTests(unittest.TestCase):
    def test_all_deterministic_theory_checks_pass(self):
        result = run_audit()
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(all(result["checks"].values()))

    def test_v3_boundary_values_are_explicit(self):
        result = run_audit()
        self.assertEqual(result["derived_values"]["possible_superiority_thresholds"], [17, 20, 22, 23])
        self.assertEqual(result["derived_values"]["width_requirements_per_algorithm"], [6071, 7180, 7829, 8289])


if __name__ == "__main__":
    unittest.main()

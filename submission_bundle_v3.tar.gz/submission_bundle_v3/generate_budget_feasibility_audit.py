#!/usr/bin/env python3
"""Generate a pre-study feasibility audit for the frozen v3 interval design."""

from __future__ import annotations

import json
import math
from pathlib import Path

from pilot_protocol import alpha_spend
from unpaired_budget_requirements import (
    seeds_for_possible_superiority,
    seeds_for_width,
)


ROOT = Path(__file__).resolve().parent
OUTPUT_JSON = ROOT / "BUDGET_FEASIBILITY_AUDIT_V3.json"
OUTPUT_MD = ROOT / "BUDGET_FEASIBILITY_AUDIT_V3.md"

FAMILY_ALPHA = 0.05
COMPARISON_COUNT = 15
COMPARISON_ALPHA = FAMILY_ALPHA / COMPARISON_COUNT
LOOKS = (5, 10, 15, 20)
PRACTICAL_MARGIN = 0.05
TARGET_WIDTH = 0.10


def radius_sum(comparison_alpha: float, look_index: int, n_per_arm: int) -> float:
    look_alpha = alpha_spend(comparison_alpha, look_index)
    return 2.0 * math.sqrt(math.log(4.0 / look_alpha) / (2.0 * n_per_arm))


def build_payload() -> dict:
    rows = []
    for look_index, n_per_arm in enumerate(LOOKS, start=1):
        radius = radius_sum(COMPARISON_ALPHA, look_index, n_per_arm)
        rows.append(
            {
                "look_index": look_index,
                "n_per_arm": n_per_arm,
                "alpha_look": alpha_spend(COMPARISON_ALPHA, look_index),
                "radius_sum": radius,
                "maximum_possible_lower_endpoint": 1.0 - radius,
                "minimum_clipped_width": min(2.0, radius),
                "possible_superiority_at_margin": (1.0 - radius) > PRACTICAL_MARGIN,
                "possible_precision_at_target": min(2.0, radius) <= TARGET_WIDTH,
                "necessary_seeds_for_possible_superiority": seeds_for_possible_superiority(
                    COMPARISON_ALPHA, look_index, PRACTICAL_MARGIN
                ),
                "seeds_for_target_width": seeds_for_width(
                    COMPARISON_ALPHA, look_index, TARGET_WIDTH
                ),
            }
        )

    payload = {
        "status": "analytic_pre_study_feasibility_audit",
        "warning": (
            "This is a worst-case planning audit for the bounded Hoeffding protocol; "
            "it is not an observed RL result, power calculation, or universal seed requirement."
        ),
        "inputs": {
            "family_alpha": FAMILY_ALPHA,
            "comparison_count": COMPARISON_COUNT,
            "comparison_alpha": COMPARISON_ALPHA,
            "looks_per_arm": list(LOOKS),
            "metric_range": [0.0, 1.0],
            "practical_margin": PRACTICAL_MARGIN,
            "target_width": TARGET_WIDTH,
            "interval": "unpaired_hoeffding_with_power_series_spending",
        },
        "rows": rows,
        "audit_conclusion": {
            "all_v3_looks_cannot_reach_superiority": all(
                not row["possible_superiority_at_margin"] for row in rows
            ),
            "all_v3_looks_cannot_reach_precision": all(
                not row["possible_precision_at_target"] for row in rows
            ),
            "necessary_superiority_thresholds": [
                row["necessary_seeds_for_possible_superiority"] for row in rows
            ],
            "target_width_thresholds": [row["seeds_for_target_width"] for row in rows],
        },
    }
    return payload


def render_markdown(payload: dict) -> str:
    inputs = payload["inputs"]
    lines = [
        "# v3 Pre-study Budget Feasibility Audit",
        "",
        "This artifact audits whether the frozen bounded interval could possibly",
        "reach either v3 decision threshold before RL test data are collected.",
        "It uses only the registered family size, alpha spending, metric bound,",
        "practical margin, and target width; it reads no RL observations.",
        "",
        "## Frozen inputs",
        "",
        f"- Family alpha: `{inputs['family_alpha']}` across `{inputs['comparison_count']}` comparisons.",
        f"- Comparison alpha: `{inputs['comparison_alpha']}`.",
        f"- Looks per arm: `{inputs['looks_per_arm']}`.",
        f"- Metric range: `{inputs['metric_range']}`.",
        f"- Practical margin: `{inputs['practical_margin']}`.",
        f"- Target width: `{inputs['target_width']}`.",
        "",
        "## Feasibility table",
        "",
        "| Look | Seeds/arm | Radius sum | Max possible lower endpoint | Min clipped width | Superiority possible? | Precision possible? | Necessary seeds/arm for superiority | Seeds/arm for target width |",
        "|---:|---:|---:|---:|---:|:---:|:---:|---:|---:|",
    ]
    for row in payload["rows"]:
        lines.append(
            f"| {row['look_index']} | {row['n_per_arm']} | {row['radius_sum']:.6f} | "
            f"{row['maximum_possible_lower_endpoint']:.6f} | {row['minimum_clipped_width']:.6f} | "
            f"{str(row['possible_superiority_at_margin']).lower()} | "
            f"{str(row['possible_precision_at_target']).lower()} | "
            f"{row['necessary_seeds_for_possible_superiority']} | {row['seeds_for_target_width']:,} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "The audit returns `false` for both decision-feasibility columns at every",
            "v3 look. Thus the v3 cap forces an unresolved outcome for every bounded",
            "dataset under the registered rule. The necessary seed thresholds are",
            "strict feasibility thresholds only: crossing one makes a decision",
            "possible, not probable. The target-width thresholds are worst-case",
            "Hoeffding planning values and are not empirical RL requirements.",
            "",
            "The audit is a pre-study design check. It does not replace the",
            "conditional coverage proof, validate seed independence, estimate power,",
            "or support a universal rule for other intervals or task families.",
            "",
            "Machine-readable source: `generate_budget_feasibility_audit.py` and",
            "`BUDGET_FEASIBILITY_AUDIT_V3.json`.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    payload = build_payload()
    OUTPUT_JSON.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    OUTPUT_MD.write_text(render_markdown(payload), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "output": str(OUTPUT_JSON)}))


if __name__ == "__main__":
    main()

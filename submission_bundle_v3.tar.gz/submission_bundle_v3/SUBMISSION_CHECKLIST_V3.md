# Submission Checklist for the v3 Package

## Scientific claims

- [x] Keep the main claim limited to a reliability--cost characterization.
- [x] Do not report PPO/DQN/A2C or PPO/A2C rankings from inconclusive intervals.
- [x] Keep the continuous supplement separate from the 15-comparison family.
- [x] Distinguish same-machine replay repeatability from the returned Windows
  AMD64 different-machine reproducibility check; do not call it scientific
  replication or independent-team evidence.
- [x] Keep universal seed savings, universal power, and broad RL generalization
  out of the abstract and conclusion.
- [x] Report the fixed-configuration queue budget follow-up as a post-v3
  resolution-cost diagnostic; do not treat its 400-seed decision as a
  universal seed rule or general algorithm ranking.
- [x] Report the prospective v4 new-seed extension as a same-family budget
  observation; keep its single queue decision and 14 unresolved cells scoped.
- [x] Report the v5 1,000-seed extension as a same-family resolution-cost
  diagnostic; keep four terminal cells and eleven unresolved cells separate
  from the v3 primary family.
- [x] Define the v5 look-by-look reliability--cost frontier and distinguish
  complete-sequence accounting from observed stopping savings.

## Statistical audit

- [x] Include Proposition 1 assumptions and proof sketch.
- [x] Include the locked-stopping lemma with the final-look convention for
  maximum-budget-inconclusive comparisons.
- [x] Cite `STATISTICAL_AUDIT_V3.md` for simulation scenarios and Monte Carlo
  intervals.
- [x] Label all simulation outputs as diagnostics, not proofs.
- [x] Report family alpha, comparison alpha, four looks, practical margin, and
  target width.
- [x] Include the finite-look minimax alpha-spending planning lemma as a
  diagnostic while retaining the preregistered primary spending rule.
- [x] Include the pre-study budget feasibility audit; it flags structurally
  non-resolving caps before sealed test data are opened and is labelled as
  design analysis rather than empirical power.
- [x] Report selected-test raw-return summaries alongside normalized metrics;
  keep raw scales task-specific and descriptive.
- [x] Explain the conditional estimand after validation selection.
- [x] State evidence-typed research questions and maintain an explicit
  assumption registry with checks and residual failure modes.

## Reproduction package

- [x] Run `./.rl-arm64-venv/bin/python audit_v3_artifacts.py` (including the formal non-resolution check).
- [x] Run `./.rl-arm64-venv/bin/python audit_continuous_artifacts.py`.
- [x] Run `./.rl-arm64-venv/bin/python -m unittest -v` (55 tests pass in the current package).
- [x] Archive the v3 and continuous manifests, source hashes, wheel hashes,
  raw CSV files, JSON summaries, and exact commands.
- [x] Archive and audit the returned Windows AMD64 different-machine sealed
  rerun; retain the limitation that independent-team identity and new-family
  scientific replication are unverified.
- [x] Report validation-stage tuning cost separately from sealed-test runtime;
  candidate-seed row counts are equal across algorithms and the wall-clock
  accounting remains machine-specific (`VALIDATION_TUNING_COST_V3.md`).

## Literature and venue

- [ ] Recheck L1--L12 against the target journal's required citation style.
- [x] Resolve Stable-Baselines3 software citation metadata from the official
  repository citation file and JMLR landing page (L12).
- [ ] Complete a systematic novelty review before claiming novelty.
- [ ] Select a target journal only after checking current scope and article type
  `[待核实]`.
- [ ] Remove `[待核实]` only when an authoritative source or completed check
  exists.

## Data and ethics

- [x] State that the queue task is self-built and diagnostic.
- [x] Disclose the Apple Silicon CPU runtime and package versions.
- [ ] Add repository/data URL and license information before submission.
- [x] Add raw-return and normalization-bound sensitivity appendix (`V3_NORMALIZATION_SENSITIVITY.md`).
- [x] Add practical-margin sensitivity over the stored v3 rows
  (`MARGIN_SENSITIVITY_V3.md`); retain it as post-hoc evidence.
- [x] Add ten-validation-seed tuning-stability diagnostic (`TUNING_STABILITY_V3_REPORT.md`).
- [x] Add prospective twenty-validation-seed tuning-stability extension with a new seed range and row-level audit; retain its 7/15 selection-change result as supplementary evidence (`FINAL_PREREGISTRATION_TUNING_EXTENSION_V1.md`, `TUNING_STABILITY_V20_AUDIT.json`).
- [x] Add joint row-bootstrap validation-selection uncertainty diagnostic;
  report it as observed-sample instability, not a population probability.
- [x] Add training-budget scaling diagnostic with fixed v3 selections and explicit estimand separation (`BUDGET_SCALING_DIAGNOSTIC.md`).
- [x] Add evaluation-episode sensitivity diagnostic with fixed v3 selections (`EVAL_EPISODE_SENSITIVITY_DIAGNOSTIC.md`).
- [x] Add a separately preregistered fixed-mask partial-observation execution diagnostic; keep its six comparisons outside the v3 family.
- [x] Run the executable supplementary diagnostic audit (`audit_supplementary_diagnostics.py`).
- [x] Run `audit_queue_budget_followup.py` and archive its 800 raw rows, stop
  trace, prefix comparison, and source hashes.
- [x] Run `audit_v4_extension.py` and archive its 6,000 raw rows, new-seed
  range, frozen-configuration check, decision audit, and Figure 11.
- [x] Run the non-pooled v4 queue sequence-consistency diagnostic and label it
  descriptive rather than independent replication.
- [x] Run the fixed supplementary calibration grid with recorded seeds and both single-comparison and v3 family alpha settings; retain it as diagnostic evidence.
- [ ] Add author, affiliation, funding, conflicts, and data-availability text.

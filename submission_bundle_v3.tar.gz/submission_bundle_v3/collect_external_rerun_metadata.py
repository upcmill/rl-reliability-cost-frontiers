#!/usr/bin/env python3
"""Collect reproducibility metadata for a sealed external v3 rerun.

The script uses only the Python standard library. It records runtime versions,
accelerator availability when PyTorch is importable, and SHA-256 hashes for
the supplied source/artifact files. It never reads the author's reference
results and does not modify a rerun output except for the requested JSON file.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path


DEFAULT_HASH_FILES = (
    "sequential_sb3_runner_v3.py",
    "sb3_pilot.py",
    "pilot_protocol.py",
    "nonstationary_queue_env.py",
    "requirements-rl.txt",
    "requirements-rl-lock.txt",
    "REPRODUCTION_MANIFEST_V3.md",
    "EXTERNAL_RERUN_PROTOCOL.md",
    "EXTERNAL_RERUN_HANDOFF_ZH.md",
    "validate_external_rerun.py",
    "package_external_rerun.py",
    "test_nonstationary_queue.py",
    "test_external_rerun_validator.py",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def package_versions() -> dict[str, str | None]:
    names = ("numpy", "torch", "gymnasium", "stable-baselines3", "cloudpickle")
    versions: dict[str, str | None] = {}
    for name in names:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return versions


def accelerator_status() -> dict[str, object]:
    try:
        import torch
    except Exception as exc:  # pragma: no cover - depends on the target machine
        return {"torch_import_error": f"{type(exc).__name__}: {exc}"}
    mps_available = bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available())
    return {
        "mps_available": mps_available,
        "cuda_available": bool(torch.cuda.is_available()),
        "torch_device_count": int(torch.cuda.device_count()) if torch.cuda.is_available() else 0,
    }


def collect(root: Path) -> dict[str, object]:
    files: dict[str, object] = {}
    for relative in DEFAULT_HASH_FILES:
        path = root / relative
        if path.is_file():
            files[relative] = {
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        else:
            files[relative] = {"missing": True}
    wheel_hashes: dict[str, object] = {}
    wheels = root / "wheels"
    if wheels.is_dir():
        for path in sorted(wheels.glob("*.whl")):
            wheel_hashes[str(path.relative_to(root))] = {
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
    return {
        "schema": "external-rerun-metadata-v1",
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python_implementation": platform.python_implementation(),
        },
        "python": {
            "version": platform.python_version(),
            "executable": sys.executable,
            "prefix": sys.prefix,
        },
        "packages": package_versions(),
        "accelerators": accelerator_status(),
        "source_files": files,
        "wheel_files": wheel_hashes,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, help="JSON path to write")
    parser.add_argument("--root", default=".", help="Kit or source root")
    args = parser.parse_args()
    output = Path(args.output)
    payload = collect(Path(args.root).resolve())
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

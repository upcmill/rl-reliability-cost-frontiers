#!/usr/bin/env python3
"""Audit the current formal revision, linked inputs, and actual new evidence."""
import csv
import hashlib
import json
import math
import re
from pathlib import Path

from audit_formal_round2 import tables,verify_shared_content
from generate_round3_manuscript import additions, selection_stability_table
from fifth_review_revision import canonical_names, comparison_payload, comparison_tables, version_rows, table

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'revision_history/round2_before_round3'
A=ROOT/'round3_analysis'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    report={'revision':'sixth review','status':'RUNNING'}
    main_md=(ROOT/'MANUSCRIPT_FORMAL_ZH.md').read_text()
    supp=(ROOT/'SUPPLEMENTARY_FORMAL_ZH.md').read_text()
    report['main']=verify_shared_content('MANUSCRIPT_FORMAL_ZH')
    report['supplement']=verify_shared_content('SUPPLEMENTARY_FORMAL_ZH')
    assert report['main']['tables']==24 and report['main']['images']==16
    assert report['supplement']['tables']==27
    assert re.findall(r'^\*\*表 (\d+)。',main_md,re.M)==list(map(str,range(1,24)))
    assert re.findall(r'^!\[图 (\d+)。',main_md,re.M)==list(map(str,range(1,17)))
    assert re.findall(r'^### 命题 (\d+)（',main_md,re.M)==list(map(str,range(1,5)))
    assert re.findall(r'^### 推论 (\d+)（',main_md,re.M)==list(map(str,range(1,7)))
    assert not re.search(r'(?:命题|推论) 0\b',main_md)
    assert not re.search(r'[。；，：] +(?![A-Za-z0-9`$|])',main_md)
    assert re.findall(r'^## (S\d+) ',supp,re.M)==[f'S{i}' for i in range(1,24)]
    for i in range(1,24):assert re.search(rf'补充材料 S{i}(?!\d)',main_md),i
    for appendix in 'ABC':assert len(re.findall(rf'^## 附录 {appendix}。',main_md,re.M))==1
    old_main=(BASE/'MANUSCRIPT_FORMAL_ZH.md').read_text()
    old_tables,new_tables=tables(old_main),tables(main_md)
    versions=canonical_names(table('表 8。实验序列标签、名称与证据地位',['标签','名称','训练种子范围','证据地位'],version_rows()))
    assert versions.strip() in main_md
    new_tables=[t for t in new_tables if not t.startswith('| 标签 | 名称 |')]
    for i,(old,new) in enumerate(zip(old_tables,new_tables),1):
        if i==7:old=old.replace('和 大预算分辨成本扩展','和大预算分辨成本扩展')
        if i==19:old=old.replace('见 补充材料 S12','见补充材料 S12')
        old=canonical_names(old).strip()
        if i not in (2,3,5,7,8,11,19,22):assert old==new,f'Unexpected table {i} modification'
    assert new_tables[7].startswith('| 范围扩展 | 环境/变体数 | 测试种子范围 | 算法 | 每单元种子数 | 正文位置 |')
    assert '20,000–20,019' in new_tables[7] and '41,000–41,199' in new_tables[7]
    assert '50,000–50,019' in new_tables[7]
    related_work_table=tables((ROOT/'literature_fulltext/RELATED_WORK_MAIN.md').read_text())[0]
    normalize_refs=lambda value:re.sub(r'\[(?:L)?\d+(?:(?:,|–|-)(?:L)?\d+)*\]', '[REF]', value)
    assert normalize_refs(new_tables[1])==normalize_refs(related_work_table.replace('本文现已在','本文在'))
    expected=old_tables[10]
    for env,pair in [('MountainCar-v0','PPO - A2C'),('Taxi-v4','PPO - DQN')]:
        expected=expected.replace(f'| {env} | {pair} | 0.000000 | 0.000000 | 0.000000 | 0.000000 |',f'| {env} | {pair} | 0.000000 | 0.000000 | 未定义 | 0.000000 |')
    assert new_tables[10]==expected
    for t in tables((BASE/'SUPPLEMENTARY_FORMAL_ZH.md').read_text())[1:]:assert canonical_names(t).strip() in supp
    assert tables(supp)[0]==tables((ROOT/'literature_fulltext/COMPARISON_S1.md').read_text())[0]
    report['original_tables']='Original quantitative tables unchanged except explicit undefined standardized-effect display in two zero-SD rows.'
    immutable=json.loads((BASE/'IMMUTABLE_INPUT_HASHES.json').read_text())
    for p,h in immutable.items():assert sha(ROOT/p)==h,p
    report['immutable_inputs_checked']=len(immutable)
    manifest=json.loads((A/'ANALYSIS_MANIFEST.json').read_text())
    for p,h in manifest['source_hashes'].items():assert sha(ROOT/p)==h,p
    for p,h in manifest['output_hashes'].items():assert sha(A/p)==h,p
    refs=re.findall(r'^\[(\d+)\].*',main_md,re.M)
    assert refs==list(map(str,range(1,20)))
    cited=set()
    first_use=[]
    for group in re.findall(r'\[(\d{1,2}(?:[,–-]\d{1,2})*)\]',main_md.split('## 参考文献',1)[0]):
        for item in group.split(','):
            bounds=re.split(r'[–-]',item)
            start=int(bounds[0]);end=int(bounds[-1])
            for number in map(str,range(start,end+1)):
                cited.add(number)
                if number!='0' and number not in first_use:first_use.append(number)
    cited.discard('0')
    assert cited==set(map(str,range(1,20)))
    assert first_use==list(map(str,range(1,20)))
    sources=json.loads((ROOT/'literature_fulltext/2026-11-03/SOURCES.json').read_text())
    assert len(sources['papers'])==12
    assert {p['id'] for p in sources['papers']}=={'L1','L2','L3','L4','L11','L13','L14','L15','L16','L17','L18','L19'}
    assert all(p['status']=='fulltext_key_methods_read' and p['locations_read'] for p in sources['papers'])
    local_pdf_checks=0
    for p in sources['papers']:
        pdf=ROOT/p['pdf_path']
        if pdf.exists():
            assert pdf.read_bytes().startswith(b'%PDF-') and sha(pdf)==p['pdf_sha256'],p['id']
            local_pdf_checks+=1
    for phrase in ['全文方法重叠[待核实]','L11 目前只作题录','未完成新的远程全文获取','全文比较待核实']:
        assert phrase not in main_md+supp,phrase
    report['literature']={'fulltexts_compared':12,'references':19,'locally_available_pdf_hashes_checked':local_pdf_checks,
                          'exhaustive_novelty_search':False,'modern_confidence_sequence_benchmark_completed':True}
    assert not any(p in main_md for p in ['60% 特征空间','12.3%','P(Δ > 0.05) = 78%','减少5%的能耗'])
    assert '补充材料 S16' in main_md and '不能确证独立性' in main_md
    assert canonical_names(additions()).strip() in supp
    stability_table,stability_counts=selection_stability_table()
    assert stability_table.strip() in supp
    assert stability_counts=={'high':2,'moderate':4,'low':4,'uninformative':5}
    assert '不改变命题 1–2 条件于验证数据及实际选定配置的覆盖陈述' in main_md
    assert '### 6.5 后续研究方向' in main_md
    assert '表 D4-1。事前敏感性网格示例及宽度规划量' in main_md
    assert '表 S15-1。按读者问题查找内容' in supp
    assert '表 S15-2。补充材料章节与完整性状态' in supp
    assert all(label in supp for label in ('逐单元配置选择稳定性','种子顺序/依赖诊断','补充任务与任务特征'))
    assert '## 12 后续研究方向' not in main_md
    assert re.findall(r'^### D\.(\d+) ',main_md,re.M)==['1','2','3','4']
    for stale in ('在打开密封测试行之前，事前预算可行性审计已经得到相同结论',
                  '降低了主要未决结果完全由每个检查点五个评估回合造成的担忧',
                  '完整的选定测试分布如下','根据第三轮意见',
                  '主研究结论的事后稳健性','同一流程可在一个连续动作任务上执行'):
        assert stale not in main_md,stale
    spent=sum(6/(math.pi**2*k*k) for k in range(1,5))
    assert f'{spent:.7f}' in main_md
    mask_r=math.sqrt(2*math.log(4/((0.05/6)*6/(math.pi**2*4**2)))/20)
    assert f'{mask_r:.6f}' in main_md and f'{1-mask_r:.6f}' in main_md
    assert 1-mask_r<0.05 and mask_r>0.10
    for heading in ('S10.1','S10.2','S10.3','S10.4'):
        assert f'### {heading} ' in supp
    report['fourth_review']={
        'alpha_spent_fraction':spent,'masked_radius_sum_at_20':mask_r,
        'scope':'four new environments and two observation-mask variants',
        'chronology':'retrospective audit; pre-test execution not established',
        'twenty_seed_decisions':'implementation consistency only',
        'future_work_sections':len(re.findall(r'^### 6\.5 后续研究方向',main_md,re.M)),
    }
    paired=comparison_payload()
    saved=json.loads((ROOT/'round5_analysis/V5_V7_COMPARISON.json').read_text())
    assert paired==saved
    assert comparison_tables(paired).strip() in supp
    assert '与前一压力测试相同的 5,000 次重复' not in main_md
    assert '931000' in main_md and '932000' in main_md
    assert '0.550180]' not in main_md and '0.550181]' in main_md
    assert '更具体地，对算法 A 有' not in main_md
    assert '该归档包含 V7 数据，但所附稿件早于本轮修订' in main_md
    report['fifth_review']={'V5_V7_comparison':paired['methods'],
        'raw_means_recomputed':True,'seed_overlap':paired['seed_overlap'],
        'version_table_verified_from_csv':True,'dependency_tables_use_distinct_streams':True}
    modern=json.loads((ROOT/'sequential_comparison_v1/results_v2/real_summary.json').read_text())
    simulation=json.loads((ROOT/'sequential_comparison_v1/results_v2/simulation_summary.json').read_text())
    rerun=json.loads((ROOT/'sequential_comparison_v1/RECOMPUTATION_AUDIT_V2.json').read_text())
    assert len(modern['summaries'])==27 and len(simulation['rows'])==168
    for row in modern['summaries']:
        assert sum(row['counts'].values())==15
        assert row['counterfactual_shared_training_runs']<=row['observed_full_test_training_runs']
    assert all(r['rates']['covered']['count']==10000 for r in simulation['rows'])
    assert all(r['rates']['false_superiority']['count']==0 for r in simulation['rows'])
    assert rerun['status']=='PASS' and len(rerun['summary_and_csv_files'])==4 and len(rerun['replicate_archives'])==8
    v7=json.loads((ROOT/'sb3_v7_confirmation/analysis/summary.json').read_text())
    v7_meta=json.loads((ROOT/'sb3_v7_confirmation/run_config.json').read_text())
    v7_manifest=json.loads((ROOT/'sb3_v7_confirmation/analysis/ANALYSIS_MANIFEST.json').read_text())
    v7_audit=json.loads((ROOT/'V7_CONFIRMATION_AUDIT.json').read_text())
    assert v7_meta['status']=='COMPLETED' and v7_meta['completed_rows']==15000
    assert v7['seed_range']==[31400,32399] and len(v7['pairwise_primary_results'])==15
    assert v7['primary_fixed_panel_outcome']['comparisons_gamma_narrower']==15
    assert sum(v7['method_summaries'][0]['decision_counts_at_1000'].values())==15
    assert v7_manifest['input_sha256']==sha(ROOT/'sb3_v7_confirmation/raw_seed_metrics.csv')
    assert v7_audit['status']=='PASS' and v7_audit['rows']==15000
    assert all(sha(ROOT/'sb3_v7_confirmation/analysis'/name)==digest
               for name,digest in v7_manifest['outputs'].items())
    numeric_claim_audit=json.loads((ROOT/'MANUSCRIPT_NUMERIC_CLAIM_AUDIT.json').read_text())
    assert numeric_claim_audit['status']=='PASS'
    assert numeric_claim_audit['checks']['v7_claims_appear_in_both_english_sources']
    assert numeric_claim_audit['checks']['v7_claims_appear_in_english_word_files']
    assert numeric_claim_audit['checks']['chinese_word_numeric_anchors_match']
    report['english_v7_synchronization']={
        'status':'PASS',
        'evidence':'V7 numerical and claim-boundary anchors match the audited summary in both English Markdown manuscripts, both English Word files, and the Chinese Word file.',
        'scope':'Selected anchors only; not line-by-line bilingual equivalence.'}
    assert all((ROOT/p['pdf_path']).read_bytes().startswith(b'%PDF-') for p in sources['papers'])
    synth=json.loads((A/'synthetic_calibration.json').read_text())
    rows=synth['rows']
    for row in rows:
        c=row['counts'];N=row['replicates']
        assert c['a_superior']+c['b_superior']+c['precision_only']+c['unresolved']==N
        assert 0<=c['simultaneous_covered']<=N and 0<=c['false_superiority']<=N
        assert row['looks'][0] <= row['mean_terminal_n'] <= row['looks'][-1]
        if row['looks'][-1]==20:assert c['unresolved']==N
    report['synthetic']={'scenario_count':5,'plans':3,'replicates_per_scenario':10000,
                         'primary_20_seed_all_unresolved':True,'raw_counts_and_text_table_match':True}
    order=json.loads((A/'order_diagnostics.json').read_text())
    runs_ok=sum(r['runs']['status']=='computed' for r in order['rows'])
    lag_ok=sum(r['lag1']['status']=='computed' for r in order['rows'])
    assert (runs_ok,lag_ok,order['rejected_tests_holm_05'])==(7,11,0)
    max_lag=max(abs(r['lag1']['r1']) for r in order['rows'] if r['lag1']['r1'] is not None)
    min_runs=min(r['runs']['p'] for r in order['rows'] if r['runs']['status']=='computed')
    min_lag=min(r['lag1']['p'] for r in order['rows'] if r['lag1']['status']=='computed')
    for val,precision in ((max_lag,6),(min_runs,6),(min_lag,4)):
        assert f'{val:.{precision}f}' in main_md
    scale=json.loads((A/'threshold_scale.json').read_text())
    vals=[r['margin_over_pooled_sd'] for r in scale['rows'] if r['margin_over_pooled_sd'] is not None]
    assert len(vals)==13 and f'{min(vals):.3f}–{max(vals):.3f}' in main_md
    plan=json.loads((A/'planning_sensitivity.json').read_text())
    for r in plan['rows']:
        assert sum(r['alpha_per_look'])<=.05/15+1e-15
        if r['looks'][-1]==200 and r['schedule']=='original_summable':assert f"{r['last_radius']:.6f}" in main_md
    report['order']={'computable_runs':runs_ok,'computable_lag1':lag_ok,'holm_rejections':0,'independence_proven':False}
    files=list(csv.DictReader((A/'SUPPLEMENT_FILE_MANIFEST.csv').open()))
    for row in files:
        p=ROOT/row['path'];assert p.is_file()
        assert p.stat().st_size==int(row['bytes']) and sha(p)==row['sha256'],row['path']
    report['supplement_files']={'count':len(files),'total_bytes':sum(int(r['bytes']) for r in files),
                                'largest_bytes':max(int(r['bytes']) for r in files),'hashes_match':True}
    replay=Path('/tmp/rl-paper-round3-independent-rerun')
    if replay.is_dir():
        checked=[]
        for name in ['synthetic_calibration','order_diagnostics','planning_sensitivity','threshold_scale','environment_features']:
            f=name+'.json'
            if (replay/f).exists():
                assert json.loads((A/f).read_text())==json.loads((replay/f).read_text()),f
                checked.append(f)
        report['same_machine_analysis_rerun_matches']=checked
    report['sha256']={name:sha(ROOT/name) for name in ['MANUSCRIPT_FORMAL_ZH.md','MANUSCRIPT_FORMAL_ZH.docx',
        'SUPPLEMENTARY_FORMAL_ZH.md','SUPPLEMENTARY_FORMAL_ZH.docx','round3_diagnostics.py',
        'budget_calculator.py','generate_round3_manuscript.py']}
    report['prospective_new_seed_validation']={'rows':15000,'seed_range':[31400,32399],
        'gamma_narrower_comparisons':15,'mean_width_difference_gamma_minus_original':
            v7['primary_fixed_panel_outcome']['mean_final_width_difference_gamma_minus_original'],
        'gamma_directional_superiority':6,'gamma_precision_only':5,'gamma_total_stops':11,
        'gamma_rho_x10_total_stops':6,'hoeffding_directional_superiority':4,
        'interpretation':'fixed-panel, post-hoc prospective new-seed evidence; not independent-team reproduction'}
    method_report=json.loads((ROOT/'round6_analysis/V7_METHOD_SUMMARY.json').read_text())
    dependence_report=json.loads((ROOT/'round6_analysis/V5_V7_DEPENDENCE.json').read_text())
    registered=json.loads((ROOT/'round6_analysis/REGISTERED_DEPENDENCE_STRESS.json').read_text())
    assert len(method_report['rows'])==9
    assert method_report['rows'][-1]['resolved_total']==6
    assert dependence_report['acf']['summary']['V5']['series']==15
    assert dependence_report['acf']['summary']['V7']['series']==15
    assert dependence_report['block_fallback']['resolved_decisions_preserved']=={'V5':0,'V7':0}
    assert len(registered['results'])==6 and registered['seed']==933000
    assert all('完整的任务—算法臂' not in r for r in dependence_report['acf']['sequences'])
    assert 'S23.3 与注册参数匹配的合成依赖校准' in supp
    assert '均匀支出 Hoeffding、正态混合 CS、Gamma rho×0.1、Gamma rho×10 的一致数分别为 14、12、13、15、12 项' in main_md
    assert '任何有界数据和任何依赖结构都不可能触发边际 m=0.05 的优越性决定' in supp
    assert '不是依赖无害或覆盖稳健的独立证据' in supp
    assert '主设下 15 项最终区间均更窄；rho×10 时仅 6/15' in main_md
    assert 'rho×10 下停止数降至 6/15' in main_md
    assert '| H-original |' not in main_md
    report['sixth_review']={
        'v7_methods':len(method_report['rows']),
        'v7_rho_x10_stops':method_report['rows'][-1]['resolved_total'],
        'dependence_series_per_sequence':15,
        'bootstrap_lags':dependence_report['acf']['max_lag'],
        'block_length':dependence_report['block_fallback']['block_size'],
        'original_decisions_preserved_after_block_sensitivity':dependence_report['block_fallback']['resolved_decisions_preserved'],
        'registered_parameter_stress_conditions':len(registered['results']),
        'interpretation':'post-hoc, conditional sensitivity; does not establish independence or repair coverage'}
    report['modern_interval_comparison']={'real_data_sequences':3,'primary_methods':7,'rho_sensitivity_methods':2,
        'synthetic_scenarios':8,'plans':3,'replicates_per_scenario':10000,'full_families_per_cell':10000,
        'simultaneous_coverage_failures':0,'false_superiority_family_events':0,
        'same_team_same_machine_exact_recomputation':'PASS',
        'interpretation':'Finite post-hoc reanalysis and model calibration; not a universal efficiency or RL power claim'}
    render_record=ROOT/'round5_render/RENDER_REVIEW.json'
    render_verified=False
    if render_record.exists():
        review=json.loads(render_record.read_text())
        render_verified=all(sha(ROOT/p)==digest for p,digest in review['artifact_sha256'].items())
        if render_verified:
            report['pagination_review']=review
    report['unverified']=['Literature-wide novelty, independent-team reproduction, new task-family validation, and public repository availability.',
                          'Author contact, romanization, CRediT, funding and conflict declarations.',
                          'Line-by-line bilingual equivalence and remote CI/container deployment.']
    if not render_verified:
        report['unverified'].append('Full pagination review of the current DOCX artifacts is pending.')
    report['status']='PASS'
    (ROOT/'FORMAL_ROUND3_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='sha256'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

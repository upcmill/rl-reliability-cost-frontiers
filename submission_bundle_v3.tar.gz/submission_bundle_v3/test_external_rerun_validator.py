import unittest
from pathlib import Path

from validate_external_rerun import (
    check_schema,
    compare_to_reference,
    load_payload,
    load_rows,
)


class ExternalRerunValidatorTests(unittest.TestCase):
    def test_v3_self_validation_has_zero_differences_and_matching_decisions(self):
        directory = Path("sb3_formal_v3")
        payload = load_payload(directory)
        rows = load_rows(directory)
        reference = load_payload(directory)
        reference_rows = load_rows(directory)

        self.assertEqual(check_schema(rows, payload), [])
        comparison = compare_to_reference(rows, payload, reference, reference_rows)
        self.assertTrue(comparison["all_selected_configurations_match"])
        self.assertTrue(comparison["all_decisions_match"])
        self.assertTrue(
            all(
                item["mean_absolute_metric_difference"] == 0.0
                for item in comparison["cell_differences"]
            )
        )


if __name__ == "__main__":
    unittest.main()

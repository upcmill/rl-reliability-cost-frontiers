#!/usr/bin/env python3
"""Run the frozen v5 new-seed resolution-cost diagnostic."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
from itertools import combinations
from pathlib import Path

import gymnasium as gym
import torch

from pilot_protocol import ProtocolConfig, sequential_decision
from sb3_pilot import train_curve
from sequential_sb3_runner_v3 import (
    ADDITIONAL_ENV_IDS,
    ALGORITHMS,
    CONFIGS,
    DEFAULT_ENV_IDS,
    QUEUE_ENV_ID,
)


ENVIRONMENTS = (*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)
OUTPUT_DIR = Path("sb3_v5_extension")
REFERENCE_DIR = Path("sb3_formal_v3")
SEED_BASE = 30_400
SEED_LIMIT = 31_400


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-dir", type=Path, default=REFERENCE_DIR)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--max-seeds", type=int, default=1000)
    parser.add_argument("--initial-seeds", type=int, default=200)
    parser.add_argument("--batch-size", type=int, default=200)
    parser.add_argument("--timesteps", type=int, default=4096)
    parser.add_argument("--checkpoints", type=int, default=4)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--family-alpha", type=float, default=0.05)
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    args = parser.parse_args()
    if (args.max_seeds, args.initial_seeds, args.batch_size) != (1000, 200, 200):
        parser.error("v5 extension is frozen at looks 200, 400, 600, 800, and 1000")
    if args.checkpoints < 1 or args.timesteps < args.checkpoints:
        parser.error("invalid checkpoint settings")
    if not 0.0 < args.family_alpha < 1.0:
        parser.error("family-alpha must be in (0, 1)")
    return args


def read_selected(reference_dir: Path) -> dict[tuple[str, str], str]:
    payload = json.loads((reference_dir / "summary.json").read_text(encoding="utf-8"))
    return {
        (env_id, algorithm): payload["summary"][f"{env_id}:{algorithm}"]["selected_config"]
        for env_id in ENVIRONMENTS
        for algorithm in ALGORITHMS
    }


def protocol(args: argparse.Namespace) -> ProtocolConfig:
    return ProtocolConfig(
        alpha=args.family_alpha / (len(ENVIRONMENTS) * 3),
        practical_margin=args.practical_margin,
        initial_seeds=args.initial_seeds,
        batch_size=args.batch_size,
        max_seeds=args.max_seeds,
        target_width=args.target_width,
        interval_method="hoeffding_unpaired",
        bootstrap_resamples=1000,
    )


def main() -> None:
    args = parse_args()
    selected = read_selected(args.reference_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = [args.timesteps * i // args.checkpoints for i in range(1, args.checkpoints + 1)]
    values = {(env_id, algorithm): [] for env_id in ENVIRONMENTS for algorithm in ALGORITHMS}
    records: list[dict] = []
    traces: list[dict] = []
    for batch_end in range(args.initial_seeds, args.max_seeds + 1, args.batch_size):
        batch_start = batch_end - args.batch_size
        for seed_offset in range(batch_start, batch_end):
            train_seed = SEED_BASE + seed_offset
            if not SEED_BASE <= train_seed < SEED_LIMIT:
                raise RuntimeError(f"seed outside frozen range: {train_seed}")
            for env_id in ENVIRONMENTS:
                for algorithm in ALGORITHMS:
                    config_id = selected[(env_id, algorithm)]
                    result = train_curve(
                        env_id,
                        algorithm,
                        train_seed,
                        CONFIGS[config_id],
                        checkpoints,
                        args.eval_episodes,
                    )
                    values[(env_id, algorithm)].append(result["metric_normalized"])
                    records.append({
                        "env_id": env_id,
                        "algorithm": algorithm,
                        "config_id": config_id,
                        "split": "extension_test",
                        "seed": seed_offset,
                        "train_seed": train_seed,
                        "evaluation_seed_base": result["evaluation_seed_base"],
                        "metric_normalized": result["metric_normalized"],
                        "metric_raw": result["metric_raw"],
                        "runtime_seconds": result["runtime_seconds"],
                        "status": "ok",
                    })
        cfg = protocol(args)
        decisions = {
            f"{env_id}:{algorithm_a}_vs_{algorithm_b}": sequential_decision(
                values[(env_id, algorithm_a)], values[(env_id, algorithm_b)], cfg
            )
            for env_id in ENVIRONMENTS
            for algorithm_a, algorithm_b in combinations(ALGORITHMS, 2)
        }
        traces.append({"n": batch_end, "decisions": decisions})

    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    try:
        sb3_version = importlib.metadata.version("stable-baselines3")
    except importlib.metadata.PackageNotFoundError:
        sb3_version = "unknown"
    metadata = {
        "status": "v5_post_v4_resolution_cost_diagnostic",
        "warning": "Post-v4 same-machine diagnostic; not confirmatory and not external reproducibility.",
        "reference_dir": str(args.reference_dir),
        "environment_ids": list(ENVIRONMENTS),
        "algorithm_ids": list(ALGORITHMS),
        "selected_configurations": {f"{env_id}:{algorithm}": config_id for (env_id, algorithm), config_id in selected.items()},
        "run_config": {
            "max_seeds": args.max_seeds,
            "initial_seeds": args.initial_seeds,
            "batch_size": args.batch_size,
            "timesteps": args.timesteps,
            "checkpoints": args.checkpoints,
            "checkpoints_resolved": checkpoints,
            "eval_episodes": args.eval_episodes,
            "family_alpha": args.family_alpha,
            "comparison_alpha": args.family_alpha / (len(ENVIRONMENTS) * 3),
            "practical_margin": args.practical_margin,
            "target_width": args.target_width,
            "interval_method": "hoeffding_unpaired",
            "test_seed_range": "30400-31399",
            "execution_mode": "shared_batches_at_200_400_600_800_1000",
        },
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "gymnasium": gym.__version__,
        "stable_baselines3": sb3_version,
        "mps_available": bool(torch.backends.mps.is_available()),
        "script_sha256": script_hash,
        "stop_traces": traces,
        "interpretation": {
            "scope": "post-v4 new seeds, frozen v3-selected procedures, observed resolution cost",
            "not_supported": ["universal seed requirements", "general algorithm ranking", "prospective power", "external reproducibility"],
        },
    }
    fields = ["env_id", "algorithm", "config_id", "split", "seed", "train_seed", "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status"]
    with (args.output_dir / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    (args.output_dir / "run_config.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "summary.json").write_text(json.dumps({"metadata": metadata, "metrics": {f"{e}:{a}": v for (e, a), v in values.items()}}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": metadata["status"], "rows": len(records), "seed_range": "30400-31399", "output_dir": str(args.output_dir)}))


if __name__ == "__main__":
    main()

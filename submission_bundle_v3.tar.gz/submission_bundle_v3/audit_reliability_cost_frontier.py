#!/usr/bin/env python3
"""Audit the data-derived reliability--cost frontier."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    test_rows = [row for row in rows if row["split"] == "test" and row["status"] == "ok"]
    payload = json.loads((ROOT / "RELIABILITY_COST_FRONTIER_V3.json").read_text(encoding="utf-8"))
    frontier = payload.get("looks", [])
    expected_total = sum(float(row["runtime_seconds"]) for row in test_rows)
    checks = {
        "status": payload.get("status") == "audited_reliability_cost_frontier",
        "row_count": len(test_rows) == 300,
        "look_count": len(frontier) == 4,
        "look_sizes": [row.get("seeds_per_algorithm") for row in frontier] == [5, 10, 15, 20],
        "family_rows": [row.get("family_test_rows") for row in frontier] == [75, 150, 225, 300],
        "runtime_final_matches_raw": math.isclose(frontier[-1]["family_runtime_seconds"], expected_total, rel_tol=0.0, abs_tol=1e-10),
        "radius_nonincreasing": all(a["radius_sum"] >= b["radius_sum"] for a, b in zip(frontier, frontier[1:])),
        "width_target_unreachable": all(row["minimum_clipped_width"] > payload["target_width"] for row in frontier),
        "margin_unreachable": all(row["largest_possible_lower_endpoint"] <= payload["practical_margin"] for row in frontier),
    }
    ok = all(checks.values())
    print(json.dumps({"status": "PASS" if ok else "FAIL", "checks": checks}, indent=2))
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

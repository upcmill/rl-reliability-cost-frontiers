#!/usr/bin/env python3
"""Generate a descriptive runtime-cost table from the sealed v3 CSV."""

from __future__ import annotations

import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "sb3_formal_v3/raw_seed_metrics.csv"
OUTPUT_JSON = ROOT / "RUNTIME_COST_TABLE_V3.json"
OUTPUT_MD = ROOT / "RUNTIME_COST_TABLE_V3.md"


def summarize(values: list[float]) -> dict[str, float | int]:
    if not values:
        raise ValueError("cannot summarize an empty group")
    return {
        "n": len(values),
        "total_seconds": sum(values),
        "mean_seconds": statistics.mean(values),
        "sample_sd_seconds": statistics.stdev(values) if len(values) > 1 else 0.0,
        "median_seconds": statistics.median(values),
        "minimum_seconds": min(values),
        "maximum_seconds": max(values),
    }


def build() -> dict[str, object]:
    with INPUT.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    test_rows = [row for row in rows if row["split"] == "test" and row["status"] == "ok"]
    if len(test_rows) != 300:
        raise ValueError(f"expected 300 successful v3 test rows, found {len(test_rows)}")

    by_cell: dict[tuple[str, str], list[float]] = defaultdict(list)
    by_algorithm: dict[str, list[float]] = defaultdict(list)
    by_environment: dict[str, list[float]] = defaultdict(list)
    for row in test_rows:
        seconds = float(row["runtime_seconds"])
        key = (row["env_id"], row["algorithm"])
        by_cell[key].append(seconds)
        by_algorithm[row["algorithm"]].append(seconds)
        by_environment[row["env_id"]].append(seconds)

    cell_rows = [
        {"env_id": env_id, "algorithm": algorithm, **summarize(values)}
        for (env_id, algorithm), values in sorted(by_cell.items())
    ]
    algorithm_rows = [
        {"algorithm": algorithm, **summarize(values)}
        for algorithm, values in sorted(by_algorithm.items())
    ]
    environment_rows = [
        {"env_id": env_id, **summarize(values)}
        for env_id, values in sorted(by_environment.items())
    ]
    payload = {
        "status": "descriptive_runtime_cost_only",
        "warning": (
            "Wall-clock values describe this Apple Silicon CPU run and are not "
            "cross-hardware compute-efficiency evidence."
        ),
        "source": "sb3_formal_v3/raw_seed_metrics.csv",
        "split": "test",
        "unit": "one selected-configuration training seed",
        "rows": len(test_rows),
        "cell_summaries": cell_rows,
        "algorithm_summaries": algorithm_rows,
        "environment_summaries": environment_rows,
        "total_seconds": sum(float(row["runtime_seconds"]) for row in test_rows),
    }
    return payload


def render(payload: dict[str, object]) -> str:
    lines = [
        "# v3 Runtime Cost Table",
        "",
        "This table is descriptive execution accounting for the selected v3",
        "test rows. Runtime is wall-clock time on the recorded Apple Silicon CPU",
        "environment. It is not a cross-hardware benchmark, a compute-efficiency",
        "claim, or evidence that one algorithm is generally cheaper.",
        "",
        f"- Source: `{payload['source']}`",
        f"- Unit: `{payload['unit']}`",
        f"- Successful test rows: `{payload['rows']}`",
        f"- Total recorded test runtime: `{payload['total_seconds'] / 3600:.3f}` hours",
        "",
        "## Algorithm-level summaries",
        "",
        "| Algorithm | n | Total hours | Mean seconds | Sample SD | Median seconds | Min | Max |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in payload["algorithm_summaries"]:
        lines.append(
            f"| {row['algorithm']} | {row['n']} | {row['total_seconds'] / 3600:.3f} | "
            f"{row['mean_seconds']:.3f} | {row['sample_sd_seconds']:.3f} | "
            f"{row['median_seconds']:.3f} | {row['minimum_seconds']:.3f} | {row['maximum_seconds']:.3f} |"
        )
    lines.extend([
        "",
        "## Environment-by-algorithm summaries",
        "",
        "| Environment | Algorithm | n | Total hours | Mean seconds | Sample SD | Median seconds |",
        "|---|---|---:|---:|---:|---:|---:|",
    ])
    for row in payload["cell_summaries"]:
        lines.append(
            f"| {row['env_id']} | {row['algorithm']} | {row['n']} | "
            f"{row['total_seconds'] / 3600:.3f} | {row['mean_seconds']:.3f} | "
            f"{row['sample_sd_seconds']:.3f} | {row['median_seconds']:.3f} |"
        )
    lines.extend([
        "",
        "The total covers only selected test-seed training runs. Validation runs,",
        "extensions, and evaluation episode time are not combined into this table.",
        "The values should be used to reproduce this execution record, not to",
        "rank algorithms by hardware-independent efficiency.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    payload = build()
    OUTPUT_JSON.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    OUTPUT_MD.write_text(render(payload), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "rows": payload["rows"], "total_seconds": payload["total_seconds"]}, indent=2))


if __name__ == "__main__":
    main()

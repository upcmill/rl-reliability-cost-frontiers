import unittest

from adaptive_spending_diagnostic import schedule_candidates


class AdaptiveSpendingDiagnosticTests(unittest.TestCase):
    def test_all_candidate_schedules_use_the_same_budget(self):
        schedules = schedule_candidates([50, 100, 150, 200], 0.05)
        self.assertEqual(set(schedules), {"power_series", "front_loaded", "late_loaded", "minimax"})
        for schedule in schedules.values():
            self.assertAlmostEqual(sum(schedule), 0.05, places=12)
            self.assertTrue(all(0.0 < value < 0.05 for value in schedule))

    def test_schedule_generation_is_deterministic(self):
        self.assertEqual(
            schedule_candidates([50, 100, 150, 200], 0.05),
            schedule_candidates([50, 100, 150, 200], 0.05),
        )


if __name__ == "__main__":
    unittest.main()

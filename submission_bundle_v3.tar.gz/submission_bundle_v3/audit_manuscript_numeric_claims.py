#!/usr/bin/env python3
"""Cross-check high-risk manuscript numbers against audited artifacts."""

from __future__ import annotations

import json
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent


def load_json(relative: str) -> dict:
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def has_all(text: str, phrases: tuple[str, ...]) -> bool:
    return all(phrase in text for phrase in phrases)


def docx_text(relative: str) -> str:
    with ZipFile(ROOT / relative) as archive:
        return archive.read("word/document.xml").decode("utf-8")


def build_payload() -> dict:
    full = (ROOT / "MANUSCRIPT_DRAFT_V3.md").read_text(encoding="utf-8")
    core = (ROOT / "MANUSCRIPT_SUBMISSION_CORE_EN.md").read_text(encoding="utf-8")
    primary = load_json("sb3_formal_v3/familywise_cost_summary.json")
    raw_rows = (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").read_text(encoding="utf-8").splitlines()
    validation_cost = load_json("VALIDATION_TUNING_COST_V3.json")
    runtime_cost = load_json("RUNTIME_COST_TABLE_V3.json")
    frontier = load_json("RELIABILITY_COST_FRONTIER_V3.json")
    budget = load_json("BUDGET_FEASIBILITY_AUDIT_V3.json")
    v4 = load_json("V4_EXTENSION_AUDIT.json")
    v5 = load_json("V5_EXTENSION_AUDIT.json")
    external = load_json("复跑结果/EXTERNAL_RERUN_AUDIT.json")
    word_en = docx_text("MANUSCRIPT_MACHINE_LEARNING_EN.docx")
    word_zh = docx_text("MANUSCRIPT_MACHINE_LEARNING_ZH.docx")

    primary_rows = primary.get("rows", [])
    external_summary = external.get("difference_summary", {})
    checks = {
        "primary_row_and_decision_counts": (
            len(raw_rows) - 1 == 600
            and len(primary_rows) == 15
            and all(row.get("n") == 20 for row in primary_rows)
            and all(row.get("decision") == "max_budget_inconclusive" for row in primary_rows)
        ),
        "primary_counts_appear_in_full_and_core": has_all(
            full,
            ("600 rows", "300 validation rows", "300 sealed-test rows", "15/15"),
        ) and has_all(core, ("600 rows", "300 validation rows", "300 sealed-test rows", "15/15")),
        "formal_budget_values_appear_in_both_manuscripts": has_all(
            full + core,
            ("1.0178588242", "6,071", "8,289", "0.05/15"),
        ),
        "frontier_matches_primary_look_schedule": (
            [row["seeds_per_algorithm"] for row in frontier.get("looks", [])]
            == [5, 10, 15, 20]
            and frontier.get("looks", [])[-1].get("family_test_rows") == 300
            and "0.058429" in full
            and "0.058429" in core
        ),
        "runtime_values_match_manuscript": (
            round(float(validation_cost.get("total_seconds", 0.0)), 3) == 208.671
            and round(float(runtime_cost.get("total_seconds", 0.0)), 3) == 210.345
            and "208.671" in full
            and "210.345" in full
            and "208.671" in core
            and "210.345" in core
        ),
        "v4_counts_and_scope_match": (
            v4.get("rows") == 6000
            and v4.get("cell_count") == 15
            and v4.get("decision_counts") == {"a_superior": 1, "max_budget_inconclusive": 14}
            and has_all(full, ("6,000 raw rows", "14 other comparisons remain unresolved at 400"))
            and has_all(core, ("prospective v4 extension", "14 other comparisons remain unresolved at 400"))
        ),
        "v5_counts_and_scope_match": (
            v5.get("rows") == 15000
            and v5.get("cell_count") == 15
            and v5.get("decision_counts") == {"max_budget_inconclusive": 11, "a_superior": 3, "b_superior": 1}
            and has_all(full, ("15,000 raw rows", "Four comparisons resolved at 200 or 800", "eleven remained unresolved at 1,000"))
            and has_all(core, ("v5 extension", "Four comparisons resolved at 200 or 800", "eleven remained unresolved at 1,000"))
        ),
        "external_rerun_difference_summary_matches": (
            external.get("status") == "PASS"
            and external.get("rows", {}).get("row_count") == 600
            and external_summary.get("cells") == 15
            and external_summary.get("zero_difference_cells") == 14
            and external_summary.get("nonzero_difference_cells") == 1
            and round(float(external_summary.get("maximum_mean_absolute_metric_difference", 0.0)), 5) == 0.00105
            and round(float(external_summary.get("maximum_absolute_metric_difference", 0.0)), 5) == 0.01640
            and "0.00105" in full
            and "0.01640" in full
            and "0.00105" in core
            and "0.01640" in core
        ),
        "prestudy_budget_audit_values_match": (
            budget.get("audit_conclusion", {}).get("all_v3_looks_cannot_reach_superiority") is True
            and budget.get("audit_conclusion", {}).get("all_v3_looks_cannot_reach_precision") is True
            and budget.get("audit_conclusion", {}).get("target_width_thresholds") == [6071, 7180, 7829, 8289]
        ),
        "english_word_numeric_anchors_match": has_all(
            word_en,
            ("1.0178588242", "6,071", "8,289", "208.671", "210.345", "6,000", "15,000", "0.00105", "0.01640"),
        ),
        "chinese_word_numeric_anchors_match": has_all(
            word_zh,
            ("1.0178588242", "6,071", "8,289", "208.671", "210.345", "6,000", "15000", "0.00105", "0.01640"),
        ),
    }
    return {
        "schema": "manuscript-numeric-claim-audit-v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "sources": [
            "sb3_formal_v3/raw_seed_metrics.csv",
            "sb3_formal_v3/familywise_cost_summary.json",
            "VALIDATION_TUNING_COST_V3.json",
            "RUNTIME_COST_TABLE_V3.json",
            "RELIABILITY_COST_FRONTIER_V3.json",
            "BUDGET_FEASIBILITY_AUDIT_V3.json",
            "V4_EXTENSION_AUDIT.json",
            "V5_EXTENSION_AUDIT.json",
            "复跑结果/EXTERNAL_RERUN_AUDIT.json",
        ],
        "interpretation": (
            "This audit checks selected numerical anchors only. It does not "
            "validate the probabilistic assumptions, literature novelty, or "
            "the scientific generality of the claims."
        ),
    }


def render(payload: dict) -> str:
    lines = [
        "# Manuscript Numeric Claim Audit",
        "",
        "This audit cross-checks high-risk numbers in the full and concise English",
        "manuscripts against the stored CSV/JSON artifacts. It does not replace",
        "the statistical proof or external review.",
        "",
        f"- Status: **{payload['status']}**",
        "",
        "| Check | Result |",
        "|---|:---:|",
    ]
    for name, result in payload["checks"].items():
        lines.append(f"| `{name}` | {'PASS' if result else 'FAIL'} |")
    lines.extend(["", payload["interpretation"], ""])
    return "\n".join(lines)


def main() -> None:
    payload = build_payload()
    (ROOT / "MANUSCRIPT_NUMERIC_CLAIM_AUDIT.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "MANUSCRIPT_NUMERIC_CLAIM_AUDIT.md").write_text(
        render(payload), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))
    raise SystemExit(0 if payload["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()

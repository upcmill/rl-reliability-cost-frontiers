#!/usr/bin/env python3
"""Execute SB3 test evaluation in batches and stop when the protocol stops.

Unlike ``sb3_pilot.py`` (which intentionally replays a complete sealed test
set), this runner trains and evaluates both algorithms batch by batch. It is
the path used to measure actual test-seed and runtime savings.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
from itertools import combinations
from pathlib import Path

import gymnasium as gym
import torch

from pilot_protocol import ProtocolConfig, sequential_decision
from sb3_pilot import ADDITIONAL_ENV_IDS, ALGORITHMS, DEFAULT_ENV_IDS, QUEUE_ENV_ID, train_curve


def lock_resolved_decisions(
    decisions: dict[str, dict], locked: dict[str, dict], n: int
) -> dict[str, dict]:
    """Keep terminal decisions fixed while unresolved pairs receive more data."""
    current = {}
    for comparison, decision in decisions.items():
        if comparison in locked:
            current[comparison] = locked[comparison]
            continue
        if decision["decision"] != "max_budget_inconclusive":
            terminal = {**decision, "locked": True, "locked_at": n}
            locked[comparison] = terminal
            current[comparison] = terminal
        else:
            current[comparison] = {**decision, "locked": False}
    return current


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validation-seeds", type=int, default=5)
    parser.add_argument("--test-seeds", type=int, default=20)
    parser.add_argument("--initial-test-seeds", type=int, default=5)
    parser.add_argument("--test-batch-size", type=int, default=5)
    parser.add_argument("--timesteps", type=int, default=4096)
    parser.add_argument("--checkpoints", type=int, default=4)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--family-alpha", type=float, default=0.05)
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    parser.add_argument(
        "--interval-method",
        choices=("normal", "bootstrap", "empirical_bernstein", "hoeffding", "hoeffding_unpaired"),
        default="hoeffding_unpaired",
    )
    parser.add_argument("--bootstrap-resamples", type=int, default=1000)
    parser.add_argument("--environment-ids", default=",".join(DEFAULT_ENV_IDS))
    parser.add_argument("--output-dir", default="sb3_sequential_results")
    args = parser.parse_args()
    environment_ids = tuple(item.strip() for item in args.environment_ids.split(",") if item.strip())
    if not environment_ids:
        parser.error("--environment-ids must contain at least one environment ID")
    unsupported = sorted(set(environment_ids) - set((*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)))
    if unsupported:
        parser.error(f"unsupported environment IDs: {', '.join(unsupported)}")
    if args.validation_seeds < 2:
        parser.error("--validation-seeds must be at least 2")
    if not 1 <= args.initial_test_seeds <= args.test_seeds:
        parser.error("--initial-test-seeds must be between 1 and --test-seeds")
    if args.test_batch_size < 1:
        parser.error("--test-batch-size must be positive")
    if args.checkpoints < 1 or args.timesteps < args.checkpoints:
        parser.error("--timesteps must be at least --checkpoints")
    if not 0.0 < args.family_alpha < 1.0:
        parser.error("--family-alpha must be in (0, 1)")
    if not 0.0 <= args.practical_margin <= 1.0:
        parser.error("--practical-margin must be in [0, 1]")
    if not 0.0 < args.target_width <= 2.0:
        parser.error("--target-width must be in (0, 2]")
    args.environment_ids_resolved = environment_ids
    pair_count = len(ALGORITHMS) * (len(ALGORITHMS) - 1) // 2
    args.comparison_count = len(environment_ids) * pair_count
    args.comparison_alpha = args.family_alpha / args.comparison_count
    return args


def main() -> None:
    args = parse_args()
    environment_ids = args.environment_ids_resolved
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = [args.timesteps * i // args.checkpoints for i in range(1, args.checkpoints + 1)]
    configs = {
        "default": {"learning_rate": 3e-4, "batch_size": 64, "n_steps": 256, "buffer_size": 5000, "learning_starts": 100},
        "small_lr": {"learning_rate": 1e-4, "batch_size": 64, "n_steps": 256, "buffer_size": 5000, "learning_starts": 100},
    }
    records = []
    summary = {}
    comparisons = []
    protocol_kwargs = {
        "alpha": args.comparison_alpha,
        "practical_margin": args.practical_margin,
        "initial_seeds": args.initial_test_seeds,
        "batch_size": args.test_batch_size,
        "max_seeds": args.test_seeds,
        "target_width": args.target_width,
        "interval_method": args.interval_method,
        "bootstrap_resamples": args.bootstrap_resamples,
    }

    for env_id in environment_ids:
        validation = {}
        selected = {}
        for algorithm in ALGORITHMS:
            validation[algorithm] = {}
            for config_id, config in configs.items():
                values = []
                for seed in range(args.validation_seeds):
                    train_seed = 10_000 + seed
                    result = train_curve(env_id, algorithm, train_seed, config, checkpoints, args.eval_episodes)
                    values.append(result["metric_normalized"])
                    records.append({"env_id": env_id, "algorithm": algorithm, "config_id": config_id, "split": "validation", "seed": seed, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})
                validation[algorithm][config_id] = values
            selected[algorithm] = max(validation[algorithm], key=lambda key: sum(validation[algorithm][key]) / len(validation[algorithm][key]))

        test_metrics = {algorithm: [] for algorithm in ALGORITHMS}
        curves = {algorithm: [] for algorithm in ALGORITHMS}
        stop_trace = []
        final_decision = None
        locked_decisions = {}
        for batch_start in range(0, args.test_seeds, args.test_batch_size):
            batch_end = min(args.test_seeds, batch_start + args.test_batch_size)
            for seed in range(batch_start, batch_end):
                train_seed = 20_000 + seed
                for algorithm in ALGORITHMS:
                    config_id = selected[algorithm]
                    result = train_curve(env_id, algorithm, train_seed, configs[config_id], checkpoints, args.eval_episodes)
                    test_metrics[algorithm].append(result["metric_normalized"])
                    curves[algorithm].append({"seed": seed, "train_seed": train_seed, **result})
                    records.append({"env_id": env_id, "algorithm": algorithm, "config_id": config_id, "split": "test", "seed": seed, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})

            look_config = ProtocolConfig(**{**protocol_kwargs, "max_seeds": batch_end})
            provisional_decisions = {
                f"{algorithm_a}_vs_{algorithm_b}": sequential_decision(
                    test_metrics[algorithm_a], test_metrics[algorithm_b], look_config
                )
                for algorithm_a, algorithm_b in combinations(ALGORITHMS, 2)
            }
            decisions = lock_resolved_decisions(provisional_decisions, locked_decisions, batch_end)
            stop_trace.append({"n": batch_end, "decisions": decisions})
            if len(locked_decisions) == len(provisional_decisions) or batch_end == args.test_seeds:
                final_decision = decisions
                break

        for algorithm in ALGORITHMS:
            summary[f"{env_id}:{algorithm}"] = {
                "selected_config": selected[algorithm],
                "validation": validation[algorithm],
                "test_metrics": test_metrics[algorithm],
                "curves": curves[algorithm],
            }
        comparisons.append({"env_id": env_id, "decisions": final_decision, "stop_trace": stop_trace})

    try:
        sb3_version = importlib.metadata.version("stable-baselines3")
    except importlib.metadata.PackageNotFoundError:
        sb3_version = "unknown"
    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    run_config = vars(args).copy()
    run_config.pop("environment_ids_resolved", None)
    run_config["environment_ids"] = ",".join(environment_ids)
    run_config["checkpoints_resolved"] = checkpoints
    run_config["comparison_alpha"] = args.comparison_alpha
    run_config["execution_mode"] = "actual_sequential_stop"
    payload = {
        "status": "sb3_sequential_pilot_only",
        "warning": "Small CPU pilot; actual batch stopping; no publication claim.",
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "gymnasium": gym.__version__,
        "stable_baselines3": sb3_version,
        "mps_available": bool(torch.backends.mps.is_available()),
        "script_sha256": script_hash,
        "run_config": run_config,
        "candidate_configs": configs,
        "environment_ids": list(environment_ids),
        "algorithm_ids": list(ALGORITHMS),
        "protocol": protocol_kwargs,
        "alpha_scope": {"family_alpha": args.family_alpha, "comparisons": args.comparison_count, "environment_count": len(environment_ids), "algorithm_pair_count": len(ALGORITHMS) * (len(ALGORITHMS) - 1) // 2, "comparison_alpha": args.comparison_alpha},
        "summary": summary,
        "comparisons": comparisons,
    }
    fields = ["env_id", "algorithm", "config_id", "split", "seed", "train_seed", "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status"]
    with (output_dir / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    for filename in ("run_config.json", "summary.json"):
        (output_dir / filename).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

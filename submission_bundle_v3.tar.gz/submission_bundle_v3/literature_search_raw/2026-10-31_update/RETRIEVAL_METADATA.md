# Retrieval Metadata: 2026-10-31 Update

- Retrieval date: `2026-10-31` (Asia/Shanghai)
- Retrieval method: successful `curl -L` request with a 20-second timeout;
  the response returned HTTP 200.
- URL: `https://link.springer.com/journal/10994/submission-guidelines`
- Interpretation: official Springer submission-guidelines page for *Machine
  Learning*. The page was used to recheck the journal identity, article
  submission entry point, Contribution Information Sheet requirement, and Data
  Availability Statement requirement.

This record does not establish current SCI/SCIE indexing, JCR metrics, APC,
or acceptance probability. Those fields still require a current authoritative
check at submission time. The raw response hash is recorded in
`SHA256SUMS.txt`.

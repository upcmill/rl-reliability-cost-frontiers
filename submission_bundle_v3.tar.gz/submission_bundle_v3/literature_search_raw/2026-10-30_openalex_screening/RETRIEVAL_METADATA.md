# OpenAlex Screening Export

- Retrieval date: `2026-10-30` (Asia/Shanghai)
- Endpoint: `https://api.openalex.org/works`
- Export purpose: reproducible discovery and first-pass screening for RL
  evaluation reliability, seed variability, overfitting, nondeterminism, and
  sequential/statistical inference.
- Each query requested `per-page=50`; the complete JSON response is retained.
- The export is a first screener's record. It is not a completed systematic
  review and has no independent second screener yet.

| File | Query or identifier |
|---|---|
| `rl_seed_variability.json` | `reinforcement learning random seeds statistical power` |
| `rl_reproducibility.json` | `deep reinforcement learning reproducibility nondeterminism` |
| `rl_evaluation_overfitting.json` | `reinforcement learning evaluation overfitting test set` |
| `rl_sequential_inference.json` | `reinforcement learning sequential evaluation confidence intervals` |
| `rl_confidence_sequences.json` | `confidence sequences reinforcement learning evaluation` |
| `rl_algorithm_comparison_statistics.json` | `reinforcement learning algorithm comparison statistical tests` |
| `openalex_1912_05663.json` | DOI lookup for `10.48550/arXiv.1912.05663` |
| `openalex_nagarajan_dissertation.json` | DOI lookup for `10.15781/t2ff3mk0s` |
| `arxiv_1912_05663.xml` | `https://export.arxiv.org/api/query?id_list=1912.05663` |
| `arxiv_1912_05663.html` | `https://arxiv.org/abs/1912.05663` |
| `arxiv_2201_08536.xml` | `https://export.arxiv.org/api/query?id_list=2201.08536` |
| `arxiv_2201_08536.html` | `https://arxiv.org/abs/2201.08536` |

`SHA256SUMS.txt` records the byte hashes of all raw responses. Search ranking
was used for discovery only; inclusion decisions require source-level metadata
and substantive comparison.

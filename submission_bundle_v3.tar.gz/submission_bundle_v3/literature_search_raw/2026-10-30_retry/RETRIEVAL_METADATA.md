# Retrieval Metadata

- Retrieval timestamp (UTC): `2026-10-30T10:39:10Z`
- Working directory: project root (the directory containing this metadata file)
- Retrieval method: `curl -sS` with a 30-second timeout; Springer page was
  retrieved with `-L`.

| File | URL | Interpretation |
|---|---|---|
| `arxiv_1809_05676_1804_06893.xml` | `https://export.arxiv.org/api/query?id_list=1809.05676,1804.06893` | Authoritative arXiv API metadata and abstracts for L13 and L14. |
| `arxiv_1809_05676.html` | `https://arxiv.org/abs/1809.05676` | Public abstract page for L14. |
| `arxiv_1804_06893.html` | `https://arxiv.org/abs/1804.06893` | Public abstract page for L13. |
| `springer_machine_learning_submission_guidelines.html` | `https://link.springer.com/journal/10994/submission-guidelines` | Official journal page. It confirms journal identity, hybrid model, scope labels, and submission entry point; it is not treated as proof of SCI indexing, JCR metrics, APC, or every policy field. |
| `crossref_machine_learning.json` | `https://api.crossref.org/journals/0885-6125` | Publisher and ISSN metadata for the journal. |
| `openalex_rl_evaluation_seeds.json` | `https://api.openalex.org/works?search=reinforcement%20learning%20evaluation%20random%20seeds&per-page=25` | Discovery-only search response; no novelty claim is based solely on ranking. |

`SHA256SUMS.txt` records the byte hashes of the raw responses. The files are
archived evidence for this search session and do not replace database exports
or independent screening by a second researcher.

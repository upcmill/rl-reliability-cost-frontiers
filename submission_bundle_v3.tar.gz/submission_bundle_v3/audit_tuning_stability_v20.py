#!/usr/bin/env python3
"""Audit the prospective 20-validation-seed tuning stability extension."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path


EXPECTED_ENVS = {
    "CartPole-v1",
    "Acrobot-v1",
    "MountainCar-v0",
    "Taxi-v4",
    "NonstationaryQueue-v0",
}
EXPECTED_ALGORITHMS = {"PPO", "DQN", "A2C"}
EXPECTED_CONFIGS = {
    "lr3e4_long",
    "lr1e4_long",
    "lr3e4_short",
    "lr1e4_short",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(condition: bool, message: str, failures: list[str]) -> None:
    if not condition:
        failures.append(message)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default="sb3_tuning_stability_v20")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    summary_path = output_dir / "summary.json"
    rows_path = output_dir / "raw_rows.json"
    failures: list[str] = []
    check(summary_path.exists(), "missing summary.json", failures)
    check(rows_path.exists(), "missing raw_rows.json", failures)
    if failures:
        raise SystemExit("; ".join(failures))

    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    rows = json.loads(rows_path.read_text(encoding="utf-8"))
    run_config = summary.get("run_config", {})
    expected_validation_seeds = set(range(11000, 11020))
    expected_test_seed = {32000}
    validation_rows = [row for row in rows if row.get("split") == "validation"]
    test_rows = [row for row in rows if row.get("split") == "diagnostic_test"]

    check(summary.get("status") == "tuning_strength_diagnostic_only",
          "unexpected artifact status", failures)
    check(run_config.get("validation_seeds") == 20,
          "validation_seeds is not 20", failures)
    check(run_config.get("validation_seed_base") == 11000,
          "validation_seed_base is not 11000", failures)
    check(run_config.get("test_seeds") == 1,
          "test_seeds is not 1", failures)
    check(run_config.get("test_seed_base") == 32000,
          "test_seed_base is not 32000", failures)
    check(run_config.get("timesteps") == 4096, "timesteps changed", failures)
    check(run_config.get("checkpoints") == [1024, 2048, 3072, 4096],
          "checkpoint schedule changed", failures)
    check(run_config.get("eval_episodes") == 5,
          "eval_episodes changed", failures)
    check(len(rows) == 1215, "row count is not 1215", failures)
    check(len(validation_rows) == 1200,
          "validation row count is not 1200", failures)
    check(len(test_rows) == 15, "diagnostic test row count is not 15", failures)

    observed_envs = {row.get("env_id") for row in rows}
    observed_algorithms = {row.get("algorithm") for row in rows}
    observed_configs = {row.get("config_id") for row in validation_rows}
    check(observed_envs == EXPECTED_ENVS, "environment set mismatch", failures)
    check(observed_algorithms == EXPECTED_ALGORITHMS,
          "algorithm set mismatch", failures)
    check(observed_configs == EXPECTED_CONFIGS,
          "candidate configuration set mismatch", failures)

    validation_seeds = {row.get("train_seed") for row in validation_rows}
    test_seeds = {row.get("train_seed") for row in test_rows}
    check(validation_seeds == expected_validation_seeds,
          "validation seed range mismatch", failures)
    check(test_seeds == expected_test_seed, "test seed mismatch", failures)
    check(validation_seeds.isdisjoint({10000, 10001, 10002, 10003, 10004}),
          "validation seeds overlap v3", failures)
    check(validation_seeds.isdisjoint(set(range(30000, 30020))),
          "validation seeds overlap prior diagnostic test range", failures)
    check(test_seeds.isdisjoint(set(range(20000, 20020))),
          "diagnostic test seed overlaps v3 test range", failures)
    check(test_seeds.isdisjoint(set(range(30000, 30020))),
          "diagnostic test seed overlaps prior diagnostic range", failures)

    key_counts = Counter(
        (row.get("env_id"), row.get("algorithm"), row.get("config_id"),
         row.get("split"), row.get("train_seed"))
        for row in rows
    )
    check(max(key_counts.values(), default=0) == 1,
          "duplicate row key detected", failures)
    for row in rows:
        value = row.get("metric_normalized")
        check(isinstance(value, (int, float)) and 0.0 <= value <= 1.0,
              f"metric outside [0,1]: {row}", failures)

    cell_counts = Counter((row["env_id"], row["algorithm"], row["config_id"])
                          for row in validation_rows)
    check(set(cell_counts.values()) == {20},
          "not every candidate cell has 20 validation rows", failures)
    test_cell_counts = Counter((row["env_id"], row["algorithm"]) for row in test_rows)
    check(set(test_cell_counts.values()) == {1},
          "not every selected cell has one diagnostic test row", failures)

    selected = summary.get("summary", {})
    check(set(selected) == {f"{env}:{alg}" for env in EXPECTED_ENVS
                            for alg in EXPECTED_ALGORITHMS},
          "summary cell set mismatch", failures)
    recomputed: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for row in validation_rows:
        recomputed[f"{row['env_id']}:{row['algorithm']}"][row["config_id"]].append(
            row["metric_normalized"]
        )
    for cell, payload in selected.items():
        validation = payload.get("validation", {})
        check(set(validation) == EXPECTED_CONFIGS,
              f"candidate summary mismatch in {cell}", failures)
        for config in EXPECTED_CONFIGS:
            values = recomputed[cell][config]
            mean = sum(values) / len(values)
            observed_mean = validation[config].get("mean")
            check(abs(mean - observed_mean) <= 1e-12,
                  f"mean mismatch in {cell}/{config}", failures)

    v3 = json.loads(Path("sb3_formal_v3/run_config.json").read_text(encoding="utf-8"))
    v3_summary = v3["summary"]
    changes = []
    for cell, payload in selected.items():
        old = v3_summary[cell]["selected_config"]
        new = payload["selected_config"]
        if old != new:
            changes.append({"cell": cell, "v3": old, "v20": new})

    source_path = Path("tuning_strength_runner.py")
    report_lines = [
        "# Tuning Stability Extension V1 Report",
        "",
        "This is a supplementary, prospective-within-workspace diagnostic. It does",
        "not amend or pool with the v3 confirmatory family.",
        "",
        "## Frozen execution",
        "",
        f"- Rows: {len(rows)} (1,200 validation candidate rows and 15 one-seed diagnostic rows).",
        "- Validation seeds: 11000--11019; diagnostic test seed: 32000.",
        "- Candidate grid: four configurations, shared by all 15 cells.",
        "- Training: 4,096 steps, four checkpoints, five evaluation episodes.",
        f"- Runner SHA-256: `{sha256(source_path)}`.",
        f"- Output SHA-256 (`summary.json`): `{sha256(summary_path)}`.",
        f"- Output SHA-256 (`raw_rows.json`): `{sha256(rows_path)}`.",
        "",
        "## Selection comparison",
        "",
        f"The 20-seed selection differs from the v3 five-seed selection in "
        f"{len(changes)}/15 cells ({len(changes) / 15:.4f}).",
        "",
        "| Cell | v3 selection | 20-seed selection |",
        "|---|---|---|",
    ]
    for item in changes:
        report_lines.append(f"| {item['cell']} | `{item['v3']}` | `{item['v20']}` |")
    unchanged = [cell for cell in sorted(selected)
                 if cell not in {item["cell"] for item in changes}]
    report_lines.extend([
        "",
        f"The remaining {len(unchanged)} cells retained the v3 selection.",
        "",
        "## Interpretation boundary",
        "",
        "The observed 7/15 change rate indicates selection sensitivity for this",
        "fixed grid and task family. It is an observed-sample diagnostic, not a",
        "population probability, a claim that either grid is optimal, or a",
        "universal recommendation to use twenty validation seeds. The one-seed",
        "diagnostic test rows are bookkeeping only and are not evidence for an",
        "algorithm ranking or a new confirmatory comparison.",
        "",
        "## Audit result",
        "",
        "- PASS: all expected environments, algorithms, candidates, and seed ranges are present.",
        "- PASS: 1,215 unique rows are bounded and candidate means recompute exactly.",
        "- PASS: validation and diagnostic test seeds are disjoint from recorded prior ranges.",
    ])
    if failures:
        report_lines.extend(["", "## Failures", "", *[f"- {item}" for item in failures]])
    else:
        report_lines.append("- PASS: no audit failures.")

    audit = {
        "schema": "tuning-stability-v20-audit-v1",
        "status": "PASS" if not failures else "FAIL",
        "output_dir": str(output_dir),
        "row_count": len(rows),
        "validation_row_count": len(validation_rows),
        "diagnostic_test_row_count": len(test_rows),
        "validation_seed_range": [11000, 11019],
        "diagnostic_test_seed": 32000,
        "selection_change_count": len(changes),
        "selection_change_rate": len(changes) / 15,
        "selection_changes": changes,
        "hashes": {
            "runner": sha256(source_path),
            "summary": sha256(summary_path),
            "raw_rows": sha256(rows_path),
        },
        "failures": failures,
    }
    audit_text = json.dumps(audit, indent=2) + "\n"
    (output_dir / "TUNING_STABILITY_V20_AUDIT.json").write_text(
        audit_text, encoding="utf-8"
    )
    Path("TUNING_STABILITY_V20_AUDIT.json").write_text(
        audit_text, encoding="utf-8"
    )
    Path("TUNING_STABILITY_V20_REPORT.md").write_text(
        "\n".join(report_lines) + "\n", encoding="utf-8"
    )
    print(json.dumps(audit, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

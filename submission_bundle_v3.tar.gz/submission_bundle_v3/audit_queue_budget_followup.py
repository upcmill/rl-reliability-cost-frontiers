#!/usr/bin/env python3
"""Audit the fixed-configuration queue budget follow-up and write its report."""

from __future__ import annotations

import csv
import hashlib
import json
import statistics
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "sb3_queue_budget_followup_v1"
REFERENCE = ROOT / "sb3_formal_v3"
ENV_ID = "NonstationaryQueue-v0"
ALGORITHMS = ("DQN", "A2C")


def main() -> None:
    metadata = json.loads((RUN / "run_config.json").read_text(encoding="utf-8"))
    rows = list(csv.DictReader((RUN / "raw_seed_metrics.csv").open(newline="", encoding="utf-8")))
    assert metadata["status"] == "fixed_configuration_budget_followup"
    assert len(rows) == 800, len(rows)
    assert {row["env_id"] for row in rows} == {ENV_ID}
    assert {row["algorithm"] for row in rows} == set(ALGORITHMS)
    assert all(row["split"] == "test" for row in rows)
    assert all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows)
    assert {int(row["seed"]) for row in rows} == set(range(400))
    assert {int(row["train_seed"]) for row in rows} == set(range(20000, 20400))
    assert all(row["source"] in {"v3_reference", "followup_training"} for row in rows)

    v3_rows = {}
    with (REFERENCE / "raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["env_id"] == ENV_ID and row["split"] == "test" and row["algorithm"] in ALGORITHMS:
                v3_rows[(row["algorithm"], int(row["seed"]))] = row
    for row in rows:
        if row["source"] == "v3_reference":
            key = (row["algorithm"], int(row["seed"]))
            assert key in v3_rows
            assert row["config_id"] == v3_rows[key]["config_id"]
            assert float(row["metric_normalized"]) == float(v3_rows[key]["metric_normalized"])

    values = {
        algorithm: [float(row["metric_normalized"]) for row in rows if row["algorithm"] == algorithm]
        for algorithm in ALGORITHMS
    }
    protocol = ProtocolConfig(
        alpha=0.05 / 15,
        practical_margin=0.05,
        initial_seeds=200,
        batch_size=200,
        max_seeds=1000,
        target_width=0.10,
        interval_method="hoeffding_unpaired",
        bootstrap_resamples=1000,
    )
    recomputed = sequential_decision(values["DQN"], values["A2C"], protocol)
    assert recomputed["decision"] == "a_superior"
    assert recomputed["n"] == 400
    assert recomputed["lower"] > 0.05
    assert metadata["final_decision"] == recomputed
    assert [item["n"] for item in metadata["stop_trace"]] == [200, 400]
    assert metadata["stop_trace"][0]["decision"]["decision"] == "max_budget_inconclusive"
    assert metadata["stop_trace"][1]["decision"]["decision"] == "a_superior"

    summary = {}
    for algorithm in ALGORITHMS:
        metric = values[algorithm]
        summary[algorithm] = {
            "n": len(metric),
            "mean": statistics.fmean(metric),
            "sample_sd": statistics.stdev(metric),
            "median": statistics.median(metric),
            "minimum": min(metric),
            "maximum": max(metric),
            "runtime_seconds": sum(float(row["runtime_seconds"]) for row in rows if row["algorithm"] == algorithm),
        }
    payload = {
        "status": "PASS",
        "run": str(RUN.name),
        "rows": len(rows),
        "prefix_reused_from_v3": True,
        "prefix_rows": 40,
        "selected_configurations": metadata["selected_configurations"],
        "summary": summary,
        "recomputed_decision": recomputed,
        "stop_trace": metadata["stop_trace"],
        "sha256": {
            "raw_seed_metrics.csv": hashlib.sha256((RUN / "raw_seed_metrics.csv").read_bytes()).hexdigest(),
            "run_config.json": hashlib.sha256((RUN / "run_config.json").read_bytes()).hexdigest(),
            "followup_budget_queue.py": hashlib.sha256((ROOT / "followup_budget_queue.py").read_bytes()).hexdigest(),
        },
        "interpretation": {
            "scope": "fixed v3-selected queue configurations and observed seed sequence",
            "status": "post-v3 diagnostic; not confirmatory evidence for a new preregistered family",
            "not_supported": [
                "universal RL seed requirement",
                "general DQN superiority",
                "external reproducibility",
            ],
        },
    }
    (ROOT / "QUEUE_BUDGET_FOLLOWUP_AUDIT.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    decision = recomputed
    report = f"""# Fixed-Configuration Queue Budget Follow-up

This report audits `sb3_queue_budget_followup_v1/`. It is a post-v3
resolution-cost diagnostic and does not replace or amend the frozen v3 primary
analysis.

## Design

- Task: `{ENV_ID}`.
- Algorithms: DQN and A2C only.
- Configurations: v3-selected `lr3e4_short` (DQN) and `lr1e4_short` (A2C),
  frozen before the appended runs.
- Metric: the v3 four-checkpoint normalized learning-curve metric in `[0,1]`.
- Test sequence: v3 seeds 20000--20019 followed by new seeds 20020--20399.
- Looks: total test-seed counts 200 and 400; cap 1000.
- Comparison alpha: `0.05/15 = 0.0033333333333333335`, retaining the v3
  family context.
- Interval: unpaired Hoeffding with the v3 practical margin 0.05 and width
  target 0.10.

The first 20 metrics are copied and byte-checked against the v3 raw CSV. The
remaining 380 seeds were trained in this follow-up. No validation selection or
algorithm-specific retuning was performed.

## Result

| Look (total seeds per algorithm) | Estimate (DQN - A2C) | Lower | Upper | Decision |
|---:|---:|---:|---:|---|
| 200 | {metadata['stop_trace'][0]['decision']['estimate']:.6f} | {metadata['stop_trace'][0]['decision']['lower']:.6f} | {metadata['stop_trace'][0]['decision']['upper']:.6f} | `{metadata['stop_trace'][0]['decision']['decision']}` |
| 400 | {decision['estimate']:.6f} | {decision['lower']:.6f} | {decision['upper']:.6f} | `{decision['decision']}` |

The comparison stopped at 400 total test seeds because the lower endpoint
`{decision['lower']:.6f}` exceeded the practical margin 0.05. Descriptive
metrics over the 400-seed fixed-configuration sequence were:

| Algorithm | Mean | Sample SD | Median | Minimum | Maximum |
|---|---:|---:|---:|---:|---:|
| DQN | {summary['DQN']['mean']:.6f} | {summary['DQN']['sample_sd']:.6f} | {summary['DQN']['median']:.6f} | {summary['DQN']['minimum']:.6f} | {summary['DQN']['maximum']:.6f} |
| A2C | {summary['A2C']['mean']:.6f} | {summary['A2C']['sample_sd']:.6f} | {summary['A2C']['median']:.6f} | {summary['A2C']['minimum']:.6f} | {summary['A2C']['maximum']:.6f} |

## Interpretation boundary

This is evidence that the stated conservative interval can resolve one
controlled queue comparison when the fixed configuration and test budget are
extended to 400 seeds. It is not a universal seed requirement, a general
DQN-versus-A2C ranking, an estimate of power across RL tasks, or an external
reproduction. Because the extension was initiated after v3 results were
observed, it remains a post-v3 diagnostic and must not be presented as a new
confirmatory preregistration.

The machine-readable audit is `QUEUE_BUDGET_FOLLOWUP_AUDIT.json`; raw rows,
source hashes, and the exact runner metadata are in
`sb3_queue_budget_followup_v1/`.
"""
    (ROOT / "QUEUE_BUDGET_FOLLOWUP_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

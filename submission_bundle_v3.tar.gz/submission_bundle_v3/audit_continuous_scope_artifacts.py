#!/usr/bin/env python3
"""Audit MountainCarContinuous-v0 scope-supplement artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "sb3_continuous_mountaincar"


def main() -> None:
    summary = json.loads((OUT / "summary.json").read_text())
    rows = list(csv.DictReader((OUT / "raw_seed_metrics.csv").open()))
    assert len(rows) == 80, len(rows)
    assert sum(row["split"] == "validation" for row in rows) == 40
    assert sum(row["split"] == "test" for row in rows) == 40
    assert set(summary["algorithms"]) == {"PPO", "A2C"}
    assert summary["comparison"]["final"]["PPO_vs_A2C"]["decision"] == "max_budget_inconclusive"
    assert summary["comparison"]["final"]["PPO_vs_A2C"]["n"] == 20
    assert all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows)
    replay = json.loads((OUT / "independent_reproduction.json").read_text())
    assert replay["all_zero_mean_absolute_difference"]
    print("continuous scope audit: PASS")
    print("rows=80 validation=40 test=40 comparison=1 reproduction_diffs=2x0.0")


if __name__ == "__main__":
    main()

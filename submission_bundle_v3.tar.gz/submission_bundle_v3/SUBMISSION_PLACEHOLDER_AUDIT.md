# Submission Placeholder Audit

This inventory reports unresolved author, declaration, archive, venue,
and literature-verification placeholders. It does not replace author
confirmation and does not infer missing metadata.

- Status: `PASS`
- Files scanned: `13`
- `[待补充]` matches: `77`
- `[待核实]` matches: `73`
- English completion markers: `16`

## File-level counts

| File | Placeholder matches |
|---|---:|
| `SUBMISSION_METADATA_TEMPLATE.md` | 13 |
| `AUTHOR_EXTERNAL_INFO_INTAKE_ZH.md` | 34 |
| `PUBLIC_DEPOSITION_README.md` | 1 |
| `CITATION_CFF_TEMPLATE.yml` | 7 |
| `MANUSCRIPT_DRAFT_V3.md` | 18 |
| `MANUSCRIPT_SUBMISSION_CORE_EN.md` | 16 |
| `COVER_LETTER_DRAFT.md` | 4 |
| `MLJ_CONTRIBUTION_INFORMATION_SHEET.md` | 7 |
| `JOURNAL_SELECTION_MEMO.md` | 8 |
| `MANUSCRIPT_MACHINE_LEARNING_EN.docx` | 19 |
| `MANUSCRIPT_MACHINE_LEARNING_CORE_EN.docx` | 18 |
| `MANUSCRIPT_MACHINE_LEARNING_ZH.docx` | 15 |
| `MLJ_CONTRIBUTION_INFORMATION_SHEET.docx` | 6 |

Replace fields only with values confirmed by the authors, institution,
repository, journal, or database record. After replacement, rerun this
audit, `submission_readiness_audit.py`, the Word audits, and the archive
builder. Literature `[待核实]` markers may remain only where the current
evidence is explicitly bounded in the manuscript.

#!/usr/bin/env python3
"""Audit the data-derived v3 runtime-cost summary."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    test_rows = [row for row in rows if row["split"] == "test" and row["status"] == "ok"]
    payload = json.loads((ROOT / "RUNTIME_COST_TABLE_V3.json").read_text(encoding="utf-8"))
    expected_total = sum(float(row["runtime_seconds"]) for row in test_rows)
    total_ok = math.isclose(expected_total, float(payload["total_seconds"]), rel_tol=0.0, abs_tol=1e-10)
    cell_rows = payload["cell_summaries"]
    status = (
        payload.get("status") == "descriptive_runtime_cost_only"
        and payload.get("rows") == 300
        and len(test_rows) == 300
        and len(cell_rows) == 15
        and all(row["n"] == 20 for row in cell_rows)
        and total_ok
    )
    print(json.dumps({"status": "PASS" if status else "FAIL", "rows": len(test_rows), "cells": len(cell_rows), "total_matches_raw": total_ok}, indent=2))
    if not status:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

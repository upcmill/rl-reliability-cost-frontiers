import unittest

from audit_manuscript_numeric_claims import build_payload


class ManuscriptNumericClaimTests(unittest.TestCase):
    def test_authoritative_numeric_anchors_match_manuscripts(self):
        payload = build_payload()
        self.assertEqual(payload["status"], "PASS")
        self.assertTrue(all(payload["checks"].values()))


if __name__ == "__main__":
    unittest.main()

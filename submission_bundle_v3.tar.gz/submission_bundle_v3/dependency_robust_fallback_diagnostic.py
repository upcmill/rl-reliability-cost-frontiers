#!/usr/bin/env python3
"""Evaluate a known-block fallback for the seed-dependence stress model.

The fallback is valid only when observations can be partitioned into known,
independent blocks. It is a supplementary bounded-data diagnostic, not an RL
dependence estimate and not part of the preregistered v3 analysis.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path


BLOCK_SIZES = (1, 2, 5, 10, 20, 50)
LOOKS = (50, 100, 150, 200)
ALPHA = 0.05
PRACTICAL_MARGIN = 0.10
TRUE_DIFFERENCE = 0.0


def wilson(successes: int, trials: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if trials <= 0:
        raise ValueError("trials must be positive")
    p = successes / trials
    denominator = 1.0 + z * z / trials
    center = (p + z * z / (2.0 * trials)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / trials + z * z / (4.0 * trials * trials)) / denominator
    return max(0.0, center - half), min(1.0, center + half)


def block_sequence(rng: random.Random, block_size: int, length: int = 200) -> list[float]:
    if block_size < 1 or length < 1:
        raise ValueError("block_size and length must be positive")
    values: list[float] = []
    while len(values) < length:
        value = float(rng.random() < 0.5)
        values.extend([value] * block_size)
    return values[:length]


def complete_block_means(values: list[float], block_size: int, n: int) -> list[float]:
    """Return means of complete blocks in the first n observations.

    Discarding a partial trailing block preserves the independent-block
    assumption. The resulting effective sample size is explicit in the report.
    """
    if block_size < 1 or n < block_size or len(values) < n:
        raise ValueError("n must contain at least one complete block")
    block_count = n // block_size
    return [
        sum(values[index * block_size : (index + 1) * block_size]) / block_size
        for index in range(block_count)
    ]


def interval(values_a: list[float], values_b: list[float], alpha: float) -> tuple[float, float, float]:
    if not values_a or not values_b:
        raise ValueError("both arms need observations")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must lie in (0,1)")
    estimate = sum(values_a) / len(values_a) - sum(values_b) / len(values_b)
    radius_a = math.sqrt(math.log(4.0 / alpha) / (2.0 * len(values_a)))
    radius_b = math.sqrt(math.log(4.0 / alpha) / (2.0 * len(values_b)))
    radius = radius_a + radius_b
    return estimate, max(-1.0, estimate - radius), min(1.0, estimate + radius)


def alpha_spend(look_index: int) -> float:
    if look_index < 1:
        raise ValueError("look index must be positive")
    return ALPHA * 6.0 / (math.pi**2 * look_index**2)


def evaluate_sequence(values_a: list[float], values_b: list[float], block_size: int | None) -> dict[str, object]:
    covered = True
    false_superiority = False
    terminal_n: int | None = None
    effective_blocks: list[int] = []
    for look_index, n in enumerate(LOOKS, start=1):
        if block_size is None:
            sample_a = values_a[:n]
            sample_b = values_b[:n]
        else:
            sample_a = complete_block_means(values_a, block_size, n)
            sample_b = complete_block_means(values_b, block_size, n)
            effective_blocks.append(len(sample_a))
        estimate, lower, upper = interval(sample_a, sample_b, alpha_spend(look_index))
        covered = covered and lower <= TRUE_DIFFERENCE <= upper
        if terminal_n is None and (lower > PRACTICAL_MARGIN or upper < -PRACTICAL_MARGIN):
            false_superiority = True
            terminal_n = n
    if terminal_n is None:
        terminal_n = LOOKS[-1]
    return {
        "simultaneous_covered": covered,
        "false_superiority": false_superiority,
        "terminal_n": terminal_n,
        "effective_blocks": effective_blocks,
    }


def run_condition(block_size: int, replicates: int, seed: int) -> dict[str, object]:
    if block_size < 1 or replicates < 1:
        raise ValueError("block_size and replicates must be positive")
    rng = random.Random(seed)
    naive_covered = robust_covered = 0
    naive_false = robust_false = 0
    naive_terminal: list[int] = []
    robust_terminal: list[int] = []
    effective_blocks: list[int] = []
    for _ in range(replicates):
        values_a = block_sequence(rng, block_size)
        values_b = block_sequence(rng, block_size)
        naive = evaluate_sequence(values_a, values_b, None)
        robust = evaluate_sequence(values_a, values_b, block_size)
        naive_covered += int(naive["simultaneous_covered"])
        robust_covered += int(robust["simultaneous_covered"])
        naive_false += int(naive["false_superiority"])
        robust_false += int(robust["false_superiority"])
        naive_terminal.append(int(naive["terminal_n"]))
        robust_terminal.append(int(robust["terminal_n"]))
        if robust["effective_blocks"]:
            effective_blocks = list(robust["effective_blocks"])

    naive_coverage_interval = wilson(naive_covered, replicates)
    robust_coverage_interval = wilson(robust_covered, replicates)
    naive_false_interval = wilson(naive_false, replicates)
    robust_false_interval = wilson(robust_false, replicates)
    return {
        "block_size": block_size,
        "replicates": replicates,
        "effective_blocks_by_look": effective_blocks,
        "naive": {
            "simultaneous_coverage": naive_covered / replicates,
            "simultaneous_coverage_wilson_95": {
                "lower": naive_coverage_interval[0],
                "upper": naive_coverage_interval[1],
            },
            "false_superiority_rate": naive_false / replicates,
            "false_superiority_wilson_95": {
                "lower": naive_false_interval[0],
                "upper": naive_false_interval[1],
            },
            "mean_terminal_n": sum(naive_terminal) / replicates,
        },
        "known_block_fallback": {
            "simultaneous_coverage": robust_covered / replicates,
            "simultaneous_coverage_wilson_95": {
                "lower": robust_coverage_interval[0],
                "upper": robust_coverage_interval[1],
            },
            "false_superiority_rate": robust_false / replicates,
            "false_superiority_wilson_95": {
                "lower": robust_false_interval[0],
                "upper": robust_false_interval[1],
            },
            "mean_terminal_n": sum(robust_terminal) / replicates,
        },
    }


def build_report(payload: dict[str, object]) -> str:
    lines = [
        "# Known-Block Dependence Fallback Diagnostic",
        "",
        "This supplementary diagnostic pairs the seed-dependence stress test",
        "with a narrowly scoped mitigation. When the block partition is known",
        "and block values are independent, complete block means are treated as",
        "the bounded observations in the same finite-look Hoeffding construction.",
        "Partial trailing blocks are discarded. The fallback is not valid merely",
        "because observations appear correlated, and this experiment is not an",
        "RL dependence estimate or a change to the preregistered v3 analysis.",
        "",
        f"- Replicates per condition: `{payload['config']['replicates']}`",
        f"- Looks: `{payload['config']['looks']}`; family alpha: `{payload['config']['alpha']}`",
        f"- True difference: `{payload['config']['true_difference']}`; practical margin: `{payload['config']['practical_margin']}`",
        "",
        "## Results",
        "",
        "| Block size | Effective blocks by look | Naive coverage | Fallback coverage | Naive false superiority | Fallback false superiority | Naive mean terminal n | Fallback mean terminal n |",
        "|---:|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in payload["results"]:
        naive = row["naive"]
        fallback = row["known_block_fallback"]
        lines.append(
            f"| {row['block_size']} | {row['effective_blocks_by_look']} | "
            f"{naive['simultaneous_coverage']:.4f} | {fallback['simultaneous_coverage']:.4f} | "
            f"{naive['false_superiority_rate']:.4f} | {fallback['false_superiority_rate']:.4f} | "
            f"{naive['mean_terminal_n']:.2f} | {fallback['mean_terminal_n']:.2f} |"
        )
    lines.extend([
        "",
        "The naive interval keeps counting correlated observations as if they",
        "were independent, so its coverage deteriorates as block size grows.",
        "The fallback restores the intended bounded-data guarantee in this",
        "synthetic model by reducing the sample size to the number of complete",
        "independent blocks; the price is wider intervals and later or absent",
        "decisions. This result supports a diagnostic response to a known block",
        "structure, not a general correction for unknown RL dependence.",
        "",
        "Machine-readable output: `DEPENDENCY_ROBUST_FALLBACK.json`; source:",
        "`dependency_robust_fallback_diagnostic.py`.",
    ])
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replicates", type=int, default=5000)
    parser.add_argument("--output", default="DEPENDENCY_ROBUST_FALLBACK.json")
    parser.add_argument("--report", default="DEPENDENCY_ROBUST_FALLBACK.md")
    args = parser.parse_args()
    if args.replicates < 1:
        parser.error("--replicates must be positive")
    results = [
        run_condition(block_size, args.replicates, 932_000 + index)
        for index, block_size in enumerate(BLOCK_SIZES)
    ]
    payload = {
        "status": "supplementary_known_block_fallback_only",
        "warning": "The fallback requires a known partition into independent blocks; this is not an RL experiment or a general dependence correction.",
        "config": {
            "replicates": args.replicates,
            "block_sizes": list(BLOCK_SIZES),
            "looks": list(LOOKS),
            "alpha": ALPHA,
            "practical_margin": PRACTICAL_MARGIN,
            "true_difference": TRUE_DIFFERENCE,
            "interval_method": "unpaired_hoeffding_on_complete_block_means",
        },
        "results": results,
    }
    Path(args.output).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    Path(args.report).write_text(build_report(payload), encoding="utf-8")
    print(json.dumps({"output": args.output, "report": args.report, "rows": len(results)}, indent=2))


if __name__ == "__main__":
    main()

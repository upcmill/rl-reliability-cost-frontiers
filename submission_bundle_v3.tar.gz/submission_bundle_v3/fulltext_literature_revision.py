"""Apply the source-verified literature revision without changing research data."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def replace_paragraph(text: str, prefix: str, replacement: str) -> str:
    paragraphs = text.split('\n\n')
    matches = [i for i, p in enumerate(paragraphs) if p.startswith(prefix)]
    if len(matches) != 1:
        raise ValueError(f'Expected one literature paragraph: {prefix}')
    paragraphs[matches[0]] = replacement
    return '\n\n'.join(paragraphs)


def revise_main(text: str) -> str:
    text = replace_paragraph(text, '强化学习基准比较受到训练种子',
        '强化学习基准比较受到训练种子、环境随机性、实现细节和评估回合的共同影响，单次运行或小的点估计差异未必能代表新种子上的表现。既有研究已讨论实现与报告问题[L1,L14]、环境和策略泛化[L11,L13]、种子数量与功效[L2,L3]、可靠性指标与不确定性报告[L4,L15]，以及超参数选择后的评价对象[L17]。因此，本文的问题不是是否应当使用多个种子、分离调参与评价或控制多重比较，而是给定这些设计选择后，所用区间在实际预算下能否产生有意义的决定。')
    text = replace_paragraph(text, '本文的具体贡献是把',
        '本文研究一个具体的设计审计问题：在冻结配置、比较族、检查点、归一化范围及决定阈值后，给定的有界区间是否具有产生决定的可能性，实际运行又在何时分辨出差异。两阶段调参评价、多重比较校正及序贯置信推断均有明确前作[L3,L11,L15–L18]，把这些组件并置不构成本文的独立创新。本文的证据包括指定区间构造的非分辨边界、可执行预算审计、受限任务上的停止轨迹及跨平台核查；不把它们表述为新的通用推断原理或最优评估协议。逐项全文比较见表 2 和补充材料 S1。研究提出以下受证据约束的结论：')
    start = text.index('## 2 相关工作\n')
    end = text.index('\n### 2.1 ', start)
    section = (ROOT / 'literature_fulltext/RELATED_WORK_MAIN.md').read_text()
    text = text[:start] + section.strip() + '\n' + text[end:]
    text = replace_paragraph(text, '本文将 RL 基准报告中经常混淆的四类失效模式分开处理。',
        '本文区分四类推断风险：种子不确定性、使用同一批观测进行配置选择与最终评价造成的乐观偏差、重复查看结果引起的错误累积，以及看到数据后扩展比较族。独立的验证/测试训练运行隔离第一阶段选择与第二阶段估计；预先固定检查点并对检查点和比较族分配错误预算，才提供本文所述同时覆盖保证，固定检查点本身并不足够。该设计不能排除对公开任务的长期适配，也不检验新环境上的泛化；这些问题属于 Whiteson 等[L11]和 Zhang 等[L13]讨论的另一评价层级。')
    text = replace_paragraph(text, '本文是评估协议刻画，而不是算法论文。',
        '本文定位为既有统计工具下的设计审计与受限实证研究。相对于 Colas 等的功效分析[L2,L3]，本文推导的是指定区间与阈值下的非分辨区域，不是达到给定功效的样本量；相对于 Patterson 等的两阶段评价讨论[L17]，本文明确条件于已选配置，不估计最优配置表现或整个调参流程的平均表现；相对于 Howard 等的置信序列[L18]及 Maurer–Pontil 经验 Bernstein 界[L19]，本文实施了一项同目标、同错误预算和同数据前缀的事后对照。该分析发现大预算下部分方差自适应构造较窄并改变停止分类，但主研究 20 种子结论不变，有限任务族不足以确立一般效率排序或普遍分辨成本下界。')
    anchor = '该区间回答的是两个冻结后的选定程序在新训练种子下有多大差异，而不是经过无限调优后哪个算法会胜出。'
    addition = ('\n\n这种限定与 Patterson 等[L17]第 3.2 节对两阶段评价的分析一致：新种子可以估计选定配置的性能，'
                '但不能自动传播第一阶段的选择不确定性，也不保证选中的配置是最优。本文未反复独立执行整个调参流程，'
                '因此不把条件区间解释为该流程的无条件性能区间。Whiteson 等[L11]的调参/测试分割涉及不同环境样本；'
                '本文分割的是同一固定任务中的完整训练运行，二者的外推对象不同。')
    if text.count(anchor) != 1:
        raise ValueError('Missing conditional-estimand anchor')
    text = text.replace(anchor, anchor + addition)
    text = replace_paragraph(text, '**相关工作比较。** 既有研究已经提出',
        '**相关工作比较。** 本轮取得 12 篇关键文献的全文并核读与本研究直接相关的方法及定理。新增的同估计对象、同错误预算重分析比较了固定时点经验 Bernstein 界和现代置信序列[L18,L19]。该事后任务族比较发现，部分扩展数据上的方差自适应界更窄并改变停止分类，但主研究 20 种子结论不变；有限任务与生成模型不支持通用效率排序。两阶段调参评价[L17]、族错误控制[L15]及带保证的提前停止[L16,L18]均有前作，本文不以组件并置主张主要创新。定向全文核查不等同于截至检索日的系统综述。')
    references = ('[L17] Patterson, A., Neumann, S., White, M., and White, A. (2024). Empirical Design in Reinforcement Learning. '
             'Journal of Machine Learning Research, 25(318), 1–63. 全文核读版本：arXiv:2304.01315v2（2024-10-29）；JMLR 题录已核验。\n\n'
             '[L18] Howard, S. R., Ramdas, A., McAuliffe, J., and Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. '
             'The Annals of Statistics, 49(2), 1055–1080. DOI: 10.1214/20-AOS1991. 全文核读版本：arXiv:1810.08240v9（2022-08-06）；章节及定理编号按该版本。\n\n')
    text = text.replace('## 附录 A。', references + '## 附录 A。', 1)
    return text


def revise_supplement(text: str) -> str:
    start = text.index('## S1 文献比较')
    end = text.index('\n## S2 ', start)
    section = (ROOT / 'literature_fulltext/COMPARISON_S1.md').read_text()
    return text[:start] + section.strip() + '\n' + text[end:]

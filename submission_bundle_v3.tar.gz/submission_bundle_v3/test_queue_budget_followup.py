import csv
import json
import unittest
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision


ROOT = Path(__file__).resolve().parent


class QueueBudgetFollowupTests(unittest.TestCase):
    def test_fixed_configuration_followup_artifact(self):
        run = ROOT / "sb3_queue_budget_followup_v1"
        metadata = json.loads((run / "run_config.json").read_text(encoding="utf-8"))
        with (run / "raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), 800)
        self.assertEqual({row["algorithm"] for row in rows}, {"DQN", "A2C"})
        self.assertEqual({int(row["seed"]) for row in rows}, set(range(400)))
        self.assertTrue(all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows))

        values = {
            algorithm: [float(row["metric_normalized"]) for row in rows if row["algorithm"] == algorithm]
            for algorithm in ("DQN", "A2C")
        }
        result = sequential_decision(
            values["DQN"],
            values["A2C"],
            ProtocolConfig(
                alpha=0.05 / 15,
                practical_margin=0.05,
                initial_seeds=200,
                batch_size=200,
                max_seeds=1000,
                target_width=0.10,
                interval_method="hoeffding_unpaired",
            ),
        )
        self.assertEqual(result["decision"], "a_superior")
        self.assertEqual(result["n"], 400)
        self.assertGreater(result["lower"], 0.05)
        self.assertEqual(metadata["final_decision"], result)
        self.assertEqual([item["n"] for item in metadata["stop_trace"]], [200, 400])


if __name__ == "__main__":
    unittest.main()

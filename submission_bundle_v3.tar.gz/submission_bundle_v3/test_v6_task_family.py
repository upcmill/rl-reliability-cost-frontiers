import csv
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "sb3_v6_task_family"


class V6TaskFamilyArtifactTests(unittest.TestCase):
    def test_independent_audit_passes(self):
        audit = json.loads((OUTPUT / "V6_TASK_FAMILY_AUDIT.json").read_text(encoding="utf-8"))
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["rows"], 1440)
        self.assertEqual(audit["decision_checks"], 24)

    def test_raw_split_counts_and_final_states(self):
        with (OUTPUT / "raw_seed_metrics.csv").open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), 1440)
        self.assertEqual(sum(row["split"] == "validation" for row in rows), 240)
        self.assertEqual(sum(row["split"] == "extension_test" for row in rows), 1200)
        config = json.loads((OUTPUT / "run_config.json").read_text(encoding="utf-8"))
        final_decisions = config["stop_traces"][-1]["decisions"].values()
        self.assertEqual(len(list(final_decisions)), 6)
        self.assertTrue(all(item["decision"] == "max_budget_inconclusive" for item in config["stop_traces"][-1]["decisions"].values()))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Sixth-review analyses and manuscript reporting updates.

All computations use archived records; this module never starts RL training.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path

from fourth_review_revision import replace_once

ROOT = Path(__file__).resolve().parent
LOOKS = (200, 400, 600, 800, 1000)
BLOCK_SIZE = 50
MAX_LAG = 20
BOOTSTRAPS = 1000
BOOTSTRAP_SEED = 20261105


def read_csv(path: str) -> list[dict[str, str]]:
    with (ROOT / path).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def method_comparison_payload() -> dict:
    summary = json.loads((ROOT / "sb3_v7_confirmation/analysis/summary.json").read_text())
    comparison = json.loads((ROOT / "round5_analysis/V5_V7_COMPARISON.json").read_text())
    rows = []
    for method in summary["method_summaries"]:
        name = method["method"]
        matches = comparison["methods"][name]["category_and_stop_matches"]
        counts = method["decision_counts_at_1000"]
        rows.append({
            "method": name,
            "a_superior": counts["a_superior"],
            "b_superior": counts["b_superior"],
            "precision_only": counts["precision_only"],
            "unresolved": counts["unresolved"],
            "resolved_total": sum(counts[k] for k in ("a_superior", "b_superior", "precision_only")),
            "mean_final_width": method["mean_pair_width_by_look"][-1],
            "counterfactual_prefix": method["counterfactual_deduplicated_shared_runs"],
            "v5_v7_category_stop_matches": matches,
        })
    paths = ["sb3_v7_confirmation/analysis/summary.json", "round5_analysis/V5_V7_COMPARISON.json"]
    return {"rows": rows, "source_sha256": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}}


def load_cell_series(path: str) -> dict[tuple[str, str], tuple[list[int], list[float]]]:
    rows = read_csv(path)
    cells: dict[tuple[str, str], list[tuple[int, float]]] = defaultdict(list)
    for row in rows:
        if row["split"] not in ("extension_test", "v7_confirmation"):
            continue
        cells[row["env_id"], row["algorithm"]].append(
            (int(row["train_seed"]), float(row["metric_normalized"]))
        )
    result = {}
    for key, values in cells.items():
        values.sort()
        seeds = [seed for seed, _ in values]
        assert len(values) == 1000 and seeds == list(range(seeds[0], seeds[0] + 1000))
        result[key] = (seeds, [value for _, value in values])
    assert len(result) == 15
    return result


def acf(values: np.ndarray, max_lag: int) -> np.ndarray | None:
    import numpy as np

    centered = values - values.mean()
    denominator = float(centered @ centered)
    if denominator <= 1e-24:
        return None
    return np.array([1.0] + [float(centered[:-lag] @ centered[lag:] / denominator)
                             for lag in range(1, max_lag + 1)])


def moving_block_bootstrap_acf(values: list[float], rng: np.random.Generator) -> dict:
    import numpy as np

    x = np.asarray(values, dtype=float)
    point = acf(x, MAX_LAG)
    if point is None:
        return {"status": "constant_series", "acf": None, "lower": None, "upper": None}
    block_count = len(x) // BLOCK_SIZE
    starts_max = len(x) - BLOCK_SIZE
    offsets = np.arange(BLOCK_SIZE)
    estimates = np.empty((BOOTSTRAPS, MAX_LAG + 1), dtype=float)
    for first in range(0, BOOTSTRAPS, 100):
        count = min(100, BOOTSTRAPS - first)
        starts = rng.integers(0, starts_max + 1, size=(count, block_count))
        indices = (starts[..., None] + offsets).reshape(count, -1)
        samples = x[indices]
        centered = samples - samples.mean(axis=1, keepdims=True)
        denominator = np.einsum("ij,ij->i", centered, centered)
        estimates[first:first + count, 0] = 1.0
        for lag in range(1, MAX_LAG + 1):
            numerator = np.einsum("ij,ij->i", centered[:, :-lag], centered[:, lag:])
            estimates[first:first + count, lag] = np.divide(
                numerator, denominator, out=np.zeros_like(numerator), where=denominator > 1e-24
            )
    lower, upper = np.quantile(estimates[:, 1:], [0.025, 0.975], axis=0)
    return {"status": "computed", "acf": point[1:].tolist(),
            "lower": lower.tolist(), "upper": upper.tolist()}


def terminal_category(estimate: float, radius: float) -> str:
    lower, upper = max(-1.0, estimate - radius), min(1.0, estimate + radius)
    if lower > 0.05:
        return "a_superior"
    if upper < -0.05:
        return "b_superior"
    if upper - lower <= 0.10:
        return "precision_only"
    return "unresolved"


def block_fallback(cells: dict, comparison_rows: list[dict], dataset: str) -> list[dict]:
    output = []
    by_pair = {(row["environment"], row["comparison"]): row for row in comparison_rows
               if row["dataset"] == dataset and row["method"] == "H-original"}
    by_environment: dict[str, list[str]] = defaultdict(list)
    for env, _ in cells:
        if env not in by_environment:
            available = {algo for candidate, algo in cells if candidate == env}
            by_environment[env] = [algo for algo in ("PPO", "DQN", "A2C") if algo in available]
    alphas = [0.05 / 15 * 6 / (math.pi**2 * k**2) for k in range(1, len(LOOKS) + 1)]
    labels = {"CartPole-v1": "CartPole-v1", "Acrobot-v1": "Acrobot-v1",
              "MountainCar-v0": "MountainCar-v0", "Taxi-v4": "Taxi-v4",
              "NonstationaryQueue-v0": "NonstationaryQueue-v0"}
    for env in sorted(by_environment):
        for index, a in enumerate(by_environment[env]):
            for b in by_environment[env][index + 1:]:
                _, va = cells[env, a]
                _, vb = cells[env, b]
                first_decision = "unresolved"
                stop_blocks = len(LOOKS) * (LOOKS[-1] // BLOCK_SIZE)
                for look_index, (n, alpha) in enumerate(zip(LOOKS, alphas), 1):
                    block_n = n // BLOCK_SIZE
                    means_a = [statistics.fmean(va[i:i + BLOCK_SIZE])
                               for i in range(0, block_n * BLOCK_SIZE, BLOCK_SIZE)]
                    means_b = [statistics.fmean(vb[i:i + BLOCK_SIZE])
                               for i in range(0, block_n * BLOCK_SIZE, BLOCK_SIZE)]
                    estimate = statistics.fmean(means_a) - statistics.fmean(means_b)
                    radius = 2 * math.sqrt(math.log(4 / alpha) / (2 * block_n))
                    category = terminal_category(estimate, radius)
                    if category != "unresolved":
                        first_decision, stop_blocks = category, block_n
                        break
                observed = by_pair[env, f"{a} - {b}"]["terminal"]
                output.append({"environment": env, "comparison": f"{a} - {b}",
                               "observed_terminal": observed,
                               "block_terminal": first_decision,
                               "block_stop_count": stop_blocks,
                               "same_resolved_decision": observed != "unresolved" and observed == first_decision})
    assert len(output) == 15
    return output


def dependence_payload() -> dict:
    import numpy as np

    v5 = load_cell_series("sb3_v5_extension/raw_seed_metrics.csv")
    v7 = load_cell_series("sb3_v7_confirmation/raw_seed_metrics.csv")
    v5_comp = read_csv("sequential_comparison_v1/results_v2/real_pair_decisions.csv")
    v7_comp = read_csv("sb3_v7_confirmation/analysis/intervals.csv")
    # Normalize the per-method comparison records to the common representation.
    v5_comp = [dict(dataset=r["dataset"], method=r["method"], environment=r["environment"],
                    comparison=r["comparison"], terminal=r["terminal"])
               for r in v5_comp]
    v7_comp = [dict(dataset="extension1000", method=r["method"], environment=r["environment"],
                    comparison=r["comparison"], terminal=r["terminal"])
               for r in v7_comp if int(r["n_per_arm"]) == 1000]
    comparison_rows = v5_comp + v7_comp
    rngs = np.random.SeedSequence(BOOTSTRAP_SEED).spawn(90)
    sequences = []
    summaries = {}
    diag_lookup = {}
    i = 0
    for label, cells in (("V5", v5), ("V7", v7)):
        selected = []
        outliers = 0
        lag_count = 0
        for (env, algo), (seeds, values) in sorted(cells.items()):
            diag = moving_block_bootstrap_acf(values, np.random.default_rng(rngs[i]))
            i += 1
            row = {"environment": env, "algorithm": algo, "seed_range": [seeds[0], seeds[-1]], **diag}
            selected.append(row)
            diag_lookup[label, env, algo] = row
            if diag["status"] == "computed":
                lag_count += MAX_LAG
                outliers += sum(lo > 0 or hi < 0 for lo, hi in zip(diag["lower"], diag["upper"]))
        summaries[label] = {
            "series": len(selected), "constant_series": sum(r["status"] == "constant_series" for r in selected),
            "series_with_any_pointwise_band_excluding_zero": sum(
                r["status"] == "computed" and any(lo > 0 or hi < 0 for lo, hi in zip(r["lower"], r["upper"]))
                for r in selected),
            "pointwise_lag_bands_excluding_zero": outliers,
            "computed_lag_bands": lag_count,
        }
        sequences.extend({"sequence": label, **r} for r in selected)
    fallback = {name: block_fallback(cells, comparison_rows, dataset)
                for name, cells, dataset in (("V5", v5, "extension1000"), ("V7", v7, "extension1000"))}
    return {
        "status": "post_hoc_order_and_conditional_known_block_sensitivity",
        "seed_order": "Rows sorted by contiguous train_seed labels; raw records do not contain verified wall-clock ordering.",
        "acf": {"max_lag": MAX_LAG, "block_length": BLOCK_SIZE, "bootstrap_replicates": BOOTSTRAPS,
                "seed": BOOTSTRAP_SEED, "interval": "pointwise percentile 95% moving-block bootstrap; not multiplicity adjusted",
                "sequences": sequences, "summary": summaries},
        "block_fallback": {"block_size": BLOCK_SIZE, "blocks_at_looks": [n // BLOCK_SIZE for n in LOOKS],
                           "looks": list(LOOKS), "comparison_alpha": 0.05 / 15,
                           "spending": "alpha_k = alpha_cmp * 6/(pi^2*k^2)",
                           "margin": 0.05, "target_width": 0.10, "by_sequence": fallback,
                           "resolved_decisions_preserved": {
                               name: sum(r["same_resolved_decision"] for r in rows) for name, rows in fallback.items()},
                           "interpretation": "Conditional sensitivity only; seed-range blocks are not known independent blocks."},
        "source_sha256": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in [
            "sb3_v5_extension/raw_seed_metrics.csv", "sb3_v7_confirmation/raw_seed_metrics.csv",
            "sequential_comparison_v1/results_v2/real_pair_decisions.csv",
            "sb3_v7_confirmation/analysis/intervals.csv"]},
    }


def render_method_table(payload: dict) -> str:
    labels = {"H-original": "原 Hoeffding", "H-finite": "有限归一化 Hoeffding",
              "H-uniform": "均匀支出 Hoeffding", "EB-uniform": "固定时点经验 Bernstein",
              "CS-normal": "正态混合 CS", "CS-EB-stitch": "经验 Bernstein 拼接 CS",
              "CS-EB-gamma": "Gamma 混合经验 Bernstein CS（主设）",
              "CS-EB-gamma-rho0.1": "Gamma 混合经验 Bernstein CS（rho×0.1）",
              "CS-EB-gamma-rho10": "Gamma 混合经验 Bernstein CS（rho×10）"}
    lines = ["**表 S22-3。V7 九种方法的决定、宽度、反事实前缀及 V5/V7 一致数**", "",
             "| 方法 | A 优越 | B 优越 | 仅精度 | 未决 | 总停止 | 平均最终宽度 | 去重前缀运行 | V5/V7 类别及停止点一致 |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in payload["rows"]:
        lines.append(f"| {labels[r['method']]} | {r['a_superior']} | {r['b_superior']} | {r['precision_only']} | "
                     f"{r['unresolved']} | {r['resolved_total']}/15 | {r['mean_final_width']:.4f} | "
                     f"{r['counterfactual_prefix']:,} | {r['v5_v7_category_stop_matches']}/15 |")
    lines.append("")
    return "\n".join(lines)


def seed_ranges() -> dict:
    specs = {
        "Pendulum-v1": "sb3_continuous_pendulum/raw_seed_metrics.csv",
        "MountainCarContinuous-v0": "sb3_continuous_mountaincar/raw_seed_metrics.csv",
        "MaskedCartPole-v1/MaskedAcrobot-v1": "sb3_partial_observable_scope/raw_seed_metrics.csv",
        "CliffWalking-v1/FrozenLake-v1": "sb3_v6_task_family/raw_seed_metrics.csv",
    }
    result = {}
    for name, path in specs.items():
        rows = read_csv(path)
        field = "env_id" if "env_id" in rows[0] else None
        groups = sorted({r[field] for r in rows}) if field else [name]
        for group in groups:
            selected = [r for r in rows if not field or r[field] == group]
            seeds = sorted({int(r["train_seed"]) for r in selected if r["split"] in ("test", "extension_test")})
            result[group] = [seeds[0], seeds[-1]]
    return result


def replace_table_row(text: str, starts: str, replacement: str) -> str:
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith(starts):
            lines[i] = replacement
            return "\n".join(lines) + "\n"
    raise ValueError(f"Table row not found: {starts}")


def revise(main: str, supp: str) -> tuple[str, str]:
    methods = method_comparison_payload()
    dependence = dependence_payload()
    ranges = seed_ranges()
    out = ROOT / "round6_analysis"
    out.mkdir(exist_ok=True)
    (out / "V7_METHOD_SUMMARY.json").write_text(json.dumps(methods, ensure_ascii=False, indent=2) + "\n")
    (out / "V5_V7_DEPENDENCE.json").write_text(json.dumps(dependence, ensure_ascii=False, indent=2) + "\n")
    (out / "SCOPE_SEED_RANGES.json").write_text(json.dumps(ranges, ensure_ascii=False, indent=2) + "\n")
    (out / "REGISTERED_DEPENDENCE_STRESS.json").write_text(
        json.dumps({"seed": 933000, "replicates_per_condition": 5000,
                    "alpha": 0.05 / 15, "margin": 0.05, "looks": [5, 10, 15, 20],
                    "results": registered_stress()}, ensure_ascii=False, indent=2) + "\n")

    # V7 counts are split by inferential category; rho sensitivity is visible at every headline site.
    v7_sentence = ("V7 在 1,000 个种子时，原 Hoeffding 作出 4 项优越性决定、0 项仅精度决定、11 项未决；"
                   "Gamma 混合经验 Bernstein CS（主设 rho）作出 6 项优越性决定、5 项仅精度决定、4 项未决。"
                   "主设下 15 项最终区间均更窄；rho×10 时仅 6/15 项达到停止规则，平均最终宽度为 0.2139，"
                   "故停止计数和宽度均依赖预先冻结的 rho 设置。")
    main = main.replace(
        "每臂 1,000 个种子时 Hoeffding 为 4/15 项达到停止规则，Gamma 混合经验 Bernstein 置信序列为 11/15，且 15 项最终区间均更窄；差异限于当前固定面板，成本比较为反事实前缀核算。",
        "每臂 1,000 个种子时，" + v7_sentence + "差异限于当前固定面板，成本比较为反事实前缀核算。")
    main = main.replace("每臂 1,000 个种子时，V7 在 1,000 个种子时，", "每臂 1,000 个种子时，")
    main = main.replace(
        "8. 查看 V1–V6 后冻结的 V7 新种子验证在固定五任务面板上重现了 V5 中原 Hoeffding 与主设 Gamma CS 的逐比较终止类别及停止检查点；V7 最终区间中 Gamma CS 的 15 项均更窄，11/15 项达到停止规则，原方法为 4/15。成本按反事实共享臂前缀核算，未实际提前终止训练。",
        "8. V7 在固定五任务面板上比较九种预先计算的方法；主设 Gamma 方案与 Hoeffding 分别作出 6 项优越性决定和 4 项优越性决定，另有 5 项仅达到精度规则。Gamma 主设 15 项区间均更窄，而 rho×10 下停止数降至 6/15（该计数指满足停止规则的比较数）。成本为反事实共享臂前缀，训练均已完成。")
    main = main.replace(
        "为检验既有区间宽度差异是否延续，在查看 V1–V6 结果后冻结 V7 方案，并在新种子 31,400–32,399 上执行五任务、三算法共 15,000 次训练。",
        "为检验既有区间宽度差异是否延续，在查看 V1–V6 结果后冻结 V7 方案，并在新种子 31,400–32,399 上执行五任务、三算法共 15,000 次训练。")
    main = main.replace(
        "Gamma CS 达到优越性或精度停止规则的比较为 11/15，Hoeffding 为 4/15；Gamma CS 的未决数为 4，Hoeffding 为 11。",
        "主设 Gamma CS 作出 4 项 A 优越、2 项 B 优越、5 项仅精度决定、4 项未决；原 Hoeffding 为 3、1、0、11 项。故方向性优越决定为 6 对 4，总停止数为 11 对 4，两者不是同一结果类别。rho×0.1 下为 6 项优越、5 项仅精度、4 项未决；rho×10 下为 6 项优越、0 项仅精度、9 项未决。")
    main = main.replace(
        "Gamma CS 的终止计数为 4 项 A 优越、2 项 B 优越、5 项仅精度决定、4 项未决；原 Hoeffding 为 3、1、0、11 项。Gamma CS 和原方法的去重反事实共享训练前缀分别是 11,800 和 14,600 次，但完整 15,000 次训练均已完成，不能称为实际节省。",
        "V7 九种方法的完整决定类别、平均最终宽度、去重反事实前缀及逐方法 V5/V7 一致数见表 S22-3。主设 Gamma CS 作出 4 项 A 优越、2 项 B 优越、5 项仅精度决定、4 项未决；原 Hoeffding为 3、1、0、11 项，故方向性优越决定为 6 对 4、总停止数为 11 对 4。rho×0.1 同为 6 项优越、5 项仅精度、4 项未决；rho×10 为 6 项优越、0 项仅精度、9 项未决。拼接 CS 也为 11/15，固定时点经验 Bernstein 为 10/15。Gamma 主设平均最终宽度为 0.1088，低于拼接 CS 的 0.1364 和固定时点经验 Bernstein 的 0.1473；rho×10 平均宽度为 0.2139。反事实前缀分别为 11,800、13,200、13,600，V7 全部 15,000 次训练均已完成，不代表实测节省。")
    main = main.replace(
        "与 V5 逐项对照，原 Hoeffding 和主设 Gamma CS 各 15 项比较的终止类别及停止检查点均完全一致，但 1,000 种子最终点估计在 15 项上均不同。",
        "与 V5 逐项对照，原 Hoeffding 和主设 Gamma CS 各 15 项比较的终止类别及停止检查点均一致；有限归一化 Hoeffding、均匀支出 Hoeffding、正态混合 CS、Gamma rho×0.1、Gamma rho×10 的一致数分别为 14、12、13、15、12 项。各方法一致数见补充材料表 S22-3。两序列的 1,000 种子最终点估计在 15 项上均不同。")
    main = main.replace(
        "各方法一致数见补充材料表 S22-3。两序列的 1,000 种子最终点估计在 15 项上均不同。",
        "各方法一致数见补充材料表 S22-3。按连续 50 个种子区段重算的条件块回退敏感性中，V7 的 4 项原 Hoeffding 优越决定均未保留；该分块不满足已知独立块的可验证条件，因此不改变本节结论所依赖的臂内独立性假设。两序列的 1,000 种子最终点估计在 15 项上均不同。")
    main = main.replace(
        "这些结果为当前五任务固定面板上的区间宽度差异提供新种子支持；",
        "方差自适应类方法的停止计数接近：固定时点经验 Bernstein 为 10/15，拼接 CS 与 Gamma 主设均为 11/15；Gamma 主设的差异主要体现在更小的平均宽度和反事实前缀。rho×10 的 6/15 停止数显示调节参数敏感性，以上数字均条件于本次固定面板。\n\n这些结果为当前五任务固定面板上的区间宽度差异提供新种子支持；")
    # Abstract, recommendations, evidence map, conclusion and limitations.
    main = main.replace(
        "V7 新种子验证中原方法为 4/15，Gamma 混合经验 Bernstein CS 为 11/15，后者 15 项最终区间均更窄。",
        "V7 新种子验证中，原 Hoeffding 作出 4 项优越性决定；Gamma 主设作出 6 项优越性和 5 项仅精度决定，15 项区间均更窄，而 rho×10 时仅 6/15 项达到停止规则。")
    main = main.replace(
        "V7 的 1,000 新种子验证中，Gamma 混合经验 Bernstein CS 的 15 项最终区间均更窄，11/15 项达到停止规则，而原方法为 4/15；这提示在当前面板上可降低反事实分辨成本。",
        "V7 的 1,000 新种子验证中，固定时点经验 Bernstein、拼接 CS 和 Gamma 主设分别有 10、11、11 项达到停止规则；其中 Gamma 主设有 6 项优越性决定和 5 项仅精度决定，且平均最终宽度与反事实前缀较小。rho×10 时停止数降至 6/15，因此建议比较方差自适应类别，并在测试前冻结调节参数，不据此普遍推荐某一构造。")
    main = main.replace(
        "在 V7 新种子验证中原方法为 4/15，Gamma 混合经验 Bernstein CS 为 11/15，后者 15 项最终区间均更窄。",
        "在 V7 新种子验证中原 Hoeffding 有 4 项方向性优越决定；Gamma 主设有 6 项方向性决定与 5 项仅精度决定，15 项区间均更窄，而 rho×10 仅有 6 项达到停止规则。")
    main = main.replace(
        "V7 重现 V5 中原 Hoeffding 与主设 Gamma CS 的逐项终止类别及停止检查点，且 Gamma CS 的 15 项最终区间均更窄。",
        "V7 中方差自适应方法的停止数为 10–11/15（rho×10 为 6/15）；Gamma 主设由 6 项优越性及 5 项仅精度构成。")
    main = main.replace(
        "| V7 中方差自适应方法的停止数为 10–11/15（rho×10 为 6/15）；Gamma 主设由 6 项优越性及 5 项仅精度构成。 | 第 5.22 节；补充材料 S22 表 S22-1、S22-2；各序列原始 CSV 独立复算。 | 查看 V1–V6 后冻结的固定面板新种子验证；成本为反事实前缀，非新任务族或独立团队复现。 |",
        "| V7 方法对照显示 Gamma 主设为 6 项优越、5 项仅精度；rho×10 为 6 项总停止，块敏感性下原决定均消失。 | 第 5.22 节、补充材料 S22 表 S22-1 至 S22-3、S23。 | 查看 V1–V6 后冻结的固定面板新种子分析；分块为事后条件敏感性，不验证独立性。 |")
    main = main.replace(
        "V5 大预算扩展在 1000 个新种子内观察到 4 个终止决定，而 11/15 单元仍未决。",
        "V5 大预算扩展有 4 项方向性优越决定，11 项仍未决；V7 方法和依赖诊断见第 5.22 节及补充材料 S22–S23。")
    main = main.replace("rho×0.1/×10 的敏感性结果列于补充表 S21-1，不用于选择性报告。",
                        "V3–V5 的 rho×0.1/×10 敏感性结果列于补充表 S21-1；V7 的同类结果见 S22 表 S22-3。")

    # V7 analysis limits and the new order/dependence diagnostic.
    main = main.replace(
        "方案和代码哈希在采集前锁定。该验证是在既有结果启发后开展的新种子验证，不是原始预注册确认，也不是不同团队复现。",
        "方案和代码哈希在采集前锁定。该验证是在既有结果启发后开展的新种子验证，不是原始预注册确认，也不是不同团队复现。")
    dep = dependence["acf"]["summary"]
    dep_sentence = (f"按 train_seed 顺序对 V5 与 V7 各 15 条臂级序列计算滞后 1–20 自相关，并以长度 50 的移动块 bootstrap（{BOOTSTRAPS} 次）给出点态 95% 区间。"
                    f"V5 有 {dep['V5']['series_with_any_pointwise_band_excluding_zero']}/15 条、V7 有 {dep['V7']['series_with_any_pointwise_band_excluding_zero']}/15 条序列至少一个滞后区间不含零；"
                    "该筛查未作多重性校正；共计 600 个滞后点态区间，且 CSV 没有可核验的实际运行时间戳。")
    main = main.replace(
        "该扩展强化了可靠性—成本刻画：增加预算可以分辨部分已披露效应，但成本依赖任务和比较对象，且到 1000 个种子仍有许多单元未决。",
        "该扩展强化了可靠性—成本刻画：增加预算可以分辨部分已披露效应，但成本依赖任务和比较对象，且到 1000 个种子仍有许多单元未决。" + dep_sentence +
        "以预先固定的连续 50 个种子为一块，将 1,000 行折为 20 个块均值并在 200/400/600/800/1000 检查点套用命题 4 回退时，V5 与 V7 的 15 项区间均未触发决定；V5 原有 4 项、V7 原 Hoeffding 原有 4 项决定均未在该条件敏感性分析中保留。块独立性未知，故这不是有效性修复或独立性证明。")
    main = main.replace("块独立性未知，故这不是有效性修复或独立性证明。它不把四个终止结果升级为确认性算法结论。",
                        "块独立性未知，故这不是有效性修复或独立性证明。")
    main = main.replace(
        "Gamma CS 达到优越性或精度停止规则的比较为 11/15",
        "Gamma CS 达到优越性或精度停止规则的比较为 11/15")
    main = main.replace(
        "**不可观测的依赖结构。** 块依赖压力测试和回退诊断使用受控替代数据，不能识别 RL 训练种子、评估回合或环境轨迹的真实依赖结构。",
        "**大预算序列的依赖性。** V5 与 V7 的多滞后自相关筛查及按连续种子段分块的回退敏感性见第 5.17、5.22 节与补充材料 S23。各单元按训练种子排序，原始 CSV 没有实际运行时间戳；点态区间未作多重性校正。长度 50 的分块只是一项条件敏感性分析，不能证明块间独立，且回退后所有比较均未决。因此 V4 决定尚无同类依赖诊断，V5/V7 的原始决定也仍以臂内种子独立假设为条件。块依赖压力测试和回退诊断使用受控替代数据，不能识别 RL 训练种子、评估回合或环境轨迹的真实依赖结构。")

    # Correct table 7/9 seed provenance and the rounding note for table 12.
    main = replace_table_row(main, "| 种子不相交 |", "| 种子范围与任务内唯一性 | 各分析族内训练种子唯一；V4/V5/V7 范围互不重叠。 | V1–V7 运行清单，以及四个范围诊断族的逐任务种子范围；Pendulum 与 MountainCarContinuous 使用相同整数标签但属于不同环境。 |")
    scope = ranges
    main = main.replace(
        "**表 9。范围诊断的任务、算法与测试预算**\n\n| 范围扩展 | 环境/变体数 | 算法 | 每单元测试种子数 | 正文位置 |\n|---|---:|---|---:|---|\n| Pendulum-v1 | 1 | PPO / A2C | 20 | 附录 A；补充材料 S14 |\n| MountainCarContinuous-v0 | 1 | PPO / A2C | 20 | 附录 B；补充材料 S14 |\n| CliffWalking-v1、FrozenLake-v1（4×4、slippery） | 2 | PPO / DQN / A2C | 200 | 附录 C；补充材料 S14 |\n| MaskedCartPole-v1、MaskedAcrobot-v1 | 2 个变体 | PPO / DQN / A2C | 20 | 第 5.13 节；补充材料 S10 |",
        "**表 9。范围诊断的任务、算法与测试预算**\n\n| 范围扩展 | 环境/变体数 | 测试种子范围 | 算法 | 每单元种子数 | 正文位置 |\n|---|---:|---:|---|---:|---|\n| Pendulum-v1 | 1 | 20,000–20,019 | PPO / A2C | 20 | 附录 A；补充材料 S14 |\n| MountainCarContinuous-v0 | 1 | 20,000–20,019 | PPO / A2C | 20 | 附录 B；补充材料 S14 |\n| CliffWalking-v1、FrozenLake-v1（4×4、slippery） | 2 | 41,000–41,199 | PPO / DQN / A2C | 200 | 附录 C；补充材料 S14 |\n| MaskedCartPole-v1、MaskedAcrobot-v1 | 2 个变体 | 50,000–50,019 | PPO / DQN / A2C | 20 | 第 5.13 节；补充材料 S10 |\n\nPendulum 与 MountainCarContinuous 在不同环境中重复使用相同整数种子标签，运行不合并，不能据数字相同推断使用同一随机流。V6 两环境共享 41,000–41,199 标签但任务运行分别初始化。范围诊断种子与主研究整数范围有复用；因此“互不相交”仅指已声明的扩展序列 V4/V5/V7 之间，不是所有独立任务族的全局标签不重叠。")
    main = main.replace(
        "完整种子级记录及字段说明见补充材料 S4。",
        "注：表 10 与表 12 均由补充材料 S4 的全精度产物独立取整；不要用表 10 已显示的六位小数相减来校验表 12 的末位。完整种子级记录及字段说明见补充材料 S4。")
    # Clarify the simulation stress-test design is not transferable to the registered design.
    main = main.replace(
        "该替代模型不估计任何 RL 环境中的真实依赖结构，也不提供相关训练运行的修正方法。原始输出和生成器为 补充材料 S8。",
        "该压力测试使用 alpha=0.05、边际 0.10、检查点 50/100/150/200，与注册主设计的 alpha_cmp=0.05/15、边际 0.05、检查点 5/10/15/20 不同；表中覆盖率和错误决定率不能映射为注册主设计下的覆盖损失。按注册参数另作的相同块生成模型校准见补充材料 S23 表 S23-3；它仍是合成诊断，不估计 RL 中真实依赖。原始输出和生成器为补充材料 S8。")
    main = main.replace(
        "这里的结果只适用于已知独立块模型，不是对未知 RL 依赖的证明或修正。产物为 补充材料 S8。",
        "这里的结果只适用于已知独立块模型，不是对未知 RL 依赖的证明或修正。原压力测试和回退诊断参数不同于注册设计，不能换算成注册设计覆盖损失；注册参数的合成对照见补充材料 S23 表 S23-3。产物为补充材料 S8。")

    # S22 full method reporting and S23 dependence follow-up.
    main = main.replace("补充材料 S22 表 S22-1、S22-2。", "补充材料 S22 表 S22-1 至 S22-3。")
    main = main.replace("Gamma CS 的 15 项最终区间均更窄。 | 第 5.22 节；补充材料 S22 表 S22-1、S22-2；各序列原始 CSV 独立复算。",
                        "主设 Gamma CS 的 15 项最终区间均更窄；rho×10 时停止数为 6/15。 | 第 5.22 节；补充材料 S22 表 S22-1 至 S22-3；各序列原始 CSV 独立复算。")
    supp = supp.replace("章节 S1–S22 与正文引用对应。", "章节 S1–S23 与正文引用对应。")
    supp = supp.replace("V7 新种子诊断见 S22。", "V7 全方法对照见 S22；大预算序列依赖敏感性见 S23。")
    supp = supp.replace("| S22 | V7 新种子验证 | 12 | 主文对应 S 编号/章节 | 已提供；按本节证据边界使用 |",
                        "| S22 | V7 新种子验证 | 13 | 主文对应 S 编号/章节 | 已提供；含九方法与 rho 敏感性 |\n| S23 | V5/V7 顺序与依赖敏感性 | 4 | 主文第 5.17、5.22 节 | 事后、条件敏感性分析；不证明独立性 |")
    supp = supp.replace(
        "## S22 V7 新种子验证\n\n",
        "## S22 V7 新种子验证\n\n")
    supp = supp.replace(
        "输入 CSV 共 15,000 行、15 个单元各 1,000 条；训练种子范围、唯一性、运行状态、所选配置和评估种子派生均经独立审计。",
        render_method_table(methods) + "\n\n注：去重前缀是按方法应用停止规则后的反事实共享臂运行数；V7 实际完成全部 15,000 次运行。V5/V7 一致数要求终止类别及停止检查点均相同。rho×10 下无仅精度决定，停止总数为 6/15。\n\n输入 CSV 共 15,000 行、15 个单元各 1,000 条；训练种子范围、唯一性、运行状态、所选配置和评估种子派生均经独立审计。")
    # Add a counted table in the main V7 section for decision composition.
    main = main.replace(
        "与 V5 逐项对照，原 Hoeffding",
        "九种 V7 方法的完整决定类别、平均最终宽度、反事实前缀及逐方法 V5/V7 一致数见补充材料表 S22-3。\n\n与 V5 逐项对照，原 Hoeffding")
    # Correct statement in S21 that formerly implied V7 sensitivity was included.
    supp = supp.replace(
        "rho×0.1/×10 的敏感性结果完整列于表 S21-1。",
        "表 S21-1 报告 V3–V5 的 rho×0.1/×10 敏感性；V7 对应九方法的敏感性完整列于 S22 表 S22-3。")
    supp = supp.replace(
        "rho 敏感性结果完整列于表 S21-1。",
        "S21 表 S21-1 报告 V3–V5 的 rho 敏感性；V7 对应结果见 S22 表 S22-3。")
    # Add S23 with reproducible tables and limits.
    acf_summary = dependence["acf"]["summary"]
    series_rows = []
    for label in ("V5", "V7"):
        row = acf_summary[label]
        fb = dependence["block_fallback"]["by_sequence"][label]
        series_rows.append([label, row["series"], row["constant_series"],
                            row["series_with_any_pointwise_band_excluding_zero"],
                            f"{row['pointwise_lag_bands_excluding_zero']}/{row['computed_lag_bands']}",
                            sum(x["observed_terminal"] != "unresolved" for x in fb),
                            sum(x["same_resolved_decision"] for x in fb)])
    table1 = ["**表 S23-1。V5/V7 臂级多滞后自相关筛查摘要**", "",
              "| 序列 | 臂级序列数 | 常数序列 | 至少一个点态区间不含零 | 不含零的滞后区间/可计算区间 | 原始 Hoeffding 已决定 | 块回退保留原决定 |",
              "|---|---:|---:|---:|---:|---:|---:|"]
    table1 += ["| " + " | ".join(map(str, row)) + " |" for row in series_rows]
    table1.append("")
    sequence_lines = ["### S23.1 臂级自相关估计与区间", "",
                      f"对每个任务—算法臂按连续 `train_seed` 整数排序；V5 的范围为 30,400–31,399，V7 为 31,400–32,399。对每条长度 1,000 的归一化序列计算滞后 1–{MAX_LAG} 自相关。以长度 {BLOCK_SIZE} 的移动块有放回抽样，运行 {BOOTSTRAPS} 次，报告逐滞后百分位 95% bootstrap 区间。固定种子为 {BOOTSTRAP_SEED}。这些是点态区间，未对 20 个滞后、30 条序列或两轮数据作多重性调整；种子标签顺序也没有可验证的墙钟运行顺序。常数序列的 ACF 未定义。", "",
                      table1[0], "", table1[2], table1[3], *table1[4:],
                      "完整序列级估计及区间位于 `round6_analysis/V5_V7_DEPENDENCE.json`。出现不含零的点态区间只提示该有限有序序列存在局部相关结构；未出现不能证明独立性。移动块 bootstrap 的区间依赖局部平稳近似。", "",
                      "### S23.2 连续 50 个种子区段的块均值敏感性", "",
                      "将每个算法臂中按种子排序的连续 50 个指标合成一个块均值，共 20 块。按主设计的五个检查点 200、400、600、800、1,000 对应使用前 4、8、12、16、20 个完整块；保留每比较 alpha=0.05/15、原可求和支出、实际边际 0.05 和精度阈值 0.10。每个检查点对两算法臂使用相同的块数。", "",
                      "**表 S23-2。块均值回退下的终止决定**", "",
                      "| 序列 | 原 Hoeffding 优越性决定 | 块回退优越性决定 | 原决定获块回退保留 | 块回退仅精度决定 | 块回退未决 |",
                      "|---|---:|---:|---:|---:|---:|"]
    for label in ("V5", "V7"):
        rows = dependence["block_fallback"]["by_sequence"][label]
        orig_res = sum(r["observed_terminal"] != "unresolved" for r in rows)
        cats = [r["block_terminal"] for r in rows]
        sequence_lines.append(f"| {label} | {orig_res} | {sum(c in ('a_superior','b_superior') for c in cats)} | "
                              f"{sum(r['same_resolved_decision'] for r in rows)} | {cats.count('precision_only')} | {cats.count('unresolved')} |")
    sequence_lines += ["", "在该条件敏感性分析中，两轮数据均为 0 项优越决定、0 项精度决定、15 项未决；原 Hoeffding 决定没有一项保留。每块含 50 次运行只是可复现的种子区段划分，不是由采集批次或已知生成机制证明的独立块。因此命题 4 的有限样本保证不能直接套用于这些块；以上结果只能显示在这一粗粒度条件假设下，决定会消失，不能据此宣称原决定错误或回退区间有效。V4 仅有 400 个种子，本轮未对其作相同分析。", "",
                      "### S23.3 与注册参数匹配的合成依赖校准", "",
                      "为回应压力测试与注册设计参数不同的问题，按主设计参数另作 Bernoulli(0.5) 块重复校准。每条件 5,000 次，两臂独立；块内重复，块大小为 1、2、5、10、20、50；比较级 alpha=0.05/15、实际边际 0.05、检查点 5/10/15/20，使用原可求和支出。该模拟只展示若设定这种已知块生成机制时的行为，不是 V5/V7 依赖估计。", "",
                      "**表 S23-3。注册参数下的合成块依赖校准**", "",
                      "| 块大小 | 末次有效完整块数 | 朴素同时覆盖 | 朴素错误优越 | 已知块回退同时覆盖 | 已知块回退错误优越 |", "|---:|---:|---:|---:|---:|---:|"]
    # Fixed deterministic Monte Carlo for the registered design.
    sim_rows = registered_stress()
    for r in sim_rows:
        fallback_coverage = "—" if r["fallback_coverage"] is None else f"{r['fallback_coverage']:.4f}"
        fallback_false = "—" if r["fallback_false_superiority"] is None else f"{r['fallback_false_superiority']:.4f}"
        sequence_lines.append(f"| {r['block_size']} | {r['effective_blocks']} | {r['naive_coverage']:.4f} | {r['naive_false_superiority']:.4f} | {fallback_coverage} | {fallback_false} |")
    sequence_lines += ["", "在注册设计参数下，n≤20 时末次半径 R₄=1.017859，大于变量均值差的最大可能值 1；因此任何有界数据和任何依赖结构都不可能触发边际 m=0.05 的优越性决定，与推论 3 的解析非分辨结论相同。表中朴素错误优越率 0.0000 是这一解析边界的模拟核验，不是依赖无害或覆盖稳健的独立证据。该校准仍依赖人为指定的重复块模型；点估计的依赖结构、真实数据中的块边界及块间独立性均未由模拟证明。大预算下实际出现决定时的依赖压力参见表 17、表 18 与表 S23-2。仿真逐次数据不作为 RL 证据。", ""]
    supplement_add = "## S23 V5 与 V7 顺序及依赖敏感性\n\n" + "\n".join(sequence_lines)
    supp = supp.rstrip() + "\n\n" + supplement_add
    main = main.replace("## 参考文献", "## 参考文献", 1)
    return main, supp


def registered_stress() -> list[dict]:
    rng = random.Random(933000)
    blocks = (1, 2, 5, 10, 20, 50)
    looks = (5, 10, 15, 20)
    alphas = [0.05 / 15 * 6 / (math.pi**2 * k**2) for k in range(1, len(looks) + 1)]
    result = []
    for block_size in blocks:
        naive_covered = naive_false = fallback_covered = fallback_false = 0
        fallback_eligible = 0
        for _ in range(5000):
            arms = []
            for _arm in range(2):
                seq = []
                while len(seq) < looks[-1]:
                    value = float(rng.random() < 0.5)
                    seq.extend([value] * block_size)
                arms.append(seq[:looks[-1]])
            vals = []
            for use_blocks in (False, True):
                covered = True
                false_superiority = False
                observed_looks = 0
                for n, alpha in zip(looks, alphas):
                    if use_blocks:
                        bn = n // block_size
                        if bn < 1:
                            continue
                        observed_looks += 1
                        samples = [[statistics.fmean(arms[arm][j:j + block_size])
                                    for j in range(0, bn * block_size, block_size)] for arm in range(2)]
                        effective_n = bn
                    else:
                        samples = [arms[arm][:n] for arm in range(2)]
                        effective_n = n
                    estimate = statistics.fmean(samples[0]) - statistics.fmean(samples[1])
                    radius = 2 * math.sqrt(math.log(4 / alpha) / (2 * effective_n))
                    lower, upper = max(-1, estimate - radius), min(1, estimate + radius)
                    covered &= lower <= 1e-12 and upper >= -1e-12
                    false_superiority |= lower > 0.05 or upper < -0.05
                vals.append((covered, false_superiority, observed_looks > 0))
            naive_covered += vals[0][0]
            naive_false += vals[0][1]
            if vals[1][2]:
                fallback_eligible += 1
                fallback_covered += vals[1][0]
                fallback_false += vals[1][1]
        result.append({"block_size": block_size, "effective_blocks": looks[-1] // block_size,
                       "naive_coverage": naive_covered / 5000,
                       "naive_false_superiority": naive_false / 5000,
                       "fallback_eligible_replicates": fallback_eligible,
                       "fallback_coverage": fallback_covered / fallback_eligible if fallback_eligible else None,
                       "fallback_false_superiority": fallback_false / fallback_eligible if fallback_eligible else None})
    return result

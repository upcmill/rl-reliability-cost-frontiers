#!/usr/bin/env python3
"""Generate the v3 selected-test seed distribution table from raw CSV."""

from __future__ import annotations

import csv
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ENVIRONMENTS = ("CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0")
ALGORITHMS = ("PPO", "DQN", "A2C")


def main() -> None:
    values: dict[tuple[str, str], list[float]] = defaultdict(list)
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["split"] == "test":
                values[(row["env_id"], row["algorithm"])].append(float(row["metric_normalized"]))
    lines = [
        "# v3 Selected-Test Seed Distribution Table",
        "",
        "Generated from `sb3_formal_v3/raw_seed_metrics.csv`; each row contains 20 selected-configuration test seeds.",
        "",
        "| Environment | Algorithm | Mean | Sample SD | Median | Minimum | Maximum |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for environment in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            sample = values[(environment, algorithm)]
            if len(sample) != 20:
                raise ValueError(f"expected 20 test metrics for {environment}/{algorithm}, got {len(sample)}")
            lines.append(
                f"| {environment} | {algorithm} | {statistics.mean(sample):.6f} | "
                f"{statistics.stdev(sample):.6f} | {statistics.median(sample):.6f} | "
                f"{min(sample):.6f} | {max(sample):.6f} |"
            )
    output = ROOT / "SEED_DISTRIBUTION_TABLE_V3.md"
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()

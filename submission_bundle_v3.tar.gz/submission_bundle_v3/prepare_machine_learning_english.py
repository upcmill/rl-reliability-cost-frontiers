#!/usr/bin/env python3
"""Prepare a Machine Learning submission draft from the latest English core.

The current English core predates the seventh-round Chinese manuscript in a
few labels and disclosure details.  This transformation keeps its audited
English prose, updates the title and evidence boundary, converts citations to
Springer's author--year convention, and writes a new working file without
touching the archived English or Chinese manuscripts.
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "MANUSCRIPT_SUBMISSION_CORE_EN.md"
OUTPUT = ROOT / "MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.md"
RESOURCE_TAG = "v3.0.5"
ZENODO_CONCEPT_DOI = "https://doi.org/10.5281/zenodo.23949004"
RESOURCE_BASE = (
    "https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/"
    f"{RESOURCE_TAG}"
)
RESOURCE_FILES = {
    1: "Online_Resource_1_Supplement.pdf",
    2: "Online_Resource_2_Primary_v3.zip",
    3: "Online_Resource_3_Supplementary_Experiments.zip",
    4: "Online_Resource_4_Dependence_Diagnostics.zip",
    5: "submission_bundle_v3.tar.gz",
    6: "Online_Resource_6_External_Rerun.zip",
}


def link_online_resources(text: str) -> str:
    """Link singular, paired, and ranged resource references in one pass."""
    def replace(match):
        expression = match.group(1)
        numbers = []
        for part in re.split(r"\s+and\s+|,\s*", expression):
            ends = re.split(r"--|–", part.strip())
            numbers.extend(range(int(ends[0]), int(ends[-1]) + 1))
        return " and ".join(
            f"[Online Resource {n}]({RESOURCE_BASE}/{RESOURCE_FILES[n]})"
            for n in numbers
        )
    return re.sub(
        r"(?<!\[)Online\s+Resources?\s+([1-6](?:(?:--|–)[1-6])?(?:\s+and\s+[1-6])?)\b",
        replace, text,
    )


CITATIONS = {
    "L1": "Henderson et al. 2018",
    "L2": "Colas et al. 2018",
    "L3": "Colas et al. 2019",
    "L4": "Agarwal et al. 2021",
    "L5": "Hoeffding 1963",
    "L6": "Lan and DeMets 1983",
    "L7": "Schulman et al. 2017",
    "L8": "Mnih et al. 2015",
    "L9": "Mnih et al. 2016",
    "L10": "Towers et al. 2025",
    "L11": "Whiteson et al. 2011",
    "L12": "Raffin et al. 2021",
    "L13": "Zhang et al. 2018",
    "L14": "Nagarajan et al. 2018",
    "L15": "Chan et al. 2019",
    "L16": "Khamaru et al. 2022",
}


REFERENCES = """## References

Agarwal, R., Schwarzer, M., Castro, P. S., Courville, A., & Bellemare, M. G.
(2021). Deep reinforcement learning at the edge of the statistical precipice.
arXiv:2108.13264. https://doi.org/10.48550/arXiv.2108.13264.

Chan, S. C. Y., Fishman, S., Canny, J., Korattikara, A., & Guadarrama, S.
(2019). Measuring the reliability of reinforcement learning algorithms.
arXiv:1912.05663. https://doi.org/10.48550/arXiv.1912.05663.

Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2018). How many random seeds?
Statistical power analysis in deep reinforcement learning experiments.
arXiv:1806.08295. https://doi.org/10.48550/arXiv.1806.08295.

Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2019). A hitchhiker's guide to
statistical comparisons of reinforcement learning algorithms. arXiv:1904.06979.
https://doi.org/10.48550/arXiv.1904.06979.

Henderson, P., Islam, R., Bachman, P., Pineau, J., Precup, D., & Meger, D.
(2018). Deep reinforcement learning that matters. Proceedings of the AAAI
Conference on Artificial Intelligence, 32(1). https://doi.org/10.1609/aaai.v32i1.11694.

Hoeffding, W. (1963). Probability inequalities for sums of bounded random
variables. Journal of the American Statistical Association, 58(301), 13--30.
https://doi.org/10.1080/01621459.1963.10500830.

Khamaru, K., Xia, E., Wainwright, M. J., & Jordan, M. I. (2022).
Instance-dependent confidence and early stopping for reinforcement learning.
arXiv:2201.08536. https://doi.org/10.48550/arXiv.2201.08536.

Lan, K. K. G., & DeMets, D. L. (1983). Discrete sequential boundaries for
clinical trials. Biometrika, 70(3), 659--663.
https://doi.org/10.1093/biomet/70.3.659.

Mnih, V., et al. (2015). Human-level control through deep reinforcement
learning. Nature, 518, 529--533. https://doi.org/10.1038/nature14236.

Mnih, V., et al. (2016). Asynchronous methods for deep reinforcement learning.
Proceedings of the 33rd International Conference on Machine Learning.
https://arxiv.org/abs/1602.01783.

Nagarajan, P., Warnell, G., & Stone, P. (2018). Deterministic implementations
for reproducibility in deep reinforcement learning. arXiv:1809.05676.
https://doi.org/10.48550/arXiv.1809.05676.

Raffin, A., Hill, A., Gleave, A., Kanervisto, A., Ernestus, M., & Dorman, N.
(2021). Stable-baselines3: Reliable reinforcement learning implementations.
Journal of Machine Learning Research, 22(268), 1--8.
https://jmlr.org/papers/v22/20-1364.html.

Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017).
Proximal policy optimization algorithms. arXiv:1707.06347.
https://arxiv.org/abs/1707.06347.

Towers, M., et al. (2025). Gymnasium: A standard interface for reinforcement
learning environments. Advances in Neural Information Processing Systems 38,
163114--163129. https://doi.org/10.52202/085713-4916.

Whiteson, S., Tanner, B., Taylor, M. E., & Stone, P. (2011). Protecting
against evaluation overfitting in empirical reinforcement learning. 2011 IEEE
Symposium on Adaptive Dynamic Programming and Reinforcement Learning, 120--127.
https://doi.org/10.1109/ADPRL.2011.5967363.

Zhang, C., Vinyals, O., Munos, R., & Bengio, S. (2018). A study on overfitting
in deep reinforcement learning. arXiv:1804.06893.
https://doi.org/10.48550/arXiv.1804.06893.
"""


def replace_citations(text: str) -> str:
    def direct(match: re.Match[str]) -> str:
        keys = [key.strip() for key in match.group(1).split(",")]
        return "(" + "; ".join(CITATIONS[key] for key in keys) + ")"

    return re.sub(r"\[(L\d+(?:\s*,\s*L\d+)*)\]", direct, text)


def renumber_labels(text: str) -> str:
    proposition_map = {"0": "2", "1": "1", "2": "3", "3": "4"}
    corollary_map = {"0": "1", "1": "2", "2": "3", "3": "4", "4": "5", "5": "6"}

    def replace(match: re.Match[str]) -> str:
        kind, number = match.group(1), match.group(2)
        mapping = proposition_map if kind == "Proposition" else corollary_map
        return f"{kind} {mapping.get(number, number)}"

    return re.sub(r"\b(Proposition|Corollary) ([0-5])\b", replace, text)


def build() -> None:
    text = SOURCE.read_text(encoding="utf-8")
    text = text.replace(
        "# Reliability--Cost Frontiers for Sequential Evaluation of Reinforcement Learning Algorithms",
        "# Resolution and Cost in Sequential Evaluation of Reinforcement Learning Algorithms: A Design Audit",
        1,
    )
    text = text.replace(
        "**Concise submission main-text version.** The full audited v3 manuscript and supplementary diagnostics remain in `MANUSCRIPT_DRAFT_V3.md` and the submission archive.",
        "**Submission preparation draft for Machine Learning (Springer).** This English working file is synchronized with the audited seventh-round evidence boundary; the Chinese manuscript remains the content source of record. Author identity fields remain for author completion. Public materials correspond to release v3.0.5.",
        1,
    )
    abstract_marker = "## Abstract\n\n"
    keywords = "\n\n**Keywords:** reinforcement learning; reproducibility; statistical inference; sequential evaluation; random seeds; bounded confidence intervals."
    if keywords.strip() not in text:
        text = text.replace("\n\n## 1. Introduction", keywords + "\n\n## 1. Introduction", 1)
    text = text.replace(
        "The evidence does not establish coverage on unknown RL seed distributions, task-population generalization, independent-team replication, universal seed requirements, or algorithm rankings.",
        "These results do not establish unknown-distribution coverage, task-population generalization, independent-team replication, universal seed requirements, or algorithm rankings. V7 `rho x 10` produced six terminal decisions and no precision-only decisions, showing tuning-parameter sensitivity.",
        1,
    )
    text = text.replace("#### Validation-stage tuning cost", "**Validation-stage tuning cost.**")
    text = renumber_labels(text)
    text = replace_citations(text)
    for value in sorted(CITATIONS.values(), key=len, reverse=True):
        author, year = value.rsplit(" ", 1)
        if author.endswith(" et al."):
            text = text.replace(f"{author} ({value})", f"{author} ({year})")
    text = text.replace(
        "Colas et al. (Colas et al. 2018; Colas et al. 2019)",
        "Colas et al. (2018, 2019)",
    )
    # Keep theorem labels in ascending order in the body.  The legacy English
    # core placed the coverage proposition after the state-machine section.
    prop1_start = text.index("### Proposition 1 (conditional finite-look coverage)")
    prop3_start = text.index("### Proposition 3 (validity under locked finite-look stopping)", prop1_start)
    prop1_block = text[prop1_start:prop3_start]
    text = text[:prop1_start] + text[prop3_start:]
    prop2_start = text.index("### Proposition 2 (selection invariance under sealed testing)")
    text = text[:prop2_start] + prop1_block + "\n" + text[prop2_start:]
    v7_anchor = "This result provides new-seed support for the interval-width difference on the\nsame fixed five-task panel."
    v7_update = (
        "The corresponding `rho x 0.1` sensitivity produced six superiority and "
        "five precision-only decisions, whereas `rho x 10` produced six total "
        "terminal decisions, no precision-only decisions, and nine unresolved "
        "comparisons. Thus the stopping count and width comparison are conditional "
        "on the frozen tuning parameter. A separate 50-seed block sensitivity "
        "removed all four original Hoeffding superiority decisions, but those "
        "blocks were not shown to be independent and therefore do not repair the "
        "primary independence assumption. The registered-parameter S23.3 result "
        "is an analytic-boundary check rather than evidence that dependence is harmless.\n\n"
    )
    if v7_anchor in text:
        text = text.replace(v7_anchor, v7_update + v7_anchor, 1)
    text = text.replace("`[待核实]`", "`[to be verified]`")
    text = text.replace("[待核实]", "[to be verified]")
    text = text.replace("[待补充]", "[to be completed]")
    text = text.replace(
        "A known independent-block structure has a conservative fallback. | Proposition 3,",
        "A known independent-block structure has a conservative fallback. | Proposition 4,",
    )
    text = text.replace(
        "The full audited v3 manuscript and post-v3 diagnostics remain in `MANUSCRIPT_DRAFT_V3.md` and the submission archive.",
        "The full audited v3 manuscript and post-v3 diagnostics are provided in the accompanying Online Resources.",
    )
    declarations = """## 11. Declarations

**Author information.** Author names, affiliations, corresponding-author
details, email addresses, and ORCID identifiers: [to be completed by the
authors].

**Author contributions.** CRediT roles: [to be completed by the authors].

**Funding.** [To be completed by the authors.]

**Competing interests.** [To be completed by the authors.]

**Data availability.** The data supporting this study are provided in Online
Resources 2--4 and 6 and archived under the Zenodo DOI
{ZENODO_CONCEPT_DOI}.

**Code availability.** The runner, analysis, audit, and reproduction scripts
are provided in Online Resource 5 and archived under the Zenodo DOI
{ZENODO_CONCEPT_DOI}.

**Ethics and broader impact.** The study uses simulated control environments
and contains no human participants, personal data, or animal subjects. The
custom queue is a controlled diagnostic and is not presented as a real-world
deployment or policy recommendation.
"""
    text = re.sub(r"## 11\. Declarations\n.*?\n## Supplementary material boundary", declarations.rstrip() + "\n\n## Supplementary material boundary", text, flags=re.S)
    text = text.split("## References", 1)[0].rstrip() + "\n\n" + REFERENCES.strip() + "\n"
    text = text.replace("{ZENODO_CONCEPT_DOI}", ZENODO_CONCEPT_DOI)
    text = link_online_resources(text)
    OUTPUT.write_text(text, encoding="utf-8")
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    build()

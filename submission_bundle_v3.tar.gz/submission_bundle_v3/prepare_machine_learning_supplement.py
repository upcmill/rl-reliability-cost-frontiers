#!/usr/bin/env python3
"""Prepare the English Online Resource supplement for Machine Learning."""

from pathlib import Path
from prepare_machine_learning_english import link_online_resources


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "SUPPLEMENTARY_INFORMATION_V3.md"
OUTPUT = ROOT / "SUPPLEMENTARY_MACHINE_LEARNING_EN.md"
RESOURCE_TAG = "v3.0.5"
RESOURCE_BASE = (
    "https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/"
    f"{RESOURCE_TAG}"
)
RESOURCE_FILES = {
    1: "Online_Resource_1_Supplement.pdf",
    2: "Online_Resource_2_Primary_v3.zip",
    3: "Online_Resource_3_Supplementary_Experiments.zip",
    4: "Online_Resource_4_Dependence_Diagnostics.zip",
    5: "submission_bundle_v3.tar.gz",
    6: "Online_Resource_6_External_Rerun.zip",
}
ZENODO_CONCEPT_DOI = "https://doi.org/10.5281/zenodo.23949004"


V7_SECTION = r"""
## S11. V7 new-seed method comparison

V7 was frozen after the V1--V6 results had been inspected and therefore is a
post-hoc prospective validation rather than a confirmatory analysis of the
original preregistration. It evaluates the same five-task panel, three
algorithms, frozen configurations, and 15 comparisons on new training seeds
31,400--32,399 (15,000 successful training records). The original Hoeffding
interval and eight variance-adaptive or sensitivity methods were evaluated at
200, 400, 600, 800, and 1,000 seeds under the same comparison-level alpha.

At 1,000 seeds, the main Gamma-mixture empirical-Bernstein confidence sequence
was narrower than the original Hoeffding interval in all 15 comparisons. Its
mean and median paired width differences were -0.185260 and -0.179334. The
main Gamma setting produced four A-superior, two B-superior, five
precision-only, and four unresolved comparisons; Hoeffding produced three
A-superior, one B-superior, and eleven unresolved comparisons. The shared-arm
counterfactual prefixes were 11,800 and 14,600 training runs, respectively,
but all 15,000 runs were completed, so these are not realized compute savings.

The `rho x 0.1` sensitivity produced six superiority and five precision-only
decisions. The `rho x 10` sensitivity produced six total terminal decisions,
no precision-only decisions, and nine unresolved comparisons. A 50-seed block
sensitivity removed all four original Hoeffding superiority decisions, but the
blocks were not shown to be independent and therefore do not repair the
primary assumption. The registered-parameter S23.3 result is an
analytic-boundary check, not evidence that dependence is harmless. Complete
method counts, widths, prefix calculations, V5/V7 comparisons, and raw files
are listed in the S12 manifest.

This section supports only a fixed-panel interval-width and tuning-sensitivity
description. It does not establish unknown-distribution coverage,
task-population generalization, a universal seed budget, algorithm rankings,
independent-team replication, or realized compute savings.

## S12. Online Resource manifest

The following materials correspond to release v3.0.5. The Zenodo DOI
{ZENODO_CONCEPT_DOI} identifies the archive series; the release fixes the
version used here.

| Resource | Content | Download |
|---|---|---|
| Supplementary narrative and tables | Extended methods, diagnostics, limitations, and claim--evidence map | [Online Resource 1]({RESOURCE_BASE}/{RESOURCE_FILES[1]}) |
| Primary v3 data package | Preregistration, row-level metrics, configurations, and summaries | [Online Resource 2]({RESOURCE_BASE}/{RESOURCE_FILES[2]}) |
| Supplementary experiment package | V4--V7 extensions, sensitivity analyses, and scope diagnostics | [Online Resource 3]({RESOURCE_BASE}/{RESOURCE_FILES[3]}) |
| Dependence diagnostics | Controlled seed-dependence stress test and known-block fallback | [Online Resource 4]({RESOURCE_BASE}/{RESOURCE_FILES[4]}) |
| Code and provenance package | Runner, audit scripts, environment metadata, references, and checksums | [Online Resource 5]({RESOURCE_BASE}/{RESOURCE_FILES[5]}) |
| External rerun package | Windows raw data, audit, summaries, runtime metadata, logs, and checksums | [Online Resource 6]({RESOURCE_BASE}/{RESOURCE_FILES[6]}) |
"""


def build() -> None:
    text = SOURCE.read_text(encoding="utf-8")
    text = text.replace(
        "# Supplementary Information for\n# Reliability--Cost Frontiers for Sequential Evaluation of Reinforcement Learning Algorithms",
        "# Supplementary Information for: Resolution and Cost in Sequential Evaluation of Reinforcement Learning Algorithms: A Design Audit",
        1,
    )
    text = text.replace(
        "The materials are publicly available from\nhttps://github.com/upcmill/rl-reliability-cost-frontiers and the Zenodo concept\nDOI https://doi.org/10.5281/zenodo.23949004. The concept DOI resolves to the\nlatest published version; its landing page lists version-specific records and\nfile checksums.",
        "The data and code supporting this paper correspond to release v3.0.5 at\nhttps://github.com/upcmill/rl-reliability-cost-frontiers/releases/tag/v3.0.5.\nThe archive series is identified by https://doi.org/10.5281/zenodo.23949004.\nThe S12 manifest links to each resource.",
        1,
    )
    text = text.replace("3. **Scientific conclusion replication:**", "4. **Scientific conclusion replication:**")
    text = text.replace(
        "| `./.rl-arm64-venv/bin/python -m unittest -q` | 55 tests pass in the current package |",
        "| `python3 -m unittest -v` | Standard-library and artifact tests run; environment-dependent imports require the recorded RL environment |",
    )
    text = text.rstrip() + "\n\n" + V7_SECTION.strip() + "\n"
    text = text.replace("{ZENODO_CONCEPT_DOI}", ZENODO_CONCEPT_DOI)
    for number, filename in RESOURCE_FILES.items():
        text = text.replace(
            f"{{RESOURCE_BASE}}/{{RESOURCE_FILES[{number}]}}",
            f"{RESOURCE_BASE}/{filename}",
        )
    text = text.replace(
        "The version-specific public archive record and license will be\n"
        "identified in the Data and Code Availability statements after the final\n"
        "archived materials are synchronized.",
        "The fixed release is v3.0.5; the archive series is available at "
        "https://doi.org/10.5281/zenodo.23949004.",
    )
    text = text.replace("Proposition 3", "Proposition 4")
    text = text.replace("Corollary 4", "Corollary 5")
    text = link_online_resources(text)
    OUTPUT.write_text(text, encoding="utf-8")
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    build()

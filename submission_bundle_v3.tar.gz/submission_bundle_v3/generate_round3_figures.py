#!/usr/bin/env python3
"""Data-derived calibration plot and protocol diagram for round-three revision."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'manuscript_figures'


def save(fig,name):
    for ext in ('png','pdf'):fig.savefig(OUT/f'{name}.{ext}',dpi=220,bbox_inches='tight')
    plt.close(fig)


def main():
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    data=json.loads((ROOT/'round3_analysis/synthetic_calibration.json').read_text())
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for n,color in ((20,'#333333'),(200,'#2166ac'),(1000,'#b35806')):
        rows=[r for r in data['rows'] if r['looks'][-1]==n]
        x=[r['true_difference'] for r in rows]
        y=[r['rates']['a_superior']['estimate'] for r in rows]
        lo=[r['rates']['a_superior']['wilson95'][0] for r in rows]
        hi=[r['rates']['a_superior']['wilson95'][1] for r in rows]
        axes[0].errorbar(x,y,yerr=[[max(0,a-b) for a,b in zip(y,lo)],[max(0,b-a) for a,b in zip(y,hi)]],marker='o',capsize=3,label=f'Max n = {n}',color=color)
        axes[1].plot(x,[r['mean_terminal_n'] for r in rows],marker='o',label=f'Max n = {n}',color=color)
    for ax in axes:
        ax.set_xlabel('True Bernoulli mean difference')
        ax.grid(alpha=.2)
        ax.axvline(.05,color='#888888',linestyle='--',linewidth=1)
    axes[0].set(ylabel='A-superiority decision proportion',ylim=(-.03,1.03),title='A. Decision frequency (95% Wilson CI)')
    axes[0].legend(frameon=False)
    axes[1].set(ylabel='Mean terminal seeds per arm',ylim=(0,1050),title='B. Stopping cost under each schedule')
    save(fig,'fig_round3_synthetic')
    fig,ax=plt.subplots(figsize=(10,5.4));ax.set_xlim(0,10);ax.set_ylim(0,5.4);ax.axis('off')
    boxes=[(.1,3.45,2.8,1.45,'Validation only\n4 candidates × 5 seeds\nSelect configuration G','#e7f0fa'),
           (3.6,3.45,2.8,1.45,'Freeze the protocol\nConfig, metric, family\nLooks, alpha, m, w','#eef0f3'),
           (7.1,3.45,2.8,1.45,'Sealed test\n20 seeds per cell\nLooks: 5 / 10 / 15 / 20','#e7f4ec'),
           (.1,.6,4.3,1.7,'Parameter-only feasibility audit\nAlgorithm 2; Corollary 3\nOriginal design cannot resolve\nCan be used before new data collection','#fff1da'),
           (5.6,.6,4.3,1.7,'Intervals and locked decisions\nPropositions 1–3\nPrimary run: 15 / 15 unresolved\nImplementation check, not equivalence','#e7f4ec')]
    for x,y,w,h,label,color in boxes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.04',facecolor=color,edgecolor='#5b6572',linewidth=1))
        ax.text(x+w/2,y+h/2,label,ha='center',va='center',linespacing=1.5,fontsize=11)
    for start,end in [((2.95,4.2),(3.5,4.2)),((6.45,4.2),(7.0,4.2)),((8.5,3.4),(8.5,2.4)),((4.5,1.45),(5.5,1.45))]:
        ax.annotate('',xy=end,xytext=start,arrowprops={'arrowstyle':'->','color':'#444444','lw':1.5})
    ax.text(5,5.18,'Validation, sealed inference, and a separate design audit',ha='center',fontsize=14)
    save(fig,'fig_round3_protocol')
    print('Generated round-three protocol and synthetic calibration PNG/PDF.')


if __name__=='__main__':main()

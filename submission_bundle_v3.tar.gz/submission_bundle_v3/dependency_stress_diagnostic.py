#!/usr/bin/env python3
"""Stress-test the finite-look interval when seed observations are dependent.

This supplementary diagnostic uses block-correlated bounded Bernoulli sequences
to isolate a failure mode of the within-algorithm seed-independence assumption.
It is not an RL experiment and does not alter the preregistered v3 analysis.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

from pilot_protocol import ProtocolConfig, alpha_spend, hoeffding_unpaired_interval, sequential_decision


BLOCK_SIZES = (1, 2, 5, 10, 20, 50)
LOOKS = (50, 100, 150, 200)
TRUE_DIFFERENCE = 0.0


def wilson(successes: int, trials: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if trials <= 0:
        raise ValueError("trials must be positive")
    p = successes / trials
    denominator = 1.0 + z * z / trials
    center = (p + z * z / (2.0 * trials)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / trials + z * z / (4.0 * trials * trials)) / denominator
    return max(0.0, center - half), min(1.0, center + half)


def block_sequence(rng: random.Random, block_size: int, length: int = 200) -> list[float]:
    """Generate a bounded sequence with a shared value within each block."""
    if block_size < 1 or length < 1:
        raise ValueError("block_size and length must be positive")
    values: list[float] = []
    while len(values) < length:
        value = float(rng.random() < 0.5)
        values.extend([value] * block_size)
    return values[:length]


def run_condition(block_size: int, replicates: int, seed: int) -> dict:
    if replicates < 1:
        raise ValueError("replicates must be positive")
    config = ProtocolConfig(
        alpha=0.05,
        practical_margin=0.10,
        initial_seeds=50,
        batch_size=50,
        max_seeds=200,
        target_width=0.10,
        interval_method="hoeffding_unpaired",
    )
    rng = random.Random(seed)
    covered = 0
    false_superiority = 0
    terminal_seeds: list[int] = []
    for _ in range(replicates):
        values_a = block_sequence(rng, block_size, config.max_seeds)
        values_b = block_sequence(rng, block_size, config.max_seeds)
        simultaneous = True
        for look_index, n in enumerate(LOOKS, start=1):
            _, lower, upper = hoeffding_unpaired_interval(
                values_a[:n], values_b[:n], alpha_spend(config.alpha, look_index)
            )
            simultaneous = simultaneous and lower <= TRUE_DIFFERENCE <= upper
        covered += int(simultaneous)
        decision = sequential_decision(values_a, values_b, config)
        terminal_seeds.append(int(decision["n"]))
        false_superiority += int(decision["decision"] in {"a_superior", "b_superior"})

    coverage_interval = wilson(covered, replicates)
    false_interval = wilson(false_superiority, replicates)
    return {
        "block_size": block_size,
        "effective_blocks_at_max": math.ceil(config.max_seeds / block_size),
        "replicates": replicates,
        "simultaneous_coverage": covered / replicates,
        "simultaneous_coverage_wilson_95": {
            "lower": coverage_interval[0],
            "upper": coverage_interval[1],
        },
        "false_superiority_rate": false_superiority / replicates,
        "false_superiority_wilson_95": {
            "lower": false_interval[0],
            "upper": false_interval[1],
        },
        "mean_terminal_seeds": sum(terminal_seeds) / replicates,
        "terminal_decisions": {
            "false_superiority": false_superiority,
            "other": replicates - false_superiority,
        },
    }


def build_report(payload: dict) -> str:
    lines = [
        "# Seed-Dependence Stress Diagnostic",
        "",
        "This supplementary Monte Carlo diagnostic probes the within-algorithm",
        "seed-independence assumption used by the finite-look Hoeffding interval.",
        "Each arm is a block-correlated Bernoulli sequence with marginal mean",
        "0.5; the two arms are generated independently and the true difference is",
        "zero. Block size 1 is the independent reference. This is a controlled",
        "assumption stress test, not an RL result and not evidence of external",
        "reproducibility.",
        "",
        f"- Replicates per condition: `{payload['config']['replicates']}`",
        f"- Looks: `{payload['config']['looks']}`; alpha: `{payload['config']['alpha']}`",
        f"- Practical margin: `{payload['config']['practical_margin']}`; true difference: `{payload['config']['true_difference']}`",
        "",
        "## Results",
        "",
        "| Block size | Effective blocks at n=200 | Simultaneous coverage | 95% Wilson interval | False-superiority rate | 95% Wilson interval | Mean terminal seeds |",
        "|---:|---:|---:|---|---:|---|---:|",
    ]
    for row in payload["results"]:
        c = row["simultaneous_coverage_wilson_95"]
        f = row["false_superiority_wilson_95"]
        lines.append(
            f"| {row['block_size']} | {row['effective_blocks_at_max']} | "
            f"{row['simultaneous_coverage']:.4f} | [{c['lower']:.4f}, {c['upper']:.4f}] | "
            f"{row['false_superiority_rate']:.4f} | [{f['lower']:.4f}, {f['upper']:.4f}] | "
            f"{row['mean_terminal_seeds']:.2f} |"
        )
    lines.extend([
        "",
        "The independent reference is a calibration condition, not a proof of",
        "the theorem. Increasing block size reduces the effective number of",
        "independent observations while the nominal radius still uses n=200.",
        "Coverage loss and false-superiority decisions therefore illustrate why",
        "the theorem must remain conditional on the seed-independence assumption.",
        "The diagnostic does not estimate the dependence structure of any RL",
        "environment and does not provide a correction for dependent training",
        "runs.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replicates", type=int, default=5000)
    parser.add_argument("--output", default="DEPENDENCY_STRESS_DIAGNOSTIC.json")
    parser.add_argument("--report", default="DEPENDENCY_STRESS_DIAGNOSTIC.md")
    args = parser.parse_args()
    if args.replicates < 1:
        parser.error("--replicates must be positive")

    results = [run_condition(block, args.replicates, 931_000 + index) for index, block in enumerate(BLOCK_SIZES)]
    payload = {
        "status": "supplementary_dependency_assumption_stress_only",
        "warning": "This diagnostic is not an RL experiment, theorem proof, or external reproducibility result.",
        "config": {
            "replicates": args.replicates,
            "block_sizes": list(BLOCK_SIZES),
            "looks": list(LOOKS),
            "alpha": 0.05,
            "practical_margin": 0.10,
            "true_difference": TRUE_DIFFERENCE,
            "max_seeds": 200,
            "interval_method": "hoeffding_unpaired",
            "marginal_distribution": "Bernoulli(0.5)",
        },
        "results": results,
    }
    Path(args.output).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    Path(args.report).write_text(build_report(payload), encoding="utf-8")
    print(json.dumps({"output": args.output, "report": args.report, "rows": len(results)}, indent=2))


if __name__ == "__main__":
    main()

# v3 Selected-Test Raw-Return Table

Generated from `sb3_formal_v3/raw_seed_metrics.csv`; each row contains 20 selected-configuration test seeds.
Raw returns are descriptive and are not pooled across tasks because the tasks have different reward scales.

| Environment | Algorithm | Mean raw return | Sample SD | Median | Minimum | Maximum |
|---|---|---:|---:|---:|---:|---:|
| CartPole-v1 | PPO | 107.160000 | 30.539003 | 97.050000 | 75.650000 | 219.250000 |
| CartPole-v1 | DQN | 12.450000 | 7.511080 | 9.725000 | 9.050000 | 39.450000 |
| CartPole-v1 | A2C | 100.687500 | 30.487875 | 90.750000 | 58.200000 | 162.700000 |
| Acrobot-v1 | PPO | -445.655000 | 100.347583 | -500.000000 | -500.000000 | -134.800000 |
| Acrobot-v1 | DQN | -408.762500 | 124.334260 | -500.000000 | -500.000000 | -170.950000 |
| Acrobot-v1 | A2C | -457.742500 | 81.882243 | -500.000000 | -500.000000 | -193.000000 |
| MountainCar-v0 | PPO | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| MountainCar-v0 | DQN | -198.862500 | 4.669917 | -200.000000 | -200.000000 | -179.100000 |
| MountainCar-v0 | A2C | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | PPO | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | DQN | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | A2C | -639.492500 | 443.534378 | -559.325000 | -1636.850000 | -200.000000 |
| NonstationaryQueue-v0 | PPO | -425.265625 | 460.855138 | -161.418750 | -1797.200000 | -158.550000 |
| NonstationaryQueue-v0 | DQN | -158.733750 | 4.147479 | -159.475000 | -168.512500 | -150.950000 |
| NonstationaryQueue-v0 | A2C | -772.948750 | 645.308638 | -644.543750 | -1796.862500 | -154.512500 |

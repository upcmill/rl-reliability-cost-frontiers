# Formal v3 Report

Version 3 is the expanded-grid primary candidate. It was preregistered in
`FINAL_PREREGISTRATION_V3.md` before the v3 sealed test analysis and is kept
separate from v1 and v2.

## Frozen design

- Five tasks: `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`, and
  `NonstationaryQueue-v0`;
- PPO, DQN, and A2C;
- Four candidate configurations, five validation seeds per candidate;
- Twenty sealed test seeds per selected algorithm/task configuration;
- 4096 training steps, four checkpoints, five evaluation episodes;
- Unpaired Hoeffding interval, four predeclared looks, practical margin 0.05;
- Family alpha 0.05 over 15 comparisons, comparison alpha 0.0033333333333333335;
- Actual batch-by-batch stopping with terminal decision locking.

## Primary outcome

All 15 comparisons reached 20 test seeds and remained
`max_budget_inconclusive`. No formal superiority or precision decision was
made. Under the formal v3 alpha allocation, Corollary 2 shows that this outcome
is forced for any bounded data sequence at 20 seeds; the RL run therefore
verifies execution of the protocol on the selected task family rather than
estimating empirical power at this budget. The expanded grid changes
descriptive point estimates relative to v2 but does not produce a formal
algorithm ranking.

Complete decisions and stop traces are in
`sb3_formal_v3/familywise_cost_summary.json`; raw validation and test records
are in `sb3_formal_v3/raw_seed_metrics.csv`.

## Final intervals

| Task | Comparison | Estimate | Interval | Decision |
|---|---|---:|---:|---|
| CartPole-v1 | PPO − DQN | 0.1894 | [−0.8284, 1.0000] | Inconclusive |
| CartPole-v1 | PPO − A2C | 0.0129 | [−1.0000, 1.0000] | Inconclusive |
| CartPole-v1 | DQN − A2C | −0.1765 | [−1.0000, 0.8414] | Inconclusive |
| Acrobot-v1 | PPO − DQN | −0.0738 | [−1.0000, 0.9441] | Inconclusive |
| Acrobot-v1 | PPO − A2C | 0.0242 | [−0.9937, 1.0000] | Inconclusive |
| Acrobot-v1 | DQN − A2C | 0.0980 | [−0.9199, 1.0000] | Inconclusive |
| MountainCar-v0 | PPO − DQN | −0.0057 | [−1.0000, 1.0000] | Inconclusive |
| MountainCar-v0 | PPO − A2C | 0.0000 | [−1.0000, 1.0000] | Inconclusive |
| MountainCar-v0 | DQN − A2C | 0.0057 | [−1.0000, 1.0000] | Inconclusive |
| Taxi-v4 | PPO − DQN | 0.0000 | [−1.0000, 1.0000] | Inconclusive |
| Taxi-v4 | PPO − A2C | 0.2176 | [−0.8003, 1.0000] | Inconclusive |
| Taxi-v4 | DQN − A2C | 0.2176 | [−0.8003, 1.0000] | Inconclusive |
| NonstationaryQueue-v0 | PPO − DQN | −0.1300 | [−1.0000, 0.8878] | Inconclusive |
| NonstationaryQueue-v0 | PPO − A2C | 0.1696 | [−0.8483, 1.0000] | Inconclusive |
| NonstationaryQueue-v0 | DQN − A2C | 0.2996 | [−0.7182, 1.0000] | Inconclusive |

## Descriptive means

| Environment | PPO | DQN | A2C |
|---|---:|---:|---:|
| CartPole-v1 | 0.214320 | 0.024900 | 0.201375 |
| Acrobot-v1 | 0.108690 | 0.182475 | 0.084515 |
| MountainCar-v0 | 0.000000 | 0.005688 | 0.000000 |
| Taxi-v4 | 0.891089 | 0.891089 | 0.673519 |
| NonstationaryQueue-v0 | 0.792553 | 0.922569 | 0.622952 |

These are descriptive values only. The configuration grid and test seeds differ
from v2, so v2 and v3 point estimates must not be pooled as if they were one
pre-registered sample.

## Reproduction

The separate reproduction runner regenerated all 20 sealed seeds for all 15
algorithm–environment combinations. Every mean absolute normalized-metric
difference was `0.0` on the same machine. This is cross-script repeatability,
not independent-team reproducibility.

## Post-v3 resolution-cost diagnostic

The separate `sb3_queue_budget_followup_v1/` run freezes the v3-selected queue
configurations and appends 380 test seeds to the v3 20-seed prefix. It keeps the
v3 normalized metric, unpaired Hoeffding interval, comparison alpha `0.05/15`,
and practical margin 0.05, with looks at total sample sizes 200, 400, 600, 800,
and 1000. The DQN--A2C comparison is inconclusive at 200 seeds
(`0.318424`, `[0.042965, 0.593883]`) and resolves as DQN superior at 400 seeds
(`0.338355`, `[0.126528, 0.550180]`). This is a post-v3 single-task
resolution-cost diagnostic, not a new confirmatory family, a universal seed
requirement, or a general DQN ranking. `QUEUE_BUDGET_FOLLOWUP_AUDIT.json`
recomputes the stop trace and checks the v3 prefix row by row.

## Limitations

The expanded grid is stronger than v2 but still modest relative to broad
hyperparameter optimization. The task family does not include continuous or
visual control. MountainCar remains at the reward floor at this budget, Taxi is
a discrete diagnostic, and the queue is self-built. The formal bounded interval
does not make an early decision at 20 seeds. A sealed Windows AMD64 rerun has
now completed: all 15 selected configurations and terminal decisions match,
14/15 cells have zero seed-level differences, and one cell reports a small
platform difference. The rerun does not verify the operator's institutional
independence or test a new task family.

## Continuous-control supplement

The separately preregistered `Pendulum-v1` supplement is reported in
`CONTINUOUS_SUPPLEMENT_REPORT.md`. It evaluates PPO and A2C on one
continuous-action task, contains 80 raw rows, and remains maximum-budget
inconclusive at 20 test seeds. It is external-validity evidence for execution
scope only and is not pooled with the v3 primary family.

## Prospective v4 new-seed extension

The separately preregistered `FINAL_PREREGISTRATION_V4_EXTENSION.md` evaluates
400 previously unused seeds per algorithm on the same 15 cells, with all v3
selected configurations frozen. The extension contains 6,000 rows and uses
looks at 200 and 400 seeds under the same family-adjusted unpaired Hoeffding
rule. Only `NonstationaryQueue-v0` DQN--A2C reaches a terminal decision at the
first look (estimate `0.345322`, interval `[0.069863, 0.620781]`); the other 14
comparisons remain maximum-budget inconclusive. This is prospective new-seed
evidence for the same task family and selected procedures, not independent
machine reproducibility, a universal seed rule, or a general algorithm ranking.
Integrity checks are in `V4_EXTENSION_AUDIT.json` and `V4_EXTENSION_REPORT.md`.

The non-pooled consistency diagnostic compares this v4 queue sequence with the
post-v3 follow-up. Both sequences have positive DQN-minus-A2C estimates at 200
and 400 seeds; the v4 400-seed value is descriptive because its terminal state
was locked at 200. This agreement is reported only as a same-task, same-machine
consistency check. It is not pooled confirmatory inference or independent
reproducibility. See `V4_SEQUENCE_CONSISTENCY.md` and
`V4_SEQUENCE_CONSISTENCY.json`.

## Post-v4 v5 resolution-cost extension

The separately preregistered `FINAL_PREREGISTRATION_V5_EXTENSION.md` freezes
the v3-selected configurations and opens seeds 30400--31399, with looks at
200, 400, 600, 800, and 1,000. The complete run contains 15,000 rows. Four
comparisons reach terminal decisions by 1,000 seeds (three `a_superior` and one
`b_superior`), while eleven remain `max_budget_inconclusive`. The runner keeps
the complete 1,000-seed sequence for every cell, so these are prefix resolution
costs rather than observed compute savings. This is a same-machine diagnostic
of the frozen task family, not prospective power, a universal seed rule,
external reproducibility, or an algorithm ranking. Integrity and recomputation
are in `V5_EXTENSION_AUDIT.json` and `V5_EXTENSION_AUDIT.md`.


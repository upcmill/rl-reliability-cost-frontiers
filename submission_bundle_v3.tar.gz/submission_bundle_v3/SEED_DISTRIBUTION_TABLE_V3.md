# v3 Selected-Test Seed Distribution Table

Generated from `sb3_formal_v3/raw_seed_metrics.csv`; each row contains 20 selected-configuration test seeds.

| Environment | Algorithm | Mean | Sample SD | Median | Minimum | Maximum |
|---|---|---:|---:|---:|---:|---:|
| CartPole-v1 | PPO | 0.214320 | 0.061078 | 0.194100 | 0.151300 | 0.438500 |
| CartPole-v1 | DQN | 0.024900 | 0.015022 | 0.019450 | 0.018100 | 0.078900 |
| CartPole-v1 | A2C | 0.201375 | 0.060976 | 0.181500 | 0.116400 | 0.325400 |
| Acrobot-v1 | PPO | 0.108690 | 0.200695 | 0.000000 | 0.000000 | 0.730400 |
| Acrobot-v1 | DQN | 0.182475 | 0.248669 | 0.000000 | 0.000000 | 0.658100 |
| Acrobot-v1 | A2C | 0.084515 | 0.163764 | 0.000000 | 0.000000 | 0.614000 |
| MountainCar-v0 | PPO | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| MountainCar-v0 | DQN | 0.005687 | 0.023350 | 0.000000 | 0.000000 | 0.104500 |
| MountainCar-v0 | A2C | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| Taxi-v4 | PPO | 0.891089 | 0.000000 | 0.891089 | 0.891089 | 0.891089 |
| Taxi-v4 | DQN | 0.891089 | 0.000000 | 0.891089 | 0.891089 | 0.891089 |
| Taxi-v4 | A2C | 0.673519 | 0.219571 | 0.713205 | 0.179777 | 0.891089 |
| NonstationaryQueue-v0 | PPO | 0.792553 | 0.224807 | 0.921259 | 0.123317 | 0.922659 |
| NonstationaryQueue-v0 | DQN | 0.922569 | 0.002023 | 0.922207 | 0.917799 | 0.926366 |
| NonstationaryQueue-v0 | A2C | 0.622952 | 0.314785 | 0.685588 | 0.123482 | 0.924628 |

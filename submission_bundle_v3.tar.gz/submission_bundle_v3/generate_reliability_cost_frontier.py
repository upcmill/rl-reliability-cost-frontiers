#!/usr/bin/env python3
"""Generate the v3 reliability--cost frontier from theory and raw test rows."""

from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path

from pilot_protocol import alpha_spend
from unpaired_budget_requirements import seeds_for_possible_superiority, seeds_for_width


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "sb3_formal_v3/raw_seed_metrics.csv"
OUTPUT_JSON = ROOT / "RELIABILITY_COST_FRONTIER_V3.json"
OUTPUT_MD = ROOT / "RELIABILITY_COST_FRONTIER_V3.md"


def build() -> dict[str, object]:
    with INPUT.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    test_rows = [row for row in rows if row["split"] == "test" and row["status"] == "ok"]
    cells = sorted({(row["env_id"], row["algorithm"]) for row in test_rows})
    if len(test_rows) != 300 or len(cells) != 15:
        raise ValueError(f"expected 300 successful test rows and 15 cells, found {len(test_rows)} and {len(cells)}")
    grouped: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    for row in test_rows:
        grouped[(row["env_id"], row["algorithm"])].append(row)
    for key in grouped:
        grouped[key].sort(key=lambda row: int(row["seed"]))
        if [int(row["seed"]) for row in grouped[key]] != list(range(20)):
            raise ValueError(f"cell {key} does not contain the ordered seeds 0..19")

    family_alpha = 0.05
    comparison_alpha = family_alpha / 15.0
    margin = 0.05
    target_width = 0.10
    looks = []
    for look_index, n in enumerate((5, 10, 15, 20), start=1):
        alpha = alpha_spend(comparison_alpha, look_index)
        radius = 2.0 * math.sqrt(math.log(4.0 / alpha) / (2.0 * n))
        runtime_seconds = sum(
            float(row["runtime_seconds"])
            for values in grouped.values()
            for row in values[:n]
        )
        looks.append(
            {
                "look": look_index,
                "seeds_per_algorithm": n,
                "comparison_alpha": alpha,
                "radius_sum": radius,
                "minimum_clipped_width": min(2.0, radius),
                "largest_possible_lower_endpoint": 1.0 - radius,
                "necessary_seeds_per_algorithm_for_possible_superiority": seeds_for_possible_superiority(comparison_alpha, look_index, margin),
                "seeds_per_algorithm_for_width_target": seeds_for_width(comparison_alpha, look_index, target_width),
                "family_test_rows": len(cells) * n,
                "family_runtime_seconds": runtime_seconds,
                "family_runtime_hours": runtime_seconds / 3600.0,
            }
        )
    return {
        "status": "audited_reliability_cost_frontier",
        "warning": (
            "The radius and thresholds are distribution-free design quantities. "
            "Runtime is wall-clock accounting for this Apple Silicon CPU run and "
            "is not a cross-hardware efficiency benchmark."
        ),
        "source": str(INPUT.name),
        "family_alpha": family_alpha,
        "comparison_count": len(cells),
        "comparison_alpha": comparison_alpha,
        "practical_margin": margin,
        "target_width": target_width,
        "looks": looks,
    }


def render(payload: dict[str, object]) -> str:
    lines = [
        "# v3 Reliability--Cost Frontier",
        "",
        "The table combines the distribution-free interval geometry with the",
        "recorded cumulative wall-clock cost of the v3 selected test rows. The",
        "radius, width, and necessary-threshold columns are analytic; the runtime",
        "column is machine-specific execution accounting. No column is an empirical",
        "power estimate or a cross-hardware efficiency claim.",
        "",
        f"- Source rows: `{payload['source']}`",
        f"- Family: `{payload['comparison_count']}` comparisons; family alpha `{payload['family_alpha']}`",
        f"- Practical margin: `{payload['practical_margin']}`; width target: `{payload['target_width']}`",
        "",
        "| Look | Seeds/algorithm | Comparison alpha | Radius sum | Minimum clipped width | Largest possible lower endpoint | Necessary seeds for possible superiority | Seeds for width target | Family test rows | Cumulative runtime (hours) |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in payload["looks"]:
        lines.append(
            f"| {row['look']} | {row['seeds_per_algorithm']} | {row['comparison_alpha']:.8g} | "
            f"{row['radius_sum']:.6f} | {row['minimum_clipped_width']:.6f} | "
            f"{row['largest_possible_lower_endpoint']:.6f} | "
            f"{row['necessary_seeds_per_algorithm_for_possible_superiority']} | "
            f"{row['seeds_per_algorithm_for_width_target']} | {row['family_test_rows']} | "
            f"{row['family_runtime_hours']:.6f} |"
        )
    lines.extend([
        "",
        "At the v3 cap, the largest possible lower endpoint remains below the",
        "0.05 practical margin and the minimum possible width remains above 0.10.",
        "Thus the formal state machine cannot resolve the v3 family at any listed",
        "look, regardless of the observed bounded values. The runtime values show",
        "the recorded cost of reaching each look when every primary comparison",
        "remains open; they do not claim that another machine or implementation",
        "would have the same duration.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    payload = build()
    OUTPUT_JSON.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    OUTPUT_MD.write_text(render(payload), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "looks": len(payload["looks"])}, indent=2))


if __name__ == "__main__":
    main()

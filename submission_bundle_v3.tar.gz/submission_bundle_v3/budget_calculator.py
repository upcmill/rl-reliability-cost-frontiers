#!/usr/bin/env python3
"""Offline analytic feasibility calculator; not a statistical power calculator."""
import argparse
import json
import math


def calculate(looks, family_alpha=.05, comparisons=15, margin=.05, width=.10):
    if not looks or any(n < 1 for n in looks) or any(b <= a for a,b in zip(looks,looks[1:])):
        raise ValueError('looks must be strictly increasing positive integers')
    if not 0 < family_alpha < 1 or comparisons < 1 or not 0 <= margin < 1 or not 0 < width <= 2:
        raise ValueError('invalid alpha, comparison count, margin or width')
    result=[]
    for k,n in enumerate(looks,1):
        a=family_alpha/comparisons*6/(math.pi**2*k*k)
        log=math.log(4/a)
        r=math.sqrt(2*log/n)
        result.append({'look':k,'n_per_arm':n,'alpha_look':a,'radius_sum':r,
                       'maximum_lower_endpoint':max(-1.,1-r),'minimum_clipped_width':min(2.,r),
                       'possible_superiority':r < 1-margin,
                       'possible_precision':min(2.,r) <= width,
                       'necessary_n_for_possible_superiority':math.floor(2*log/(1-margin)**2)+1,
                       'sufficient_n_for_untruncated_width':math.ceil(8*log/width**2)})
    return {'scope':'equal-size two-arm bounded interval, original summable spending',
            'warning':'necessary feasibility is not sufficient power; no wall-clock savings estimate',
            'family_alpha':family_alpha,'comparisons':comparisons,'margin':margin,'width':width,'rows':result}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--looks',type=int,nargs='+',default=[5,10,15,20])
    p.add_argument('--family-alpha',type=float,default=.05)
    p.add_argument('--comparisons',type=int,default=15)
    p.add_argument('--margin',type=float,default=.05)
    p.add_argument('--width',type=float,default=.10)
    a=p.parse_args()
    try: result=calculate(a.looks,a.family_alpha,a.comparisons,a.margin,a.width)
    except ValueError as e:p.error(str(e))
    print(json.dumps(result,indent=2))


if __name__ == '__main__': main()

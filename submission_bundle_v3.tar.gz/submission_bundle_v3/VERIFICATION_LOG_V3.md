# Verification Log: v3 Submission Package

This log records the final local verification pass for the v3 manuscript
package. It is an execution record, not evidence of independent replication or
publication acceptance.

## Supported runtime

- Host: Apple Silicon macOS, arm64
- Research interpreter: `.rl-arm64-venv/bin/python`
- Word-generation interpreter: system Python 3.11 with `python-docx` 1.2.0;
  this formatting-only step does not run RL experiments.
- Environment boundary: the system interpreter is not suitable for RL tests;
  see `ENVIRONMENT_VALIDATION.md` for the observed architecture mismatch and
  the passing arm64 command.

## Commands and outcomes

The table preserves earlier verification entries as an audit history, so older
rows may show 48, 49, 50, 52, or 53 tests as the package grew. The current package
verification is recorded in the final revalidation entry below and reports 55
passing tests.

Earlier rows that mention 12 figures or fewer test counts describe superseded
intermediate artifacts. The current artifact counts are authoritative only in
the final revalidation entry and in `SUBMISSION_READINESS_AUDIT.md`.

| Command | Outcome |
|---|---|
| `./.rl-arm64-venv/bin/python -m unittest -v` | PASS; 48 tests |
| `./.rl-arm64-venv/bin/python audit_v3_artifacts.py` | PASS; 600 rows, 15 decisions, 15 zero-difference replays |
| `python3 audit_submission_claim_boundaries.py` | PASS; full/core Markdown, English/Chinese Word, readiness status, and declarations boundary anchors |
| `./.rl-arm64-venv/bin/python dependency_stress_diagnostic.py --replicates 5000` | PASS; six block-dependence conditions, Wilson intervals, and false-superiority diagnostics generated |
| `./.rl-arm64-venv/bin/python -m unittest -q test_dependency_stress_diagnostic.py` | PASS; deterministic block generator and diagnostic output checks |
| `./.rl-arm64-venv/bin/python dependency_robust_fallback_diagnostic.py --replicates 5000` | PASS; six block conditions, raw-count versus known-block coverage and false-superiority diagnostics generated |
| `./.rl-arm64-venv/bin/python -m unittest -q test_dependency_robust_fallback_diagnostic.py` | PASS; deterministic complete-block aggregation and fallback checks |
| `python3 independent_theory_reimplementation.py` | PASS; formula-only second implementation matches theory audit alpha, radius, width, and threshold values |
| `./.rl-arm64-venv/bin/python -m unittest -q test_independent_theory_reimplementation.py` | PASS; deterministic theory cross-check |
| `python3 independent_v3_recompute.py` | PASS; raw-CSV second implementation matches all 15 primary means, intervals, and decisions |
| `./.rl-arm64-venv/bin/python -m unittest -q test_independent_v3_recompute.py` | PASS; deterministic raw-CSV recomputation check |
| 2026-10-31 literature discovery update | PASS; two OpenAlex and one Crossref raw responses saved with SHA-256 manifest; no unverified source admitted |
| `python3 generate_design_planning_sensitivity.py` and `python3 audit_design_planning_sensitivity.py` | PASS; five family sizes, four looks, 20 analytic rows |
| `./.rl-arm64-venv/bin/python -m unittest -q test_design_planning_sensitivity.py` | PASS; 4 deterministic planning tests |
| `./.rl-arm64-venv/bin/python audit_supplementary_diagnostics.py` | PASS; both 300-row sensitivity runs plus six-condition known-block fallback audit |
| `./.rl-arm64-venv/bin/python audit_continuous_artifacts.py` | PASS; 80 rows, one comparison |
| `./.rl-arm64-venv/bin/python audit_continuous_scope_artifacts.py` | PASS; 80 rows, one comparison |
| `./.rl-arm64-venv/bin/python audit_partial_observable_scope.py` | PASS; 240 rows, six comparisons |
| `python3 generate_machine_learning_word.py` | PASS; English and Chinese Word files regenerated with 12 figures and 26 tables after adding the validation tuning-cost evidence |
| `python3 generate_runtime_cost_table.py` and `python3 audit_runtime_cost_table.py` | PASS; 300 selected test rows, 15 cells, and raw-CSV total-runtime match |
| `python3 generate_validation_tuning_cost.py` and `python3 audit_validation_tuning_cost.py` | PASS; 300 validation rows, 100 candidate-seed runs per algorithm, and raw-CSV total-runtime match |
| `python3 generate_reliability_cost_frontier.py` and `python3 audit_reliability_cost_frontier.py` | PASS; four looks combine analytic radius/threshold values with recorded cumulative runtime |
| `python3 build_core_manuscript.py` and core Word generation | PASS; 13,624-word core source and English core Word file generated; post-v3 diagnostics are marked supplementary |
| `python3 generate_supplementary_word.py` | PASS; supplementary-information source rendered to a ten-table Word file |
| `python3 validate_external_rerun.py --external-dir sb3_formal_v3 --output /tmp/self_rerun_validation.json` | PASS; validator self-test matched all 15 selected configurations, seed-level metrics, and decision states; this is not external evidence |
| `python3 audit_theory_v3.py` and `test_theory_audit.py` | PASS; deterministic alpha, radius, non-resolution, threshold, and width checks |
| `python3 generate_mlj_contribution_sheet.py` | PASS; Springer contribution information sheet generated in Markdown and DOCX forms |
| `./.rl-arm64-venv/bin/python audit_queue_budget_followup.py` | PASS; 800 queue rows, v3 prefix match, and DQN--A2C resolution at 400 seeds |
| `./.rl-arm64-venv/bin/python audit_v4_extension.py` | PASS; 6,000 rows, 15 cells, one queue decision at 200 new seeds, 14 caps at 400 |
| `./.rl-arm64-venv/bin/python v4_sequence_consistency.py` | PASS; non-pooled queue consistency values for both sequences at 200 and 400 seeds |
| `./.rl-arm64-venv/bin/python minimax_alpha_spending.py` | PASS; deterministic minimax allocation and radius comparison generated |
| `./.rl-arm64-venv/bin/python margin_sensitivity_v3.py` | PASS; seven post-hoc margins, analytic thresholds and 15-cell decision counts generated |
| `./.rl-arm64-venv/bin/python -m unittest -v test_margin_sensitivity_v3.py` | PASS; 2 deterministic diagnostic tests |
| `./.rl-arm64-venv/bin/python -m unittest -q` | PASS; 48 tests |
| `python3 audit_tuning_stability_v20.py` | PASS; 1,215 rows, disjoint validation/test seed ranges, and 7/15 observed selection changes relative to v3 |
| `./.rl-arm64-venv/bin/python -m unittest -q test_tuning_stability_v20.py` | PASS; deterministic extension artifact checks |
| `./.rl-arm64-venv/bin/python -m unittest -q` | PASS; 49 tests after adding the v20 tuning-stability artifact check |
| `python3 audit_theory_v3.py` | PASS; deterministic finite-look values plus locked-stopping and frontier-definition anchors |
| `python3 audit_word_manuscript_parity.py` | PASS; English and Chinese Word files retain Propositions 2/3 and Definition 1 |
| `./.rl-arm64-venv/bin/python audit_v3_artifacts.py` | PASS; primary artifact and claim facts rechecked |
| `./.rl-arm64-venv/bin/python audit_v4_extension.py` | PASS; prospective extension rechecked |
| `python3 submission_readiness_audit.py` | PASS internally; status remains `submission_candidate_with_blockers`; three external gates remain blocked (public archive, independent literature screening, author declarations) |
| `python3 build_submission_bundle.py --output submission_bundle_v3.tar.gz` | PASS; archive rebuilt and sidecar written |
| `./.rl-arm64-venv/bin/python audit_v5_extension.py` | PASS; 15,000 rows, 3 `a_superior`, 1 `b_superior`, and 11 maximum-budget inconclusive cells |
| `python3 generate_v5_reliability_cost_frontier.py` and `python3 audit_v5_reliability_cost_frontier.py` | PASS; five v5 looks, raw-runtime match, monotone radius/resolution, and 3/1/11 decision classes |
| `./.rl-arm64-venv/bin/python -m unittest -q test_v5_reliability_cost_frontier.py` | PASS; deterministic v5 frontier checks |
| `python3 submission_readiness_audit.py` | PASS internally; v3 and v5 frontier gates pass, while three external gates remain blocked (public archive, independent literature screening, author declarations) |
| `python3 audit_manuscript_structure.py` | PASS; chapter order, claim-boundary anchors, final-look convention, 294/281-word full/core abstracts, matching 16 citation keys, and 12-figure/26-table Word dimensions |
| `python3 build_core_manuscript.py` and core Word generation | PASS; Discussion Section 6.3 theorem-supported evaluation-design recommendations synchronized into the concise main text |
| `python3 audit_word_manuscript_parity.py` | PASS; English and Chinese Word files retain the theory, family-control, and selection-boundary anchors after regeneration |
| `python3 audit_submission_claim_boundaries.py` | PASS; new design recommendations retain explicit conditional-scope and no-universal-claim boundaries |
| `python3 audit_tuning_stability_v20.py` | PASS; 1,215 rows, 20 disjoint validation seeds per candidate, and 7/15 observed selection changes relative to v3 |
| v20 provenance note | PASS; legacy shared-runner status labels are explicitly bounded by the v20 preregistration and audit |
| `python3 audit_public_archive_safety.py` | PASS; 293 planned archive members and 276 text files scanned with zero local-path or credential-marker hits |
| `python3 audit_submission_placeholders.py` | PASS; 12 submission files scanned; unresolved placeholders are inventoried and intentionally retained |
| `./.rl-arm64-venv/bin/python -m unittest -q` | PASS; 50 tests after adding the public-archive safety check and deposition-template coverage |
| `python3 generate_reproduction_hashes.py` | PASS; 145 manifest entries recomputed and rechecked with zero mismatches |
| `./.rl-arm64-venv/bin/python -m unittest -q test_tuning_stability_v20.py` | PASS; deterministic extension artifact checks |
| `python3 audit_manuscript_structure.py` | PASS; 294/281-word abstracts and 12-figure/26-table full Word dimensions |
| `python3 build_submission_bundle.py --output submission_bundle_v3.tar.gz` | PASS; archive rebuilt with the tuning extension; final SHA-256 is recorded in `submission_bundle_v3.tar.gz.sha256` |
| `ML_MANUSCRIPT_SOURCE=MANUSCRIPT_DRAFT_V3.md ... generate_machine_learning_word.py` | PASS; Chinese and English full manuscripts synchronized with Windows AMD64 different-machine rerun evidence |
| `python3 submission_readiness_audit.py` | PASS internally; status `submission_candidate_with_blockers`, exactly three blocked gates |
| `python3 generate_budget_feasibility_audit.py` and `./.rl-arm64-venv/bin/python -m unittest -q test_budget_feasibility_audit.py` | PASS; the four v3 looks are analytically unable to reach either registered threshold, with deterministic superiority thresholds 17/20/22/23 and width thresholds 6071/7180/7829/8289 seeds per arm |
| `python3 build_core_manuscript.py` and `python3 generate_machine_learning_word.py` | PASS; full and concise English manuscripts plus Chinese Word manuscript include the pre-study feasibility audit section and updated abstract |
| `python3 audit_manuscript_structure.py` | PASS; full/core abstracts remain under 300 words and Word dimensions remain valid after the new method section |
| `python3 audit_word_manuscript_parity.py` | PASS; English and Chinese Word files retain required theory, family-control, selection-boundary, and feasibility-audit anchors |
| `python3 audit_submission_claim_boundaries.py` | PASS; feasibility audit is explicitly bounded as a design diagnostic, not empirical power or a universal seed rule |
| `./.rl-arm64-venv/bin/python -m unittest -q` | PASS; 52 tests |
| `python3 build_submission_bundle.py` | PASS; final archive SHA-256 recorded in `submission_bundle_v3.tar.gz.sha256` |
| `./.rl-arm64-venv/bin/python audit_adaptive_spending.py` | PASS; four schedules, 8,000 diagnostic replicates, zero coverage failures and zero false-superiority decisions |
| `./.rl-arm64-venv/bin/python audit_word_manuscript_parity.py` | PASS; English and Chinese manuscripts contain the required theory and family-control anchors |
| `curl` retrieval audit | PASS; arXiv, Springer, Crossref, and OpenAlex raw responses saved under `literature_search_raw/2026-10-30_retry/` with SHA-256 manifest |
| `python3 deduplicate_openalex_screening.py` | PASS; 249 DOI/title-deduplicated OpenAlex candidates and first-pass screening record generated |
| Springer contribution-sheet audit | PASS; official page confirms the MLJ Contribution Information Sheet and Data Availability Statement requirements; preparation template added |
| `python3 audit_submission_placeholders.py` | PASS; 12 submission files scanned; unresolved author and external-source placeholders remain explicitly inventoried |
| `python3 audit_public_archive_safety.py` | PASS; 300 planned archive members and 283 text files scanned with zero local-path or credential-marker hits |
| `python3 generate_reproduction_hashes.py` | PASS; reproduction hash manifest regenerated after adding the readiness audit files |
| `python3 build_submission_bundle.py --output submission_bundle_v3.tar.gz` | PASS; archive rebuilt with readiness audit files; SHA-256 `ed7aa4203834b504eb2dd3023713a940884894a2c32147aee03f960166aa767c` |
| `python3 submission_readiness_audit.py` | PASS internally; archive contains 293 unique paths/296 tar members and exactly three external gates remain blocked |
| `./.rl-arm64-venv/bin/python -m unittest -q` | PASS; 50 tests |

The full English and Chinese Word files contain 26 tables and 12 figures each.
The concise English core Word file contains 17 tables and 4 figures, including
the validation-stage tuning-cost table.
The concise English core Word file contains 16 tables and 4 figures. All three
documents contain no literal `$` delimiters or backslash LaTeX source in
paragraph text.
The manuscript now includes an explicit research-question/hypothesis table, an
assumption registry linking coverage conditions to artifact checks, a formal
locked-stopping lemma with the `bar_tau=min(tau,K)` final-look convention, and
a definition of the reliability--cost frontier.
It also includes Proposition 3 and a known-block dependence fallback diagnostic;
the fallback is valid only when the block partition and block independence are
known, and is not a correction for unknown RL dependence.

The queue budget follow-up is a post-v3 fixed-configuration diagnostic. Its
400-seed stop is not a new confirmatory family, a universal seed requirement,
or evidence of general DQN superiority. The raw rows and exact recomputation
audit are included in the submission bundle.

## Archive identity

The authoritative SHA-256 is written to and checked against
`submission_bundle_v3.tar.gz.sha256` after each archive rebuild. The hash is
kept in that sidecar rather than duplicated here, because this log is itself a
member of the archive.

The data-independent v3 budget derivation is archived as
`ANALYTIC_NONRESOLUTION_NOTE_V3.md`; it does not amend the preregistration or
change any primary result.

The current archive contains the paths reported by `submission_readiness_audit.py`;
the authoritative archive digest is written to
`submission_bundle_v3.tar.gz.sha256` and must be checked after any subsequent
rebuild.

## Known non-blocking toolchain note

The bare system command `python3 -m unittest -v` is not the supported research
command on this machine: its NumPy installation is x86_64 while the active
interpreter is arm64, and it lacks Gymnasium. The arm64 virtual-environment
command above is the recorded and passing test command.

## Remaining publication gates

The readiness audit reports three unresolved external inputs: a public
repository or DOI, an independent second-reviewer literature screening with
database exports, and completed author/declaration metadata. The sealed Windows
AMD64 rerun closes the different-machine rerun gate, but independent-team
identity and new-task-family scientific replication remain unverified. The
same-machine cross-script replay must continue to be labelled repeatability,
while the Windows result is labelled different-machine reproducibility of the
frozen protocol.

## Consistency correction recorded on 2026-11-01

`STATISTICAL_AUDIT_V3.md` now distinguishes the legacy
`unpaired_budget_requirements.json` schedule (`1, 2, 4, 10, 20` look labels at
single-comparison alpha) from the formal v3 schedule (`5, 10, 15, 20` seeds per
arm at comparison alpha `0.05/15`). The legacy row labelled `20` remains an
archival planning value; the v3 manuscript and `BUDGET_FEASIBILITY_AUDIT_V3`
remain the authoritative sources for the formal study. This correction removes
an ambiguous use of the phrase “final look” without changing any RL artifact
or primary result.

## Revalidation recorded on 2026-11-01

After the consistency correction, the recorded arm64 research interpreter ran
`./.rl-arm64-venv/bin/python -m unittest -q` with 55 tests passing. The v3,
continuous-control, continuous-scope, partial-observation, v4, v5, runtime,
reliability-frontier, supplementary-diagnostic, and theory audits all returned
`PASS`. The manuscript structure, Word parity, claim-boundary, placeholder,
public-archive safety, manuscript numeric-claim (including English and Chinese
Word numeric anchors), and submission-readiness audits also returned `PASS`
internally. The rebuilt local archive is
`submission_bundle_v3.tar.gz`; its
current SHA-256 is recorded in the adjacent
`submission_bundle_v3.tar.gz.sha256` sidecar after each rebuild.
The submission status remains `submission_candidate_with_blockers` because the
public archive, independent literature screening, and author/declaration gates
are external inputs.

## v6 task-family extension recorded on 2026-11-01

A separately preregistered v6 extension added `CliffWalking-v1` and fixed
4 x 4 slippery `FrozenLake-v1` using new seeds 40000--40009 for validation and
41000--41199 for the extension test. The completed artifact contains 1,440
rows (240 validation and 1,200 test). `audit_v6_task_family.py` recomputes all
24 finite-look decisions from the raw CSV, verifies the frozen configuration
selection, environment options, seed ranges, and script hash, and returns
`PASS`; all six comparisons remain `max_budget_inconclusive` at 200 seeds.
CliffWalking evaluation is explicitly capped at 100 steps because its
Gymnasium spec has no TimeLimit wrapper. The extension is a same-machine scope
diagnostic and is not pooled with v3 or presented as external replication.

The English and Chinese Word artifacts now contain 13 figures and 26 tables,
including the v6 final-look interval figure. The current local archive digest
is recorded in `submission_bundle_v3.tar.gz.sha256` after each rebuild.

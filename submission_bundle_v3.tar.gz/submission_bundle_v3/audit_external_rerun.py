#!/usr/bin/env python3
"""Audit a returned v3 external rerun and write JSON/Markdown evidence.

This report combines the frozen validator with runtime, source-hash, output
checksum, and row-count checks. It does not alter the primary v3 artifacts.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
from collections import Counter
from pathlib import Path

from validate_external_rerun import (
    ALGORITHMS,
    ENVIRONMENTS,
    cell_metrics,
    check_schema,
    compare_to_reference,
    load_payload,
    load_rows,
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check_output_manifest(directory: Path) -> dict[str, object]:
    manifest = directory / "EXTERNAL_RERUN_OUTPUT_SHA256SUMS.txt"
    if not manifest.is_file():
        return {"present": False, "all_match": False, "files": {}}
    files: dict[str, object] = {}
    for line in manifest.read_text(encoding="utf-8-sig").splitlines():
        line = line.rstrip("\r")
        if not line.strip():
            continue
        expected, relative = line.split(None, 1)
        relative = relative.strip()
        path = directory / relative
        actual = sha256_file(path) if path.is_file() else None
        files[relative] = {"expected": expected, "actual": actual, "match": actual == expected}
    return {"present": True, "all_match": all(item["match"] for item in files.values()), "files": files}


def source_hash_comparison(metadata: dict, root: Path) -> dict[str, object]:
    results: dict[str, object] = {}
    documentation_updates = {"REPRODUCTION_MANIFEST_V3.md"}
    for relative, expected_info in metadata.get("source_files", {}).items():
        path = root / relative
        actual = sha256_file(path) if path.is_file() else None
        expected = expected_info.get("sha256")
        results[relative] = {
            "expected": expected,
            "actual": actual,
            "match": actual == expected,
            "classification": "post_rerun_documentation_update" if relative in documentation_updates and actual != expected else "runtime_source",
        }
    runtime = [item for item in results.values() if item["classification"] == "runtime_source"]
    return {
        "all_match": all(item["match"] for item in results.values()),
        "runtime_source_match": all(item["match"] for item in runtime),
        "post_rerun_documentation_updates": [name for name, item in results.items() if item["classification"] == "post_rerun_documentation_update" and not item["match"]],
        "files": results,
    }


def row_summary(rows: list[dict[str, str]]) -> dict[str, object]:
    split_counts = Counter(row.get("split") for row in rows)
    status_counts = Counter(row.get("status", "ok") for row in rows)
    cells = {(row.get("env_id"), row.get("algorithm")) for row in rows if row.get("split") == "test"}
    return {
        "row_count": len(rows),
        "split_counts": dict(split_counts),
        "status_counts": dict(status_counts),
        "test_cell_count": len(cells),
        "environment_ids": sorted({row.get("env_id") for row in rows}),
        "algorithm_ids": sorted({row.get("algorithm") for row in rows}),
        "validation_seed_range": [10000, 10004],
        "test_seed_range": [20000, 20019],
    }


def build_report(external_dir: Path, reference_dir: Path, source_root: Path) -> dict[str, object]:
    payload = load_payload(external_dir)
    rows = load_rows(external_dir)
    reference = load_payload(reference_dir)
    reference_rows = load_rows(reference_dir)
    schema_errors = check_schema(rows, payload)
    comparison = compare_to_reference(rows, payload, reference, reference_rows) if not schema_errors else None
    metadata_path = external_dir / "final_metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.is_file() else {}
    reference_config = reference.get("run_config", {})
    runtime = {
        "external": {
            "platform": metadata.get("platform"),
            "python": metadata.get("python"),
            "packages": metadata.get("packages"),
            "accelerators": metadata.get("accelerators"),
        },
        "reference": {
            "platform": reference_config.get("platform"),
            "python_version": reference_config.get("python_version"),
            "python_arch": reference_config.get("python_arch"),
            "packages": {
                "numpy": reference_config.get("numpy"),
                "torch": reference_config.get("torch"),
                "gymnasium": reference_config.get("gymnasium"),
                "stable_baselines3": reference_config.get("stable_baselines3"),
            },
        },
    }
    cell_differences = (comparison or {}).get("cell_differences", [])
    return {
        "schema": "external-rerun-audit-v1",
        "status": "PASS" if not schema_errors and (comparison or {}).get("all_selected_configurations_match") and (comparison or {}).get("all_decisions_match") else "FAIL",
        "evidence_boundary": {
            "different_machine_rerun": True,
            "independent_team_identity_verified": False,
            "operator_reported_no_reference_access": True,
            "public_archive_url_or_doi": False,
        },
        "external_dir": str(external_dir),
        "reference_dir": str(reference_dir),
        "schema_errors": schema_errors,
        "rows": row_summary(rows),
        "output_checksums": check_output_manifest(external_dir),
        "source_hashes": source_hash_comparison(metadata, source_root),
        "runtime": runtime,
        "comparison": comparison,
        "difference_summary": {
            "cells": len(cell_differences),
            "zero_difference_cells": sum(item["mean_absolute_metric_difference"] == 0.0 for item in cell_differences),
            "nonzero_difference_cells": sum(item["mean_absolute_metric_difference"] not in (None, 0.0) for item in cell_differences),
            "maximum_mean_absolute_metric_difference": max((item["mean_absolute_metric_difference"] or 0.0 for item in cell_differences), default=0.0),
            "maximum_absolute_metric_difference": max((item["maximum_absolute_metric_difference"] or 0.0 for item in cell_differences), default=0.0),
        },
    }


def markdown(report: dict[str, object]) -> str:
    rows = report["rows"]
    runtime = report["runtime"]
    diff = report["difference_summary"]
    comparison = report.get("comparison") or {}
    lines = [
        "# External v3 Rerun Audit",
        "",
        f"Status: **{report['status']}**",
        "",
        "This report audits a sealed rerun returned from a Windows AMD64 machine. It is evidence of a different-machine rerun; it does not verify the operator's institutional independence and does not create a public archive.",
        "",
        "## Scope and integrity",
        "",
        f"- Rows: {rows['row_count']} ({rows['split_counts'].get('validation', 0)} validation; {rows['split_counts'].get('test', 0)} test).",
        f"- Test cells: {rows['test_cell_count']}; environments: {', '.join(rows['environment_ids'])}; algorithms: {', '.join(rows['algorithm_ids'])}.",
        f"- Output checksum manifest: {'PASS' if report['output_checksums']['all_match'] else 'FAIL'}.",
        f"- Runtime source hashes: {'PASS' if report['source_hashes']['runtime_source_match'] else 'FAIL'}.",
        f"- Post-rerun documentation hash updates: {', '.join(report['source_hashes']['post_rerun_documentation_updates']) or 'none'}.",
        f"- Schema errors: {len(report['schema_errors'])}.",
        "",
        "## Runtime",
        "",
        f"- External machine: {runtime['external'].get('platform', {}).get('system')} {runtime['external'].get('platform', {}).get('release')}, {runtime['external'].get('platform', {}).get('machine')}.",
        f"- External Python: {runtime['external'].get('python', {}).get('version')}.",
        f"- External packages: NumPy {runtime['external'].get('packages', {}).get('numpy')}, PyTorch {runtime['external'].get('packages', {}).get('torch')}, Gymnasium {runtime['external'].get('packages', {}).get('gymnasium')}, SB3 {runtime['external'].get('packages', {}).get('stable-baselines3')}.",
        f"- Accelerator status: {runtime['external'].get('accelerators')}.",
        "",
        "## Comparison with macOS v3 reference",
        "",
        f"- Selected configurations: {'MATCH' if comparison.get('all_selected_configurations_match') else 'MISMATCH'} for all 15 cells.",
        f"- Terminal decisions: {'MATCH' if comparison.get('all_decisions_match') else 'MISMATCH'} for all 15 comparisons.",
        f"- Zero-difference cells: {diff['zero_difference_cells']}/15.",
        f"- Nonzero-difference cells: {diff['nonzero_difference_cells']}/15.",
        f"- Maximum cell mean absolute metric difference: {diff['maximum_mean_absolute_metric_difference']:.6f}.",
        f"- Maximum seed-level absolute metric difference: {diff['maximum_absolute_metric_difference']:.6f}.",
        "",
        "The only nonzero cell is `Acrobot-v1:DQN`: mean absolute normalized-metric difference 0.001050 and maximum absolute difference 0.016400. All 15 terminal decisions remain `max_budget_inconclusive`.",
        "",
        "## Evidence boundary",
        "",
        "The returned handoff states that the operator did not access the author reference directory and that the frozen command parameters were unchanged. The machine and operating system differ from the original Apple Silicon macOS run. This closes the different-machine rerun gate, subject to preserving the raw archive and metadata. It does not verify that the operator was an independent research team, and it does not close the public-archive, literature-screening, or author-declaration gates.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--external-dir", required=True)
    parser.add_argument("--reference-dir", default="sb3_formal_v3")
    parser.add_argument("--source-root", default=".")
    parser.add_argument("--json-output", required=True)
    parser.add_argument("--markdown-output", required=True)
    args = parser.parse_args()
    report = build_report(Path(args.external_dir), Path(args.reference_dir), Path(args.source_root))
    Path(args.json_output).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    Path(args.markdown_output).write_text(markdown(report), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if report["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()

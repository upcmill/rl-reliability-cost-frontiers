#!/usr/bin/env python3
"""Separate replay of selected masked-task test configurations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import partial_observable_env  # noqa: F401
from partial_observable_scope_runner import ENVIRONMENTS, train_curve
from sequential_sb3_runner_v3 import CONFIGS


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-dir", default="sb3_partial_observable_scope")
    parser.add_argument("--output", default=None)
    args = parser.parse_args()
    reference = json.loads((Path(args.reference_dir) / "summary.json").read_text(encoding="utf-8"))
    rows = []
    for environment_id in ENVIRONMENTS:
        for algorithm in reference["algorithm_ids"]:
            cell = reference["summary"][f"{environment_id}:{algorithm}"]
            reproduced = []
            for seed in range(20):
                result = train_curve(environment_id, algorithm, 50000 + seed, CONFIGS[cell["selected_config"]], [1024, 2048, 3072, 4096], 5)
                reproduced.append(result["metric_normalized"])
            reference_mean = sum(cell["test_metrics"]) / len(cell["test_metrics"])
            replay_mean = sum(reproduced) / len(reproduced)
            rows.append({"environment": environment_id, "algorithm": algorithm, "reference_mean": reference_mean, "replay_mean": replay_mean, "mean_absolute_metric_difference": abs(reference_mean - replay_mean)})
    payload = {"status": "same_machine_cross_script_replay", "all_zero_mean_absolute_difference": all(row["mean_absolute_metric_difference"] == 0.0 for row in rows), "rows": rows}
    output = Path(args.output) if args.output else Path(args.reference_dir) / "independent_reproduction.json"
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

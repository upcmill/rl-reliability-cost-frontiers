# v3 独立密封复跑手册

本手册用于把 v3 研究交给另一台机器或另一支团队独立执行。它描述的是
可执行的复跑流程，不是已经完成独立复现的证明。当前工作区的同机重跑和
脚本交叉复核不能替代不同机器或独立团队的密封复跑。

## 1. 复跑目标

复跑方只应接收 `external_rerun_kit_v3.tar.gz` 及其 SHA-256 校验值。复跑
完成前，复跑方不应接触作者的 `sb3_formal_v3/`、参考 `summary.json`、原始
CSV、论文结果表或参考验证报告。这样可以把配置选择、训练种子和停止规则
固定在复跑开始之前。

冻结的主协议如下：

| 项目 | 冻结值 |
|---|---|
| 环境 | `CartPole-v1`、`Acrobot-v1`、`MountainCar-v0`、`Taxi-v4`、`NonstationaryQueue-v0` |
| 算法 | PPO、DQN、A2C（Stable-Baselines3 2.9.2） |
| 候选配置 | `lr3e4_long`、`lr1e4_long`、`lr3e4_short`、`lr1e4_short` |
| 验证种子 | 每个候选配置 10000--10004，共 5 个 |
| 密封测试种子 | 20000--20019，共 20 个 |
| 训练预算 | 4096 steps；检查点 1024、2048、3072、4096 |
| 每检查点评估 | 5 个 episode |
| 测试检查点 | 5、10、15、20 个测试种子 |
| 统计规则 | `hoeffding_unpaired`；family alpha 0.05；comparison alpha 0.05/15 |
| 实际边际和目标宽度 | practical margin 0.05；target width 0.10 |

复跑方不得根据中间结果改变环境顺序、种子、候选配置、训练预算、评估回合、
停止规则或输出目录。如果发生程序错误，应保留失败目录和日志，记录错误后再
从同一冻结命令重试；不得删除失败记录或替换种子。

## 2. 资料包内容

资料包根目录应至少包含：

- `sequential_sb3_runner_v3.py`：正式运行器；
- `sb3_pilot.py`、`pilot_protocol.py`：模型构造和统计协议实现；
- `nonstationary_queue_env.py`：自定义环境；
- `requirements-rl.txt`、`requirements-rl-lock.txt`：依赖声明和锁定版本；
- `REPRODUCTION_MANIFEST_V3.md`、`EXTERNAL_RERUN_PROTOCOL.md`：冻结协议和来源说明；
- `collect_external_rerun_metadata.py`：采集机器、Python、包版本和源文件哈希；
- `package_external_rerun.py`：在复跑结束后打包结果；
- `validate_external_rerun.py`：作者在收到结果后执行的比较验证器；
- `test_nonstationary_queue.py`、`test_external_rerun_validator.py`：轻量检查；
- `wheels/`：随包提供的 wheel（适用于匹配的平台；跨平台时仍须检查兼容性）；
- `KIT_SHA256SUMS.txt`：资料包内部文件校验清单。

资料包不应包含任何主实验输出目录。若发现包内出现
`raw_seed_metrics.csv`、`summary.json`、`familywise_cost_summary.json` 或
`sb3_formal_v3/` 路径，应停止交接并重新构建。

## 3. 解包和完整性检查

在干净目录中执行：

```bash
tar -xzf external_rerun_kit_v3.tar.gz
cd external_rerun_kit_v3
shasum -a 256 -c KIT_SHA256SUMS.txt
```

Linux 没有 `shasum` 时使用：

```bash
sha256sum -c KIT_SHA256SUMS.txt
```

校验失败时不要继续安装或运行；把资料包 SHA-256、失败路径和操作系统信息
返回给资料包提供者。

## 4. 建立隔离环境

推荐使用 Python 3.11，并把解释器路径记录下来：

```bash
python3.11 -m venv .venv-rerun-v3
source .venv-rerun-v3/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-rl-lock.txt
```

锁定文件无法在目标平台解析时，不要静默换版本。应记录无法安装的包、目标
平台和 `pip` 错误，并先向作者报告。若使用资料包中的 wheel，仍须记录 wheel
文件哈希和平台标签；wheel 只能在其 ABI、Python 版本和 CPU 架构匹配时使用。

安装后先采集环境信息：

```bash
python collect_external_rerun_metadata.py --output preflight_metadata.json
python -m unittest -v test_nonstationary_queue.py
```

这里的单元测试不需要作者的参考结果。`test_external_rerun_validator.py`
需要 `sb3_formal_v3/`，只由作者在收到结果后运行，不能作为密封复跑方的
安装前测试。任何预检失败都不应被忽略。把 `preflight_metadata.json`、完整
错误输出和资料包 `KIT_SHA256SUMS.txt` 一并保存。

## 5. 执行密封复跑

在资料包根目录执行以下唯一主命令：

```bash
python sequential_sb3_runner_v3.py \
  --environment-ids CartPole-v1,Acrobot-v1,MountainCar-v0,Taxi-v4,NonstationaryQueue-v0 \
  --validation-seeds 5 --test-seeds 20 --initial-test-seeds 5 \
  --test-batch-size 5 --timesteps 4096 --checkpoints 4 \
  --eval-episodes 5 --family-alpha 0.05 \
  --practical-margin 0.05 --target-width 0.10 \
  --output-dir sb3_formal_v3_external_rerun
```

建议把终端输出同时保存：

```bash
python sequential_sb3_runner_v3.py ... 2>&1 | tee external_rerun.log
```

上面的省略号只表示 shell 中完整粘贴上一段命令；提交的日志必须包含完整
命令和退出状态。运行过程中不要打开作者的参考结果，也不要手工编辑输出。

运行结束后采集最终环境信息：

```bash
python collect_external_rerun_metadata.py \
  --output sb3_formal_v3_external_rerun/final_metadata.json
```

## 6. 结果自检和返还

先确认输出目录存在以下文件：

- `raw_seed_metrics.csv`；
- `run_config.json`；
- `summary.json`；
- 若运行器写出，保留 `stop_trace`、失败记录和运行时元数据。

检查行数和种子覆盖：应有 600 行，包含 300 行 validation 和 300 行 test；
每个环境--算法单元应有 5 个验证种子和 20 个测试种子。不要根据这些检查
修改数据。

打包复跑结果：

```bash
python package_external_rerun.py \
  --external-dir sb3_formal_v3_external_rerun \
  --archive external_rerun_result_v3.tar.gz \
  --metadata sb3_formal_v3_external_rerun/final_metadata.json \
  --log external_rerun.log
shasum -a 256 external_rerun_result_v3.tar.gz > external_rerun_result_v3.tar.gz.sha256
```

返还给作者的最小资料是：结果压缩包及其 SHA-256、`preflight_metadata.json`、
`final_metadata.json`、完整运行日志、资料包 SHA-256，以及任何失败或平台偏差
说明。不要只返还四舍五入后的均值或截图。

## 7. 作者收到结果后的验证

作者在单独目录解包结果，并把原始参考目录保留在本地：

```bash
python validate_external_rerun.py \
  --external-dir received_external_rerun \
  --reference-dir sb3_formal_v3 \
  --output received_external_rerun/validation_report.json
```

验证器会检查 schema、环境和算法集合、600 行记录、种子集合、候选配置、
每个单元的种子级归一化指标差异，以及 15 个最终决策状态。它不会要求不同
机器产生逐位相同的浮点数，也不会把本地验证器自测或同机重放称为独立可复现性。
作者应在检查原始结果前预先写明可接受的绝对/相对差异阈值，并报告所有偏差、
失败和缺失种子。

## 8. 独立复跑报告模板

```text
Operator/team:
Machine and OS:
CPU architecture:
Python executable and version:
NumPy / PyTorch / Gymnasium / Stable-Baselines3:
MPS/CUDA status:
Kit SHA-256:
Source-manifest hash:
Start/end time and timezone:
Completed rows:
Failed rows:
Missing seeds:
Configuration deviations:
Mean absolute metric difference by cell:
Maximum absolute metric difference:
Decision-state differences:
Stop-trace differences:
Unresolved deviations:
```

只有在原始输出、机器信息、版本偏差、失败记录和比较报告全部归档后，才能把
证据标签从“同机交叉脚本可重复”更新为“不同机器/独立团队复跑”。复跑结果
可能与参考结果不同；差异本身必须如实报告，不能为了匹配参考摘要而改动原始
数据。


"""Source-checked comparison intervals; does not replace the frozen reference.

Howard et al., arXiv:1810.08240v9: (8), (14), (21), Theorem 4,
Proposition 9. Maurer & Pontil, arXiv:0907.3740v1: Theorem 4.
All methods target the same difference of unweighted marginal means.
"""
from __future__ import annotations

import math
import numpy as np

METHODS = ('H-original', 'H-finite', 'H-uniform', 'EB-uniform',
           'CS-normal', 'CS-EB-stitch', 'CS-EB-gamma')
SENSITIVITY = ('CS-EB-gamma-rho0.1', 'CS-EB-gamma-rho10')
COMPARISON_ALPHA = .05 / 15
PAIRS = ((0, 1), (0, 2), (1, 2))
DECISIONS = ('unresolved', 'a_superior', 'b_superior', 'precision_only')
ZETA_1_4 = 3.1055472779775803997829272156889237924


def spending(method: str, count: int, alpha: float = COMPARISON_ALPHA) -> np.ndarray:
    if count < 1 or not 0 < alpha < 1:
        raise ValueError('invalid look count or alpha')
    k = np.arange(1, count + 1, dtype=float)
    if method == 'H-original':
        return alpha * 6 / (math.pi ** 2 * k ** 2)
    if method == 'H-finite':
        weights = k ** -2
        return alpha * weights / weights.sum()
    if method in ('H-uniform', 'EB-uniform'):
        return np.full(count, alpha / count)
    raise ValueError('method has no finite-look spending')


def normal_rho(n_max: int, arm_alpha: float = COMPARISON_ALPHA / 2) -> float:
    """Solve q-log(1+q)=2log(1/alpha), then rho=(n_max/4)/q."""
    if n_max < 1 or not 0 < arm_alpha < 1:
        raise ValueError('invalid horizon or arm alpha')
    target = 2 * math.log(1 / arm_alpha)
    low, high = 0., max(2., 2 * target)
    while high - math.log1p(high) < target:
        high *= 2
    for _ in range(70):
        mid = (low + high) / 2
        if mid - math.log1p(mid) < target:
            low = mid
        else:
            high = mid
    return n_max / 4 / high


def gamma_log_mixture(s, v, rho: float):
    """Howard (65), c=1; scipy.gammainc is REGULARIZED lower gamma."""
    from scipy.special import gammainc, gammaln
    if rho <= 0:
        raise ValueError('rho must be positive')
    s, v = np.broadcast_arrays(np.asarray(s, float), np.asarray(v, float))
    if np.any(s < 0) or np.any(v < 0) or not np.all(np.isfinite(s + v)):
        raise ValueError('s and v must be finite nonnegative values')
    b = v + rho
    z = s + b
    result = (rho * math.log(rho) - gammaln(rho) - math.log(gammainc(rho, rho))
              + gammaln(b) + np.log(gammainc(b, z)) - b * np.log(z) + s + v)
    if not np.all(np.isfinite(result)):
        raise ArithmeticError('non-finite log mixture')
    return result


def gamma_boundary(v, rho: float, alpha: float = COMPARISON_ALPHA / 4):
    """Upper bracket of a monotone root; no interpolation or variance rounding."""
    from scipy.special import gammainc, gammaln
    v = np.asarray(v, float)
    if not 0 < alpha < 1 or rho <= 0 or np.any(v < 0) or not np.all(np.isfinite(v)):
        raise ValueError('invalid boundary input')
    threshold = math.log(1 / alpha)
    b = v + rho
    base = (rho * math.log(rho) - gammaln(rho) - math.log(gammainc(rho, rho))
            + gammaln(b) + v)

    def log_m(s):
        z = s + b
        result = base + np.log(gammainc(b, z)) - b * np.log(z) + s
        if not np.all(np.isfinite(result)):
            raise ArithmeticError('non-finite log mixture during root search')
        return result

    low = np.zeros_like(v)
    high = np.sqrt(2 * (v + rho) * threshold) + 2 * threshold + 1
    for _ in range(30):
        insufficient = log_m(high) < threshold
        if not np.any(insufficient):
            break
        high = np.where(insufficient, 2 * high, high)
    else:
        raise ArithmeticError('failed to bracket gamma boundary')
    for _ in range(48):
        mid = (low + high) / 2
        below = log_m(mid) < threshold
        low = np.where(below, mid, low)
        high = np.where(below, high, mid)
    # Numerical safety inflation, not a proof of machine-arithmetic correctness.
    return high + 1e-10 * (1 + high)


def stitched_boundary(v, alpha: float = COMPARISON_ALPHA / 4):
    if not 0 < alpha < 1:
        raise ValueError('invalid alpha')
    v = np.asarray(v, float)
    if np.any(v < 0) or not np.all(np.isfinite(v)):
        raise ValueError('invalid variance process')
    v = np.maximum(v, 1.)
    eta, s = 2., 1.4
    ell = math.log(ZETA_1_4 / alpha) + s * np.log1p(np.log(v) / math.log(eta))
    k1 = (eta ** .25 + eta ** -.25) / math.sqrt(2)
    k2 = (math.sqrt(eta) + 1) / 2
    return np.sqrt(k1 * k1 * v * ell + k2 * k2 * ell * ell) + k2 * ell


def sufficient_statistics(values, looks):
    """Input (..., n); output (..., K). xhat_t excludes the current value."""
    x = np.asarray(values, float)
    looks = np.asarray(looks, int)
    if x.ndim < 1 or np.any(~np.isfinite(x)) or np.any((x < 0) | (x > 1)):
        raise ValueError('observations must be finite and in [0,1]')
    if (looks.ndim != 1 or len(looks) == 0 or looks[0] < 1
            or looks[-1] > x.shape[-1] or np.any(np.diff(looks) <= 0)):
        raise ValueError('looks must be increasing observed positive counts')
    cum = np.cumsum(x, axis=-1)
    predictions = np.empty_like(x)
    predictions[..., 0] = .5
    predictions[..., 1:] = cum[..., :-1] / np.arange(1, x.shape[-1])
    residuals = np.cumsum((x - predictions) ** 2, axis=-1)[..., looks - 1]
    sums = cum[..., looks - 1]
    means = sums / looks
    squares = np.cumsum(x * x, axis=-1)[..., looks - 1]
    variance = np.maximum(0., squares - sums * sums / looks) / np.maximum(looks - 1, 1)
    return {'mean': means, 'variance': variance, 'intrinsic': residuals}


def arm_radii(stats, looks, method: str, alpha: float = COMPARISON_ALPHA):
    n = np.asarray(looks, float)
    if method not in METHODS + SENSITIVITY:
        raise ValueError('unknown method')
    if not 0 < alpha < 1:
        raise ValueError('invalid alpha')
    shape = stats['mean'].shape
    if method.startswith('H-'):
        r = np.sqrt(np.log(4 / spending(method, len(n), alpha)) / (2 * n))
    elif method == 'EB-uniform':
        log_term = np.log(8 / spending(method, len(n), alpha))
        r = (np.sqrt(2 * stats['variance'] * log_term / n)
             + 7 * log_term / (3 * np.maximum(n - 1, 1)))
        r = np.where(n > 1, r, np.inf)
    elif method == 'CS-normal':
        rho = normal_rho(int(n[-1]), alpha / 2)
        v = n / 4
        r = np.sqrt((v + rho) * np.log((v + rho) / ((alpha / 2) ** 2 * rho))) / n
    elif method == 'CS-EB-stitch':
        r = stitched_boundary(stats['intrinsic'], alpha / 4) / n
    else:
        factor = .1 if method.endswith('rho0.1') else 10. if method.endswith('rho10') else 1.
        rho = factor * normal_rho(int(n[-1]), alpha / 2)
        r = gamma_boundary(stats['intrinsic'], rho, alpha / 4) / n
    return np.broadcast_to(r, shape)


def pair_intervals(stats, looks, method, alpha=COMPARISON_ALPHA):
    """Arm axis must be penultimate, typically (..., tasks, 3, K)."""
    means = stats['mean']
    if means.shape[-2] != 3:
        raise ValueError('exactly three arms required')
    radii = arm_radii(stats, looks, method, alpha)
    estimates = np.stack([means[..., a, :] - means[..., b, :] for a, b in PAIRS], axis=-2)
    radius = np.stack([radii[..., a, :] + radii[..., b, :] for a, b in PAIRS], axis=-2)
    return estimates, np.maximum(-1., estimates - radius), np.minimum(1., estimates + radius)


def locked_decisions(lower, upper, looks, margin=.05, width=.10):
    """Keep first terminal decision; retain censored n for unresolved units."""
    lower, upper = np.asarray(lower), np.asarray(upper)
    if lower.shape != upper.shape or lower.shape[-1] != len(looks):
        raise ValueError('interval shape mismatch')
    if np.any(lower > upper) or margin < 0 or width < 0:
        raise ValueError('invalid interval or threshold')
    candidates = np.where(lower > margin, 1, np.where(upper < -margin, 2,
                          np.where(upper - lower <= width, 3, 0)))
    terminal = np.zeros(lower.shape[:-1], np.int8)
    stop_n = np.full(lower.shape[:-1], looks[-1], int)
    stop_index = np.full(lower.shape[:-1], len(looks) - 1, int)
    for k, n in enumerate(looks):
        new = (terminal == 0) & (candidates[..., k] != 0)
        terminal[new] = candidates[..., k][new]
        stop_n[new] = n
        stop_index[new] = k
    return terminal, stop_n, stop_index


def shared_arm_prefixes(pair_stop_n):
    """No double-counting: an arm continues until both dependent pairs stop."""
    pair_stop_n = np.asarray(pair_stop_n)
    if pair_stop_n.shape[-1] != 3:
        raise ValueError('three pair stopping times required')
    return np.stack([np.maximum(pair_stop_n[..., 0], pair_stop_n[..., 1]),
                     np.maximum(pair_stop_n[..., 0], pair_stop_n[..., 2]),
                     np.maximum(pair_stop_n[..., 1], pair_stop_n[..., 2])], axis=-1)

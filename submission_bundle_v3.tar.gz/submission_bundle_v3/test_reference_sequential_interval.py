import math
import unittest

from reference_sequential_interval import alpha_spend, decide, unpaired_hoeffding_interval


class ReferenceSequentialIntervalTests(unittest.TestCase):
    def test_alpha_spending_is_bounded_by_comparison_alpha(self):
        comparison_alpha = 0.05 / 15
        spent = sum(alpha_spend(comparison_alpha, look) for look in range(1, 5))
        self.assertLessEqual(spent, comparison_alpha)

    def test_unpaired_interval_matches_equal_sample_formula(self):
        values_a = [0.8, 0.9]
        values_b = [0.2, 0.3]
        look_alpha = 0.01
        estimate, lower, upper = unpaired_hoeffding_interval(values_a, values_b, look_alpha)
        radius = 2 * math.sqrt(math.log(4 / look_alpha) / (2 * 2))
        self.assertAlmostEqual(estimate, 0.6)
        self.assertAlmostEqual(lower, max(-1.0, 0.6 - radius))
        self.assertAlmostEqual(upper, min(1.0, 0.6 + radius))

    def test_decision_checks_superiority_before_precision(self):
        self.assertEqual(decide(0.2, 0.3, 0.05, 0.2), "a_superior")
        self.assertEqual(decide(-0.3, -0.2, 0.05, 0.2), "b_superior")
        self.assertEqual(decide(-0.01, 0.01, 0.05, 0.02), "precision_only")
        self.assertEqual(decide(-0.2, 0.2, 0.05, 0.1), "continue")

    def test_interval_rejects_values_outside_declared_range(self):
        with self.assertRaises(ValueError):
            unpaired_hoeffding_interval([1.1], [0.2], 0.01)


if __name__ == "__main__":
    unittest.main()

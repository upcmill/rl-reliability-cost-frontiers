#!/usr/bin/env python3
"""Independently validate the completed V7 data and frozen analysis outputs."""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

from analyze_v7_confirmation import ENVS, ALGORITHMS, N, analyze, load_values

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "sb3_v7_confirmation"
ANALYSIS = DATA / "analysis"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    lock = json.loads((ROOT / "V7_CONFIRMATION_LOCK.json").read_text())
    for relative, expected in lock["hashes"].items():
        if sha(ROOT / relative) != expected:
            raise AssertionError(f"frozen source hash mismatch: {relative}")
    run = json.loads((DATA / "run_config.json").read_text())
    raw_path = DATA / "raw_seed_metrics.csv"
    config = json.loads((ROOT / "sb3_v5_extension/run_config.json").read_text())["selected_configurations"]
    counts = Counter()
    keys = set()
    with raw_path.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            env, algorithm, seed = row["env_id"], row["algorithm"], int(row["train_seed"])
            key = (env, algorithm, seed)
            if key in keys:
                raise AssertionError(f"duplicate key: {key}")
            keys.add(key)
            if row["status"] != "ok" or row["split"] != "v7_confirmation":
                raise AssertionError(f"unsuccessful row: {key}")
            if row["config_id"] != config[f"{env}:{algorithm}"]:
                raise AssertionError(f"configuration drift: {key}")
            if int(row["evaluation_seed_base"]) != seed + 1_000_000:
                raise AssertionError(f"evaluation seed drift: {key}")
            if not math.isfinite(float(row["runtime_seconds"])) or float(row["runtime_seconds"]) < 0:
                raise AssertionError(f"invalid runtime: {key}")
            counts[(env, algorithm)] += 1
    expected_keys = len(ENVS) * len(ALGORITHMS) * N
    if len(keys) != expected_keys or any(counts[(e,a)] != N for e in ENVS for a in ALGORITHMS):
        raise AssertionError("row count does not match the frozen 15 x 1,000 design")
    if run["status"] != "COMPLETED" or run["completed_rows"] != expected_keys:
        raise AssertionError("run metadata does not mark the complete run")
    values = load_values(raw_path)
    intervals, computed = analyze(values)
    stored = json.loads((ANALYSIS / "summary.json").read_text())
    if computed != stored or len(intervals) != 9 * 5 * 3 * 5:
        raise AssertionError("stored analysis differs from deterministic recomputation")
    manifest = json.loads((ANALYSIS / "ANALYSIS_MANIFEST.json").read_text())
    if manifest["input_sha256"] != sha(raw_path):
        raise AssertionError("analysis input hash mismatch")
    for filename, digest in manifest["outputs"].items():
        if sha(ANALYSIS / filename) != digest:
            raise AssertionError(f"analysis output hash mismatch: {filename}")
    report = {
        "status": "PASS",
        "rows": len(keys),
        "cells": len(counts),
        "seeds_per_cell": N,
        "seed_range": [31400, 32399],
        "frozen_source_hashes_match": True,
        "config_and_evaluation_seed_checks": "PASS",
        "stored_analysis_matches_deterministic_recomputation": True,
        "runner_terminal_message_exception": "JSON printing raised TypeError after COMPLETED metadata and all 15,000 CSV rows were written; no data-generation exception was recorded.",
        "scope": "post-hoc prospective new-seed validation on a fixed five-task panel; not independent-team reproduction or coverage validation",
        "sha256": {"raw_seed_metrics.csv": sha(raw_path),
                   "run_config.json": sha(DATA / "run_config.json"),
                   "summary.json": sha(ANALYSIS / "summary.json")},
    }
    (ROOT / "V7_CONFIRMATION_AUDIT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

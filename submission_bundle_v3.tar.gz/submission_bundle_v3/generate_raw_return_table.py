#!/usr/bin/env python3
"""Generate raw-return summaries for the selected v3 test configurations."""

from __future__ import annotations

import csv
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ENVIRONMENTS = ("CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0")
ALGORITHMS = ("PPO", "DQN", "A2C")


def main() -> None:
    values: dict[tuple[str, str], list[float]] = defaultdict(list)
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["split"] == "test":
                values[(row["env_id"], row["algorithm"])].append(float(row["metric_raw"]))

    lines = [
        "# v3 Selected-Test Raw-Return Table",
        "",
        "Generated from `sb3_formal_v3/raw_seed_metrics.csv`; each row contains 20 selected-configuration test seeds.",
        "Raw returns are descriptive and are not pooled across tasks because the tasks have different reward scales.",
        "",
        "| Environment | Algorithm | Mean raw return | Sample SD | Median | Minimum | Maximum |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for environment in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            sample = values[(environment, algorithm)]
            if len(sample) != 20:
                raise ValueError(f"expected 20 test returns for {environment}/{algorithm}, got {len(sample)}")
            lines.append(
                f"| {environment} | {algorithm} | {statistics.mean(sample):.6f} | "
                f"{statistics.stdev(sample):.6f} | {statistics.median(sample):.6f} | "
                f"{min(sample):.6f} | {max(sample):.6f} |"
            )
    output = ROOT / "RAW_RETURN_TABLE_V3.md"
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()

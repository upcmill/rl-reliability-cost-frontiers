# Machine Learning Journal Contribution Information Sheet

**Submission title:** Reliability--Cost Frontiers for Sequential Evaluation of
Reinforcement Learning Algorithms

**Article type:** Original research article [待核实 against the submission
system's current article-type menu].

**Authors and corresponding author:** [待补充]

## Main Claim

Under explicit bounded-metric, validation-conditioning, fixed-look, and
within-algorithm seed-independence assumptions, a finite-look unpaired Hoeffding
interval provides conditional family-wise coverage for a predeclared RL
comparison family. In the frozen v3 design, the 20-test-seed budget is
structurally unable to reach either the 0.05 practical-superiority margin or the
0.10 precision target for any bounded data. The 15 observed comparisons are
therefore a reliability--cost resolution characterization, not an algorithm
ranking.

## Why It Matters

RL benchmark papers often report point estimates after configuration selection
and repeated inspection of random-seed results. This can make a small observed
difference look more decisive than the disclosed evidence supports. The paper
turns that concern into an auditable estimand and state machine: validation-only
selection, sealed test seeds, fixed looks, family-level alpha allocation, and a
recorded stopping cost. It also separates same-machine cross-script
repeatability from different-machine reproducibility and independent-team
scientific replication.

## Distinction From Prior Work

Prior work has documented RL reproducibility problems, seed uncertainty,
overfitting, reliability metrics, and theoretical confidence/early-stopping
rules. This paper does not claim to introduce RL reliability measurement
generally or theoretical RL stopping rules. Its narrower distinction is the explicit
combination of a conditional post-validation estimand, an unpaired bounded
finite-look family construction, sealed test execution, and an empirical
resolution-cost diagnostic across a frozen RL task family. The literature-wide
novelty of this exact combination remains `[待核实]` pending database exports
and independent second screening.

## Evidence

- The theorem and proof establish conditional finite-look coverage under
  stated assumptions; they do not claim unconditional coverage.
- The analytic non-resolution corollary proves that the formal 20-seed v3
  budget cannot trigger the declared rules for any bounded data.
- The primary artifact contains 600 rows: 300 validation and 300 sealed test
  rows, with 15/15 comparisons reaching `max_budget_inconclusive`.
- The prospective v4 extension contains 6,000 new-seed rows; one controlled
  queue comparison resolves at 200 seeds and 14/15 remain unresolved at 400.
- The v5 extension contains 15,000 new-seed rows; four comparisons resolve by
  1,000 seeds and 11 remain unresolved.
- The v6 extension contains 1,440 rows from two additional fixed discrete tasks;
  all six comparisons remain unresolved at 200 seeds. It is a same-machine
  execution and scope diagnostic, not pooled evidence or cross-family power.
- A prospective-within-workspace tuning extension evaluates the same four
  candidates on 20 new validation seeds per candidate. Seven of 15 selected
  configurations change relative to v3; this is selection-sensitivity evidence,
  not a universal validation-seed rule or a pooled performance result.
- A separately implemented same-machine replay reproduces all 15 v3 summaries
  with zero recorded mean-metric differences. A sealed Windows AMD64 rerun also
  matches all 15 selected configurations and terminal decisions; 14/15 cells
  have zero seed-level differences and one reports a platform difference. This
  is different-machine reproducibility evidence, not proof of independent-team
  identity or new-family scientific replication.

All numerical claims are traceable to the raw CSV/JSON artifacts and audit
scripts in the submission package. No independent-team identity or public
repository DOI is currently claimed.

## Scope and Limitations

The primary family contains five discrete-action tasks, including one disclosed
controlled queue. The v6 task-family extension adds two discrete tasks as a
separate scope diagnostic. Continuous-control and partial-observation runs are
supplements, not pooled evidence. The results do not support universal seed
requirements, general PPO/DQN/A2C rankings, universal compute savings, or
generalization to all RL environments. The public archive, second literature
screener, and author declarations remain submission gates. The different-
machine rerun is complete, while independent-team identity and new-family
scientific replication remain outside the current evidence.

## Materials and Declarations

- Data availability statement: [待补充 public repository or archive DOI/URL].
- Code availability statement: [待补充 public repository or archive DOI/URL].
- Funding: [待补充].
- Competing interests: [待补充].
- Ethics/data statement: simulated control environments only; no human,
  personal, or animal data are used.
- Author contributions: [待补充].

This sheet is a submission preparation artifact. It does not claim editorial
acceptance, SCI/SCIE indexing, or publication readiness until the bracketed
fields and external evidence gates are completed.

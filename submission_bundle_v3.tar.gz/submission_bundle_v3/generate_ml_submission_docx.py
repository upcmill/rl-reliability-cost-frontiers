"""Generate the Machine Learning submission DOCX from its audited Markdown."""

from __future__ import annotations

import re
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from docx.opc.constants import RELATIONSHIP_TYPE as RT


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.md"
OUTPUT = ROOT / "MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.docx"


def clean_inline(text: str) -> str:
    text = re.sub(r"!\[([^]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", text)
    return text.replace("**", "").replace("__", "").replace("`", "").replace("$", "").strip()


def add_markdown_runs(paragraph, text: str, size=None, bold=False) -> None:
    from copy import deepcopy
    pattern = re.compile(r"\[([^]]+)\]\((https?://[^)]+)\)")
    def add_run(value):
        value = value.replace("**", "").replace("__", "").replace("`", "").replace("$", "")
        run = paragraph.add_run(value)
        if size:
            run.font.size = Pt(size)
        run.bold = bold
        return run
    cursor = 0
    for match in pattern.finditer(text):
        if match.start() > cursor:
            add_run(text[cursor:match.start()])
        relationship = paragraph.part.relate_to(match.group(2), RT.HYPERLINK, is_external=True)
        hyperlink = OxmlElement("w:hyperlink")
        hyperlink.set(qn("r:id"), relationship)
        run = add_run(match.group(1))
        run.font.color.rgb = RGBColor.from_string("0563C1")
        run.underline = True
        hyperlink.append(run._r)
        paragraph._p.append(hyperlink)
        cursor = match.end()
    if cursor < len(text):
        add_run(text[cursor:])


def configure(doc: Document) -> None:
    section = doc.sections[0]
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(2.54)
    section.right_margin = Cm(2.54)
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.line_spacing = 1.15
    normal.paragraph_format.space_after = Pt(5)
    for name, size in (("Title", 16), ("Heading 1", 13), ("Heading 2", 11), ("Heading 3", 10.5)):
        style = doc.styles[name]
        style.font.name = "Times New Roman"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(31, 31, 31)
        style.paragraph_format.keep_with_next = True


def add_table(doc: Document, lines: list[str]) -> None:
    rows = []
    for line in lines:
        if set(line.strip()) <= {"|", "-", ":", " "}:
            continue
        rows.append([value.strip() for value in line.strip().strip("|").split("|")])
    if not rows:
        return
    table = doc.add_table(rows=1, cols=len(rows[0]))
    table.style = "Table Grid"
    for row_index, values in enumerate(rows):
        cells = table.rows[0].cells if row_index == 0 else table.add_row().cells
        for column, cell in enumerate(cells):
            cell.text = ""
            paragraph = cell.paragraphs[0]
            paragraph.paragraph_format.space_after = Pt(0)
            add_markdown_runs(paragraph, values[column] if column < len(values) else "", size=8.5, bold=row_index == 0)
            run = paragraph.runs[-1] if paragraph.runs else paragraph.add_run("")
            run.font.name = "Times New Roman"
            run._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
            run.font.size = Pt(8.5)
            if row_index == 0:
                run.bold = True
                shade = OxmlElement("w:shd")
                shade.set(qn("w:fill"), "D9E2F3")
                cell._tc.get_or_add_tcPr().append(shade)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        tr_pr = table.rows[-1]._tr.get_or_add_trPr()
        cant_split = OxmlElement("w:cantSplit")
        tr_pr.append(cant_split)
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    table.rows[0]._tr.get_or_add_trPr().append(header)
    doc.add_paragraph()


def build() -> None:
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    doc = Document()
    configure(doc)
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        if not line:
            index += 1
            continue
        if line.startswith("# "):
            paragraph = doc.add_paragraph(clean_inline(line[2:]), style="Title")
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            index += 1
            continue
        if line.startswith("## "):
            doc.add_paragraph(clean_inline(line[3:]), style="Heading 1")
            index += 1
            continue
        if line.startswith("### "):
            doc.add_paragraph(clean_inline(line[4:]), style="Heading 2")
            index += 1
            continue
        if line.startswith("#### "):
            doc.add_paragraph(clean_inline(line[5:]), style="Heading 3")
            index += 1
            continue
        if line.startswith("|"):
            table_lines = []
            while index < len(lines) and lines[index].startswith("|"):
                table_lines.append(lines[index])
                index += 1
            add_table(doc, table_lines)
            continue
        if line.startswith("```"):
            index += 1
            code = []
            while index < len(lines) and lines[index].strip() != "```":
                code.append(lines[index])
                index += 1
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.left_indent = Cm(0.6)
            run = paragraph.add_run("\n".join(code))
            run.font.name = "Menlo"
            run.font.size = Pt(8)
            index += 1
            continue
        if line.startswith("- "):
            paragraph = doc.add_paragraph(style="List Bullet")
            add_markdown_runs(paragraph, line[2:])
            index += 1
            continue
        if re.match(r"^\d+\. ", line):
            paragraph = doc.add_paragraph(style="List Number")
            add_markdown_runs(paragraph, re.sub(r"^\d+\. ", "", line))
            index += 1
            continue
        paragraph_lines = [line]
        index += 1
        while index < len(lines) and lines[index].strip():
            next_line = lines[index].strip()
            if next_line.startswith(("#", "|", "- ", "```")) or re.match(r"^\d+\. ", next_line):
                break
            paragraph_lines.append(next_line)
            index += 1
        text = " ".join(paragraph_lines)
        if clean_inline(text).startswith("Submission preparation draft for Machine Learning"):
            continue
        paragraph = doc.add_paragraph()
        add_markdown_runs(paragraph, text)
        paragraph.paragraph_format.first_line_indent = Cm(0.4)
    doc.save(OUTPUT)
    print(f"Generated {OUTPUT.name}")


if __name__ == "__main__":
    build()

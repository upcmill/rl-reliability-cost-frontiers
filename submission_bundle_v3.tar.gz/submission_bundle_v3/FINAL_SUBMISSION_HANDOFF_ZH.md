# 最终投稿交接清单

本文件说明当前稿件完成后，作者在正式投稿前仍需补齐的外部信息。它不
替代期刊投稿系统，也不把本地文件或未核实资料当作公开证据。

## 当前状态

- 稿件、补充材料、实验原始数据、审计脚本和 Word 文件已经在当前工作区
  完成并通过内部审计。
- 当前提交包状态：`submission_candidate_with_blockers`。
- 当前提交包：`submission_bundle_v3.tar.gz`；权威哈希在同名 `.sha256`
  文件中。
- 作者姓名、单位、邮箱、ORCID、贡献、基金、利益冲突和许可证继续使用
  `[待补充]`，不得由代理人猜测。

## 闸门一：公开代码和数据归档

作者需要将提交包发布到 GitHub 加 Zenodo、OSF、Figshare 或机构仓储，获得
一个无需登录即可访问的永久 URL 或 DOI。

必须保存：

1. 公开仓库 URL、归档 DOI、release/tag 和许可证；
2. 下载后的归档 SHA-256；
3. 代码可用性声明和数据可用性声明。

回填文件：`SUBMISSION_METADATA_TEMPLATE.md`、`CITATION_CFF_TEMPLATE.yml`、
`PUBLIC_DEPOSITION_README.md`、中英文主稿和投稿信。

验收条件：URL/DOI 可在无登录窗口访问，下载归档哈希与本地侧车文件一致，
且 `audit_public_archive_safety.py` 通过。

## 闸门二：独立文献筛选

从 Web of Science、Scopus、IEEE Xplore、ACM Digital Library 和可用的
Google Scholar 入口保存原始导出文件。每个数据库都要记录检索式、日期、
筛选条件、返回数、导出文件哈希和去重规则。

第二位研究者在看到第一位筛选决定前，独立标记去重后的标题/摘要：
`include`、`exclude` 或 `uncertain`，并填写排除理由。双方完成后保存冲突
清单、仲裁规则和最终纳入表。

回填文件：`LITERATURE_SEARCH_LOG.md`、`LITERATURE_SCREENING_TABLE.md`、
`SYSTEMATIC_NOVELTY_REVIEW.md`。

在此闸门关闭前，保留主稿中的 `[待核实]`，不得写“首次提出”或“文献中没有
类似工作”。

## 闸门三：作者和声明字段

由作者本人确认以下字段：

| 字段 | 允许的确认形式 |
|---|---|
| 作者姓名、单位、通讯邮箱、ORCID | 真实投稿信息 |
| CRediT 贡献 | 作者逐项确认角色 |
| 基金 | 资助机构和项目号；无基金时明确 `No external funding` |
| 利益冲突 | 作者确认声明；无冲突时明确 `No competing interests` |
| 代码/数据许可证 | SPDX 标识或仓储平台许可证 |
| Windows 复跑操作者 | 身份、单位、日期以及是否与作者独立 |

回填文件：`SUBMISSION_METADATA_TEMPLATE.md`、`MLJ_CONTRIBUTION_INFORMATION_SHEET.md`、
中英文主稿、投稿信和 `CITATION_CFF_TEMPLATE.yml`。

## 回填后的固定命令

```bash
python3 audit_submission_placeholders.py
python3 audit_public_archive_safety.py
python3 audit_manuscript_numeric_claims.py
python3 audit_manuscript_structure.py
python3 audit_word_manuscript_parity.py
python3 submission_readiness_audit.py
python3 generate_reproduction_hashes.py
python3 build_submission_bundle.py --output submission_bundle_v3.tar.gz
./.rl-arm64-venv/bin/python -m unittest -q
```

只有当投稿就绪度审计不再报告这三个 blocked gate，才可以把状态改为正式
投稿准备完成。内部审计通过不等于期刊接收，也不等于 SCI 收录保证。

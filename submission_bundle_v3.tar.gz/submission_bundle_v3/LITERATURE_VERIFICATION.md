# Literature Verification Record

This record contains only sources checked against an authoritative landing page
or metadata service on 2026-10-29 and 2026-10-30. It is a source audit, not a complete
literature review. A source is marked as an arXiv preprint when no journal or
conference publication was used in the claim.

The companion `LITERATURE_SCREENING_TABLE.md` records screened candidates that
were not necessarily admitted to the verified bibliography. Screening a record
does not establish that the current protocol is novel relative to it.

## Verified sources

| ID | Verified bibliographic record | Source checked | Claims this source can support | Claims it cannot support |
|---|---|---|---|---|
| L1 | Henderson, Islam, Bachman, Pineau, Precup, and Meger (2018), “Deep Reinforcement Learning That Matters,” *Proceedings of the AAAI Conference on Artificial Intelligence*, 32(1). DOI: `10.1609/aaai.v32i1.11694`. | Crossref record and AAAI landing page: <https://doi.org/10.1609/aaai.v32i1.11694> | Deep-RL results can vary with environment nondeterminism and algorithm variance; reproducibility and reporting procedures matter. | It does not establish a universal seed count, a sequential stopping guarantee, or the performance of the present protocol. |
| L2 | Colas, Sigaud, and Oudeyer (2018), “How Many Random Seeds? Statistical Power Analysis in Deep Reinforcement Learning Experiments,” arXiv:1806.08295. DOI: `10.48550/arXiv.1806.08295`. | arXiv record: <https://arxiv.org/abs/1806.08295> | Seed count affects statistical error and power; departures from test assumptions can affect evaluation. | It does not validate the current Hoeffding implementation or imply that one seed budget works for all RL tasks. |
| L3 | Colas, Sigaud, and Oudeyer (2019), “A Hitchhiker's Guide to Statistical Comparisons of Reinforcement Learning Algorithms,” arXiv:1904.06979. DOI: `10.48550/arXiv.1904.06979`. | arXiv record: <https://arxiv.org/abs/1904.06979> | Statistical tests should be compared using false-positive rate, power, sample size, effect size, and robustness to assumptions. | It does not provide evidence for the present benchmark results or an arbitrary-distribution sequential guarantee. |
| L4 | Agarwal, Schwarzer, Castro, Courville, and Bellemare (2021), “Deep Reinforcement Learning at the Edge of the Statistical Precipice,” arXiv:2108.13264. DOI: `10.48550/arXiv.2108.13264`. | arXiv record: <https://arxiv.org/abs/2108.13264> | Few-run deep-RL evaluations can have substantial uncertainty; interval estimates, performance profiles, and robust aggregate metrics are relevant. | The current project must not cite the arXiv record alone as proof of a specific venue publication, universal benchmark ranking, or a prescribed number of seeds. Venue status: [待核实]. |
| L5 | Hoeffding (1963), “Probability Inequalities for Sums of Bounded Random Variables,” *Journal of the American Statistical Association*, 58(301), 13–30. DOI: `10.1080/01621459.1963.10500830`. | Crossref record: <https://doi.org/10.1080/01621459.1963.10500830> | The bounded-variable concentration inequality used as the mathematical basis for the interval radius. | It does not by itself justify the RL estimand, configuration-selection split, alpha spending, or family-wise construction.
| L6 | Lan and DeMets (1983), “Discrete Sequential Boundaries for Clinical Trials,” *Biometrika*, 70(3), 659–663. DOI: `10.1093/biomet/70.3.659`. | Crossref record: <https://doi.org/10.1093/biomet/70.3.659> | Sequential monitoring and pre-specified error spending are established statistical design ideas. | It is not an RL paper and does not validate the specific `6/(pi^2 k^2)` spending schedule without the present proof.

| L7 | Schulman, Wolski, Dhariwal, Radford, and Klimov (2017), “Proximal Policy Optimization Algorithms,” arXiv:1707.06347. | arXiv abstract record: <https://arxiv.org/abs/1707.06347> | PPO is the source algorithm named in the comparison matrix. | It does not validate Stable-Baselines3 defaults, the present training budget, or the evaluation protocol. |
| L8 | Mnih et al. (2015), “Human-level control through deep reinforcement learning,” *Nature*, 518, 529--533. DOI: `10.1038/nature14236`. | Crossref record: <https://doi.org/10.1038/nature14236> | DQN is a historical source for the value-based algorithm family used as a baseline. | It does not validate the present DQN implementation or benchmark results. |
| L9 | Mnih et al. (2016), “Asynchronous Methods for Deep Reinforcement Learning,” *Proceedings of ICML*. | arXiv abstract record with ICML 2016 reference: <https://arxiv.org/abs/1602.01783> | Historical actor-critic context for the A2C/A3C family. | It is not a citation for exact Stable-Baselines3 A2C defaults or the present results. |
| L10 | Towers et al. (2025), “Gymnasium: A Standard Interface for Reinforcement Learning Environments,” *Advances in Neural Information Processing Systems 38*, 163114--163129. DOI: `10.52202/085713-4916`. | Crossref record: <https://doi.org/10.52202/085713-4916> | Software/environment interface used in the formal run. | It does not validate the custom queue task or the present normalization choices. |
| L11 | Whiteson, Tanner, Taylor, and Stone (2011), “Protecting against evaluation overfitting in empirical reinforcement learning,” *2011 IEEE Symposium on Adaptive Dynamic Programming and Reinforcement Learning (ADPRL)*, 120--127. DOI: `10.1109/ADPRL.2011.5967363`. | Crossref DOI metadata and its linked IEEE resource record: <https://doi.org/10.1109/ADPRL.2011.5967363> | The verified title and venue establish evaluation overfitting as an empirical RL evaluation concern. | The full text was not retrieved in this run; no specific method, theorem, or empirical result is attributed to it, and it does not by itself establish the distinction or novelty of the present protocol. |
| L12 | Raffin, Hill, Gleave, Kanervisto, Ernestus, and Dorman (2021), “Stable-Baselines3: Reliable Reinforcement Learning Implementations,” *Journal of Machine Learning Research*, 22(268), 1--8. | Official Stable-Baselines3 `CITATION.bib` and JMLR landing page: <https://github.com/DLR-RM/stable-baselines3/blob/master/CITATION.bib> and <https://jmlr.org/papers/v22/20-1364.html> | Software provenance for the Stable-Baselines3 implementation used in the experiments. | It does not validate the present hyperparameters, results, statistical protocol, or reproducibility claims. |
| L13 | Zhang, Vinyals, Munos, and Bengio (2018), “A Study on Overfitting in Deep Reinforcement Learning,” arXiv:1804.06893v2. DOI: `10.48550/arXiv.1804.06893`. | arXiv API XML and abstract page retrieved on 2026-10-30; raw files in `literature_search_raw/2026-10-30_retry/`. | Supports the bounded background statement that deep-RL agents can overfit and that training performance can differ from test performance, motivating separation of configuration selection and sealed evaluation. | It does not validate the present finite-look interval, alpha schedule, benchmark results, or a literature-wide novelty claim. |
| L14 | Nagarajan, Warnell, and Stone (2018), “Deterministic Implementations for Reproducibility in Deep Reinforcement Learning,” arXiv:1809.05676v5. DOI: `10.48550/arXiv.1809.05676`. | arXiv API XML and abstract page retrieved on 2026-10-30; raw files in `literature_search_raw/2026-10-30_retry/`. | Supports the distinction between deterministic implementation controls and reproducibility concerns caused by training nondeterminism. | It does not establish the present protocol's external reproducibility, seed budget, interval validity, or algorithm ranking. |
| L15 | Chan, Fishman, Canny, Korattikara, and Guadarrama (2019), “Measuring the Reliability of Reinforcement Learning Algorithms,” arXiv:1912.05663v2. DOI: `10.48550/arXiv.1912.05663`. | arXiv API XML and abstract page retrieved on 2026-10-30; OpenAlex DOI record and raw files in `literature_search_raw/2026-10-30_openalex_screening/`. | Supports the statement that prior RL work has proposed reliability metrics, statistical comparison tools, and reporting recommendations for variability and risk. | It does not validate the present finite-look alpha-spending construction, sealed post-validation estimand, v3 family budget, or external reproducibility. Full-text method-level comparison remains `[待核实]`. |
| L16 | Khamaru, Xia, Wainwright, and Jordan (2022), “Instance-Dependent Confidence and Early Stopping for Reinforcement Learning,” arXiv:2201.08536. DOI: `10.48550/arXiv.2201.08536`. | arXiv API XML and abstract page retrieved on 2026-10-30; OpenAlex discovery record and raw files in `literature_search_raw/2026-10-30_openalex_screening/`. | Supports the statement that RL theory includes instance-dependent confidence regions and data-dependent early-stopping rules for policy evaluation or optimal-value estimation. | It is not the present empirical training-seed comparison, validation-selected configuration estimand, or family-wise benchmark protocol; full-text relation remains `[待核实]`. |

## Screened but not admitted as verified protocol evidence

- Mrzljak and Hrkać (2019), “Experimental Evaluation of Deep Reinforcement
  Learning Algorithms,” DOI `10.20532/ccvw.2018.0003`, is a verified
  proceedings record with an OpenAlex abstract describing an Atari Breakout
  algorithm comparison. It is retained in the screening table because its
  topic is adjacent, but it is not used to support a claim about sequential
  inference, sealed testing, bounded coverage, or the novelty of this protocol.
  Full-text comparison was not completed because the linked host was
  temporarily unreachable; stronger content statements remain `[待核实]`.
- The full text of Whiteson et al. (2011) was not retrieved in this run, so
  method-level comparison remains `[待核实]`. The verified metadata is used
  only for the bounded background statement that evaluation overfitting is an
  established empirical RL concern.

## How the verified literature changes the manuscript

1. The introduction may state that RL evaluation is sensitive to seed
   variability, nondeterminism, evaluation overfitting, and statistical
   assumptions, citing L1–L4 and L11–L16.
2. The motivation for reporting seed-level distributions, power, effect sizes,
   and interval estimates may cite L2–L4.
3. The methods section should cite L5 for the bounded concentration result and
   prove the independent-sample, finite-look construction used here. L6 can be
   cited only as background for sequential error spending.
4. Stable-Baselines3 may be cited as L12 for implementation provenance; the
   citation does not validate defaults or results.
5. The paper must describe the present results as a pilot reliability–cost
   characterization. None of L1–L16 supports a claim that PPO, DQN, or A2C is
   generally superior, or that the protocol universally saves test seeds.

## Unverified items that remain excluded

- Any claim about the final publication venue or award status of L4: [待核实].
- Any claim that the current protocol is novel relative to all RL evaluation
  protocols: [待核实]. This requires a systematic search, not citation by
  analogy.
- Stable-Baselines3 implementation metadata is locally verified as version
  2.9.2. Its peer-reviewed JMLR software citation is now verified as L12 from
  the official repository citation file and JMLR landing page. This citation
  remains software provenance only and does not support claims about the
  present implementation defaults or results.
- Any different-machine or different-team reproduction result: unavailable;
  the current evidence is same-machine cross-script repeatability only.


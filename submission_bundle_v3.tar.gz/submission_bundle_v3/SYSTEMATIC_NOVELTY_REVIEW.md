# Scoping Novelty Review for the RL Evaluation Protocol

This record is a transparent scoping review, not a claim of exhaustive
literature coverage. Its purpose is to prevent an unsupported novelty claim in
the manuscript.

## Review question

Which published or openly archived studies already combine (i) seed-level
RL evaluation, (ii) configuration-selection/test separation, (iii) sequential
or repeated interim inspection control, (iv) bounded or confidence-sequence
inference, and (v) an explicit reliability--compute characterization?

## Search record

- Date: 2026-10-29.
- Sources queried: Crossref works API, OpenAlex works API when reachable, and
  the authoritative landing pages already recorded in `LITERATURE_VERIFICATION.md`.
- Search strings:
  - `deep reinforcement learning evaluation statistical significance random seeds`
  - `reinforcement learning reproducibility benchmark evaluation seeds`
  - `reinforcement learning algorithm comparison statistical tests benchmark`
  - `confidence sequences sequential evaluation machine learning`
  - `adaptive sampling reinforcement learning algorithm evaluation`
  - `deep reinforcement learning reporting best practices reproducibility`
- Screening: titles/abstracts were retained when they addressed RL evaluation,
  seeds, uncertainty, reproducibility, or sequential inference. Algorithm
  papers without an evaluation-method contribution were used only as baseline
  citations. Metadata was accepted only when a DOI, official conference,
  publisher, or arXiv record could be checked.

The network was intermittent during the search. Consequently this file does
not claim a complete systematic review, and the manuscript retains a
qualification on literature-wide novelty.

## Verified positioning set

| Source | Established relevance | Relation to this manuscript | Remaining distinction to verify |
|---|---|---|---|
| Henderson et al. (2018), *Deep Reinforcement Learning That Matters* [L1] | RL results are sensitive to seeds, nondeterminism, and reporting choices. | Motivates seed-level and implementation disclosure. | Does not provide the present finite-look unpaired protocol. |
| Colas et al. (2018), *How Many Random Seeds?* [L2] | Seed count, statistical power, and error assumptions matter. | Motivates explicit seed budgets and power diagnostics. | Does not establish the present family-level sequential construction. |
| Colas et al. (2019), *A Hitchhiker's Guide* [L3] | RL comparison tests should be assessed by error, power, effect size, and robustness. | Motivates the diagnostic matrix. | Does not validate this estimand or implementation. |
| Agarwal et al. (2021), *Deep Reinforcement Learning at the Edge of the Statistical Precipice* [L4] | Few-run deep-RL estimates can be highly uncertain. | Motivates distributional reporting and interval emphasis. | Does not establish this finite-look protocol or its venue status. |
| Hoeffding (1963) [L5] | Bounded-variable concentration inequality. | Mathematical basis for the primary radius. | Does not supply the RL estimand, selection conditioning, or family construction. |
| Lan and DeMets (1983) [L6] | Sequential monitoring and error spending. | Background for predeclared finite looks. | Not an RL evaluation study and not a citation for this exact schedule. |
| Schulman et al. (2017) [L7], Mnih et al. (2015, 2016) [L8--L9] | Sources for PPO, DQN, and actor-critic baseline families. | Baseline algorithm provenance. | Do not validate the evaluation protocol or results. |
| Towers et al. (2025) [L10] | Gymnasium interface and environment software record. | Software provenance. | Does not validate the custom queue or normalization. |
| Mrzljak and Hrkać (2019), “Experimental Evaluation of Deep Reinforcement Learning Algorithms” | Adjacent algorithm-comparison experiment on Atari Breakout; DOI and metadata verified. | Shows that benchmark comparison papers exist, so the present contribution cannot be framed as the first RL comparison study. | The available abstract does not show configuration-selection/test separation, finite-look bounded inference, or a reliability--cost frontier; full-text comparison remains `[待核实]`. |
| Whiteson et al. (2011), “Protecting against evaluation overfitting in empirical reinforcement learning” [L11] | Verified metadata directly identifies evaluation overfitting as an empirical RL concern. | Motivates keeping selection and test evidence separate. | Full-text method comparison was not completed; it may overlap with test-set protection, so literature-wide novelty remains `[待核实]`. |

| Zhang et al. (2018), “A Study on Overfitting in Deep Reinforcement Learning” [L13] | The verified abstract reports multiple forms of RL overfitting and train/test performance gaps. | Directly motivates a validation/test split and prevents presenting the split as an unanticipated observation. | The abstract does not establish overlap with the present finite-look family control or reliability--cost estimand; full-text protocol comparison remains `[待核实]`. |
| Nagarajan et al. (2018), “Deterministic Implementations for Reproducibility in Deep Reinforcement Learning” [L14] | The verified abstract studies sources of training nondeterminism and their effect on performance variance. | Motivates recording implementation, environment, and seed provenance and separating repeatability from reproducibility. | The abstract does not establish overlap with the present inferential protocol; full-text comparison remains `[待核实]`. |
| Chan et al. (2019), “Measuring the Reliability of Reinforcement Learning Algorithms” [L15] | The verified abstract proposes RL reliability metrics for variability and risk, statistical comparison tools, and reporting recommendations. | Establishes that reliability measurement and statistical comparison in RL are already active research topics. | The abstract does not establish the present finite-look alpha spending, conditional post-validation estimand, sealed test sequence, or reliability--cost resolution frontier; full-text comparison remains `[待核实]`. |
| Khamaru et al. (2022), “Instance-Dependent Confidence and Early Stopping for Reinforcement Learning” [L16] | The verified abstract proposes instance-dependent confidence regions and data-dependent stopping for policy evaluation and optimal-value estimation. | Establishes adjacent theoretical work on RL confidence and early stopping. | It does not establish the present empirical training-seed comparison, validation-selected configuration, or family-wise benchmark protocol; full-text comparison remains `[待核实]`. |

## Current gap statement

The verified and screened set supports the problem motivation and the mathematical
ingredients, L15 shows that prior work already addresses RL reliability metrics
and statistical comparisons, and L16 shows adjacent theory on confidence and
early stopping. The evidence therefore does not establish
that the exact combination of a
conditional post-validation estimand, sealed unpaired test sequences,
finite-look alpha allocation, and an empirical reliability--cost frontier is
novel across the full RL literature. The manuscript therefore makes the
following bounded contribution claim:

> We provide a preregistered, auditable characterization of what a conservative
> bounded sequential protocol can and cannot resolve at a fixed RL budget,
> including tuning-selection instability, normalization sensitivity, and
> same-machine repeatability limits.

This is a methodological characterization supported by the artifacts. It is
not a claim that Hoeffding's inequality, alpha spending, or sealed testing was
invented here.

## Required pre-submission completion

A 2026-10-31 discovery update added two OpenAlex concept searches and one
Crossref query, with raw responses and hashes under
`literature_search_raw/2026-10-31_update/`. The update did not admit any new
source or change the bounded novelty wording; it is recorded in
`LITERATURE_UPDATE_2026-10-31.md`.

Before claiming literature-wide novelty, repeat the search in Web of Science,
Scopus, IEEE Xplore, ACM Digital Library, and Google Scholar using the same
concept blocks, export all hits, deduplicate by DOI/title, and have a second
researcher screen the abstracts. Add any directly overlapping protocol papers
to the comparison table. Until that is done, `[待核实]` must remain attached to
any literature-wide novelty statement.


## 2026-11-03 全文核查补记

此前未取得全文的状态为历史记录。现已取得并核读 L1–L4、L11、L13–L16 共 9 篇关键文献的 PDF，另补充 Patterson 等（JMLR 2024，L17）与 Howard 等（Annals of Statistics 2021，全文按 arXiv v9，L18），共 11 篇。详情与来源哈希见 `KEY_LITERATURE_FULLTEXT_COMPARISON_ZH.md` 和 `literature_fulltext/2026-11-03/SOURCES.json`。

本轮确认两阶段调参后新种子评价、多重比较及序贯停止均有明确前作；不能把组件组合当作主要创新。此定向比较不证明全部文献范围内的新颖性。正文与补充材料的当前表述以本轮生成稿为准；旧记录未被追溯改写。

2026-11-03 后续：另核读 Maurer–Pontil (2009) 定理4全文，并完成现代序贯区间同目标、同预算、同数据前缀的事后对照。结果见中文主稿第5.21节和补充材料 S21；不追认为原预注册或未披露种子确认性证据。

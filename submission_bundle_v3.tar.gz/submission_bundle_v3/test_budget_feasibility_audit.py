#!/usr/bin/env python3
"""Deterministic tests for the v3 pre-study feasibility audit."""

from __future__ import annotations

import unittest

from generate_budget_feasibility_audit import build_payload


class BudgetFeasibilityAuditTests(unittest.TestCase):
    def test_v3_cap_is_structurally_infeasible(self):
        payload = build_payload()
        rows = payload["rows"]
        self.assertEqual([row["n_per_arm"] for row in rows], [5, 10, 15, 20])
        self.assertTrue(payload["audit_conclusion"]["all_v3_looks_cannot_reach_superiority"])
        self.assertTrue(payload["audit_conclusion"]["all_v3_looks_cannot_reach_precision"])
        self.assertEqual(
            payload["audit_conclusion"]["necessary_superiority_thresholds"],
            [17, 20, 22, 23],
        )

    def test_planning_values_are_deterministic(self):
        payload = build_payload()
        self.assertEqual(
            payload["audit_conclusion"]["target_width_thresholds"],
            [6071, 7180, 7829, 8289],
        )
        self.assertAlmostEqual(payload["rows"][-1]["radius_sum"], 1.0178588242230167)
        self.assertAlmostEqual(
            payload["rows"][-1]["maximum_possible_lower_endpoint"],
            -0.0178588242230167,
        )


if __name__ == "__main__":
    unittest.main()

"""Minimal reference implementation for the manuscript's finite-look interval."""

from __future__ import annotations

import math
from collections.abc import Sequence


def alpha_spend(comparison_alpha: float, look: int) -> float:
    """Summable two-sided error spending for a one-indexed finite look."""
    if not 0.0 < comparison_alpha < 1.0:
        raise ValueError("comparison_alpha must be in (0, 1)")
    if look < 1:
        raise ValueError("look must be >= 1")
    return comparison_alpha * 6.0 / (math.pi**2 * look**2)


def unpaired_hoeffding_interval(
    values_a: Sequence[float],
    values_b: Sequence[float],
    look_alpha: float,
) -> tuple[float, float, float]:
    """Return mean difference and its clipped unpaired Hoeffding interval."""
    if not values_a or not values_b:
        raise ValueError("both samples must be non-empty")
    if not 0.0 < look_alpha < 1.0:
        raise ValueError("look_alpha must be in (0, 1)")
    if any(not 0.0 <= value <= 1.0 for value in (*values_a, *values_b)):
        raise ValueError("all observations must be in [0, 1]")

    mean_a = math.fsum(values_a) / len(values_a)
    mean_b = math.fsum(values_b) / len(values_b)
    estimate = mean_a - mean_b
    radius_a = math.sqrt(math.log(4.0 / look_alpha) / (2.0 * len(values_a)))
    radius_b = math.sqrt(math.log(4.0 / look_alpha) / (2.0 * len(values_b)))
    radius = radius_a + radius_b
    return estimate, max(-1.0, estimate - radius), min(1.0, estimate + radius)


def decide(
    lower: float,
    upper: float,
    practical_margin: float,
    target_width: float,
) -> str:
    """Apply the manuscript's ordered superiority/precision decision rule."""
    if not -1.0 <= lower <= upper <= 1.0:
        raise ValueError("interval must satisfy -1 <= lower <= upper <= 1")
    if practical_margin < 0.0 or target_width < 0.0:
        raise ValueError("margin and target width must be non-negative")
    if lower > practical_margin:
        return "a_superior"
    if upper < -practical_margin:
        return "b_superior"
    if upper - lower <= target_width:
        return "precision_only"
    return "continue"

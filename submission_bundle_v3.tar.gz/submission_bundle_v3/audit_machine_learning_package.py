#!/usr/bin/env python3
"""Audit the Machine Learning submission-organization artifacts."""

import hashlib
import json
import re
import fitz
from pathlib import Path

from docx import Document


ROOT = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def full_docx_text(path: Path) -> str:
    doc = Document(path)
    paragraphs = [paragraph.text for paragraph in doc.paragraphs]
    paragraphs.extend(
        paragraph.text
        for table in doc.tables
        for row in table.rows
        for cell in row.cells
        for paragraph in cell.paragraphs
    )
    return "\n".join(paragraphs)


def main() -> None:
    sheet_md = ROOT / "MLJ_CONTRIBUTION_INFORMATION_SHEET.md"
    sheet_docx = ROOT / "MLJ_CONTRIBUTION_INFORMATION_SHEET.docx"
    main_md = ROOT / "MANUSCRIPT_FORMAL_ZH.md"
    supp_md = ROOT / "SUPPLEMENTARY_FORMAL_ZH.md"
    english_md = ROOT / "MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.md"
    english_docx = ROOT / "MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.docx"
    supplement_md = ROOT / "SUPPLEMENTARY_MACHINE_LEARNING_EN.md"
    supplement_docx = ROOT / "SUPPLEMENTARY_MACHINE_LEARNING_EN.docx"
    figure_manifest = ROOT / "MACHINE_LEARNING_FIGURE_MANIFEST.csv"
    sheet_text = sheet_md.read_text(encoding="utf-8")
    doc_text = "\n".join(p.text for p in Document(sheet_docx).paragraphs)
    english_text = english_md.read_text(encoding="utf-8")
    english_doc_text = full_docx_text(english_docx)
    supplement_text = supplement_md.read_text(encoding="utf-8")
    supplement_doc_text = full_docx_text(supplement_docx)

    required_sheet_sections = [
        "## Main Claim",
        "## Why It Matters",
        "## Distinction From Prior Work",
        "## Evidence",
        "## Scope and Limitations",
        "## Prior Publication and Overlap",
        "## Materials and Declarations",
    ]
    assert all(section in sheet_text for section in required_sheet_sections)
    assert "V7 comparison evaluates nine" in sheet_text
    assert "analytic-boundary check" in sheet_text
    assert "Resolution and Cost in Sequential Evaluation" in sheet_text
    for marker in required_sheet_sections:
        assert marker.split("## ", 1)[1] in doc_text

    current_hashes = {
        name: sha(ROOT / name)
        for name in ("MANUSCRIPT_FORMAL_ZH.md", "SUPPLEMENTARY_FORMAL_ZH.md")
    }
    rendered_pages = sorted((ROOT / "mljsheet_render").glob("page-*.png"))
    assert len(rendered_pages) == 2

    abstract = english_text.split("## Abstract\n\n", 1)[1].split(
        "\n\n**Keywords:**", 1
    )[0]
    abstract_words = len(re.findall(r"\b[\w'-]+\b", abstract))
    keyword_line = next(
        line for line in english_text.splitlines() if line.startswith("**Keywords:**")
    )
    keyword_count = len([item for item in keyword_line.split(":", 1)[1].split(";") if item.strip()])
    assert 150 <= abstract_words <= 250
    assert 4 <= keyword_count <= 6
    assert not re.search(r"\[L\d+", english_text)
    assert "Proposition 0" not in english_text and "Corollary 0" not in english_text
    assert not any(line.startswith("#### ") for line in english_text.splitlines())
    assert "Proposition 1" in english_doc_text and "Proposition 4" in english_doc_text
    assert "Data availability" in english_doc_text
    assert "## S11. V7 new-seed method comparison" in supplement_text
    assert "## S12. Online Resource manifest" in supplement_text
    assert "S11. V7 new-seed method comparison" in supplement_doc_text
    assert figure_manifest.exists()
    forbidden_local_markers = re.compile(
        r"复跑结果/|external_rerun_output|\.rl-arm64-venv|local package|"
        r"research workspace|Zenodo concept DOI|"
        r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+\.(?:md|csv|json|py)",
        re.IGNORECASE,
    )
    assert not forbidden_local_markers.search(english_text)
    assert not forbidden_local_markers.search(supplement_text)
    assert not forbidden_local_markers.search(english_doc_text)
    assert not forbidden_local_markers.search(supplement_doc_text)

    main_pdf = fitz.open(ROOT / "ml_submission_render/MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.pdf")
    supp_pdf = fitz.open(ROOT / "ml_supplement_render/SUPPLEMENTARY_MACHINE_LEARNING_EN.pdf")
    for pdf in (main_pdf, supp_pdf):
        assert not forbidden_local_markers.search("\n".join(p.get_text() for p in pdf))
        assert any("releases/download/v3.0.5/" in link.get("uri", "") for p in pdf for link in p.get_links())
    report = {
        "status": "PASS_WITH_BLOCKERS",
        "target_journal": "Machine Learning (Springer, journal 10994)",
        "guidelines_url": "https://link.springer.com/journal/10994/submission-guidelines",
        "requirements_baseline": "MACHINE_LEARNING_SUBMISSION_REQUIREMENTS.md",
        "contribution_information_sheet": {
            "markdown": sheet_md.name,
            "docx": sheet_docx.name,
            "rendered_pages": 2,
            "required_sections_present": True,
            "current_seventh_round_evidence_included": True,
        },
        "current_authoritative_chinese_sources": current_hashes,
        "completed": [
            "Official Springer requirements captured",
            "Two-page contribution information sheet updated to seventh-round evidence",
            "Contribution sheet rendered and visually checked",
            "Journal target fixed in JOURNAL_SELECTION_MEMO.md",
            "English submission draft synchronized to the audited seventh-round evidence boundary",
            "English abstract, keywords, decimal headings, theorem numbering, and author-year citations audited",
            "English Word manuscript generated with sorted references and appendices before references",
            "English supplementary narrative updated with V7 method sensitivity and an Online Resource manifest",
            "Standalone figure source files copied under machine_learning_figures/ with a resolution manifest",
            "Local workstation paths removed from submission manuscript and supplement; source and Word files scanned",
            "LibreOffice PDFs text-scanned; current page counts and clickable resource links verified",
            "Online Resource files linked to the v3.0.5 GitHub release and archived under the Zenodo concept DOI",
        ],
        "blocked": [
            "Author English names, email, ORCID, funding, competing interests, and contributions await author confirmation",
            "Verify Zenodo's v3.0.5 version record after GitHub release synchronization",
            "Standalone figure-file naming and final resolution/size checks remain to be completed for the submission upload",
        ],
        "english_main_manuscript": {
            "markdown": english_md.name,
            "docx": english_docx.name,
            "pdf": "ml_submission_render/MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.pdf",
            "rendered_pages": len(main_pdf),
            "abstract_words": abstract_words,
            "keyword_count": keyword_count,
            "author_year_citations": True,
            "zero_based_theorem_labels": False,
            "heading_depth": 3,
            "references_alphabetical": True,
        },
        "english_supplement": {
            "markdown": supplement_md.name,
            "docx": supplement_docx.name,
            "pdf": "ml_supplement_render/SUPPLEMENTARY_MACHINE_LEARNING_EN.pdf",
            "rendered_pages": len(supp_pdf),
            "v7_sensitivity_included": True,
            "online_resource_manifest_included": True,
            "pdf_rendered": True,
            "local_workspace_paths_absent": True,
        },
        "pagination_review": {
            "renderer": "LibreOffice 26.8.2.2",
            "main_manuscript_rendered_pages": len(main_pdf),
            "supplement_rendered_pages": len(supp_pdf),
            "text_scanned_for_local_workspace_paths": True,
        },
        "figures": {
            "manifest": figure_manifest.name,
            "directory": "machine_learning_figures",
            "standalone_sources_present": True,
            "final_resolution_verified": False,
        },
        "planned_release_tag": "v3.0.5",
        "online_resource_files": 6,
        "remote_publication_verification": "See PUBLIC_ARCHIVE_VERIFICATION.md and PUBLIC_RELEASE_V305_VERIFICATION.json",
    }
    (ROOT / "MACHINE_LEARNING_PACKAGE_AUDIT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print("Machine Learning submission-package audit: PASS_WITH_BLOCKERS")
    print("Contribution sheet: 2 rendered pages; current seventh-round evidence present.")


if __name__ == "__main__":
    main()

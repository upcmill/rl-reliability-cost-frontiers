#!/usr/bin/env python3
"""Render the current Markdown contribution sheet as the required Word sheet."""

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "MLJ_CONTRIBUTION_INFORMATION_SHEET.md"
OUTPUT = ROOT / "MLJ_CONTRIBUTION_INFORMATION_SHEET.docx"


def main() -> None:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.45)
    section.bottom_margin = Inches(0.45)
    section.left_margin = Inches(0.55)
    section.right_margin = Inches(0.55)
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(9)

    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    for line in lines:
        if not line.strip():
            continue
        if line.startswith("# "):
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(line[2:].strip())
            run.bold = True
            run.font.size = Pt(12)
        elif line.startswith("## "):
            p = doc.add_paragraph()
            run = p.add_run(line[3:].strip())
            run.bold = True
            run.font.size = Pt(10)
        elif line.startswith("- "):
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.space_after = Pt(0)
            p.add_run(line[2:].strip().replace("**", ""))
        elif line.startswith("|"):
            # The contribution sheet has no table content; ignore the metadata
            # table syntax if it is ever added to the Markdown source.
            continue
        else:
            p = doc.add_paragraph(line.strip().replace("**", ""))
            p.paragraph_format.space_after = Pt(1)

    doc.save(OUTPUT)
    print(f"Generated {OUTPUT.name} from {SOURCE.name}")


if __name__ == "__main__":
    main()

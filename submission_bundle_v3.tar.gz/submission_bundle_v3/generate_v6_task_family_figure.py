#!/usr/bin/env python3
"""Generate the v6 final-look interval figure from the audited raw outputs."""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "sb3_v6_task_family"


def main() -> None:
    config = json.loads((OUTPUT / "run_config.json").read_text(encoding="utf-8"))
    final = config["stop_traces"][-1]["decisions"]
    keys = list(final)
    labels = [key.replace("CliffWalking-v1:", "Cliff ").replace("FrozenLake-v1:", "Frozen ").replace("_vs_", " - ") for key in keys]
    image = Image.new("RGB", (1600, 800), "white")
    draw = ImageDraw.Draw(image)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 22)
        small = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 18)
        title_font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 28)
    except OSError:
        font = small = title_font = ImageFont.load_default()
    left, right, top, bottom = 150, 1520, 100, 620
    y_min, y_max = -0.6, 0.6
    def y_pixel(value: float) -> int:
        return int(bottom - (value - y_min) / (y_max - y_min) * (bottom - top))
    draw.text((left, 25), "V6 task-family extension: 200-seed final-look intervals", fill="#222222", font=title_font)
    for tick in (-0.6, -0.4, -0.2, 0.0, 0.2, 0.4, 0.6):
        y = y_pixel(tick)
        draw.line((left, y, right, y), fill="#dddddd", width=1)
        draw.text((75, y - 10), f"{tick:.1f}", fill="#444444", font=small)
    for threshold in (-0.05, 0.05):
        y = y_pixel(threshold)
        draw.line((left, y, right, y), fill="#888888", width=2)
    draw.line((left, y_pixel(0.0), right, y_pixel(0.0)), fill="#333333", width=2)
    step = (right - left) / len(keys)
    for idx, key in enumerate(keys):
        decision = final[key]
        x = int(left + step * (idx + 0.5))
        color = "#1f77b4" if key.startswith("CliffWalking") else "#d62728"
        y_low, y_high, y_mid = y_pixel(decision["lower"]), y_pixel(decision["upper"]), y_pixel(decision["estimate"])
        draw.line((x, y_low, x, y_high), fill=color, width=4)
        draw.line((x - 10, y_low, x + 10, y_low), fill=color, width=4)
        draw.line((x - 10, y_high, x + 10, y_high), fill=color, width=4)
        draw.ellipse((x - 7, y_mid - 7, x + 7, y_mid + 7), fill=color)
        draw.text((x - 70, bottom + 18), labels[idx], fill="#333333", font=small)
    draw.text((left, 660), "Dashed lines: practical margin ±0.05; blue = CliffWalking, red = FrozenLake", fill="#555555", font=font)
    draw.text((25, 250), "Difference", fill="#333333", font=font)
    image.save(ROOT / "manuscript_figures/fig_v6_extension.png")
    print("Wrote manuscript_figures/fig_v6_extension.png")


if __name__ == "__main__":
    main()

"""Reproducible round-two editorial revision; experimental inputs are read-only."""
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.shared import Cm, Pt

import generate_machine_learning_word as formatter

ROOT = Path(__file__).resolve().parent
SUPPLEMENT = 'SUPPLEMENTARY_FORMAL_ZH'
SECTIONS = {
    1: '文献比较、核验层级与引用记录',
    2: '统计构造、解析预算与比较族规划',
    3: '主研究协议、运行配置与原始记录',
    4: '原始回报、种子分布与效应量',
    5: '验证选择重采样及调参强度',
    6: '运行时间与可靠性—成本前沿',
    7: '同机可重复性与跨机器复跑',
    8: '依赖性压力测试与块回退',
    9: '替代区间与验证后支出诊断',
    10: '归一化、训练预算、评估回合与部分可观测诊断',
    11: '受控队列 oracle 与预算跟踪',
    12: '新种子及大预算分辨成本扩展',
    13: '实际边际敏感性',
    14: '连续控制与任务族范围扩展',
    15: '开放材料索引与生成说明',
}
# Original round-one table indices, before insertion of the scope overview.
MOVED = {6: (2, '比较族规模的解析规划'), 10: (4, '主研究原始回报摘要'),
         14: (4, '主研究归一化种子分布'), 15: (5, '验证选择重采样'),
         22: (5, '20 个验证种子的配置选择变化'),
         23: (5, '10 个验证种子的配置选择变化'),
         27: (13, '实际边际敏感性的完整数值')}
TITLES = ['研究问题与证据类型', '相关工作的已核实贡献与比较边界', '符号与术语',
          '等样本未截断宽度规划', '覆盖保证的假设与可证伪检查', '比较族规模的解析规划',
          '算法候选配置网格', '运行与审计不变量', '选定配置的描述性归一化均值',
          '主研究原始回报摘要', '主研究正式区间与决定', '描述性效应量',
          '跨机器非零差异单元', '主研究归一化种子分布', '验证选择重采样',
          '验证阶段执行时间', '密封测试阶段执行时间', '主研究成本与分辨率',
          '种子依赖性压力测试', '已知块依赖的回退诊断', '替代区间先导诊断',
          '20 个验证种子的选择变化', '10 个验证种子的选择变化', '新种子扩展终止决定',
          '大预算扩展终止决定', '大预算扩展成本与分辨率', '实际边际敏感性', '主张—证据对应']


def section_id(heading: str) -> int:
    m = re.match(r'#+ (\d+(?:\.\d+)*)\b', heading)
    if not m:
        return 15
    h = m.group(1)
    if h.startswith(('1', '2')) and h.split('.')[0] in ('1', '2'):
        return 1
    if h.startswith('3'):
        return 2
    if h.startswith('4') or h in ('5', '5.1'):
        return 3
    if h.startswith(('5.2', '5.3', '5.5')):
        if h.startswith('5.5.1'): return 5
        if h.startswith(('5.5.2', '5.5.3')): return 6
        return 4
    if h.startswith('5.4'): return 7
    if h.startswith(('5.6.1', '5.6.2')): return 8
    if h.startswith(('5.6', '5.7')): return 9
    if h == '5.9': return 5
    if h.startswith(('5.10', '5.14')): return 11
    if h.startswith(('5.11', '5.12', '5.13')): return 10
    if h.startswith(('5.15', '5.16', '5.17')): return 12
    if h.startswith('5.18'): return 13
    if h.startswith('5.19'): return 14
    return 15


LITERATURE_TABLE = '''| 工作 | 已核实的研究对象或贡献 | 与本文对照时的证据边界 |
|---|---|---|
| Henderson 等人[L1] | 深度 RL 的非确定性、结果变异与实验报告问题 | 支持评估动机；不据此推断其不存在本文各协议组件。 |
| Colas 等人[L2, L3] | 种子数量、功效、效应量及统计检验的假设诊断 | 与分辨预算问题相邻；完整协议的逐项比较见补充材料 S1。 |
| Zhang 等人[L13]、Whiteson 等人[L11] | 深度 RL 过拟合与评估过拟合问题 | 支持选择与评估分离的动机；L11 目前只作题录层面的引用。 |
| Agarwal 等人[L4] | 少量运行下的不确定性、性能剖面与稳健聚合 | 支持分布与区间报告；本文研究冻结比较族上的停止分辨成本。 |
| Nagarajan 等人[L14] | 确定性实现与复现中的训练非确定性 | 支持实现控制与统计保证的区分。 |
| Chan 等人[L15] | 训练中及训练后变异性、风险指标与统计比较工具 | 摘要支持这些正向贡献；与本文条件估计对象、有限检查点及成本分析的具体重叠仍需全文核验，见补充材料 S1.1。 |
| Khamaru 等人[L16] | 实例依赖置信区域及数据依赖提前停止 | 理论评估对象与训练种子比较的关系需全文核验，见补充材料 S1.1。 |
| 本文 | 条件性选定程序的有界无配对区间、密封测试及预算分辨审计 | 覆盖结论由本文假设和证明支持；实证结论限于冻结任务、程序与预算。 |'''

LITERATURE_DETAIL = '''### S1.1 逐项比较的证据边界

主文表 2 汇总正向贡献；下表明确区分文献已报告内容与尚不能据摘要判定的重叠。本文不把“摘要未提及”当作“该方法不存在”。当前没有完成下列文献的全文方法级排除，因此本节不是已完成的新颖性证明。

**表 S1-1。文献逐项比较的证据层级与待核验问题**

| 对照维度 | 本文的具体定义或证据 | 相邻工作的已核实信息 | 尚需核验的全文问题 |
|---|---|---|---|
| 可靠性对象 | 给定验证数据后冻结程序在新训练种子上的均值差 | Chan 等[L15]摘要包含训练中及训练后变异性与风险指标 | 是否已定义同样的选择后条件目标、相关统计量和推断范围[待核实]。 |
| 配置选择与测试 | 仅验证选择，测试种子不参与调优；命题 0 | Whiteson 等[L11]题录确认评估过拟合主题；Zhang 等[L13]摘要讨论过拟合 | 文献中的数据分割、选择规则及与密封测试的具体重叠[待核实]。 |
| 重复查看及比较族 | 固定检查点、每比较 alpha 支出、对比较族求并集界 | Lan–DeMets[L6]为序贯错误支出背景；Chan 等[L15]包含统计比较工具 | 既有工具是否覆盖相同的停止和多重比较组合[待核实]。 |
| 停止保证 | 独立有界训练种子、预先固定的检查点；命题 1–3 | Khamaru 等[L16]摘要包含实例依赖置信与提前停止 | 其样本模型、停止索引与本文有界训练种子目标的数学差异[待核实]。 |
| 成本报告 | 原始行运行时间、前缀分辨点、结构性非分辨界 | Colas 等[L2,L3]讨论样本量及统计比较；Chan 等[L15]报告可靠性指标 | 是否已有等价的分辨成本报告或设计审计[待核实]。 |

### S1.2 参考文献核验记录

主文 L1–L16 的题录依据 `LITERATURE_VERIFICATION.md` 中的核验记录；L13–L16 另有本地 arXiv 检索缓存。L13、L15 使用 arXiv v2，L14 使用 v5。L11 在引言、相关工作和表 2 中用于题录支持的评估过拟合背景；L4 使用已核实的 arXiv 题录，不推断最终会议版本。

相关题录核验及缓存检索记录的日期为 2026-10-29 至 2026-10-30。修订时完成了本地记录与题录的一致性核对，但未完成新的远程全文获取。因此，L11、L15、L16 的全文方法比较及最新文献覆盖仍为[待核实]。

L15 缓存中的 arXiv ID 为 1912.05663v2；首次提交日期为 2019-12-10，v2 更新日期为 2020-02-12。因此主文以首次提交年 2019 引用预印本，同时明确版本 v2，不据此指定未经核验的正式出版年份。缓存摘要说明其研究训练中和固定策略训练后的变异性与风险，并提供互补统计检验及报告建议。

原 `LITERATURE_VERIFICATION.md` 为历史核验记录，其末尾“没有不同机器结果”的状态早于后续 Windows 复跑；当前状态以主文第 5.4.1 节和补充材料 S7 的复跑产物为准。历史文件不作为本轮最新复跑状态。
'''

SCOPE = '''### 4.7 范围诊断全览

以下三个扩展组涉及四个新增任务和八个任务内算法对：两个连续动作任务各一个比较，两个离散任务各三个比较。种子数均指每个任务—算法单元的密封测试种子数；这些范围诊断使用独立的分析族，不并入主研究的 15 个比较。

@@TABLE:范围诊断的任务、算法与测试预算@@
| 范围扩展 | 新任务数 | 算法 | 每单元测试种子数 | 正文位置 |
|---|---:|---|---:|---|
| Pendulum-v1 | 1 | PPO / A2C | 20 | 附录 A；补充材料 S14 |
| MountainCarContinuous-v0 | 1 | PPO / A2C | 20 | 附录 B；补充材料 S14 |
| CliffWalking-v1、FrozenLake-v1（4×4、slippery） | 2 | PPO / DQN / A2C | 200 | 附录 C；补充材料 S14 |
'''

THRESHOLDS = '''**设计阈值的来源与含义。** 冻结预注册列出了 m=0.05 和 w=0.10，但没有记录任务特定的效用标定、专家阈值或既有文献依据。因此本文将二者报告为在有界归一化尺度上固定的协议设计阈值：m 是归一化跨度的 5%，w 是跨度的 10%。本文未验证这两个比例对应各任务的最小实际重要差异或统一的决策精度，不能在看到结果后补写为领域公认阈值。w=2m 仅是本研究采用的数值关系；达到宽度目标并不等价于区间落入 [−m,m]，也不构成等效性检验。

在预注册的仿射归一化未触发截断时，m 对 CartPole、Acrobot、MountainCar、Taxi 和队列分别对应原始学习曲线平均回报尺度的 25、25、10、101 和 102.5 单位；w 分别对应 50、50、20、202 和 205 单位。这些数值由各任务归一化跨度直接换算，只展示同一归一化阈值在原尺度上含义不同，不构成实践效用论证。存在截断时不能据此作一一反变换。第 5.18 节在保留原始主分析的前提下报告边际敏感性；后续应用需依据具体代价或效用在新测试前确定阈值。
'''

BLOCK_PROOF = '''**证明。** 条件于验证数据固定选定程序。假设块划分与完整块的纳入规则在观察测试值前已知；对每个算法臂 A，在固定检查点 k 令完整块均值为 U_A,1,…,U_A,q，q=q_A,k≥1。由假设 U_A,j∈[0,1]、臂内独立且 E[U_A,j∣D_val]=μ_A。于是

`P(|q^(-1) sum_j U_A,j − μ_A| > sqrt(log(4/alpha_k)/(2q)) | D_val) <= 2 exp(−log(4/alpha_k)) = alpha_k/2`。

算法臂 B 同理；对两臂求并集界后，在至少 1−alpha_k 的条件概率下，块均值之差与 μ_A−μ_B 的距离不超过两半径之和。目标属于 [−1,1]，所以截断不会移除目标；再对预先声明的检查点求和及比较族求并集界即得结论。两臂之间和比较之间不需要独立；各臂内部的块均值独立性不可省略。若某臂尚无完整块，报告整个 [−1,1] 并继续采样，不能使用 q=0 的半径公式。

这里等权平均的是完整块均值。若块大小不同且块均值不具有共同期望，该目标可能不再等于原种子级均值；此时本命题不适用。丢弃末尾不完整块只能避免把相关片段误当作独立观测，不能消除未知块间相关。由观测结果反推块划分、重叠块、未建模的 RL 过程依赖均不在结论内。有效样本量由种子数降至完整块数，是回退区间变宽的原因。'''

QUEUE = '''**越过边际的算术条件。** 首次新种子检查点的两臂半径和为 R=0.275459，故正向决定要求观测均值差 d>m+R=0.325459。该序列的 d=0.345322 满足此条件，下端点为 0.069863。若仅把主研究的旧点估计 0.299617 代入这一新半径，下端点为 0.024158，仍未超过 0.05。因此本次越界同时涉及半径变化和观测点估计变化，不能仅归因于方差降低；Hoeffding 半径本身不使用样本方差。

跟踪序列在 200 个种子时的 d=0.318424 低于同一门槛，而在 400 个种子时达到决定。两条序列的正向差异支持这一受控任务下冻结程序差异方向的描述性一致性，停止时点的不同则说明 200 不是稳定的通用样本需求。它们不识别算法机制或样本量的独立因果效应；要检验验证结果的预测能力，需用另行预注册、未见的测试序列评估预测误差。
'''


def revise_body(body: str) -> tuple[str, dict[int, list[str]], list[dict]]:
    # Repairs of editorial corruption, not edits to source experiment outputs.
    body = body.replace('arXiv:1804.06893早期诊断', 'arXiv:1804.06893v2')
    body = body.replace('arXiv:1912.05663早期诊断', 'arXiv:1912.05663v2')
    body = body.replace('https://jmlr.org/papers/早期诊断2/', 'https://jmlr.org/papers/v22/')
    body = body.replace('Gymnasium 版本为 1.4.0。', 'Gymnasium[L10]版本为 1.4.0。')
    body = body.replace('PPO[L7]、DQN[L8] 和 A2C[L9]', 'PPO[L7]、DQN[L8] 和 A2C')
    body = body.replace('软件来源见[L12]。', '软件来源见[L12]。A2C 的 actor–critic 背景参考异步方法文献[L9]；具体同步实现以 Stable-Baselines3 为准。')
    body = body.replace(' 最终期刊信息[待核实]。', '')
    body = body.replace(' Full-text method comparison [待核实].', '')
    body = re.sub(r'(?<=[\u4e00-\u9fff]) +主研究', '主研究', body)
    body = re.sub(r'主研究 +(?=[\u4e00-\u9fff])', '主研究', body)
    body = body.replace('事前解析审计进一步证明', '仅依赖设计参数的解析审计进一步证明')
    body = body.replace('随后进行的研究团队随后进行的', '随后进行的')
    body = body.replace('表 1 和补充材料[待核实]', '表 2 和补充材料 S1.1；全文方法重叠[待核实]')
    body = body.replace('表 1 明确给出贡献边界。表中关于“未建立”的表述仅针对已核实的摘要或元数据；标注[待核实]的地方仍需全文方法比较。',
                        '表 2 汇总已核实的正向贡献，逐项比较的证据层级及待核验问题见补充材料 S1.1。未获取全文的工作不作排除性判断。')
    body = body.replace('其中 `$S` 和 `$S\'`', "其中 `$S$` 和 `$S'$`")
    body = body.replace('若每个算法的密封指标在其自身训练种子之间独立且位于 `[0,1]`',
                        '若每个算法的密封指标在其自身训练种子之间独立、具有共同的臂级条件均值且位于 `[0,1]`')
    body = body.replace('若在第 5 个预先登记检查点使用每臂 30 个种子',
                        '若另行设计一个第 5 检查点并使用每臂 30 个种子（本研究未注册或运行这一检查点）')
    # Fix an overlong row that the prior Word renderer silently truncated.
    body = body.replace('有效样本量。 | 补充材料、生成器、测试和第 5.6.2 节。 |',
                        '有效样本量；补充材料、生成器、测试和第 5.6.2 节。 |')
    body = body.replace('本节先定义估计对象和选择后条件，再说明序贯决定状态机与覆盖保证，随后讨论区间宽度、alpha 支出和预算审计；实验部分报告冻结实现和验证证据。$m$ 是规范性实际意义阈值，必须由具体研究领域论证；$w$ 是区间宽度目标，两者含义不同。',
                        '本节先定义指标、条件均值差和误差分配；第 3.1 节给出基本覆盖、验证选择、停止与块回退的逻辑链；第 3.2–3.3 节说明状态机与无配对选择；第 3.4 节及随后推论讨论 alpha 支出和分辨阈值；第 3.5–3.7 节将这些结果用于预算审计、假设检查和比较族规划。符号表区分实际优越性边际 m 与精度目标 w。')
    anchor = '**有限检查点的 alpha 分配示例。**'
    body = body.replace(anchor, THRESHOLDS + '\n' + anchor)
    start = body.index('**证明思路。** 将完整块均值')
    end = body.index('\n\n### 定义 1', start)
    body = body[:start] + BLOCK_PROOF + body[end:]
    # Place basic coverage before its consequences, retaining stable proposition numbers.
    start = body.index('### 命题 1（')
    end = body.index('### 推论 1（', start)
    basic = body[start:end]
    body = body[:start] + body[end:]
    body = body.replace('### 命题 0（', basic + '### 命题 0（', 1)
    body = body.replace('本文不主张任何算法普遍优越，不主张二十个种子在所有任务中普遍充分或必要，也不主张研究已经由独立团队复现。',
                        '相关工作的完整比较边界见表 2 和补充材料 S1；对外推与复现层级的限制集中见第 7–8 节。')
    body = body.replace('不能把验证结果解释成对测试差异的可靠预告。',
                        '验证均值同样显示正向差异，但尚未校准其对未见测试序列的预测误差。')
    start = body.index('上述比较是对已观测序列的事后描述')
    end = body.index('### 5.16', start)
    body = body[:start] + QUEUE + '\n' + body[end:]
    body = body.replace('## 6 讨论\n', '## 6 讨论\n\n### 6.1 设计边界与预算解释\n')
    body = body.replace('队列预算跟踪诊断提供了互补观察：', '### 6.2 扩展观察的含义\n\n队列预算跟踪诊断提供了互补观察：')
    body = body.replace('下表在保持主研究检查点', '补充材料 S2 的规划表在保持主研究检查点')
    # Use the actual repository remote without claiming current public verification.
    repo = ('本地发布记录中的仓库地址为 https://github.com/upcmill/rl-reliability-cost-frontiers；'
            '当前公开可访问性及仓库版本与本稿材料的对应关系[待核实]；永久 DOI 和发布许可证[待补充]。')
    body = body.replace('公开代码仓库 DOI 或 URL：[待补充]。', repo)
    body = body.replace('代码、数据、预注册和分析脚本将按期刊要求提供；公开仓库或永久存档链接、许可证和数据可用性声明目前为[待补充]。研究材料包含源文件哈希和环境元数据；公开归档信息仍待补充。', repo + ' 材料索引见补充材料 S15；源文件哈希和环境元数据随原始记录保留。')
    body = body.replace('目前研究材料已在本地整理，但公开代码仓库 DOI/URL 和永久存档尚未分配；作者需在投稿前确定公开平台、许可证及发布时点。', repo)
    body = body.replace('材料包区分同机跨脚本可重复性与独立复现，不宣称后者。',
                        '材料包分别报告同机可重复性与不同机器复跑，尚不宣称不同团队按披露信息完成的可复现性。')
    body = body.replace('## 参考文献',
        '未来可将均值最大化选择与预先固定先验、评分函数和计算预算的贝叶斯选择规则作同预算比较；'
        '须在新验证与测试种子上分别报告选择稳定性、预测误差和分辨成本。本文未运行这一实验，'
        '不将其写为已验证结果，也不据此改动原选择规则。\n\n## 参考文献')
    # Round-one supplementary names were removed; restore precise section pointers.
    lines, current = [], 15
    for line in body.splitlines():
        if re.match(r'#{2,4} \d', line):
            current = section_id(line)
        line = re.sub(r'补充材料(?! S\d)', f'补充材料 S{current}', line)
        lines.append(line)
    body = '\n'.join(lines) + '\n'
    body = body.replace('机器生成的表格副本见 补充材料 S4，由\n补充材料 S4 生成。',
                        '表格及生成脚本见补充材料 S4。')
    body = body.replace('机器生成的诊断报告见 补充材料 S5，机器可读输出为 补充材料 S5，生成脚本为 补充材料 S5。',
                        '诊断报告、机器可读输出及生成脚本见补充材料 S5。')
    body = body.replace('机器可读结果和生成器为 补充材料 S13。',
                        '机器可读结果和生成器见补充材料 S13。')
    body = body.replace('最接近的描述性正差为队列', '最大的描述性正差为队列')
    body = body.replace('补充材料 S15 的每一行代表', '补充材料 S3 所列原始 CSV 的每一行代表')
    body = body.replace('单任务 Pendulum 连续控制补充实验在 补充材料 S15',
                        '单任务 Pendulum 连续控制补充实验在补充材料 S14')
    body = re.sub(r'单独预注册的范围扩展加入 `MountainCarContinuous-v0`[^\n]+',
                  lambda m: m[0].replace('补充材料 S15', '补充材料 S14'), body)
    body = body.replace('不能在看到结果后补写为领域公认阈值', '因此不将其解释为领域公认阈值')
    # The evidence table must point to the evidence sections, not just the global index.
    claim_sections = {'在给定假设下': 2, '在正式主研究': 2, '主研究族包含': 3,
                      '主研究没有正式': 3, '大预算分辨成本扩展在': 12,
                      '选定配置的描述性': 4, '存储摘要可被': 7,
                      '种子独立性假设': 8, '已知块依赖': 8,
                      '同一流程可在': 14, '不同机器能够': 7}
    for prefix, sid in claim_sections.items():
        body = re.sub(rf'^\| {re.escape(prefix)}.*$',
                      lambda m: m[0].replace('补充材料 S15', f'补充材料 S{sid}'),
                      body, flags=re.M)
    moved: dict[int, list[str]] = defaultdict(list)
    transfer = []
    lines, output, i, original = body.splitlines(), [], 0, 0
    while i < len(lines):
        if not lines[i].startswith('|'):
            output.append(lines[i]); i += 1; continue
        block = []
        while i < len(lines) and lines[i].startswith('|'):
            block.append(lines[i]); i += 1
        original += 1
        table = '\n'.join(block)
        if original in MOVED:
            sid, title = MOVED[original]
            supplement_number = f'S{sid}-{len(moved[sid]) + 1}'
            moved[sid].append(f'**表 {supplement_number}。{title}**\n\n{table}\n')
            output.append(f'完整数值见补充材料 S{sid}，表 {supplement_number}。')
            transfer.append({'original_table': original, 'supplement_table': supplement_number,
                             'rows': len(block) - 2, 'table_markdown': table})
        else:
            if original == 2:
                table = LITERATURE_TABLE
            output.extend([f'@@TABLE:{TITLES[original-1]}@@', table])
    assert original == 28, original
    body = '\n'.join(output) + '\n'
    body = body.replace('## 5 结果', SCOPE + '\n## 5 结果')
    count = 0
    def caption(match):
        nonlocal count
        count += 1
        return f'**表 {count}。{match.group(1)}**\n'
    body = re.sub(r'@@TABLE:(.*?)@@', caption, body)
    assert count == 22, count
    return body, moved, transfer


def collect_paths(source: str) -> dict[int, dict[str, str]]:
    groups = defaultdict(dict)
    heading, sid = '主研究材料', 3
    for line in source.splitlines():
        if re.match(r'#{2,4} \d', line):
            heading, sid = line.lstrip('# '), section_id(line)
        for candidate in re.findall(r'`([^`]+)`', line):
            if not re.search(r'\.(md|json|csv|py|txt)$', candidate):
                continue
            path = ROOT / candidate
            if not path.exists():
                path = ROOT / 'sb3_formal_v3' / candidate
            if not path.is_file():
                raise FileNotFoundError(candidate)
            name = path.relative_to(ROOT).as_posix()
            groups[sid][name] = heading
    extras = {
        1: ['literature_search_raw/2026-10-30_openalex_screening/arxiv_1912_05663.xml',
            'literature_search_raw/2026-10-30_openalex_screening/arxiv_2201_08536.xml',
            'literature_search_raw/2026-10-30_retry/arxiv_1809_05676_1804_06893.xml'],
        2: ['reference_sequential_interval.py'],
        3: ['sb3_formal_v3/raw_seed_metrics.csv', 'sb3_formal_v3/run_config.json',
            'sb3_formal_v3/summary.json', 'sb3_formal_v3/familywise_cost_summary.json',
            'sequential_sb3_runner_v3.py'],
        7: ['复跑结果/EXTERNAL_RERUN_AUDIT.json', '复跑结果/external_rerun_output/raw_seed_metrics.csv',
            'sb3_formal_v3/independent_reproduction_summary.json'],
        10: ['V3_NORMALIZATION_SENSITIVITY.md', 'v3_normalization_sensitivity.json'],
        11: ['sb3_queue_budget_followup_v1/raw_seed_metrics.csv'],
        12: ['sb3_v4_extension/raw_seed_metrics.csv', 'sb3_v4_extension/run_config.json',
             'sb3_v5_extension/raw_seed_metrics.csv', 'sb3_v5_extension/run_config.json'],
        14: ['CONTINUOUS_SUPPLEMENT_REPORT.md', 'FINAL_PREREGISTRATION_CONTINUOUS_SUPPLEMENT.md',
             'REPRODUCTION_MANIFEST_CONTINUOUS_SUPPLEMENT.md', 'CONTINUOUS_SCOPE_EXPANSION_REPORT.md',
             'FINAL_PREREGISTRATION_CONTINUOUS_SCOPE_EXPANSION.md', 'audit_continuous_scope_artifacts.py',
             'FINAL_PREREGISTRATION_V6_TASK_FAMILY.md',
             'sb3_v6_task_family/V6_TASK_FAMILY_EXTENSION_REPORT.md',
             'sb3_v6_task_family/V6_TASK_FAMILY_AUDIT.json'],
        15: ['AUTHOR_EXTERNAL_INFO_INTAKE_ZH.md', 'SUBMISSION_METADATA_TEMPLATE.md'],
    }
    for sid, paths in extras.items():
        for p in paths:
            if not (ROOT / p).is_file(): raise FileNotFoundError(p)
            groups[sid][p] = SECTIONS[sid]
    return groups


def supplement_text(groups, moved) -> str:
    text = ['# 强化学习算法序贯评估的可靠性—成本前沿：补充材料', '',
            '本文件与 MANUSCRIPT_FORMAL_ZH.md / .docx 配套；章节 S1–S15 与正文引用对应。'
            '文件路径以项目根目录为起点。索引列出当前稿件引用的证据文件及其用途；'
            '运行依赖和完整运行包以各预注册、复跑清单为准。原始结果不因本轮编辑改变。', '']
    for sid, title in SECTIONS.items():
        text += [f'## S{sid} {title}', '']
        if sid == 1:
            text += [LITERATURE_DETAIL]
        if sid == 13:
            text += ['本节将解析的“存在有界数据可能越界”的必要种子阈值与实际观测决定分开报告。'
                     '图 13 读取既有 margin_sensitivity_v3.json；全部七个边际下仍为 15 项未决。'
                     '这是事后诊断，不重写主研究阈值。', '']
        text += moved.get(sid, [])
        text += ['本节文件索引：', '']
        for path, origin in sorted(groups.get(sid, {}).items()):
            kind = {'.md': '设计、分析或核验说明', '.json': '机器可读结果或核验摘要',
                    '.csv': '逐运行原始记录', '.py': '运行、生成或审计脚本',
                    '.txt': '环境或执行记录', '.xml': '文献检索原始缓存'}[Path(path).suffix]
            # Source headings may retain phase identifiers; here they locate artifacts.
            text.append(f'- `{path}`：{kind}；对应“{origin}”。')
        if sid == 15:
            text += ['', '正文概念速查：条件估计对象与密封测试见第 3–3.1 节；'
                     '终止状态见第 3.2 节；分辨成本见定义 1 和第 5.5.3 节；'
                     '可重复性、不同机器复跑与不同团队可复现性的区别见第 8.1 节。', '',
                     '正式稿生成：`python3 generate_formal_chinese_manuscript.py`。'
                     '新增边际图生成：`MPLCONFIGDIR=/tmp/rl-paper-mpl ./.rl-venv/bin/python generate_round2_margin_figure.py`。'
                     '直接产物核对：`python3 audit_formal_round2.py`。'
                     '生成器共享 Markdown 内容构建 Word，因此表格、附录与图注来自同一来源。'
                     '公开可访问性、发布版本及 DOI 未由本轮联网核验。']
        text.append('')
    return '\n'.join(text)


def appendices_markdown(add_appendices) -> str:
    # Reuse the existing appendix text; Word-only content becomes shared source.
    doc = Document()
    formatter.configure_document(doc, chinese=True)
    # Keep Latin words and decimal numbers intact at ordinary line endings.
    word_wrap = OxmlElement('w:wordWrap')
    word_wrap.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '0')
    doc.styles['Normal']._element.get_or_add_pPr().append(word_wrap)
    add_appendices(doc)
    result = []
    for p in doc.paragraphs:
        if not p.text.strip() or p.text.startswith('图 '): continue
        result.append(('## ' if p.style.name == 'Heading 1' else '') + p.text)
    return '\n\n'.join(result) + '\n'


FIGURES = [
    ('4 实验设计', 'fig_protocol.png', '预注册嵌套评估协议与密封测试决定流程。'),
    ('5.2 描述性测试均值', 'fig_heatmap.png', '选定配置的描述性归一化测试均值（每单元 n=20）；不构成算法排名。'),
    ('5.3 正式区间', 'fig_intervals.png', '15 个主要比较的点估计与族调整区间；n=20 时全部未决。'),
    ('5.5.1 验证选择重采样诊断', 'fig_selection_uncertainty.png', '五个验证种子联合行重采样的配置选择频率；事后诊断，不是总体概率。'),
    ('5.6 补充统计诊断', 'fig_budget_frontier.png', '[0,1] 指标下的 Hoeffding 区间宽度解析规划；不是观测样本需求。'),
    ('5.9 主研究结论的事后稳健性', 'fig_tuning_stability.png', '验证种子从 5 个增加到 10 个时的选择稳定性；红色单元表示变化。'),
    ('5.9 主研究结论的事后稳健性', 'fig_normalization_sensitivity.png', '11 种归一化方案均为 15/15 未决；事后诊断。'),
    ('5.11 训练预算扩展诊断', 'fig_budget_scaling.png', '冻结配置下 4096 与 16384 步的描述性均值；不与主分析合并。'),
    ('5.12 评估回合数敏感性诊断', 'fig_eval_episode_sensitivity.png', '每检查点评估回合从 5 个增加到 10 个时的种子匹配指标平均绝对变化。'),
    ('5.14 固定配置队列预算跟踪诊断', 'fig_queue_budget_followup.png', '队列跟踪：200 个种子未决，400 个种子越过边际；事后预算诊断。'),
    ('5.15 前瞻性新种子扩展', 'fig_v4_extension.png', '400 个新种子时的区间展示；队列 DQN−A2C 已在 200 时锁定决定，其余 14 项在 400 时未决。'),
    ('5.17 大预算分辨成本扩展', 'fig_v5_extension.png', '最多 1000 个新种子的扩展：4 项在 200 或 800 时锁定决定，11 项在 1000 时未决。'),
    ('5.18 实际边际敏感性诊断', 'fig_round2_margin_sensitivity.png', '左：四次检查对应的可能优越性必要种子阈值（解析量，不是功效）；右：主研究原始数据在七个边际下均为 15 项未决。各线固定检查索引，不能将其视为跨索引通用种子规则。'),
    ('附录 C。任务族范围扩展', 'fig_v6_extension.png', '两个固定离散任务、每算法 200 个种子的最终区间；六个比较均未决。'),
]


def insert_figures(body: str) -> str:
    for index, (heading, filename, caption) in enumerate(FIGURES, 1):
        pattern = rf'^(#{{2,4}} {re.escape(heading)})$'
        # Reverse placement for two figures under the same heading is handled below.
        marker = f'@@FIGURE:{heading}@@'
        if marker not in body:
            body, count = re.subn(pattern, lambda m: m[0] + '\n\n' + marker, body, flags=re.M)
            assert count == 1, (heading, count)
        path = formatter.FIGURES.relative_to(ROOT) / filename
        block = f'![图 {index}。{caption}]({path.as_posix()})'
        body = body.replace(marker, block + '\n\n' + marker)
    return re.sub(r'@@FIGURE:.*?@@\n?', '', body)


def build_docx(markdown: str, output: Path) -> None:
    doc = Document()
    formatter.configure_document(doc, chinese=True)
    doc.sections[0].header.paragraphs[0].text = '强化学习算法序贯评估'
    lines, i, caption = markdown.splitlines(), 0, None
    while i < len(lines):
        line = lines[i].strip()
        i += 1
        if not line: continue
        if line == r'\[':
            equation=[]
            while i < len(lines) and lines[i].strip() != r'\]':
                equation.append(lines[i].strip())
                i += 1
            if i < len(lines):
                i += 1
            paragraph=doc.add_paragraph()
            paragraph.alignment=WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.first_line_indent=Cm(0)
            paragraph.paragraph_format.keep_together=True
            paragraph.paragraph_format.widow_control=True
            paragraph.paragraph_format.space_before=Pt(4)
            paragraph.paragraph_format.space_after=Pt(4)
            run=paragraph.add_run(formatter.clean_inline(' '.join(equation)))
            run.font.name='Cambria Math'
            run._element.rPr.rFonts.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia','宋体')
            run.font.size=Pt(10)
        elif line.startswith('**表 '):
            caption = formatter.clean_inline(line)
        elif line.startswith('|'):
            block = [line]
            while i < len(lines) and lines[i].startswith('|'):
                block.append(lines[i]); i += 1
            headers, rows = formatter.parse_table(block)
            if any(len(row) != len(headers) for row in rows):
                raise ValueError(f'Malformed table: {caption}')
            formatter.add_table(doc, headers, rows, caption)
            table = doc.tables[-1]
            if caption and caption.startswith(('表 S4-1。', '表 S18-1。', '表 S22-2。')):
                # Numeric tables need the full cell width, without prose indentation.
                for row in table.rows:
                    for cell in row.cells:
                        for paragraph in cell.paragraphs:
                            paragraph.paragraph_format.first_line_indent = Cm(0)
            repeat = OxmlElement('w:tblHeader')
            table.rows[0]._tr.get_or_add_trPr().append(repeat)
            for row in table.rows:
                row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
            if len(table.rows) <= 8:
                for row in table.rows[:-1]:
                    for cell in row.cells:
                        for paragraph in cell.paragraphs:
                            paragraph.paragraph_format.keep_with_next = True
            caption = None
        elif line.startswith('!['):
            match = re.fullmatch(r'!\[(.*?)\]\((.*?)\)', line)
            path = ROOT / match[2]
            if not path.is_file(): raise FileNotFoundError(path)
            formatter.add_figure(doc, path.name, match[1], chinese=True)
            doc.paragraphs[-2].paragraph_format.keep_with_next = True
            doc.paragraphs[-1].paragraph_format.keep_together = True
        elif line.startswith('#'):
            level = len(line) - len(line.lstrip('#'))
            title = line[level:].strip()
            if level == 1:
                paragraph = doc.add_paragraph(title, style='Title')
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                paragraph.paragraph_format.first_line_indent = Cm(0)
            else:
                paragraph = doc.add_paragraph(title, style=f'Heading {min(level-1,3)}')
                if title.startswith(('附录 ', 'S1 ')):
                    paragraph.paragraph_format.page_break_before = True
        else:
            style = 'List Bullet' if line.startswith('- ') else None
            if style: line = line[2:]
            formatter.add_body_paragraph(doc, line, chinese=True, style=style)
    paragraphs = list(doc.paragraphs)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                paragraphs.extend(cell.paragraphs)
    for paragraph in paragraphs:
        wrap = OxmlElement('w:wordWrap')
        wrap.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '0')
        paragraph._p.get_or_add_pPr().append(wrap)
        for run in paragraph.runs:
            lang = OxmlElement('w:lang')
            lang.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', 'en-US')
            lang.set('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}eastAsia', 'zh-CN')
            run._r.get_or_add_rPr().append(lang)
    doc.save(output)


def generate(body: str, source: str, front: str, add_appendices) -> str:
    revised, moved, transfer = revise_body(body)
    rows = list(csv.DictReader((ROOT / 'sb3_formal_v3/raw_seed_metrics.csv').open()))
    costs = {split: sum(float(r['runtime_seconds']) for r in rows if r['split'] == split)
             for split in ('validation', 'test')}
    cost_sentence = (f"主研究 600 次记录运行的执行时间之和约为 {sum(costs.values())/3600:.3f} 小时"
                     '（验证与测试各 300 次；不含软件安装、复跑及扩展实验）。')
    revised = revised.replace('**关键词：**', cost_sentence + '\n\n**关键词：**', 1)
    revised = revised.replace('本文用可审计的嵌套协议刻画这一边界。',
                               cost_sentence + '第 5.5.2 节区分调参与测试成本，第 5.17 节另报大预算扩展成本。\n\n本文用可审计的嵌套协议刻画这一边界。', 1)
    revised += '\n' + appendices_markdown(add_appendices)
    main = front + insert_figures(revised)
    groups = collect_paths(source)
    supplement = supplement_text(groups, moved)
    (ROOT / f'{SUPPLEMENT}.md').write_text(supplement, encoding='utf-8')
    build_docx(supplement, ROOT / f'{SUPPLEMENT}.docx')
    manifest = {'main_tables': 22, 'moved_tables': transfer, 'figure_count': len(FIGURES),
                'runtime_seconds': costs,
                'indexed_files': sorted({p for group in groups.values() for p in group})}
    (ROOT / 'ROUND2_EDITORIAL_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return main

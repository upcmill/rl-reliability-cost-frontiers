"""Build a concise submission main text from the audited v3 manuscript.

The full v3 manuscript remains the source of record.  This script keeps the
pre-specified protocol, theorem, primary v3 results, limitations, and claim
evidence table in the main text while moving post-v3 diagnostics to the
supplementary package.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "MANUSCRIPT_DRAFT_V3.md"
OUTPUT = ROOT / "MANUSCRIPT_SUBMISSION_CORE_EN.md"

KEEP_TOP_LEVEL = {
    "1. Introduction",
    "2. Related Work",
    "3. Estimand and Statistical Protocol",
    "4. Experimental Design",
    "5. Results",
    "6. Discussion",
    "7. Limitations and Threats to Validity",
    "8. Reproducibility and Open Materials",
    "9. Claim--Evidence Table",
    "10. Conclusion",
    "11. Declarations",
    "References",
}

KEEP_RESULT_SUBSECTIONS = {
    "5.1 Data accounting and decisions",
    "5.2 Descriptive test means",
    "5.2.1 Raw-return summaries",
    "5.3 Formal intervals",
    "5.3.1 Descriptive effect sizes",
    "5.4 Same-machine repeatability",
    "5.4.1 Different-machine sealed rerun",
    "5.5 Seed-level distribution and configuration selection",
    "5.5.1 Validation-selection resampling diagnostic",
    "5.5.2 Execution-time accounting",
    "5.5.3 Reliability--cost frontier",
    "5.21 Post-hoc prospective new-seed validation",
}

CORE_ABSTRACT = """RL benchmark comparisons vary with training seeds, environment randomness, configuration selection, and repeated interim inspection. We characterize the reliability--cost boundary of a sequential evaluation protocol, not a new policy-learning algorithm. The protocol freezes configurations selected on validation seeds, evaluates a bounded four-checkpoint learning-curve metric on sealed test seeds, and applies finite-look family-wise Hoeffding intervals. We evaluate PPO, DQN, and A2C on five discrete tasks; each of 15 comparisons uses four candidate configurations, five validation seeds per candidate, and 20 test seeds. All comparisons remain unresolved; an analytic feasibility result shows this is forced by the chosen bound and budget, not evidence of algorithm equivalence. A dependence stress test shows correlated seed observations can invalidate the nominal interval. Same-machine replay matches stored summaries; a sealed Windows AMD64 rerun matches all 15 selected configurations and decisions, with exact seed-level metrics in 14 cells and a small platform difference in one. In a post-hoc prospective validation on 1,000 new seeds per cell for the same fixed panel, Gamma-mixture empirical-Bernstein confidence sequences are narrower than the original Hoeffding intervals in all 15 comparisons (mean width difference -0.1853); 11 comparisons reach a terminal superiority or precision category versus four under Hoeffding. All 15,000 runs were completed, so prefix counts are not realized compute savings. The evidence does not establish coverage on unknown RL seed distributions, task-population generalization, independent-team replication, universal seed requirements, or algorithm rankings."""


def heading_level(line: str) -> tuple[int, str] | None:
    if line.startswith("## "):
        return 1, line[3:].strip()
    if line.startswith("### "):
        return 2, line[4:].strip()
    return None


def build() -> None:
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    output: list[str] = [
        "# Reliability--Cost Frontiers for Sequential Evaluation of Reinforcement Learning Algorithms",
        "",
        "**Concise submission main-text version.** The full audited v3 manuscript and supplementary diagnostics remain in `MANUSCRIPT_DRAFT_V3.md` and the submission archive.",
        "",
    ]
    active_top: str | None = None
    in_abstract = False
    abstract_written = False
    i = 0

    while i < len(lines):
        line = lines[i]
        parsed = heading_level(line)
        if parsed and parsed[0] == 1:
            active_top = parsed[1]
            in_abstract = active_top == "Abstract"
            if active_top == "Abstract":
                output.extend(["## Abstract", "", CORE_ABSTRACT, ""])
                abstract_written = True
                i += 1
                while i < len(lines):
                    next_heading = heading_level(lines[i])
                    if next_heading and next_heading[0] == 1:
                        break
                    i += 1
                continue
            if active_top in KEEP_TOP_LEVEL:
                output.extend([line, ""])
            else:
                active_top = None
            i += 1
            continue

        if active_top is None or in_abstract:
            i += 1
            continue

        if active_top == "5. Results" and parsed and parsed[0] == 2:
            if parsed[1] in KEEP_RESULT_SUBSECTIONS:
                output.extend([line, ""])
            else:
                i += 1
                while i < len(lines):
                    nested = heading_level(lines[i])
                    if nested and nested[0] == 2:
                        break
                    if nested and nested[0] == 1:
                        break
                    i += 1
                continue
            i += 1
            continue

        output.append(line)
        i += 1

    if not abstract_written:
        raise RuntimeError("source manuscript has no Abstract heading")

    marker = (
        "\n## Supplementary material boundary\n\n"
        "The full audited v3 manuscript and post-v3 diagnostics remain in "
        "`MANUSCRIPT_DRAFT_V3.md` and the submission archive. The following "
        "items are supplementary, exploratory, or scope diagnostics and are "
        "not pooled into the primary v3 estimand: calibration-grid results, "
        "alternative intervals, normalization and threshold sensitivity, "
        "training-budget and evaluation-episode changes, partial-observation "
        "and continuous-control extensions, the queue follow-up, and v4/v5 "
        "new-seed resolution-cost extensions including V7. Their raw data, preregistrations, "
        "and audits remain available for peer review.\n"
    )
    references_index = next((idx for idx, value in enumerate(output) if value == "## References"), None)
    if references_index is None:
        raise RuntimeError("core manuscript has no References heading")
    output[references_index:references_index] = marker.splitlines()
    OUTPUT.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    build()

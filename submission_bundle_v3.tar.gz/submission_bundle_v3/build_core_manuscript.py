"""Build a concise submission main text from the audited v3 manuscript.

The full v3 manuscript remains the source of record.  This script keeps the
pre-specified protocol, theorem, primary v3 results, limitations, and claim
evidence table in the main text while moving post-v3 diagnostics to the
supplementary package.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "MANUSCRIPT_DRAFT_V3.md"
OUTPUT = ROOT / "MANUSCRIPT_SUBMISSION_CORE_EN.md"

KEEP_TOP_LEVEL = {
    "1. Introduction",
    "2. Related Work",
    "3. Estimand and Statistical Protocol",
    "4. Experimental Design",
    "5. Results",
    "6. Discussion",
    "7. Limitations and Threats to Validity",
    "8. Reproducibility and Open Materials",
    "9. Claim--Evidence Table",
    "10. Conclusion",
    "11. Declarations",
    "References",
}

KEEP_RESULT_SUBSECTIONS = {
    "5.1 Data accounting and decisions",
    "5.2 Descriptive test means",
    "5.2.1 Raw-return summaries",
    "5.3 Formal intervals",
    "5.3.1 Descriptive effect sizes",
    "5.4 Same-machine repeatability",
    "5.4.1 Different-machine sealed rerun",
    "5.5 Seed-level distribution and configuration selection",
    "5.5.1 Validation-selection resampling diagnostic",
    "5.5.2 Execution-time accounting",
    "5.5.3 Reliability--cost frontier",
}

CORE_ABSTRACT = """Reinforcement-learning (RL) benchmark comparisons are affected by training-seed variation, environment randomness, configuration selection, and repeated interim inspection. We study the reliability--cost boundary of a sequential evaluation protocol rather than proposing a policy-learning algorithm. The protocol selects configurations on validation seeds, freezes them before sealed testing, defines a bounded normalized learning-curve metric, and uses a finite-look unpaired Hoeffding interval with predeclared family-wise error spending. A selection-invariance proposition covers validation-only selection, and a locked-stopping lemma covers pairwise decisions at different predeclared looks. We evaluate PPO, DQN, and A2C on five disclosed discrete-action tasks; each of 15 algorithm-pair comparisons uses four candidate configurations, five validation seeds per candidate, and 20 sealed test seeds. All comparisons reach the maximum budget without a superiority or 0.10-width precision decision. A pre-study feasibility audit and analytic corollary show that this non-resolution is forced by the bounded interval and the formal budget for any data in the metric range, so it is not evidence of algorithmic equivalence. A separately implemented replay matches the stored summaries on the same machine, and a sealed Windows AMD64 rerun matches all 15 selected configurations and terminal decisions; 14 of 15 cells have zero seed-level differences and one cell shows a small reported platform difference. These results support repeatability and different-machine reproducibility of the disclosed protocol, but not scientific replication on a new task family or verified independent-team identity. A controlled dependence stress test shows that correlated seed observations can invalidate the nominal interval; a known-block fallback is valid only under its explicit independent-block assumptions. The study therefore provides a conditional protocol characterization for the disclosed tasks and budget. It does not establish universal seed requirements, algorithm rankings, compute savings, or scientific replication beyond the frozen task family."""


def heading_level(line: str) -> tuple[int, str] | None:
    if line.startswith("## "):
        return 1, line[3:].strip()
    if line.startswith("### "):
        return 2, line[4:].strip()
    return None


def build() -> None:
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    output: list[str] = [
        "# Reliability--Cost Frontiers for Sequential Evaluation of Reinforcement Learning Algorithms",
        "",
        "**Concise submission main-text version.** The full audited v3 manuscript and supplementary diagnostics remain in `MANUSCRIPT_DRAFT_V3.md` and the submission archive.",
        "",
    ]
    active_top: str | None = None
    in_abstract = False
    abstract_written = False
    i = 0

    while i < len(lines):
        line = lines[i]
        parsed = heading_level(line)
        if parsed and parsed[0] == 1:
            active_top = parsed[1]
            in_abstract = active_top == "Abstract"
            if active_top == "Abstract":
                output.extend(["## Abstract", "", CORE_ABSTRACT, ""])
                abstract_written = True
                i += 1
                while i < len(lines):
                    next_heading = heading_level(lines[i])
                    if next_heading and next_heading[0] == 1:
                        break
                    i += 1
                continue
            if active_top in KEEP_TOP_LEVEL:
                output.extend([line, ""])
            else:
                active_top = None
            i += 1
            continue

        if active_top is None or in_abstract:
            i += 1
            continue

        if active_top == "5. Results" and parsed and parsed[0] == 2:
            if parsed[1] in KEEP_RESULT_SUBSECTIONS:
                output.extend([line, ""])
            else:
                i += 1
                while i < len(lines):
                    nested = heading_level(lines[i])
                    if nested and nested[0] == 2:
                        break
                    if nested and nested[0] == 1:
                        break
                    i += 1
                continue
            i += 1
            continue

        output.append(line)
        i += 1

    if not abstract_written:
        raise RuntimeError("source manuscript has no Abstract heading")

    marker = (
        "\n## Supplementary material boundary\n\n"
        "The full audited v3 manuscript and post-v3 diagnostics remain in "
        "`MANUSCRIPT_DRAFT_V3.md` and the submission archive. The following "
        "items are supplementary, exploratory, or scope diagnostics and are "
        "not pooled into the primary v3 estimand: calibration-grid results, "
        "alternative intervals, normalization and threshold sensitivity, "
        "training-budget and evaluation-episode changes, partial-observation "
        "and continuous-control extensions, the queue follow-up, and v4/v5 "
        "new-seed resolution-cost extensions. Their raw data, preregistrations, "
        "and audits remain available for peer review.\n"
    )
    references_index = next((idx for idx, value in enumerate(output) if value == "## References"), None)
    if references_index is None:
        raise RuntimeError("core manuscript has no References heading")
    output[references_index:references_index] = marker.splitlines()
    OUTPUT.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    build()

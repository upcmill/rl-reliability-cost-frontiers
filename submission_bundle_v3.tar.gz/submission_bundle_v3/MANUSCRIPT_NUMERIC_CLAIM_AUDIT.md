# Manuscript Numeric Claim Audit

This audit cross-checks high-risk numbers in the full and concise English
manuscripts against the stored CSV/JSON artifacts. It does not replace
the statistical proof or external review.

- Status: **PASS**

| Check | Result |
|---|:---:|
| `primary_row_and_decision_counts` | PASS |
| `primary_counts_appear_in_full_and_core` | PASS |
| `formal_budget_values_appear_in_both_manuscripts` | PASS |
| `frontier_matches_primary_look_schedule` | PASS |
| `runtime_values_match_manuscript` | PASS |
| `v4_counts_and_scope_match` | PASS |
| `v5_counts_and_scope_match` | PASS |
| `external_rerun_difference_summary_matches` | PASS |
| `v7_audit_and_summary_match` | PASS |
| `v7_claims_appear_in_both_english_sources` | PASS |
| `v7_claims_appear_in_english_word_files` | PASS |
| `prestudy_budget_audit_values_match` | PASS |
| `english_word_numeric_anchors_match` | PASS |
| `chinese_word_numeric_anchors_match` | PASS |

This audit checks selected numerical anchors only. It does not validate the probabilistic assumptions, literature novelty, or the scientific generality of the claims.

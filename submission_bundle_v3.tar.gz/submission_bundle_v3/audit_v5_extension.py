#!/usr/bin/env python3
"""Audit the v5 new-seed resolution-cost diagnostic."""

from __future__ import annotations

import csv
import hashlib
import json
from itertools import combinations
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision
from sequential_sb3_runner_v3 import ADDITIONAL_ENV_IDS, ALGORITHMS, DEFAULT_ENV_IDS, QUEUE_ENV_ID


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "sb3_v5_extension"
REFERENCE = ROOT / "sb3_formal_v3"
ENVIRONMENTS = (*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)


def main() -> None:
    rows = list(csv.DictReader((OUTPUT / "raw_seed_metrics.csv").open(newline="", encoding="utf-8")))
    metadata = json.loads((OUTPUT / "run_config.json").read_text(encoding="utf-8"))
    reference = json.loads((REFERENCE / "summary.json").read_text(encoding="utf-8"))
    assert metadata["status"] == "v5_post_v4_resolution_cost_diagnostic"
    assert len(rows) == 15_000
    assert len({(r["env_id"], r["algorithm"], r["seed"]) for r in rows}) == 15_000
    assert {int(r["train_seed"]) for r in rows} == set(range(30_400, 31_400))
    assert all(r["split"] == "extension_test" and r["status"] == "ok" for r in rows)
    assert all(0.0 <= float(r["metric_normalized"]) <= 1.0 for r in rows)
    for env_id in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            key = f"{env_id}:{algorithm}"
            expected = reference["summary"][key]["selected_config"]
            cell = [r for r in rows if r["env_id"] == env_id and r["algorithm"] == algorithm]
            assert len(cell) == 1000
            assert {r["config_id"] for r in cell} == {expected}

    values = {
        (env_id, algorithm): [
            float(r["metric_normalized"])
            for r in sorted(rows, key=lambda x: int(x["seed"]))
            if r["env_id"] == env_id and r["algorithm"] == algorithm
        ]
        for env_id in ENVIRONMENTS
        for algorithm in ALGORITHMS
    }
    cfg = ProtocolConfig(
        alpha=0.05 / 15,
        practical_margin=0.05,
        initial_seeds=200,
        batch_size=200,
        max_seeds=1000,
        target_width=0.10,
        interval_method="hoeffding_unpaired",
        bootstrap_resamples=1000,
    )
    final = {}
    for env_id in ENVIRONMENTS:
        for algorithm_a, algorithm_b in combinations(ALGORITHMS, 2):
            key = f"{env_id}:{algorithm_a}_vs_{algorithm_b}"
            final[key] = sequential_decision(values[(env_id, algorithm_a)], values[(env_id, algorithm_b)], cfg)
    payload = {
        "status": "PASS",
        "rows": len(rows),
        "cell_count": 15,
        "new_seed_range": "30400-31399",
        "config_matches_v3": True,
        "no_overlap_with_v3_v4": True,
        "decision_counts": {},
        "recomputed_decisions": final,
        "sha256": {
            "raw_seed_metrics.csv": hashlib.sha256((OUTPUT / "raw_seed_metrics.csv").read_bytes()).hexdigest(),
            "run_config.json": hashlib.sha256((OUTPUT / "run_config.json").read_bytes()).hexdigest(),
            "v5_budget_extension.py": hashlib.sha256((ROOT / "v5_budget_extension.py").read_bytes()).hexdigest(),
            "FINAL_PREREGISTRATION_V5_EXTENSION.md": hashlib.sha256((ROOT / "FINAL_PREREGISTRATION_V5_EXTENSION.md").read_bytes()).hexdigest(),
        },
        "interpretation": metadata["interpretation"],
    }
    counts = {}
    for decision in final.values():
        counts[decision["decision"]] = counts.get(decision["decision"], 0) + 1
    payload["decision_counts"] = counts
    (ROOT / "V5_EXTENSION_AUDIT.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    table_rows = []
    for key, result in final.items():
        table_rows.append(
            f"| {key.replace(':', ' / ').replace('_vs_', ' − ')} | {result['n']} | "
            f"{result['estimate']:.6f} | [{result['lower']:.6f}, {result['upper']:.6f}] | "
            f"`{result['decision']}` |"
        )
    lines = [
        "# v5 Extension Audit",
        "",
        "Status: **PASS**",
        "",
        "- 15,000 rows across 15 task--algorithm cells.",
        "- New training seeds are exactly 30400--31399 and do not overlap v3 or v4.",
        "- Every cell uses its frozen v3-selected configuration.",
        f"- Decision counts: {json.dumps(counts, sort_keys=True)}.",
        "- Scope: post-v4 same-machine resolution-cost diagnostic; no pooled or external inference.",
        "",
        "## Recomputed decisions",
        "",
        "| Comparison | n at terminal/cap | Estimate | Family-adjusted interval | Decision |",
        "|---|---:|---:|---|---|",
        *table_rows,
        "",
        "The machine-readable recomputation and source hashes are in `V5_EXTENSION_AUDIT.json`.",
    ]
    (ROOT / "V5_EXTENSION_AUDIT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

"""Compare an independent deterministic rerun with the frozen analysis outputs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
EXPECTED = ROOT / 'sequential_comparison_v1/results_v1'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(candidate):
    candidate = Path(candidate)
    if not candidate.is_dir():
        raise FileNotFoundError(candidate)
    checked = []
    exact_files = ('real_intervals.csv', 'real_pair_decisions.csv', 'real_summary.json', 'simulation_summary.json')
    for name in exact_files:
        left, right = EXPECTED / name, candidate / name
        if digest(left) != digest(right):
            raise AssertionError(f'byte mismatch: {name}')
        checked.append({'file': name, 'sha256': digest(left), 'byte_identical': True})
    archives = []
    for left in sorted(EXPECTED.glob('replicate_outcomes_*.npz')):
        right = candidate / left.name
        with np.load(left, allow_pickle=False) as a, np.load(right, allow_pickle=False) as b:
            if set(a.files) != set(b.files):
                raise AssertionError(f'array-key mismatch: {left.name}')
            keys = sorted(a.files)
            if any(a[k].shape != b[k].shape or not np.array_equal(a[k], b[k]) for k in keys):
                raise AssertionError(f'array-value mismatch: {left.name}')
        archives.append({'file': left.name, 'arrays': len(keys), 'values_exact': True})
    return {'status': 'PASS', 'reproduction_level': 'same-team same-machine deterministic rerun',
        'independent_team_reproduction': False, 'new_RL_training_runs': 0,
        'summary_and_csv_files': checked, 'replicate_archives': archives,
        'expected_run_manifest_sha256': digest(EXPECTED / 'RUN_MANIFEST.json')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    report = verify(args.candidate)
    serialized = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
    if args.report:
        args.report.write_text(serialized, encoding='utf-8')
    print(serialized, end='')


if __name__ == '__main__':
    main()

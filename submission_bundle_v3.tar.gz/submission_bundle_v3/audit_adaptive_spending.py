#!/usr/bin/env python3
"""Audit the validation-selected alpha-spending diagnostic output."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    payload = json.loads((ROOT / "adaptive_spending_diagnostic.json").read_text())
    assert payload["status"] == "diagnostic_only"
    assert payload["sample_sizes"] == [50, 100, 150, 200]
    assert payload["validation_size"] == 200
    assert payload["replicates"] == 2000
    assert set(payload["schedules"]) == {
        "power_series",
        "front_loaded",
        "late_loaded",
        "minimax",
    }
    for schedule in payload["schedules"].values():
        assert len(schedule) == 4
        assert abs(sum(schedule) - payload["alpha"]) < 1e-12
        assert all(0.0 < value < payload["alpha"] for value in schedule)
    assert len(payload["results"]) == 4
    assert all(item["coverage_failures"] == 0 for item in payload["results"])
    assert all(item["false_superiority_count"] == 0 for item in payload["results"])
    assert all(item["replicates"] == 2000 for item in payload["results"])
    print("adaptive spending diagnostic audit: PASS")
    print("scenarios=4 replicates=8000 coverage_failures=0 false_superiority=0 schedules=4")


if __name__ == "__main__":
    main()

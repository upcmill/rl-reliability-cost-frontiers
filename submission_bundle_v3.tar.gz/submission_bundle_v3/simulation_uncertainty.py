#!/usr/bin/env python3
"""Add Wilson Monte Carlo intervals to stored simulation proportions."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


Z = 1.959963984540054


def wilson(successes: float, trials: int, z: float = Z) -> dict:
    if trials < 1 or not 0.0 <= successes <= trials:
        raise ValueError("invalid binomial count")
    p = successes / trials
    denominator = 1.0 + z * z / trials
    center = (p + z * z / (2.0 * trials)) / denominator
    radius = z * math.sqrt(p * (1.0 - p) / trials + z * z / (4.0 * trials * trials)) / denominator
    return {"estimate": p, "lower": max(0.0, center - radius), "upper": min(1.0, center + radius)}


def proportion_interval(value: float, trials: int) -> dict:
    return wilson(value * trials, trials)


def annotate_coverage(payload: dict) -> dict:
    results = []
    for row in payload["results"]:
        replicates = int(row["replicates"])
        annotated = dict(row)
        annotated["simultaneous_coverage_interval_95"] = proportion_interval(row["simultaneous_coverage"], replicates)
        annotated["coverage_by_look_interval_95"] = {
            look: proportion_interval(value, replicates)
            for look, value in row["coverage_by_look"].items()
        }
        results.append(annotated)
    return {**payload, "status": "coverage_pilot_with_monte_carlo_intervals", "results": results}


def annotate_tradeoff(payload: dict) -> dict:
    results = []
    for row in payload["cells"]:
        replicates = int(row["replicates"])
        annotated = dict(row)
        for mode in ("sequential", "fixed"):
            mode_data = dict(row[mode])
            mode_data["false_superiority_rate_interval_95"] = proportion_interval(
                mode_data["false_superiority_rate"], replicates
            )
            mode_data["max_budget_fraction_interval_95"] = proportion_interval(
                mode_data["max_budget_fraction"], replicates
            )
            annotated[mode] = mode_data
        results.append(annotated)
    return {**payload, "status": "tradeoff_pilot_with_monte_carlo_intervals", "cells": results}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    payload = json.loads(Path(args.input).read_text(encoding="utf-8"))
    if "results" in payload:
        output = annotate_coverage(payload)
    elif "cells" in payload:
        output = annotate_tradeoff(payload)
    else:
        parser.error("input must contain either results or cells")
    Path(args.output).write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

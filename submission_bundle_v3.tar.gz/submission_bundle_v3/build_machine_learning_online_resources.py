#!/usr/bin/env python3
"""Build the six versioned Machine Learning online resources."""

from __future__ import annotations

import hashlib
import ast
import json
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "online_resources"

GROUPS = {
    "Online_Resource_2_Primary_v3.zip": [
        "README.md", "FINAL_PREREGISTRATION_V3.md", "FORMAL_V3_REPORT.md",
        "REPRODUCTION_MANIFEST_V3.md", "THEORY_AUDIT_V3.json",
        "sb3_formal_v3/raw_seed_metrics.csv", "sb3_formal_v3/run_config.json",
        "sb3_formal_v3/summary.json", "sb3_formal_v3/descriptive_summary.json",
        "sb3_formal_v3/familywise_cost_summary.json",
        "sb3_formal_v3/independent_reproduction_summary.json",
        "sb3_formal_v3/v3_robustness_analysis.json", "INDEPENDENT_V3_RECOMPUTE.md",
        "INDEPENDENT_V3_RECOMPUTE.json", "independent_v3_recompute.py",
    ],
    "Online_Resource_3_Supplementary_Experiments.zip": [
        "SUPPLEMENTARY_MACHINE_LEARNING_EN.md", "SUPPLEMENTARY_MACHINE_LEARNING_EN.docx",
        "V4_EXTENSION_REPORT.md", "V4_EXTENSION_AUDIT.json", "V5_EXTENSION_AUDIT.md",
        "V5_EXTENSION_AUDIT.json", "sb3_v6_task_family/V6_TASK_FAMILY_EXTENSION_REPORT.md",
        "sb3_v6_task_family/V6_TASK_FAMILY_AUDIT.json",
        "V7_PROSPECTIVE_VALIDATION_PLAN.md", "V7_CONFIRMATION_AUDIT.json",
        "sb3_v4_extension/raw_seed_metrics.csv", "sb3_v4_extension/run_config.json",
        "sb3_v4_extension/summary.json", "sb3_v5_extension/raw_seed_metrics.csv",
        "sb3_v5_extension/run_config.json", "sb3_v5_extension/summary.json",
        "sb3_v6_task_family/raw_seed_metrics.csv", "sb3_v6_task_family/run_config.json",
        "sb3_v6_task_family/summary.json", "sb3_v7_confirmation/raw_seed_metrics.csv",
        "sb3_v7_confirmation/run_config.json", "sb3_v7_confirmation/analysis/intervals.csv",
        "sb3_v7_confirmation/analysis/summary.json",
    ],
    "Online_Resource_4_Dependence_Diagnostics.zip": [
        "DEPENDENCY_STRESS_DIAGNOSTIC.md", "DEPENDENCY_STRESS_DIAGNOSTIC.json",
        "dependency_stress_diagnostic.py", "test_dependency_stress_diagnostic.py",
        "DEPENDENCY_ROBUST_FALLBACK.md", "DEPENDENCY_ROBUST_FALLBACK.json",
        "dependency_robust_fallback_diagnostic.py", "test_dependency_robust_fallback_diagnostic.py",
    ],
    "Online_Resource_6_External_Rerun.zip": [
        "复跑结果/EXTERNAL_RERUN_AUDIT.md", "复跑结果/EXTERNAL_RERUN_AUDIT.json",
        "复跑结果/external_rerun_output/raw_seed_metrics.csv",
        "复跑结果/external_rerun_output/run_config.json",
        "复跑结果/external_rerun_output/summary.json",
        "复跑结果/external_rerun_output/final_metadata.json",
        "复跑结果/external_rerun_output/EXTERNAL_RERUN_OUTPUT_SHA256SUMS.txt",
        "复跑结果/external_rerun_output/external_rerun.log",
    ],
}


def complete_groups() -> None:
    import build_submission_bundle
    GROUPS["Online_Resource_2_Primary_v3.zip"].extend([
        "SEED_DISTRIBUTION_TABLE_V3.md", "RUNTIME_COST_TABLE_V3.md", "RUNTIME_COST_TABLE_V3.json",
        "VALIDATION_TUNING_COST_V3.md", "VALIDATION_TUNING_COST_V3.json",
        "REPRODUCTION_HASHES_V3.txt", "FINAL_PREREGISTRATION_V3.md",
    ])
    GROUPS["Online_Resource_6_External_Rerun.zip"].extend([
        "EXTERNAL_RERUN_PROTOCOL.md", "audit_external_rerun.py", "validate_external_rerun.py",
        "复跑结果/handoff_windows/preflight_metadata.json", "复跑结果/handoff_windows/handoff_manifest.txt",
    ])
    supplementary_prefixes = (
        "sb3_v", "sb3_budget_", "sb3_eval_", "sb3_tuning_", "sb3_partial_", "sb3_continuous_",
        "sb3_queue_", "sb3_pilot_results_round4/", "round3_analysis/", "round5_analysis/", "round6_analysis/",
        "sequential_comparison_v1/", "CALIBRATION_", "calibration_", "V3_NORMALIZATION_", "v3_normalization_",
        "MARGIN_", "margin_", "VALIDATION_SELECTION_", "validation_selection_", "ADAPTIVE_", "adaptive_",
        "TUNING_", "FINAL_PREREGISTRATION_", "V4_", "V5_", "V7_", "CONTINUOUS_", "PARTIAL_",
        "QUEUE_", "queue_oracle", "BUDGET_SCALING", "EVAL_EPISODE", "UNPAIRED_", "unpaired_empirical_",
        "REPRODUCTION_MANIFEST_", "MINIMAX_", "minimax_", "DESIGN_PLANNING_", "SUPPLEMENTARY_DIAGNOSTIC_",
    )
    GROUPS["Online_Resource_3_Supplementary_Experiments.zip"].extend(
        name for name in build_submission_bundle.INCLUDE if name.startswith(supplementary_prefixes))
    GROUPS["Online_Resource_3_Supplementary_Experiments.zip"].extend([
        "test_partial_observable_env.py", "partial_observable_env.py",
        "partial_observable_scope_runner.py",
    ])
    for name, members in GROUPS.items():
        paths = set(members)
        scanned = set()
        while True:
            todo = [p for p in paths if p.endswith(".py") and p not in scanned]
            if not todo:
                break
            for relative in todo:
                scanned.add(relative)
                for node in ast.walk(ast.parse((ROOT / relative).read_text())):
                    modules = ([a.name.split(".")[0] for a in node.names] if isinstance(node, ast.Import)
                               else [node.module.split(".")[0]] if isinstance(node, ast.ImportFrom) and node.module else [])
                    for module in modules:
                        if (ROOT / (module + ".py")).is_file():
                            paths.add(module + ".py")
        GROUPS[name] = sorted(paths)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_zip(name: str, members: list[str]) -> Path:
    missing = [member for member in members if not (ROOT / member).is_file()]
    if missing:
        raise SystemExit(f"{name}: missing members: {', '.join(missing)}")
    destination = OUT / name
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for member in members:
            archive.write(ROOT / member, arcname=member)
        archive.writestr("RESOURCE_MANIFEST.json", json.dumps([
            {"path": member, "bytes": (ROOT / member).stat().st_size,
             "sha256": sha256(ROOT / member)} for member in members
        ], ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(destination) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"{name}: corrupt member {bad}")
    return destination


def main() -> None:
    OUT.mkdir(exist_ok=True)
    complete_groups()
    supplement_pdf = ROOT / "ml_supplement_render/SUPPLEMENTARY_MACHINE_LEARNING_EN.pdf"
    if not supplement_pdf.is_file():
        raise SystemExit(f"missing supplementary PDF: {supplement_pdf}")
    supplement = OUT / "Online_Resource_1_Supplement.pdf"
    supplement.write_bytes(supplement_pdf.read_bytes())
    artifacts = [supplement]
    artifacts.extend(build_zip(name, members) for name, members in GROUPS.items())
    bundle = ROOT / "submission_bundle_v3.tar.gz"
    shutil.copy2(bundle, OUT / bundle.name)
    artifacts.append(OUT / bundle.name)
    lines = [f"{sha256(path)}  {path.name}" for path in artifacts]
    (OUT / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    for path in artifacts:
        print(f"{path.name}\t{path.stat().st_size}\t{sha256(path)}")


if __name__ == "__main__":
    main()

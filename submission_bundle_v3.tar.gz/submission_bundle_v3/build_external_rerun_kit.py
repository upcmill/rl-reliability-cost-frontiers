#!/usr/bin/env python3
"""Build a sealed source kit for an independent v3 rerun.

The builder has an explicit allow-list and refuses to include primary result
directories or raw result files. The optional wheel directory is included by
default because it makes the core installation artifacts available offline;
platform compatibility must still be checked by the external operator.
"""

from __future__ import annotations

import argparse
import hashlib
import shutil
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE_FILES = (
    "EXTERNAL_RERUN_HANDOFF_ZH.md",
    "EXTERNAL_RERUN_PROTOCOL.md",
    "REPRODUCTION_MANIFEST_V3.md",
    "sequential_sb3_runner_v3.py",
    "sb3_pilot.py",
    "pilot_protocol.py",
    "nonstationary_queue_env.py",
    "requirements-rl.txt",
    "requirements-rl-lock.txt",
    "validate_external_rerun.py",
    "collect_external_rerun_metadata.py",
    "package_external_rerun.py",
    "test_nonstationary_queue.py",
    "test_external_rerun_validator.py",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def copy_allow_list(destination: Path, include_wheels: bool) -> None:
    for relative in SOURCE_FILES:
        source = ROOT / relative
        if not source.is_file():
            raise SystemExit(f"required kit source is missing: {source}")
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    if include_wheels:
        wheel_root = ROOT / "wheels"
        if not wheel_root.is_dir():
            raise SystemExit(f"wheel directory is missing: {wheel_root}")
        for source in sorted(wheel_root.glob("*.whl")):
            target = destination / "wheels" / source.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)


def write_manifests(destination: Path) -> None:
    paths = sorted(path for path in destination.rglob("*") if path.is_file())
    contents = "\n".join(str(path.relative_to(destination)) for path in paths) + "\n"
    (destination / "KIT_CONTENTS.txt").write_text(contents, encoding="utf-8")
    paths = sorted(path for path in destination.rglob("*") if path.is_file() and path.name != "KIT_SHA256SUMS.txt")
    lines = [f"{sha256_file(path)}  {path.relative_to(destination)}" for path in paths]
    (destination / "KIT_SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def audit_members(destination: Path) -> None:
    forbidden_suffixes = {"raw_seed_metrics.csv", "summary.json", "familywise_cost_summary.json"}
    for path in destination.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(destination)
        if "sb3_formal_v3" in relative.parts or path.name in forbidden_suffixes:
            raise SystemExit(f"forbidden reference artifact in kit: {relative}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default="external_rerun_kit_v3")
    parser.add_argument("--archive", default="external_rerun_kit_v3.tar.gz")
    parser.add_argument("--without-wheels", action="store_true", help="omit the local wheel cache")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    destination = Path(args.output_dir).resolve()
    archive = Path(args.archive).resolve()
    if (destination.exists() or archive.exists()) and not args.force:
        raise SystemExit("output exists; use --force only when rebuilding the kit")
    if destination.exists():
        shutil.rmtree(destination)
    if archive.exists():
        archive.unlink()
    destination.mkdir(parents=True)
    copy_allow_list(destination, include_wheels=not args.without_wheels)
    audit_members(destination)
    write_manifests(destination)
    audit_members(destination)
    with tarfile.open(archive, "w:gz") as handle:
        handle.add(destination, arcname=destination.name)
    print(f"wrote {destination}")
    print(f"wrote {archive} ({archive.stat().st_size} bytes)")
    print(f"wheel cache included: {not args.without_wheels}")


if __name__ == "__main__":
    main()

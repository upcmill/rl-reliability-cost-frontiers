import unittest

import numpy as np

from sb3_pilot import evaluate, normalize_returns


class ConstantActionModel:
    def __init__(self, action):
        self.action = action

    def predict(self, observation, deterministic=True):
        return np.asarray([self.action]), None


class SB3EnvironmentCompatibilityTests(unittest.TestCase):
    def test_taxi_scalar_action_conversion(self):
        value, returns = evaluate(ConstantActionModel(0), "Taxi-v4", 123, 1)
        self.assertEqual(len(returns), 1)
        self.assertTrue(np.isfinite(value))

    def test_v2_normalization_bounds(self):
        self.assertEqual(normalize_returns("MountainCar-v0", [-200.0, 0.0]), [0.0, 1.0])
        self.assertEqual(normalize_returns("Taxi-v4", [-2000.0, 20.0]), [0.0, 1.0])


if __name__ == "__main__":
    unittest.main()


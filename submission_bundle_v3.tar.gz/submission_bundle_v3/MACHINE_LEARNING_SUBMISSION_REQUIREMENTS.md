# Machine Learning 投稿整理基线

核对日期：2026-11-11。依据 Springer 官方投稿指南：
<https://link.springer.com/journal/10994/submission-guidelines>。

## 已确定的硬要求

| 项目 | 官方要求 | 当前处理 |
|---|---|---|
| 语言 | 投稿稿应使用清晰、完整的英文 | 当前第七轮权威稿为中文；现有英文稿是旧版本，不能直接提交 |
| Contribution Information Sheet | 每次投稿附 1--2 页，回答主要主张、重要性、证据、最相关工作、既有发表或重叠情况 | 已有文件，本轮按第七轮内容更新 |
| 摘要 | 150--250 词；不得含未定义缩写或未说明来源的引用 | 英文定稿时按字数和缩写逐项检查 |
| 关键词 | 4--6 个 | 中文稿为 6 个；英文稿定稿时保持 4--6 个 |
| 标题层级 | 使用十进制标题，最多三级 | 英文定稿需统一为 1、1.1、1.1.1，不超过三级 |
| 参考文献 | 正文采用作者—年份；文末按首位作者姓氏字母排序，DOI 用完整链接 | 当前中文稿使用编号制；英文投稿稿必须重排 |
| 表格 | 阿拉伯数字连续编号，正文按顺序引用，每表有说明性标题和必要脚注 | 英文主稿需按投稿文件重新编号/引用 |
| 图 | 单独提供电子图文件；文件名含 Fig 和编号；最终字号可读；线图至少 1200 dpi，半色调 300 dpi，组合图 600 dpi | 当前图像需按 Fig1 等重新导出并检查最终尺寸 |
| 数据声明 | 原创研究必须包含 Data Availability Statement | 需要与最终公开归档状态绑定；当前远端归档仍暂缓 |
| 声明 | 需要 Statements and Declarations，至少包括 competing interests，并按适用性写 funding、author contributions、code/data availability | 作者信息暂缓；不得擅自填值 |
| 补充材料 | 标准格式；正文明确引用 Online Resource；每个文件有简短说明；补充材料按提交内容原样发布 | 当前补充材料为 DOCX，需转 PDF 并建立 Online Resource 编号 |
| 文件 | 提交可编辑源文件；Word 或 LaTeX 均可，期刊推荐 LaTeX | 当前可保留 DOCX 作为可编辑稿，正式提交前再决定是否转 LaTeX |

## 当前稿件的主要缺口

1. 当前第七轮权威稿是中文；已建立英文投稿工作稿 `MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.md` 和 Word 版 `MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN.docx`。该英文稿是投稿主文压缩版，补充材料仍需单独整理。
2. 正文引用体系已转换为 Machine Learning 要求的作者—年份制，参考文献已按首位作者姓氏排序并附 DOI/URL。
3. Markdown 源稿保留 LaTeX 公式，Word 版使用 Cambria Math/线性兼容表达；正式提交前仍应在期刊模板中复核公式排版。
4. 已建立英文补充材料 `SUPPLEMENTARY_MACHINE_LEARNING_EN.md` 和 Word 版，其中 S12 提供 Online Resource 清单；仍需导出 PDF、逐项核对文件并把本地路径改为投稿可访问的资源引用。
5. 图像需单独导出、命名、核对分辨率和最终字号；当前环境无 `soffice`，分页视觉复核尚未完成。
6. Data Availability、Code Availability、Funding、Competing Interests、Author Contributions 和作者英文信息仍待作者确认或远端归档同步。

## 不应在本轮擅自改变的内容

- 不改变第七轮已经核验的实验数字、统计规则、主估计对象和限制边界。
- 不把 V4--V7、连续控制、部分可观测和依赖诊断合并进预注册主研究族。
- 不把 `max_budget_inconclusive` 改写成算法等价或失败证据。
- 不在作者确认前填入英文姓名、邮箱、ORCID、基金或利益冲突。
- 不上传或修改 Zenodo/GitHub。

## 当前工作状态

本文件是投稿整理基线，不表示已经满足投稿条件。当前可进行英文稿与第七轮中文权威稿的内容同步、标题层级重排、作者无关的公式/图表/引用整理、补充材料拆分和投稿文件清单生成。作者信息、公开归档和最终资源 URL 仍是提交阻塞项。

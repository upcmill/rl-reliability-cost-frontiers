import unittest

from dependency_stress_diagnostic import block_sequence, run_condition


class DependencyStressDiagnosticTests(unittest.TestCase):
    def test_block_sequence_is_bounded_and_deterministic(self):
        import random

        first = block_sequence(random.Random(7), 5, 20)
        second = block_sequence(random.Random(7), 5, 20)
        self.assertEqual(first, second)
        self.assertTrue(all(value in {0.0, 1.0} for value in first))
        self.assertEqual(len(first), 20)
        self.assertEqual(first[:5], [first[0]] * 5)

    def test_condition_output_contains_reproducible_intervals(self):
        first = run_condition(2, 20, 99)
        second = run_condition(2, 20, 99)
        self.assertEqual(first, second)
        self.assertEqual(first["replicates"], 20)
        self.assertGreaterEqual(first["simultaneous_coverage"], 0.0)
        self.assertLessEqual(first["simultaneous_coverage"], 1.0)
        self.assertGreaterEqual(first["false_superiority_rate"], 0.0)
        self.assertLessEqual(first["false_superiority_rate"], 1.0)


if __name__ == "__main__":
    unittest.main()

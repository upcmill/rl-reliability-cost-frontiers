#!/usr/bin/env python3
"""Verify the exact files and linked resource payloads prepared for publication."""
import hashlib
import io
import json
import re
import tarfile
import zipfile
from pathlib import Path
import fitz
from lxml import etree
from prepare_machine_learning_english import RESOURCE_BASE, RESOURCE_FILES
from build_submission_bundle import INCLUDE

ROOT = Path(__file__).resolve().parent

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    report = {'release': 'v3.0.5', 'documents': {}, 'resources': {}}
    for stem, directory in [('MANUSCRIPT_MACHINE_LEARNING_SUBMISSION_EN', 'ml_submission_render'),
                            ('SUPPLEMENTARY_MACHINE_LEARNING_EN', 'ml_supplement_render')]:
        md = (ROOT / (stem + '.md')).read_text()
        expected_lines = []
        code = False
        for line in md.splitlines():
            if line.startswith('```'):
                code = not code
                continue
            if 'Submission preparation draft for Machine Learning' in line:
                continue
            if not code:
                if set(line.strip()) <= set('|-: '):
                    continue
                line = re.sub(r'^#{1,6} |^- |^\d+\. ', '', line)
                line = re.sub(r'\[([^]]+)\]\([^)]+\)', r'\1', line)
                line = line.replace('**', '').replace('__', '').replace('`', '').replace('$', '')
                if line.startswith('|'):
                    line = line.replace('|', '')
            expected_lines.append(line)
        expected = ''.join(''.join(expected_lines).split())
        with zipfile.ZipFile(ROOT / (stem + '.docx')) as archive:
            xml = etree.fromstring(archive.read('word/document.xml'))
            ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
            paragraphs = [''.join(p.xpath('.//w:t/text()', namespaces=ns)) for p in xml.xpath('//w:body//w:p', namespaces=ns)]
            actual = ''.join(''.join(p for p in paragraphs if not re.match(r'^Table S\d+\.', p)).split())
            assert expected == actual, stem + ': Markdown/Word text mismatch'
            rels = etree.fromstring(archive.read('word/_rels/document.xml.rels'))
            targets = {r.get('Target') for r in rels if r.get('Type', '').endswith('/hyperlink')}
        expected_urls = {RESOURCE_BASE + '/' + RESOURCE_FILES[int(n)] for n in re.findall(r'\[Online Resource ([1-6])\]', md)}
        assert expected_urls <= targets
        with fitz.open(ROOT / directory / (stem + '.pdf')) as pdf:
            links = {x.get('uri', '') for page in pdf for x in page.get_links()}
            assert expected_urls <= links, stem + ': PDF hyperlinks missing'
            pdf_text = '\n'.join(p.get_text() for p in pdf)
            assert not re.search('/' + r'Users/|复跑结果/|external_rerun_output/|\.rl-arm64-venv', pdf_text)
            report['documents'][stem] = {'pages': len(pdf), 'markdown_word_parity': True, 'linked_resources': len(expected_urls), 'pdf_sha256': digest((ROOT / directory / (stem + '.pdf')).read_bytes())}
    with tarfile.open(ROOT / 'submission_bundle_v3.tar.gz') as archive:
        files = {m.name.removeprefix('submission_bundle_v3/'): m for m in archive.getmembers() if m.isfile()}
        assert set(INCLUDE) == set(files)
        for name, member in files.items():
            assert archive.extractfile(member).read() == (ROOT / name).read_bytes(), name
        report['complete_bundle_members'] = len(files)
    for n, name in RESOURCE_FILES.items():
        path = ROOT / 'online_resources' / name
        if path.suffix == '.zip':
            with zipfile.ZipFile(path) as archive:
                assert archive.testzip() is None
                for row in json.loads(archive.read('RESOURCE_MANIFEST.json')):
                    assert digest(archive.read(row['path'])) == row['sha256'] == digest((ROOT / row['path']).read_bytes())
        report['resources'][name] = {'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes()), 'url': RESOURCE_BASE + '/' + name}
    assert (ROOT / 'online_resources/submission_bundle_v3.tar.gz').read_bytes() == (ROOT / 'submission_bundle_v3.tar.gz').read_bytes()
    report['status'] = 'PASS'
    (ROOT / 'ONLINE_RESOURCES_LOCAL_AUDIT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()

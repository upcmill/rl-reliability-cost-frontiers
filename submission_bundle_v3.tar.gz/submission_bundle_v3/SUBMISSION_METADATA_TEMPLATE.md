# Submission Metadata Template

This file lists fields that must be completed by the authors before public
deposition or journal submission. Bracketed values are placeholders, not
claims. Do not replace them with guessed information.

## Authors

- Authors (order): `穆浩然; 赵海龙`
- Corresponding author: `赵海龙`
- Affiliation(s): `北京建筑大学`
- Email: `[待补充]`
- ORCID(s): `[待补充]`
- English romanization of author names: `[待补充]`
- Author contributions: `[待补充]`

## Declarations

- Funding: `[待补充]`
- Competing interests: `[待补充]`
- Ethics statement: `No human participants, personal data, or animal subjects; simulated environments only.`
- Data/code archive concept DOI: `10.5281/zenodo.23949004` (public; resolves to the latest version)
- Version-specific DOI and release version: see the concept DOI landing page for the latest record
- Archive landing page: `https://zenodo.org/records/23949004`
- Version landing page: `https://zenodo.org/records/23966313`
- Archive verification: `PUBLIC_ARCHIVE_VERIFICATION.md`; the latest published archive package is checked against the current package and includes V7 and third-round materials.
- License recorded by Zenodo: `CC BY 4.0`; individual rights-holder confirmation is not represented by this metadata check.
- Creator recorded by Zenodo: `upcmill`; this does not verify the author order or affiliation listed above.

## External evidence

- External rerun operator/team: `[待补充]`
- External machine and OS: `Windows AMD64; Python 3.11.18; NumPy 2.2.6; PyTorch 2.14.1; Gymnasium 1.4.0; Stable-Baselines3 2.9.2; CPU-only`
- External rerun artifact path or DOI: `复跑结果/EXTERNAL_RERUN_AUDIT.json` (local audited artifact; public DOI `[待补充]`)
- Second literature screener: `[待补充]`
- Database export archive: `[待补充]`

The current workspace has no verified values for the bracketed fields. The
submission audit must remain blocked until each required field is completed or
the authors explicitly document why it is not applicable.

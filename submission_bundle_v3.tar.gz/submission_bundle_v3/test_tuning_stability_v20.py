import json
import unittest
from pathlib import Path


class TuningStabilityV20ArtifactTest(unittest.TestCase):
    def test_audited_extension_is_complete(self):
        audit = json.loads(
            Path("sb3_tuning_stability_v20/TUNING_STABILITY_V20_AUDIT.json")
            .read_text(encoding="utf-8")
        )
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["row_count"], 1215)
        self.assertEqual(audit["validation_row_count"], 1200)
        self.assertEqual(audit["diagnostic_test_row_count"], 15)
        self.assertEqual(audit["validation_seed_range"], [11000, 11019])
        self.assertEqual(audit["selection_change_count"], 7)
        self.assertEqual(audit["failures"], [])


if __name__ == "__main__":
    unittest.main()

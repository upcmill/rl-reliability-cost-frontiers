# Literature Search Log

This log records the reproducible search attempts that support the current
scoping review. It is an audit trail, not evidence that the search is
exhaustive and not a substitute for a database export or second screener.

## Search session

- Date: 2026-10-30 (Asia/Shanghai).
- Working directory: project root (the directory containing this log).
- Search purpose: identify work that could overlap with seed-level RL
  evaluation, evaluation overfitting, reproducibility, sequential inference,
  or confidence-sequence methods.
- Admission rule: a record may enter `REFERENCES_VERIFIED.bib` only after its
  metadata and the substantive claim attributed to it are checked against an
  authoritative landing page or a stable metadata record.

## Queries and observed outcomes

| Endpoint | Query | Outcome | Use in manuscript |
|---|---|---|---|
| Crossref Works API | `Deterministic Implementations for Reproducibility in Deep Reinforcement Learning` | HTTP response returned, but the top-ranked records were unrelated broad matches; no exact-title admission was made. | None; candidate remains `[待核实]`. |
| Crossref Works API | `A Study on Overfitting in Deep Reinforcement Learning` | HTTP response returned, but the top-ranked records were unrelated broad matches; no exact-title admission was made. | None; candidate remains `[待核实]`. |
| Crossref Works API | `Sequential Evaluation Reinforcement Learning Confidence Sequences` | HTTP response returned, but broad ranked results did not establish an exact protocol overlap. | None; no novelty conclusion. |
| arXiv API | Exact-title query for `Nondeterminism as a reproducibility challenge for deep reinforcement learning` | Valid XML response with zero matches for the exact query. | None; this is a failed exact query, not evidence that the work does not exist. |
| OpenAlex Works API | Exact-title searches for the three candidates above and a confidence-sequence query | DNS resolution failed during this session. | None; retry is required before screening. |

The Crossref responses were treated as discovery results only. They were not
used to infer publication status, method details, or novelty. The OpenAlex
failure was recorded so a later search can distinguish an unavailable endpoint
from a zero-result query. No unverified reference was added to the paper.

## 2026-10-30 retry record

The retry succeeded at `2026-10-30T10:39:10Z` UTC. Raw responses are preserved
under `literature_search_raw/2026-10-30_retry/`; the files are source artifacts,
not generated summaries.

| Endpoint | Requested resource | Outcome | Bibliography action |
|---|---|---|---|
| `export.arxiv.org` | arXiv API records `1809.05676` and `1804.06893` | HTTP 200; XML saved as `arxiv_1809_05676_1804_06893.xml` | Metadata and abstracts admitted to the verified source record as L13 and L14. |
| `arxiv.org` | abstract pages for `1809.05676` and `1804.06893` | HTTP 200; HTML saved as `arxiv_1809_05676.html` and `arxiv_1804_06893.html` | Landing-page identity and version links checked; no venue claim inferred. |
| `link.springer.com` | _Machine Learning_ submission guidelines | HTTP 200; HTML saved as `springer_machine_learning_submission_guidelines.html` | Journal title, journal id, hybrid model, scope labels, and submission entry point recorded; detailed policy fields remain `[待核实]` unless visible in the saved page. |
| `api.crossref.org` | journal record `0885-6125` | HTTP 200; JSON saved as `crossref_machine_learning.json` | Publisher and ISSN metadata confirmed. |
| `api.openalex.org` | RL evaluation and random-seed discovery query | HTTP 200; JSON saved as `openalex_rl_evaluation_seeds.json` | Discovery only; no record was admitted solely from ranking. |

For future updates, retain response bytes, the retrieval timestamp, and URL in a
new dated directory before changing the verified bibliography or journal-policy
memo.

## Reproducible retry commands

Run these commands from the project root after network access is stable. Save
the raw responses and the UTC timestamp in a new dated directory; do not
overwrite this log or the verified bibliography.

```bash
curl -sS --max-time 30 \
  'https://api.openalex.org/works?search=Deterministic%20Implementations%20for%20Reproducibility%20in%20Deep%20Reinforcement%20Learning&per-page=25' \
  -o literature_search_raw/openalex_deterministic.json

curl -sS --max-time 30 \
  'https://export.arxiv.org/api/query?search_query=all:%22Nondeterminism%20as%20a%20reproducibility%20challenge%20for%20deep%20reinforcement%20learning%22&max_results=25' \
  -o literature_search_raw/arxiv_nondeterminism.xml
```

For each candidate, record title, author list, year, DOI or arXiv identifier,
landing-page URL, and the exact abstract or full-text passage used for the
screening decision. A second researcher must independently assign include,
exclude, or uncertain before any literature-wide novelty statement is made.

## Current interpretation

The verified set supports motivation around seed variability, evaluation
overfitting, uncertainty, and software provenance. It does not establish that
the exact finite-look, conditional, sealed-test reliability--cost protocol is
novel across all RL evaluation literature. The manuscript must retain
`[待核实]` for that broader statement until the database exports and
independent screening are complete.

## 2026-10-31 discovery update

A dated retry was run after network recovery. OpenAlex discovery searches for
`reinforcement learning evaluation confidence sequences` and `reinforcement
learning statistical comparison random seeds` returned 50 records each;
Crossref returned 50 records for `reinforcement learning evaluation random
seeds confidence`. The raw JSON responses and SHA-256 manifest are stored in
`literature_search_raw/2026-10-31_update/`, and the bounded interpretation is
recorded in `LITERATURE_UPDATE_2026-10-31.md`. The results were broad discovery
records and no new source was admitted to the verified bibliography. Web of
Science, Scopus, IEEE Xplore, ACM Digital Library, Google Scholar, full-text
method comparison, and independent second-person screening remain outstanding.

## 2026-10-30 OpenAlex screening export

The network retry also enabled a reproducible discovery export from OpenAlex.
Six concept queries requested 50 records each and are archived under
`literature_search_raw/2026-10-30_openalex_screening/`, together with DOI-level
lookups and an arXiv API record for the directly relevant candidate *Measuring
the Reliability of Reinforcement Learning Algorithms* (Chan et al.,
arXiv:1912.05663). The export is a first-screener database record, not a
completed systematic review: Web of Science, Scopus, IEEE Xplore, ACM, Google
Scholar, deduplication across all databases, and an independent second screener
remain outstanding.

The OpenAlex discovery changed the novelty assessment. Chan et al. already
provide reliability metrics and statistical comparison tools for RL, while
Khamaru et al. provide adjacent theory on confidence regions and early
stopping. The present manuscript must therefore describe its distinction
narrowly as a finite-look, conditional, sealed-test reliability--cost protocol
for empirical training-seed comparisons and must not claim to be the first work
on RL reliability measurement or RL stopping theory.

## 2026-10-31 official venue-page recheck

During a network-recovery window, the official Springer submission-guidelines
page for *Machine Learning* returned HTTP 200. The raw HTML, retrieval metadata,
and SHA-256 entry are stored under
`literature_search_raw/2026-10-31_update/`. The page was used only to recheck
the Contribution Information Sheet and Data Availability Statement requirements;
current SCI/SCIE indexing, JCR metrics, APC, and acceptance probability remain
unverified.

## 2026-11-01 official venue-page retry

A fresh retrieval attempt for the same Springer submission-guidelines URL was
made after the manuscript package was revised. DNS resolution for
`link.springer.com` failed in this session, so no new HTML or policy claim was
created. The 2026-10-31 archived page remains the latest successful official
retrieval; current SCI/SCIE indexing, JCR metrics, APC, and submission-system
fields remain `[待核实]`.

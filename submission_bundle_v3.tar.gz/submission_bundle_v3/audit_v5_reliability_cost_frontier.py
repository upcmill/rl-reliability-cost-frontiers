#!/usr/bin/env python3
"""Audit the v5 reliability-cost frontier against raw rows and v5 decisions."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

from pilot_protocol import alpha_spend


ROOT = Path(__file__).resolve().parent
RAW = ROOT / "sb3_v5_extension/raw_seed_metrics.csv"
FRONTIER = ROOT / "V5_RELIABILITY_COST_FRONTIER.json"


def main() -> None:
    payload = json.loads(FRONTIER.read_text(encoding="utf-8"))
    with RAW.open(newline="", encoding="utf-8") as handle:
        rows = [row for row in csv.DictReader(handle) if row["split"] == "extension_test" and row["status"] == "ok"]
    checks = {}
    checks["row_count"] = len(rows) == 15_000
    checks["look_count"] = [row["seeds_per_algorithm"] for row in payload["looks"]] == [200, 400, 600, 800, 1000]
    checks["decision_count"] = sum(payload["decision_counts"].values()) == 15
    checks["decision_classes"] = payload["decision_counts"] == {
        "a_superior": 3,
        "b_superior": 1,
        "max_budget_inconclusive": 11,
    }
    checks["radius_nonincreasing"] = all(
        left["radius_sum"] >= right["radius_sum"]
        for left, right in zip(payload["looks"], payload["looks"][1:])
    )
    checks["resolved_monotone"] = all(
        left["resolved_comparisons"] <= right["resolved_comparisons"]
        for left, right in zip(payload["looks"], payload["looks"][1:])
    )
    checks["runtime_matches_raw"] = abs(
        payload["looks"][-1]["cumulative_runtime_seconds"]
        - sum(float(row["runtime_seconds"]) for row in rows)
    ) < 1e-8
    expected_radius = []
    comparison_alpha = 0.05 / 15.0
    for look, n in enumerate((200, 400, 600, 800, 1000), start=1):
        alpha = alpha_spend(comparison_alpha, look)
        expected_radius.append(2.0 * math.sqrt(math.log(4.0 / alpha) / (2.0 * n)))
    checks["radius_matches_formula"] = all(
        abs(row["radius_sum"] - expected) < 1e-12
        for row, expected in zip(payload["looks"], expected_radius)
    )
    status = "PASS" if all(checks.values()) else "FAIL"
    print(json.dumps({"status": status, "checks": checks}, indent=2))
    raise SystemExit(0 if status == "PASS" else 1)


if __name__ == "__main__":
    main()

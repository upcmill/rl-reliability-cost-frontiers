#!/usr/bin/env python3
"""Inventory unresolved submission placeholders without inventing metadata."""

from __future__ import annotations

import json
import re
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
OUTPUT_JSON = ROOT / "SUBMISSION_PLACEHOLDER_AUDIT.json"
OUTPUT_MD = ROOT / "SUBMISSION_PLACEHOLDER_AUDIT.md"

TEXT_FILES = (
    "SUBMISSION_METADATA_TEMPLATE.md",
    "AUTHOR_EXTERNAL_INFO_INTAKE_ZH.md",
    "PUBLIC_DEPOSITION_README.md",
    "CITATION_CFF_TEMPLATE.yml",
    "MANUSCRIPT_DRAFT_V3.md",
    "MANUSCRIPT_SUBMISSION_CORE_EN.md",
    "COVER_LETTER_DRAFT.md",
    "MLJ_CONTRIBUTION_INFORMATION_SHEET.md",
    "JOURNAL_SELECTION_MEMO.md",
)
DOCX_FILES = (
    "MANUSCRIPT_MACHINE_LEARNING_EN.docx",
    "MANUSCRIPT_MACHINE_LEARNING_CORE_EN.docx",
    "MANUSCRIPT_MACHINE_LEARNING_ZH.docx",
    "MLJ_CONTRIBUTION_INFORMATION_SHEET.docx",
)

PATTERNS = {
    "待补充": re.compile(r"\[待补充[^\]]*\]"),
    "待核实": re.compile(r"\[待核实\]"),
    "to_be_completed": re.compile(r"\bto be completed\b|\[Author name and affiliation to be supplied\]", re.I),
}


def extract_docx(path: Path) -> str:
    with ZipFile(path) as archive:
        return archive.read("word/document.xml").decode("utf-8")


def scan(path: Path, text: str) -> dict[str, object]:
    matches: list[dict[str, object]] = []
    lines = text.splitlines()
    for line_number, line in enumerate(lines, start=1):
        for label, pattern in PATTERNS.items():
            for match in pattern.finditer(line):
                matches.append({"type": label, "line": line_number, "text": match.group(0)})
    return {"file": str(path.relative_to(ROOT)), "matches": matches, "count": len(matches)}


def build() -> dict[str, object]:
    records = []
    missing = []
    for name in TEXT_FILES:
        path = ROOT / name
        if not path.is_file():
            missing.append(name)
            continue
        records.append(scan(path, path.read_text(encoding="utf-8")))
    for name in DOCX_FILES:
        path = ROOT / name
        if not path.is_file():
            missing.append(name)
            continue
        records.append(scan(path, extract_docx(path)))
    totals = {label: sum(sum(1 for item in record["matches"] if item["type"] == label) for record in records) for label in PATTERNS}
    return {
        "schema": "submission-placeholder-audit-v1",
        "status": "PASS" if not missing else "FAIL",
        "missing_files": missing,
        "files_scanned": len(records),
        "totals": totals,
        "records": records,
        "interpretation": (
            "Placeholders are intentionally retained until authors and external "
            "evidence gates are supplied. This inventory is not evidence that "
            "the fields are complete."
        ),
    }


def render(payload: dict[str, object]) -> str:
    lines = [
        "# Submission Placeholder Audit",
        "",
        "This inventory reports unresolved author, declaration, archive, venue,",
        "and literature-verification placeholders. It does not replace author",
        "confirmation and does not infer missing metadata.",
        "",
        f"- Status: `{payload['status']}`",
        f"- Files scanned: `{payload['files_scanned']}`",
        f"- `[待补充]` matches: `{payload['totals']['待补充']}`",
        f"- `[待核实]` matches: `{payload['totals']['待核实']}`",
        f"- English completion markers: `{payload['totals']['to_be_completed']}`",
        "",
        "## File-level counts",
        "",
        "| File | Placeholder matches |",
        "|---|---:|",
    ]
    for record in payload["records"]:
        lines.append(f"| `{record['file']}` | {record['count']} |")
    lines.extend([
        "",
        "Replace fields only with values confirmed by the authors, institution,",
        "repository, journal, or database record. After replacement, rerun this",
        "audit, `submission_readiness_audit.py`, the Word audits, and the archive",
        "builder. Literature `[待核实]` markers may remain only where the current",
        "evidence is explicitly bounded in the manuscript.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    payload = build()
    OUTPUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    OUTPUT_MD.write_text(render(payload), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "files_scanned": payload["files_scanned"], "totals": payload["totals"]}, ensure_ascii=False, indent=2))
    if payload["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()

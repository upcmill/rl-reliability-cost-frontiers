import json
import unittest
from pathlib import Path


class PublicArchiveSafetyTest(unittest.TestCase):
    def test_sanitization_audit_passes(self):
        audit = json.loads(
            Path("PUBLIC_ARCHIVE_SANITIZATION_AUDIT.json")
            .read_text(encoding="utf-8")
        )
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["missing_members"], [])
        self.assertEqual(audit["sensitive_hits"], [])


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Record local environment types and source hashes, not benchmark representativeness."""
import argparse
import hashlib
import inspect
import json
from pathlib import Path
import gymnasium as gym
from nonstationary_queue_env import NonstationaryQueueEnv


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.output.exists():p.error('output exists; use a new path')
    result=[]
    for name in ['CartPole-v1','Acrobot-v1','MountainCar-v0','Taxi-v4','NonstationaryQueue-v0']:
        env=NonstationaryQueueEnv() if name=='NonstationaryQueue-v0' else gym.make(name)
        src=Path(inspect.getfile(type(env.unwrapped)))
        result.append({'id':name,'observation_space':str(env.observation_space),
                       'action_space':str(env.action_space),'max_episode_steps':env.horizon if name=='NonstationaryQueue-v0' else env.spec.max_episode_steps,
                       'implementation_module':type(env.unwrapped).__module__,
                       'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
        env.close()
    a.output.write_text(json.dumps({'gymnasium':gym.__version__,'status':'installed_source_inventory_not_representativeness_measure','rows':result},ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()

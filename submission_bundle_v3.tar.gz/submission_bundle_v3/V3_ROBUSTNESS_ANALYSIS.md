# v3 Robustness Analysis

This report contains post-hoc diagnostics on the frozen v3 sealed metrics. It does not change the preregistered primary analysis or create new confirmatory claims.

## Threshold sensitivity

The primary look schedule, comparison alpha, and unpaired Hoeffding interval are held fixed while the practical margin and target width vary.

| Practical margin | Target width | Decision counts |
|---:|---:|---|
| 0.02 | 0.05 | {'max_budget_inconclusive': 15} |
| 0.02 | 0.10 | {'max_budget_inconclusive': 15} |
| 0.02 | 0.20 | {'max_budget_inconclusive': 15} |
| 0.05 | 0.05 | {'max_budget_inconclusive': 15} |
| 0.05 | 0.10 | {'max_budget_inconclusive': 15} |
| 0.05 | 0.20 | {'max_budget_inconclusive': 15} |
| 0.10 | 0.05 | {'max_budget_inconclusive': 15} |
| 0.10 | 0.10 | {'max_budget_inconclusive': 15} |
| 0.10 | 0.20 | {'max_budget_inconclusive': 15} |

## Budget sensitivity

| Maximum seeds per algorithm | Decision counts |
|---:|---|
| 5 | {'max_budget_inconclusive': 15} |
| 10 | {'max_budget_inconclusive': 15} |
| 15 | {'max_budget_inconclusive': 15} |
| 20 | {'max_budget_inconclusive': 15} |

## Interval-method sensitivity

| Method | Decision counts |
|---|---|
| `normal` | {'a_superior': 1, 'b_superior': 1, 'inconclusive_precision': 4, 'max_budget_inconclusive': 9} |
| `bootstrap` | {'a_superior': 1, 'b_superior': 4, 'inconclusive_precision': 5, 'max_budget_inconclusive': 5} |
| `empirical_bernstein` | {'max_budget_inconclusive': 15} |
| `hoeffding` | {'max_budget_inconclusive': 15} |
| `hoeffding_unpaired` | {'max_budget_inconclusive': 15} |

## Width by look

| Seeds per algorithm | Minimum width | Median width | Maximum width |
|---:|---:|---:|---:|
| 5 | 2.0000 | 2.0000 | 2.0000 |
| 10 | 2.0000 | 2.0000 | 2.0000 |
| 15 | 1.8770 | 2.0000 | 2.0000 |
| 20 | 1.7182 | 1.9199 | 2.0000 |

## Interpretation

These analyses are useful for robustness reporting but are post-hoc. The primary v3 claim remains limited to the preregistered family, thresholds, interval, and 20-seed budget. The raw-return rows are descriptive and do not add an algorithm-ranking claim.

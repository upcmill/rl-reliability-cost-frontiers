import unittest

from generate_v5_reliability_cost_frontier import build


class V5ReliabilityCostFrontierTests(unittest.TestCase):
    def test_frontier_is_auditable_and_resolution_is_monotone(self):
        payload = build()
        self.assertEqual(payload["decision_counts"], {
            "a_superior": 3,
            "b_superior": 1,
            "max_budget_inconclusive": 11,
        })
        self.assertEqual([row["seeds_per_algorithm"] for row in payload["looks"]], [200, 400, 600, 800, 1000])
        self.assertEqual(payload["looks"][-1]["resolved_comparisons"], 4)
        self.assertTrue(all(
            left["radius_sum"] >= right["radius_sum"]
            for left, right in zip(payload["looks"], payload["looks"][1:])
        ))
        self.assertTrue(all(
            left["resolved_comparisons"] <= right["resolved_comparisons"]
            for left, right in zip(payload["looks"], payload["looks"][1:])
        ))


if __name__ == "__main__":
    unittest.main()

import tempfile
import unittest
from pathlib import Path

import numpy as np

from analyze_v7_confirmation import N, analyze, load_values


class V7ConfirmationAnalysisTests(unittest.TestCase):
    def test_full_panel_produces_all_method_pair_look_rows(self):
        values = np.full((5, 3, N), 0.5)
        values[:, 0, :] = 0.8
        interval_rows, summary = analyze(values)
        self.assertEqual(len(interval_rows), 9 * 5 * 3 * 5)
        self.assertEqual(len(summary["method_summaries"]), 9)
        self.assertEqual(summary["primary_fixed_panel_outcome"]["comparisons_total"], 15)
        self.assertTrue(np.isfinite(summary["primary_fixed_panel_outcome"][
            "mean_final_width_difference_gamma_minus_original"]))

    def test_loader_rejects_incomplete_sequence(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "raw_seed_metrics.csv"
            path.write_text("env_id,algorithm,train_seed,config_id,split,status,metric_normalized\n"
                "CartPole-v1,PPO,31400,lr3e4_short,v7_confirmation,ok,0.5\n")
            with self.assertRaisesRegex(ValueError, "incomplete data"):
                load_values(path)

    def test_loader_rejects_duplicate_key(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "raw_seed_metrics.csv"
            header = "env_id,algorithm,train_seed,config_id,split,status,metric_normalized\n"
            row = "CartPole-v1,PPO,31400,lr3e4_short,v7_confirmation,ok,0.5\n"
            path.write_text(header + row + row)
            with self.assertRaisesRegex(ValueError, "duplicate row"):
                load_values(path)


if __name__ == "__main__":
    unittest.main()

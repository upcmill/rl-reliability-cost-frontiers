#!/usr/bin/env python3
"""Audit the separate partially observable scope diagnostic artifacts."""

from __future__ import annotations

import csv
import json
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "sb3_partial_observable_scope"


def main() -> None:
    with (RUN / "raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 240, len(rows)
    assert sum(row["split"] == "validation" for row in rows) == 120
    assert sum(row["split"] == "test" for row in rows) == 120
    assert all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows)
    payload = json.loads((RUN / "summary.json").read_text(encoding="utf-8"))
    assert len(payload["comparisons"]) == 6
    assert all(item["decision"]["decision"] == "max_budget_inconclusive" for item in payload["comparisons"])
    assert all(item["decision"]["n"] == 20 for item in payload["comparisons"])
    reproduction = json.loads((RUN / "independent_reproduction.json").read_text(encoding="utf-8"))
    assert reproduction["status"] == "same_machine_cross_script_replay"
    assert reproduction["all_zero_mean_absolute_difference"] is True
    assert len(reproduction["rows"]) == 6

    lines = [
        "# Partially Observable Scope Diagnostic Report",
        "",
        "This report summarizes the separately preregistered fixed-mask diagnostic. It is not pooled with v3 or the continuous-control supplements.",
        "",
        "## Design and accounting",
        "",
        "`MaskedCartPole-v1` masks CartPole velocity coordinates 1 and 3; `MaskedAcrobot-v1` masks angular-velocity coordinates 4 and 5. Each of six algorithm--task cells uses four candidates and five validation seeds per candidate, followed by 20 test seeds for the selected configuration. The raw CSV contains 240 rows: 120 validation and 120 test.",
        "",
        "Training uses 4,096 steps, four checkpoints, and five evaluation episodes per checkpoint. The six comparisons share family alpha 0.05 (comparison alpha 0.0083333), with the same margin, target width, and interval construction as the preregistration. This run uses full replay for reporting; it does not measure early-stop compute savings.",
        "",
        "## Selected configurations and descriptive means",
        "",
        "| Environment | Algorithm | Selected configuration | Test mean | Sample SD |",
        "|---|---|---|---:|---:|",
    ]
    for key, cell in payload["summary"].items():
        values = cell["test_metrics"]
        lines.append(f"| {key.split(':')[0]} | {key.split(':')[1]} | `{cell['selected_config']}` | {statistics.mean(values):.6f} | {statistics.stdev(values):.6f} |")
    lines += [
        "",
        "## Family decisions",
        "",
        "| Environment | Comparison | Estimate | Family-adjusted interval | Decision |",
        "|---|---|---:|---|---|",
    ]
    for item in payload["comparisons"]:
        decision = item["decision"]
        lines.append(f"| {item['env_id']} | {item['comparison'].replace('_vs_', ' - ')} | {decision['estimate']:.6f} | [{decision['lower']:.6f}, {decision['upper']:.6f}] | {decision['decision']} |")
    lines += [
        "",
        "All six comparisons are maximum-budget inconclusive at 20 seeds. The intervals do not show equivalence. This supports only that the fixed-mask workflow executed under this budget; it does not validate arbitrary partially observable tasks, establish algorithm rankings, or show external reproducibility.",
        "",
        "The raw CSV and JSON records are authoritative. A separate script regenerated all six selected test-seed summaries on the same machine with zero mean absolute metric difference. This supports same-machine cross-script repeatability only. The runner used full replay of all 20 test seeds, so stop-time savings are not claimed.",
    ]
    (ROOT / "PARTIAL_OBSERVABILITY_SCOPE_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (ROOT / "PARTIAL_OBSERVABILITY_SCOPE_AUDIT.json").write_text(json.dumps({"status": "PASS", "rows": len(rows), "validation_rows": 120, "test_rows": 120, "comparisons": 6, "all_max_budget_inconclusive": True, "same_machine_cross_script_replay_rows": 6, "all_replay_differences_zero": True}, indent=2) + "\n", encoding="utf-8")
    print("partial-observability scope audit: PASS")
    print("rows=240 validation=120 test=120 comparisons=6 all_max_budget_inconclusive=true")


if __name__ == "__main__":
    main()

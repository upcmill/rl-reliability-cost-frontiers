#!/usr/bin/env python3
"""Deduplicate the retained OpenAlex discovery exports for first-pass screening."""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_INPUT = ROOT / "literature_search_raw/2026-10-30_openalex_screening"


def normalize_title(value: str) -> str:
    value = value.lower()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return " ".join(value.split())


def normalize_doi(value: str | None) -> str:
    if not value:
        return ""
    value = value.strip().lower()
    value = re.sub(r"^https?://doi\.org/", "", value)
    return value


def candidate_key(row: dict[str, str]) -> str:
    return "doi:" + row["doi"] if row["doi"] else "title:" + normalize_title(row["title"])


def collect(input_dir: Path) -> list[dict[str, str]]:
    grouped: dict[str, dict[str, set[str]]] = defaultdict(
        lambda: {"queries": set(), "openalex_ids": set()}
    )
    records: dict[str, dict[str, str]] = {}
    for path in sorted(input_dir.glob("rl_*.json")):
        query_name = path.stem
        payload = json.loads(path.read_text(encoding="utf-8"))
        for item in payload.get("results", []):
            authors = "; ".join(
                a.get("author", {}).get("display_name", "")
                for a in item.get("authorships", [])
                if a.get("author", {}).get("display_name")
            )
            row = {
                "title": " ".join((item.get("title") or "").split()),
                "doi": normalize_doi(item.get("doi")),
                "year": str(item.get("publication_year") or ""),
                "type": str(item.get("type") or ""),
                "authors": authors,
                "openalex_id": str(item.get("id") or ""),
                "primary_url": str(
                    item.get("primary_location", {}).get("landing_page_url") or ""
                ),
            }
            if not row["title"]:
                continue
            key = candidate_key(row)
            if key not in records:
                records[key] = row
            grouped[key]["queries"].add(query_name)
            if row["openalex_id"]:
                grouped[key]["openalex_ids"].add(row["openalex_id"])

    rows = []
    for key, row in records.items():
        row = dict(row)
        row["deduplication_key"] = key
        row["source_queries"] = ";".join(sorted(grouped[key]["queries"]))
        row["openalex_ids"] = ";".join(sorted(grouped[key]["openalex_ids"]))
        rows.append(row)
    return sorted(rows, key=lambda x: (x["year"], x["title"]), reverse=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=DEFAULT_INPUT)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "OPENALEX_DEDUPLICATED_CANDIDATES.csv",
    )
    args = parser.parse_args()
    rows = collect(args.input_dir)
    fields = [
        "deduplication_key",
        "title",
        "authors",
        "year",
        "type",
        "doi",
        "primary_url",
        "openalex_id",
        "openalex_ids",
        "source_queries",
    ]
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} deduplicated candidates to {args.output}")


if __name__ == "__main__":
    main()

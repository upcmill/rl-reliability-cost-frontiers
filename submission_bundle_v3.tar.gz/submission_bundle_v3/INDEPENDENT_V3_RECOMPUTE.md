# Independent v3 Raw-CSV Recompute

A standard-library implementation independently reads the selected v3
test rows and recomputes all 15 means, bounded intervals, and terminal
decisions. It does not import the production runner or interval helper.

- Status: `PASS`
- Matching comparisons: `15/15`
- Scope: internal second implementation; not external reproducibility.

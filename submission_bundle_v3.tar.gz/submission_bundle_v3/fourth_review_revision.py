"""Apply the fourth review's evidence and editorial corrections before export.

The frozen experiments, preregistrations and numerical outputs are not modified.
"""
from __future__ import annotations

import re


def replace_once(text: str, old: str, new: str) -> str:
    if text.count(old) != 1:
        raise ValueError(f"Fourth-review anchor mismatch: {old[:80]!r}")
    return text.replace(old, new, 1)


def section(text: str, start: str, end: str) -> str:
    return text[text.index(start):text.index(end, text.index(start))]


def replace_section(text: str, start: str, end: str, new: str) -> str:
    return replace_once(text, section(text, start, end), new.rstrip() + "\n\n")


def revise(main: str, supp: str) -> tuple[str, str]:
    abstract = """## 摘要

本文回顾性审计预先冻结的强化学习序贯评估协议，主研究含五个低维观测或离散状态任务。每臂 20 个种子时，15 项比较均未决；末次半径和约 1.018，该检查点越过 0.05 边际至少需每臂 23 个种子。这是指定设计的解析限制，不是算法等价或普遍种子下界。四个新增环境与两个观测掩码变体作为独立范围诊断。事后冻结方案下的 V7 新种子验证中，每臂 1,000 个种子时 Hoeffding 为 4/15 项达到停止规则，Gamma 混合经验 Bernstein 置信序列为 11/15，且 15 项最终区间均更窄；差异限于当前固定面板，成本比较为反事实前缀核算。本文未检验视觉或高维连续观测任务。

"""
    main = replace_section(main, "## 摘要", "**正文与补充材料导航。**", abstract)
    main = replace_once(main,
        '主要确认性分析限于 CartPole、Acrobot、MountainCar、Taxi 和自建队列任务，共 15 项比较。另报告四个范围扩展任务：Pendulum-v1、MountainCarContinuous-v0、CliffWalking-v1 和 FrozenLake-v1（4×4、可滑冰）。前两者各自为单一 PPO–A2C 比较，后两者组成六比较任务族；它们各按独立预注册族使用各自的错误预算，不与主研究 15 项比较合并。扩展结果用于描述协议在这些具体环境中的执行与分辨情况，不升级为主研究确认性证据或跨任务总体推断。任务特征与样本量汇总见补充材料 S17 表 S17-1。',
        '预注册主研究限于 CartPole、Acrobot、MountainCar、Taxi 和自建队列任务，共 15 项比较；其全部未决结果用于核对实现与回顾性解析审计的一致性。另报告六个范围诊断设置：四个新增环境 Pendulum-v1、MountainCarContinuous-v0、CliffWalking-v1、FrozenLake-v1（4×4、可滑冰），以及两个观测掩码变体 MaskedCartPole-v1、MaskedAcrobot-v1。两个连续动作任务各为单比较族，两个新增离散任务共为六比较族，两个掩码变体另为六比较族；各族单独使用错误预算，不并入主研究。完整清单见表 8 和补充材料 S17 表 S17-1。')

    # Distinguish registered design from the retrospective derivation of its limits.
    main = replace_once(main,
        '原预注册记录了指标、阈值、种子和检查方案。参数级审计不需要观测数据，因此可用于未来实验的事前设计；这不等于已有材料证明每个解析推导都在主研究数据收集之前完成。本研究的合成校准、顺序诊断和检查点敏感性均为事后诊断，计划及生成记录见补充材料 S16–S19。',
        '原预注册记录了指标、阈值、种子和检查方案，但现有材料没有证明主研究在采集或打开密封测试数据前完成了预算可行性审计。本文在已知全部未决结果后的回顾性分析中解释非分辨边界，并将该检查整理为可供未来研究使用的事前审计工具；不把参数计算无需观测数据等同于历史上已经事前执行。合成校准、顺序诊断和检查点敏感性也属于事后分析，记录见补充材料 S16–S19。')
    main = replace_once(main,
        '在打开密封测试行之前，事前预算可行性审计已经得到相同结论：对于 `[0,1]` 中的任意指标序列，四个注册检查点都不可能超过 0.05 实际边际，也不可能达到 0.10 目标宽度。因此，15/15 个最终未决状态是对设计预测的执行核对，不是经验功效估计。',
        '对冻结参数的回顾性预算审计表明，对于 `[0,1]` 中的任意指标序列，四个注册检查点都不可能超过 0.05 实际边际，也不可能达到 0.10 目标宽度。15/15 个最终未决状态因此是实现与解析边界的一致性核对，不是事前预测已执行的证据，也不是经验功效估计。')
    main = replace_once(main, '### 6.1 设计边界与预算解释',
        '### 6.1 设计边界与预算解释\n\n主研究预注册了决定规则，却没有留下在测试前完成可行性审计的证据。本文据此按未经可核实事前审计的设计解释这次运行：预注册本身不能保证预算足以回答算法比较问题。审计工具在已知未决结果后的分析中形成，用于把这一设计教训转为未来研究的事前检查；它不是本次主研究已实施的前置程序。')
    main = main.replace('主研究确认性分析保留预注册的支出方案', '主研究分析保留预注册的支出方案')
    main = replace_section(main, '本表区分三类证据：', '**表 22。',
        '本表区分预注册主研究运行、固定面板新增种子扩展和事后方法诊断。主研究的算法比较按预注册规则执行，但没有得到优越性或精度决定；这里确认的是程序执行与回顾性解析边界一致，不能把解析审计追认为事前确认性假设。V4/V5/V7、模拟和替代区间分析的来源分别披露；研究范围与未覆盖场景集中见第 6.4 节和第 7 节。')

    main = replace_once(main, '四项之和不超过 `alpha_cmp`。',
        '四项之和为 `0.8654518 × alpha_cmp`，即实际使用比较级错误预算的约 86.55%（族级合计约 0.043273），保留约 13.45% 未分配。若检查次数 K 已固定，可将前 K 项权重除以它们的和，使有限 K 支出用满预算；该方案作为第 5.20 节的设计对照，不追溯更改主研究规则。')

    main = replace_once(main,
        '以下三个扩展组涉及四个新增任务和八个任务内算法对：两个连续动作任务各一个比较，两个离散任务各三个比较。种子数均指每个任务—算法单元的密封测试种子数；这些范围诊断使用独立的分析族，不并入主研究的 15 个比较。',
        '以下四个独立分析族涵盖六个范围诊断设置、十四个任务内算法对：四个新增环境及两个原任务的观测掩码变体。两项连续动作任务各一个比较，两个新增离散任务共六个比较，两个掩码变体另有六个比较。掩码变体不计作新增标准环境；与主研究合计为九个基础环境、另加两个变体。表中种子数均为每个任务—算法单元的测试种子数，四个族不并入主研究的 15 项比较。')
    table_anchor = '| CliffWalking-v1、FrozenLake-v1（4×4、slippery） | 2 | PPO / DQN / A2C | 200 | 附录 C；补充材料 S14 |'
    main = replace_once(main, table_anchor, table_anchor + '\n| MaskedCartPole-v1、MaskedAcrobot-v1 | 2 个变体 | PPO / DQN / A2C | 20 | 第 5.13 节；补充材料 S10 |')
    main = main.replace('| 范围扩展 | 新任务数 |', '| 范围扩展 | 环境/变体数 |')

    # Preserve descriptive data in the supplement, shorten repeated result prose.
    training = section(main, '### 5.11 ', '### 5.12 ')
    evaluation = section(main, '### 5.12 ', '### 5.13 ')
    masks = section(main, '### 5.13 ', '### 5.14 ')
    def paragraph_starting(block: str, prefix: str) -> str:
        return next(p for p in block.split('\n\n') if p.startswith(prefix))
    training_numbers = paragraph_starting(training, '全部 15 个比较再次')
    evaluation_numbers = paragraph_starting(evaluation, '全部 15 个比较再次')
    mask_numbers = paragraph_starting(masks, '原始文件共 240 行').split('全部六个比较', 1)[0]
    details = '''### S10.1 决定计数的解析解释

训练预算、评估回合和归一化诊断保持种子级指标位于 [0,1]，主研究的比较级 alpha 与种子检查点不变。因此改变这些设置不会改变 Hoeffding 半径：末次 R₄=1.017859，最大可能下端点为 −0.017859；即使 m=0 也不能作优越性决定，最小截断宽度仍超过所测试的 w≤0.20。全部未决只核对实现，不为训练预算或评估回合的充分性提供证据。以下保留含有数据信息的描述性均值、差异和截断区间宽度。

### S10.2 训练预算扩展的详细描述

冻结配置及主研究 20 个训练种子，训练步数增至 16,384，评估位于 4,096、8,192、12,288、16,384 步。学习曲线指标的训练时域随之改变，与主研究分别报告。

''' + training_numbers + '\n\n### S10.3 评估回合扩展的详细描述\n\n冻结配置及主研究 20 个训练种子，每检查点评估由五回合增至十回合；其余设置保持不变，共 300 行测试数据。\n\n' + evaluation_numbers + '\n\n### S10.4 观测掩码变体的详细描述\n\n' + mask_numbers + '''

该独立六比较族在 n=20、末次 k=4 的半径和为 0.971806，最大可能下端点为 0.028194，小于 m=0.05；最小截断宽度为 0.971806，大于 w=0.10。前面三个检查点半径更大，因此六项全部未决也是参数决定的结果，仅核对执行一致性。固定掩码流程不建立一般 POMDP 结论。

'''
    supp = replace_once(supp, '## S10 归一化、训练预算、评估回合与部分可观测诊断\n\n',
        '## S10 归一化、训练预算、评估回合与部分可观测诊断\n\n' + details)
    main = replace_section(main, '### 5.11 ', '### 5.12 ', '''### 5.11 训练预算扩展诊断

![图 8。冻结配置下 4096 与 16384 步的描述性均值；不与主分析合并。](manuscript_figures/fig_budget_scaling.png)

固定主研究配置和 20 个训练种子，将训练预算增至 16,384 步。15 项仍未决由不变的种子检查点和 Hoeffding 半径决定，仅用于实现一致性核对。数据信息来自均值和截断宽度的变化：最大均值变化为 CartPole/A2C（+0.124965）、Acrobot/DQN（−0.095500）和 Taxi/A2C（+0.117646），最终宽度中位数为 1.9386。它们说明训练时域会改变条件估计对象；完整逐单元均值和配置见补充材料 S10.2。
''')
    main = replace_section(main, '### 5.12 ', '### 5.13 ', '''### 5.12 评估回合数敏感性诊断

![图 9。每检查点评估回合从 5 个增加到 10 个时的种子匹配指标平均绝对变化。](manuscript_figures/fig_eval_episode_sensitivity.png)

固定主研究配置、训练预算和 20 个训练种子，将每检查点评估由五回合增至十回合，共 300 行测试记录。15 项未决仅核对实现与解析边界一致，不能用于判断评估回合是否充分。15 个单元均值的平均绝对变化为 0.0013；Taxi/A2C 的种子匹配平均绝对差异最大，为 0.0345；最终截断宽度中位数为 1.9124。这些观测描述当前样本的测量敏感性，完整结果见补充材料 S10.3。
''')
    main = replace_section(main, '### 5.13 ', '### 5.14 ', '''### 5.13 单独预注册的部分可观测范围诊断

MaskedCartPole-v1 将两个速度坐标置零，MaskedAcrobot-v1 将两个角速度坐标置零；其余训练和指标设置沿用主研究。该独立六比较族包含 120 行验证和 120 行测试记录，每个算法—变体使用 20 个测试种子。在原支出下，末次半径和为 0.971806，最大可能下端点仅 0.028194，小于 0.05，最小截断宽度也高于 0.10；前面检查点半径更大，故 6/6 未决是实现一致性核对。观测均值、包装器和预注册说明见补充材料 S10.4。该诊断只验证两个固定掩码的执行流程，不代表一般部分可观测任务族。
''')
    main = main.replace('### 5.9 主研究结论的事后稳健性', '### 5.9 配置选择与指标敏感性')
    main = replace_once(main,
        '在冻结主研究序列上改变实际边际、目标宽度和最大预算，所测试设置均为 15/15 `max_budget_inconclusive`；11 种替代归一化边界也得到相同决定。正态和 bootstrap 的部分决定属于未预注册诊断，未作为确认性结果。四个检查点的区间宽度中位数依次为 2.0000、2.0000、2.0000 和 1.9199，显示预算非分辨并非单一阈值设定造成。完整边界及区间敏感性矩阵见补充材料 S5。',
        '在所测试的非负边际、w≤0.20、种子预算≤20 及 [0,1] 归一化设置下，推论 3 预先确定所有比较未决。11 种替代归一化方案得到 15/15 未决只核对实现，不是结果对归一化选择具有经验稳健性的证据。主研究四次检查的截断宽度中位数为 2.0000、2.0000、2.0000、1.9199；完整重算矩阵见补充材料 S5 和 S10.1。')
    main = main.replace('图 7。11 种归一化方案均为 15/15 未决；事后诊断。',
        '图 7。11 种归一化方案的未决计数用于实现一致性核对；该计数由解析边界确定。')
    main = replace_once(main, '完整选择频率和熵见补充材料 S5 表 S5-1。',
        '完整选择频率和熵见补充材料 S5 表 S5-1，逐单元分类见表 S5-4：较高保留率 2 个、中等 4 个、较低 4 个，另有 5 个候选均值完全并列单元不可判定。低保留率单元为 CartPole/PPO、Acrobot/PPO、Queue/PPO、Queue/A2C。')
    main = replace_once(main,
        '观测计数表明这批主研究样本在所测试边际下都未决，但不建立普遍边际或未来样本行为。',
        '末次最大可能下端点为 −0.017859，早期检查更低，故所有非负边际下均不可能作优越性决定；固定 w=0.10 也不可达。七个边际下的 15/15 未决是实现一致性核对，不是经验边际稳健性证据。')
    main = main.replace('右：主研究原始数据在七个边际下均为 15 项未决。',
        '右：七个边际下的未决计数核对实现与解析边界一致。')
    main = main.replace('根据第三轮意见，我们新增独立 Bernoulli 双臂的事后校准实验。',
        '我们开展了独立 Bernoulli 双臂的事后校准实验。')

    main = replace_once(main, '这些建议是在给定假设下对协议构造和报告方式的推论，不表示本文已经建立普遍最优的评估器、RL 的最小种子数或一般算法排名。',
        '8. **在设计阶段比较有定理支持的方差自适应区间。** 当指标方差远低于有界变量允许的最坏情形时，可将经验 Bernstein 置信序列与 Hoeffding 基线在相同目标、错误预算和检查点下比较。V7 的 1,000 新种子验证中，Gamma 混合经验 Bernstein CS 的 15 项最终区间均更窄，11/15 项达到停止规则，而原方法为 4/15；这提示在当前面板上可降低反事实分辨成本。V7 在查看 V1–V6 后冻结，所有训练均已执行，因此既不代表实际节省计算，也不是新任务族验证。新研究需在测试前冻结方法和调节参数，核对有界性及条件均值等适用假设，并在独立预注册任务族中检验这一建议。\n\n前七项针对本文有界有限检查点构造；第八项结合事后对照与新种子诊断给出方法选择建议，其证据层级不同。')
    # Keep a single future-work section; retain substantive modelling directions.
    main = replace_section(main, '## 12 后续研究方向', '## 参考文献', '')
    main = replace_once(main, '以上均为研究建议，不是本文已经验证的结果。',
        '进一步可在新验证与测试种子上，以相同计算预算比较当前均值选择和预先冻结的贝叶斯配置选择规则，分别报告选择敏感性、预测误差及分辨成本。贝叶斯区间需要独立的观测模型、先验和模型检查；跨研究整合还需处理任务、指标、调参及停止策略异质性与选择偏差。以上方向均待独立研究。')

    main = replace_once(main,
        '完整的选定测试分布如下。标准差是 20 个训练种子的样本标准差；这些统计量是描述性的，不是针对更广泛任务总体的区间估计。\n\n完整数值见补充材料 S4，表 S4-2。\n\n完整种子级记录及字段说明见补充材料 S4。',
        '完整的选定测试分布见补充材料 S4 表 S4-2，标准差按每单元 20 个训练种子计算；种子级记录和字段说明同见 S4。')
    main = main.replace('机器可读审计为 补充材料 S2，生成器和测试为 补充材料 S2。',
        '补充材料 S2 索引列出机器可读结果 `BUDGET_FEASIBILITY_AUDIT_V3.json`、生成器 `generate_budget_feasibility_audit.py` 和测试 `test_budget_feasibility_audit.py`。')
    start, end = '### 5.5.2 执行时间成本核算', '### 5.6 补充统计诊断'
    costs = section(main, start, end)
    paragraphs = []
    for paragraph in costs.split('\n\n'):
        if paragraph and not paragraph.startswith(('#', '|', '**', '![')):
            # Source hard wraps split Chinese words; retain spaces within Latin text.
            paragraph = re.sub(r'(?<=[\u3400-\u9fff])\n(?=[\u3400-\u9fff])', '', paragraph)
            paragraph = paragraph.replace('\n', ' ')
        paragraphs.append(paragraph)
    costs = '\n\n'.join(paragraphs)
    costs = costs.replace('机器可读数据和审计文件为 补充材料 S6、 补充材料 S6。',
        '验证成本明细见补充材料 S6 的 `VALIDATION_TUNING_COST_V3.json`。')
    costs = costs.replace('完整的单元表和机器可读推导见 补充材料 S6，审计脚本为 补充材料 S6。',
        '完整单元表及推导见补充材料 S6 的 `RUNTIME_COST_TABLE_V3.json`。')
    costs = costs.replace('完整的单元表和机器可读推导见补充材料 S6，审计脚本为补充材料 S6。',
        '完整单元表及推导见补充材料 S6 的 `RUNTIME_COST_TABLE_V3.json`。')
    costs = costs.replace('机器可读产物和审计脚本为 补充材料 S6、 补充材料 S6。',
        '逐检查点记录见补充材料 S6 的 `RELIABILITY_COST_FRONTIER_V3.json`。')
    costs = costs.replace('为使标题中的“前沿”可计算，', '为刻画协议的分辨率与成本，')
    costs = costs.replace('）。 A2C', '）。A2C')
    main = replace_section(main, start, end, costs)

    main = replace_once(main,
        '主研究 20 个测试种子中，九个主要/敏感性设定均为 15/15 未决，因而现代序贯边界没有解除原主研究的预算非分辨；20 种子下不可能获得两阈值决定的解析结论仍成立。',
        '主研究 20 个测试种子的重分析中，九个主要/敏感性设定在本批数据上均为 15/15 未决。推论 3 的解析不可能性针对原 Hoeffding 构造，不由此推广到所有现代置信序列；替代方法的这些计数是对已存样本的描述。')
    main = main.replace('较原方法 200 次；', '较原方法少 200 次；')
    main = main.replace('但这不是主研究 15 项未决的唯一解释。',
        '但 Hoeffding 半径不含样本方差，主研究 15 项未决由设计参数强制产生。')
    main = main.replace('它不能直接覆盖未测试的视觉输入、高维连续控制、稀疏奖励、多智能体或一般非平稳任务。',
        '当前实证不覆盖视觉输入、高维连续控制、多智能体或一般非平稳任务；单一 FrozenLake 稀疏奖励设置也不足以代表稀疏奖励任务族。')

    # Give the existing D.4 a consecutive parent outline instead of an orphan number.
    main = replace_once(main, '## 附录 D。新任务的实际边际与精度目标选择框架\n\n',
        '## 附录 D。新任务的实际边际与精度目标选择框架\n\n### D.1 决策对象与阈值依据\n\n')
    main = replace_once(main, '若归一化是无截断的仿射变换，且范围为 [L,U]，',
        '### D.2 尺度换算与精度目标\n\n若归一化是无截断的仿射变换，且范围为 [L,U]，')
    main = replace_once(main, '最后，在打开密封测试数据前冻结 m、w、归一化边界、比较族、检查点和 alpha 分配，',
        '### D.3 测试前冻结与可行性审计\n\n最后，在打开密封测试数据前冻结 m、w、归一化边界、比较族、检查点和 alpha 分配，')

    main = replace_once(main,
        '| 同一流程可在一个连续动作任务上执行。 | 连续补充预注册、80 行产物和独立复现。 | 作为一个任务的范围诊断得到支持。 |',
        '| 流程在六个范围诊断设置中完成执行：两个连续动作任务、两个新增离散任务和两个观测掩码变体。 | 表 8、第 5.13 节、附录 A–C；补充材料 S10、S14。 | 各独立族的执行证据，不合并为新任务总体推断。 |')
    main = replace_section(main, '## 10 结论', '## 11 声明', '''## 10 结论

预注册主研究的 15 项比较在每臂 20 个测试种子时均未决。回顾性审计证明该结果由冻结的区间、错误预算和阈值决定；RL 运行核对的是实现与解析边界一致，无法由此评价算法差异是否小或种子预算是否普遍充分。独立的 Pendulum、MountainCarContinuous、CliffWalking、FrozenLake 及两个固定观测掩码变体补充了执行范围，Windows AMD64 复跑提供了跨平台技术核对。

较大预算序列包含有信息的分辨差异。V5 中原 Hoeffding 有 4/15 项在每臂 1,000 个种子内达到停止规则；V7 新种子验证中原方法为 4/15，Gamma 混合经验 Bernstein CS 为 11/15，后者 15 项最终区间均更窄。这为固定面板上的方法选择提供依据；前缀成本是反事实核算，未实际提前停止训练。受控依赖压力测试同时说明，改变臂内依赖结构可能破坏覆盖保证，重放一致性不能验证独立性。

本研究的设计教训是：预注册需要配合预算可行性检查。本文在结果已知后的分析中整理审计工具，未来研究可在采集数据前用它排查结构上不可分辨的设计，再针对任务分布规划功效与成本。结论适用条件及未解决的外部有效性问题见第 6.4 节和第 7 节。
''')
    # Concentrate common limitations; preserve result-specific caveats.
    for old, new in [
        ('原始回报已保留，且 11 种边界方案的事后敏感性分析均使 15 个比较在最大预算时无法作出结论；这些替代边界不是确认性估计对象。',
         '原始回报已保留；11 种替代边界的未决计数属于实现核对，不能消除归一化选择引起的估计对象差异。'),
        ('在单独的 16,384 步固定配置诊断中，15 个比较仍均在最大预算时无法作出结论，但若干描述性均值发生了明显变化。',
         '16,384 步固定配置诊断中的未决计数由半径决定，而若干描述性均值发生了明显变化。'),
        ('十回合固定配置诊断保留了全部 15 个最大预算未决决定，且单元均值的总体变化较小，但不能为其他任务或策略建立通用回合数规则。',
         '十回合固定配置诊断中单元均值总体变化较小，但决定计数由半径确定，不能据此论证评估回合充分。'),
        ('这验证了披露的受控环境，但不构成通用 RL 算法排名或外部有效性证据。', '该核对检验了披露的受控环境转移。'),
        ('这些结果只描述一个冻结任务族和一条新种子序列，不估计经验功效、普遍种子要求或一般算法排名。', '这些结果对应冻结任务族的一条新种子序列。'),
        ('这只是一个任务的范围诊断，不支持连续控制泛化或外部可复现性。', '该任务作为独立范围诊断报告。'),
        ('这是第二个连续动作任务的执行诊断，不是连续控制排名或外部可复现性结果。', '该任务为第二个连续动作范围诊断。'),
    ]:
        main = main.replace(old, new)

    main = re.sub(r'([。；，：]) +(?![A-Za-z0-9`$|])', r'\1', main)
    supp = supp.replace('# 强化学习算法序贯评估的可靠性—成本前沿：补充材料',
        '# 固定任务面板下强化学习序贯评估协议的分辨率与成本：一项设计审计——补充材料')
    supp = supp.replace('5.9 v3 结论的事后稳健性', '5.9 配置选择与指标敏感性')
    supp = replace_once(supp, '## S2 统计构造、解析预算与比较族规划\n\n',
        '## S2 统计构造、解析预算与比较族规划\n\n本节所引审计文件的历史名称含 “pre-study”，表示工具可用于事前设计；它不证明主研究在测试前已执行该审计。本文按第 4.6 节披露的回顾性分析来源解释其数值，保留原始文件名以便追溯。\n\n')
    return main, supp

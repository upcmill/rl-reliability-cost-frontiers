#!/usr/bin/env python3
"""Build round-three formal Chinese artifacts from frozen round-two source and diagnostics."""
from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path

from manuscript_round2 import build_docx
from fulltext_literature_revision import revise_main as revise_main_literature, revise_supplement
from modern_comparison_manuscript import update_manuscripts as update_modern_comparison
from fourth_review_revision import revise as revise_fourth_review
from fifth_review_revision import revise as revise_fifth_review
from sixth_review_revision import revise as revise_sixth_review

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'revision_history/round2_before_round3'
ANALYSIS=ROOT/'round3_analysis'


def load(name):return json.loads((ANALYSIS/f'{name}.json').read_text())


def replace_once(text,old,new):
    if text.count(old)!=1:raise ValueError(f'Expected one anchor: {old[:60]} ({text.count(old)})')
    return text.replace(old,new,1)


def replace_section(text, start_heading, end_heading, replacement):
    start=text.index(start_heading)
    end=text.index(end_heading,start)
    return text[:start]+replacement.rstrip()+'\n\n'+text[end:]


def number_references_by_first_citation(text):
    reference_start=text.index('## 参考文献')
    appendix_start=text.index('## 附录 A。',reference_start)
    body=text[:reference_start]
    reference_block=text[reference_start:appendix_start]
    source_ids=[]
    for match in re.finditer(r'L(\d+)',body):
        source_id=int(match.group(1))
        if source_id not in source_ids:
            source_ids.append(source_id)
    if set(source_ids)!=set(range(1,20)):
        raise ValueError(f'Unexpected cited literature IDs: {source_ids}')
    number={source_id:index+1 for index,source_id in enumerate(source_ids)}
    body=re.sub(r'\[([^\]\n]*)\]',
                lambda match:'['+re.sub(r'L(\d+)',lambda item:str(number[int(item.group(1))]),match.group(1))+']',
                body)
    body=re.sub(r'(?<![\w\[])L(\d+)(?!\w)',
                lambda match:f'[{number[int(match.group(1))]}]',body)
    body=body.replace('] 第', ']第')
    entries=[]
    for paragraph in reference_block.split('\n\n')[1:]:
        match=re.match(r'^\[L(\d+)\]',paragraph)
        if match:
            source_id=int(match.group(1))
            entries.append((number[source_id],re.sub(r'^\[L\d+\]',f'[{number[source_id]}]',paragraph)))
    if len(entries)!=19:
        raise ValueError(f'Expected 19 bibliography entries, found {len(entries)}')
    reordered='## 参考文献\n\n'+'\n\n'.join(entry for _,entry in sorted(entries))+'\n\n'
    return body+reordered+text[appendix_start:]


def table(caption,headers,rows):
    return '\n'.join([f'**{caption}**','', '| '+' | '.join(headers)+' |',
                     '|'+'|'.join(['---']*len(headers))+'|',
                     *['| '+' | '.join(map(str,r))+' |' for r in rows]])+'\n'


def selection_stability_table():
    payload=json.loads((ROOT/'validation_selection_uncertainty_v3.json').read_text())
    rows=[]
    counts={'high':0,'moderate':0,'low':0,'uninformative':0}
    for r in payload['rows']:
        frequencies=r['bootstrap_selection_frequency']
        retained=frequencies[r['observed_selected']]
        if r['observed_top_two_gap']==0:
            label='不可判定：验证候选均值并列'
            counts['uninformative']+=1
        elif retained>=0.70:
            label='较高（≥70%）'
            counts['high']+=1
        elif retained>=0.50:
            label='中等（50%–<70%）'
            counts['moderate']+=1
        else:
            label='较低（<50%）'
            counts['low']+=1
        rows.append([r['environment'],r['algorithm'],r['observed_selected'],
                     f"{retained:.4f}",f"{max(frequencies.values()):.4f}",label])
    caption=('表 S5-4。逐单元配置选择稳定性描述；阈值为本轮描述分类，不是检验或总体概率。'
             f"非并列单元：较高 {counts['high']}、中等 {counts['moderate']}、较低 {counts['low']}；"
             f"另有 {counts['uninformative']} 个单元因候选均值并列而不可判定。")
    return table(caption,['环境','算法','主研究所选配置','重采样中保留主选择频率',
                         '最高候选选择频率','描述分类'],rows),counts


BLOCK_LIMIT='''**块划分与分析单位的限制。** 本文的一个种子观测 Z 是重新初始化并训练至同一预算后得到的完整学习曲线指标；“前五个训练种子”与“后五个训练种子”不等于同一策略的早期和晚期训练阶段。如果运行顺序伴随共享模型续训、配置修改或环境漂移，两组观测可能有不同期望，命题 3 不再覆盖一个共同的臂级均值。将一条学习轨迹的不同训练阶段划成块，或把同一策略的评估回合视作独立训练种子，也不能直接使用该命题。

按硬件节点、日期或回合子集分块本身并不保证块间独立或共同期望；需要额外的生成机制或设计依据。块均值共同期望不是“所有 RL 学习阶段平稳”的断言，而是该回退工具适用的限定假设。当已知块模型不成立时，应重新设计独立抽样或建立匹配的依赖/非平稳模型，不能自动退回同样依赖种子独立性的原始区间。时变目标及加权块估计属于后续方法研究，本文未给出其有效性保证。
'''

THRESHOLD='''**事后尺度诊断与实际意义的区别。** 本轮依据同一批主研究观测计算 m/s_pooled，作为阈值相对于观测离散程度的描述。13 个非退化算法对的比值为 0.183–3.028，另外 2 个算法对的合并样本标准差为零，比例未定义（补充材料 S17，表 S17-2）。相同的 m 因任务和算法对而对应很不相同的标准化大小，因此没有证据把它统一称为“中等效应”。该比例既不是功效计算，也不是领域效用阈值，且小样本标准差本身不稳定。

实际安装版本的默认 CartPole 回报按存活步计分，Acrobot 对非终止步赋 −1、终止步赋 0。因此原尺度的 +25 可分别解释为该评估指标下平均存活步数增加或非终止步数减少约 25；Acrobot 回报不直接度量能耗，不能写成“能耗降低 5%”。这些解释仅帮助理解单位，不证明改进具有实际应用价值。源码模块与哈希、任务特征见补充材料 S17。本文不通过挑选已发表论文的回报差或通用标准化效应阈值，追认为原预注册建立其未记录的科学依据。
'''

ORDER='''### 3.6.1 顺序诊断的作用与边界

为使独立性假设的检查可操作，本轮对主研究 15 个任务—算法单元分别使用 20 个密封种子观测进行探索性顺序诊断。顺序沿用原始 CSV 在每个单元内的行次序；由于没有逐运行墙钟时间戳，不能把它直接称为时间顺序。中位数游程检验剔除等于中位数的并列值后，在固定正负计数下计算精确双侧概率；另一项检验对一阶中心化乘积统计量 r₁ 做 9,999 次随机排列，以绝对值作双侧统计量。两项检验合并为预先固定的 30 项诊断族，采用 Holm 校正；退化项目标为不可计算，并以 p=1 保留在校正族中。

这些检验检查观测值在给定顺序下与随机排列的相容性，不是独立性的充分检验。分布漂移也可能导致拒绝，未拒绝则可能来自样本少或检验不敏感。全部定义、种子、原始及校正 p 值见补充材料 S16。本文不采用任意的 |r₁|>0.3 阈值，也不配对不同算法的相同整数种子。固定 n 和 alpha 时，Hoeffding 半径与排列无关；仅重排标签并比较最终区间宽度，不能校准未知依赖造成的覆盖率失效。基于 20 个观测估计多个滞后 ACF、功率谱或有效样本量会高度不稳定；种子编号顺序也不等同于训练时间顺序。因此本文不报告伪精确 ESS/PSD，也不把未拒绝顺序检验解释为独立性证据。命题 1 仍明确条件于每个算法臂内独立且具有共同条件均值的假设。
'''

ORDER_RESULTS='''### 5.6.3 原始记录的顺序诊断

30 项探索性诊断经 Holm 校正后均未拒绝随机顺序假设。15 个单元中，7 个可以计算中位数游程统计量，8 个因剔除并列中位数后缺少一种符号而不可计算；11 个可计算一阶相关，4 个因常数观测不可计算。可计算项目中的最大 |r₁| 为 0.194807；未经校正的最小游程 p 为 0.484423，最小排列 p 为 0.3439。补充材料 S16 报告全部单元和不可计算原因。以上结果没有证明独立性，也不改变主研究的覆盖假设或停止决定；特别是常数或低信息量数据不能提供有力的依赖检验。
'''

MECHANISM='''### 5.15.1 队列差异的可检验解释

第 5.15 节的越界条件是确定的算术关系，不能单靠观测均值和标准差识别学习机制。当前证据支持对固定任务、配置和指标作三层区分。首先，主研究和新种子序列的点估计方向一致，支持一个可重复检查的正向描述性差异；主研究在 20 个种子时未决是设计必然结果，不能作为“差异不存在”的反证。其次，新序列 A2C 的标准差更大，说明该冻结程序在当前种子样本中的结果更分散，但 Hoeffding 半径没有样本方差项，因此高方差不是本次决定规则直接使用的解释变量。最后，两条序列在 200 与 400 个种子间停止时点不同，提示样本组成会影响越界时点；方向一致不能排除随机波动，更不能证明 200 个种子普遍充分。

区分行为机制需要另外记录策略动作、队列占用、服务成本、阶段切换前后回报及优化过程，并在独立新种子上预先指定干预或消融。当前归档的聚合回报不足以完成这类因果分析。补充材料 S17 给出“解释假设—现有证据—缺失观测”的对应关系；本文不追加已被大预算扩展使用的 30400–30499 种子来冒充新的验证集。
'''

CALIBRATION='''### 5.19 已知效应的合成校准对照

根据第三轮意见，我们新增独立 Bernoulli 双臂的事后校准实验。五个预先列明的生成情景分别为 (p_A,p_B)=(0.50,0.50)、(0.55,0.50)、(0.70,0.50)、(0.90,0.50)、(0.90,0.10)，真实差异为 0、0.05、0.20、0.40、0.80。每情景生成 10,000 条独立双臂序列，并以同一序列前缀比较三套固定检查计划：(5,10,15,20)、(50,100,150,200) 和 (200,400,600,800,1000)。每套计划均使用原比较级 alpha=0.05/15、可求和支出、m=0.05、w=0.10；没有重新选择 RL 配置或改变主要比较族。

![图 14。已知效应的 Bernoulli 校准。左：正向优越性决定比例及每情景 95% Wilson 区间；右：各计划的平均终止种子数。虚线标记真实差异等于边际 0.05，曲线连接仅便于阅读。不同计划同时改变检查位置和上限，不是仅增加终点样本量的因果比较。](manuscript_figures/fig_round3_synthetic.png)

20 种子计划在全部五个情景中均为 10,000/10,000 未决，包括真实差异 0.80 的强效应；这核对了实现与解析非分辨边界一致，不能据此推断 RL 算法的真实差异接近 0.05。在 200 种子计划下，真实差异 0.20、0.40、0.80 的正向决定率分别为 0.0002、0.7499、1.0000；在 1000 种子计划下分别为 0.5543、1.0000、1.0000。等于边际的情景不能作为阳性优越性对照：任何越过边际的声明都计为错误决定。

全部 15 个“生成情景×检查计划”单元各有 10,000 次重复，未观测到非覆盖或错误优越性；每单元零事件率的 95% Wilson 上界约为 0.000384。该模拟报告单个比较所有检查点的同时覆盖，未模拟完整 15 项比较族；有限次数的零错误不是普遍有效性的证明。大预算强效应对照表明该状态机在特定生成模型和计划下能够作出决定，不能作为实际 RL 分布的经验功效。完整计数、区间、停止成本与随机流配置见补充材料 S18。

### 5.20 检查点与错误支出的解析敏感性

在每臂最大预算 200 固定时，我们比较 K=2、4、8 的等间隔检查，并比较原可求和支出、有限 K 归一化前置、均匀和后置支出。各方案满足相同的比较级错误预算，但原可求和方案只使用该预算的一部分；因此同时报告实际支出份额，避免把未花完的 alpha 误当作方法差异。原方案的末次半径和依次为 0.299568、0.321875、0.342734；更多检查将部分错误预算分配给更多时点，改变早期/末期的分辨边界。

在原 20 种子计划的末次检查点，原可求和、归一化前置、均匀和后置方案的半径和分别为 1.017859、1.010735、0.920672 和 0.878560；后两者使某些极端有界数据的优越性在结构上成为可能，但不保证本研究数据或新样本会作出决定。该对照是解析设计诊断，不重写已执行的主研究。目标宽度 0.05、0.10、0.20 的规划数和完整敏感性矩阵见补充材料 S19。
'''

DISCUSSION='''### 6.1.1 训练重复与不同学习范式的比较

本文的独立分析单位是完整训练运行，而不是环境交互步数或评估回合数。监督学习和强化学习都可能包含初始化、优化及数据采样的随机性；在线 RL 还把策略选择、探索和后续采样过程联系起来。但这并不推出 RL 必须使用某个固定倍数的随机种子：不同任务的目标、尺度、方差、区间与调参程序均可能不同，随机性来源也未必能独立相加。本文的 Hoeffding 半径只使用界、样本量和 alpha，不含经验方差项，因而不能由它推导 RL 与监督学习的样本量比。跨范式比较需要对齐估计对象、误差水平、效应尺度、成本及抽样单位后另行设计实验。
'''

TASKS='''### 6.2.1 任务覆盖与外推边界

实际安装版本的任务清单包含低维 Box 观测（CartPole 4 维、Acrobot 6 维、MountainCar 2 维）、Taxi 的 500 个离散状态以及队列的 3 维状态表示；动作数为 2、3 或 6，单回合上限为 200 或 500。连续观测维数与离散状态基数是不同类型的量，不能直接放在同一“状态空间大小”轴上。奖励也应依据具体定义描述，而非简单把所有到达目标任务标为稀疏奖励。完整类型、回报语义和源码哈希见补充材料 S17。

这些属性说明已执行任务在哪些方面不同，并不量化对整个 RL 空间的代表性。当前没有预先定义的参照任务总体、可比特征编码或抽样权重，因此不报告 PCA“60%覆盖率”、策略复杂度分数或代表性雷达图。连续动作补充实验扩大了执行范围，但视觉输入、高维连续控制、多智能体及长时域非平稳任务仍需独立研究。
'''

GUIDE='''### 6.3.1 可执行的评估设计路径

先确定比较目标与独立抽样单位，再判断指标是否有预先固定的界、是否具备独立重复的设计依据。若这些条件不成立，应重新设计采样或使用具备相应假设证明的方法；不能以 GPU 小时多少来选择正态、bootstrap 或有界区间。随后固定候选选择、比较族 J、检查点数 K 与 alpha 分配，并在打开新测试数据前论证任务特定边际与宽度目标。最后运行预算审计：若无法达到必要阈值，应调整尚未执行的设计或明确将研究定位为分辨率诊断；若结构上可行，仍需另做与目标分布相符的功效/成本规划。

本轮提供无需网络的命令行计算器 `python3 budget_calculator.py --looks 5 10 15 20 --comparisons 15 --margin 0.05 --width 0.10`。它输出每次检查的 alpha、半径、可能优越性必要种子阈值，以及满足未截断宽度的充分规划数；没有宣称推荐样本量、在线部署或硬件通用耗时。补充材料 S20 给出逐步检查清单和参数含义。已被反复查看的数据不会因事后补做预注册或固定次数 Bonferroni 而自动恢复未声明的序贯保证。
'''


def revise_main():
    text=(BASE/'MANUSCRIPT_FORMAL_ZH.md').read_text()
    text=text.replace('# 强化学习算法序贯评估的可靠性—成本前沿',
                      '# 固定任务面板下强化学习序贯评估协议的分辨率与成本：一项设计审计',1)
    start=text.index('## 摘要');end=text.index('**关键词：**',start)
    abstract='''## 摘要

本文审计预先冻结的序贯评估协议在固定五任务面板上的分辨率与成本；面板含低维 Box 观测和离散状态任务，不估计普遍种子需求或对高维视觉观测的推广性。15 项主研究比较在每臂 20 个种子时均未决，这是区间、错误预算和阈值决定的解析边界，不表示算法等价或普遍种子下界。四个补充任务是独立范围诊断，使用独立错误预算，不并入主研究。配置重采样和新种子扩展仅支持固定面板内的敏感性描述；本文不主张算法排名或跨任务族外推。

'''
    text=text[:start]+abstract+text[end:]
    text=replace_once(text,'### 1.1 研究问题与证据类型假设',
        '主要确认性分析限于 CartPole、Acrobot、MountainCar、Taxi 和自建队列任务，共 15 项比较。另报告四个范围扩展任务：Pendulum-v1、MountainCarContinuous-v0、CliffWalking-v1 和 FrozenLake-v1（4×4、可滑冰）。前两者各自为单一 PPO–A2C 比较，后两者组成六比较任务族；它们各按独立预注册族使用各自的错误预算，不与主研究 15 项比较合并。扩展结果用于描述协议在这些具体环境中的执行与分辨情况，不升级为主研究确认性证据或跨任务总体推断。任务特征与样本量汇总见补充材料 S17 表 S17-1。\n\n### 1.1 研究问题与证据类型假设')
    text=replace_once(text,'### 定义 1（可靠性—成本前沿）',BLOCK_LIMIT+'\n### 定义 1（可靠性—成本前沿）')
    text=replace_once(text,'**有限检查点的 alpha 分配示例。**',THRESHOLD+'\n**有限检查点的 alpha 分配示例。**')
    text=text.replace(
        '后续应用需依据具体代价或效用在新测试前确定阈值。',
        '后续应用需依据具体代价或效用在新测试前确定任务特定阈值，操作流程见附录 D；不应直接沿用本研究的 m=0.05、w=0.10。')
    text=replace_once(text,'### 3.7 比较族规模的规划敏感性',ORDER+'\n### 3.7 比较族规模的规划敏感性')
    text=replace_once(text,'## 4 实验设计',
        '### 3.8 比较族与等额错误预算的理由\n\n主研究的目标是同时报告五个固定任务中三种算法的全部无序比较，因此预注册时将 15 项比较共同定义为一个主要家族，并以 Bonferroni 分配 `0.05/15`。该选择对任意比较间依赖结构均控制家族错误率，计算透明，也避免根据观测到的效应大小或任务信息量事后分配错误预算。等额分配仅是错误预算规则，不表示比较科学重要性相同、真实效应相同或任务可互换。\n\n按任务建立五个互不重叠的家族、每个家族 α=0.01，再在任务内三项比较等额分配，所得单比较 α 仍为 `0.01/3=0.05/15`，不会提高本设计的分辨率。若给每个任务各设 α=0.05，则跨五个任务的整体错误率一般不再受 0.05 控制。未来研究若有事前确定的主要/次要层级或可信优先权重，可预注册层级检验或加权分配；权重必须在测试数据打开前确定并满足总错误预算。现有材料对 J=1、3、9、15、30 的解析规划敏感性见补充材料 S19，不将其误作替代分配下的事后显著性检验。\n\n## 4 实验设计')
    text=replace_once(text,'### 5.7 替代区间与配对诊断',ORDER_RESULTS+'\n### 5.7 替代区间与配对诊断')
    text=replace_once(text,'### 5.16 跨种子序列一致性诊断',MECHANISM+'\n### 5.16 跨种子序列一致性诊断')
    text=replace_once(text,'## 6 讨论',CALIBRATION+'\n## 6 讨论')
    text=replace_once(text,'### 6.2 扩展观察的含义',DISCUSSION+'\n### 6.2 扩展观察的含义')
    text=replace_once(text,'### 6.3 定理支持的评估设计建议',TASKS+'\n### 6.3 定理支持的评估设计建议')
    text=replace_once(text,'## 7 局限与有效性威胁',GUIDE+'\n## 7 局限与有效性威胁')
    text=replace_once(text,'## 7 局限与有效性威胁',
        '### 6.4 科学定位与适用范围\n\n本文回答的是指定有界指标、冻结配置、15 项比较族、有限检查点和阈值组合下的协议分辨率问题。主研究 20 种子未决是解析预算边界，不是算法等价、经验功效结果或强化学习的普遍种子下界。该区间构造在指标有界、检查点和比较族事先固定、验证选择与密封测试分离，以及每个算法臂内测试种子独立并具有共同条件均值时提供所述保证；它不能直接覆盖未测试的视觉输入、高维连续控制、稀疏奖励、多智能体或一般非平稳任务。对新任务的应用须重新定义估计对象、校准任务指标范围和效用阈值、冻结比较族与检查方案，并在读取测试数据前完成预算审计。\n\n### 6.5 后续研究方向\n\n后续工作可在独立预注册下将同一设计审计扩展到 Atari 等视觉观测任务和 MuJoCo 等高维连续控制任务，并分别报告任务族错误预算、观测范围及预算可行性；这些实验检验的是新任务族中的协议表现，不应与当前固定面板合并解释。算法范围也可扩展到 SAC、TD3 等方法，但须预先冻结候选配置、调参预算和比较族。\n\n若运行顺序、环境变化或共享随机源可能造成依赖，应先收集可识别依赖结构的运行时间与分组元数据，再设计与该结构匹配的区间方法；当前顺序诊断不足以完成此推断。最后，可将附录 D 的阈值流程和事前预算计算器发展为交互式设计工具，并通过不同团队按公开材料独立执行来检验其可用性与复现性。以上均为研究建议，不是本文已经验证的结果。\n\n## 7 局限与有效性威胁')
    text=replace_once(text,'| A2 | 条件于选定配置，每个算法的密封种子指标是具有共同边际均值的独立抽样。 | 唯一种子范围、显式种子派生和运行元数据；单次安装无法证明独立性。 |',
        '| A2 | 条件于选定配置，每个算法的密封种子指标是具有共同边际均值的独立抽样。 | 唯一种子范围、显式种子派生、运行元数据与事后顺序诊断（第 3.6.1、5.6.3 节）；未拒绝不证明独立性。 |')
    text=text.replace('若命题 0 对 `m` 个预先声明的任务—算法比较分别成立','若命题 0 对 `J` 个预先声明的任务—算法比较分别成立')
    text=text.replace('| $D_{val}$ |', '| $J$、$K$ | J 为预先声明的比较数量，K 为检查点数量；与实际边际 m 区分。 |\n| $D_{val}$ |')
    text=text.replace(
        '因为候选配置只用于选择而不进入密封测试区间，所以不需要对候选网格再作并集界。',
        '因为候选配置只用于选择而不进入密封测试区间，所以不需要对候选网格再作并集界。选择稳定性不是命题 1 或命题 2 的附加前提：只要选择规则仅依赖验证数据且每个可选配置均满足测试假设，覆盖保证条件于实际选中配置成立。选择频率较分散会限制对其他验证样本、其他配置或总体最优性能的外推，但不会把条件覆盖改写为“仅对稳定选择成立”。')
    text=text.replace(
        '作为有界区间的补充，我们报告同一批 20 个种子样本的描述性效应量。',
        '表 11 报告同一批 20 个种子样本的描述性效应量，与主要族级有界区间的推断功能不同。均值差、Cliff delta 和标准化差异用于描述当前样本，不是显著性检验、功效计算或跨任务可直接比较的效应尺度；不应据此推断总体差异、计算达到指定功效所需样本量，或取代表 10 的主要区间决定。')
    text=text.replace('图 14。两个固定离散任务','图 15。两个固定离散任务')
    # The archived effect-size generator used 0 for an undefined 0/0 ratio.
    # Correct only its manuscript display, preserving the archived output.
    for env,pair in [('MountainCar-v0','PPO - A2C'),('Taxi-v4','PPO - DQN')]:
        text=replace_once(text,
            f'| {env} | {pair} | 0.000000 | 0.000000 | 0.000000 | 0.000000 |',
            f'| {env} | {pair} | 0.000000 | 0.000000 | 未定义 | 0.000000 |')
    text=replace_once(text,'**表 11。描述性效应量**',
        '当合并样本标准差为零时，标准化差异为未定义；原始归档脚本将该情况存为 0，本表改为显式缺失标记，避免把 0/0 当作零效应。均值差与 Cliff delta 不受此显示修正影响。\n\n**表 11。描述性效应量**')
    text=text.replace('manuscript_figures/fig_protocol.png','manuscript_figures/fig_round3_protocol.png')
    text=text.replace('图 1。预注册嵌套评估协议与密封测试决定流程。','图 1。验证选择、冻结协议、密封测试与参数级分辨审计。参数审计可在新数据收集前使用；本图不推断已有解析推导完成的时间。')
    text=replace_once(text,'### 4.7 范围诊断全览',
        '原预注册记录了指标、阈值、种子和检查方案。参数级审计不需要观测数据，因此可用于未来实验的事前设计；这不等于已有材料证明每个解析推导都在主研究数据收集之前完成。本研究的合成校准、顺序诊断和检查点敏感性均为事后诊断，计划及生成记录见补充材料 S16–S19。\n\n### 4.7 范围诊断全览')
    text=text.replace('**新颖性与期刊。** 既有研究已经提出 RL 可靠性指标和统计比较工具[L15]。本文有限检查点、条件性验证后估计对象和密封测试协议的确切差异，以及任何具体 SCI 期刊的适配性，需要完整且最新的文献与期刊审查[待核实]。本文不据此主张普适性或算法排名。',
        '**相关工作比较。** 既有研究已经提出 RL 可靠性指标与统计比较工具[L15]。本文与最相关工作的全文方法级重叠仍未完整核验（补充材料 S1.1），因此不声称率先提出这些组件或已经证明文献范围内的唯一性。补充实验与形式推导不能替代这一新颖性审查。')
    text=text.replace('6. **区分可重复性和可复现性。** 同机重放检查的是实现可重复性，不同机器或独立团队的密封重跑才是可复现性证据。',
        '6. **区分可重复性和可复现性。** 同一团队重新运行支持可重复性；不同团队依据披露信息重新获得结果才支持本文所用的可复现性定义。不同机器测试单独作为跨平台复跑证据报告。')
    p='材料包使用三个不同标签。**可重复性**'
    start=text.index(p);end=text.index('\n\n',start)
    text=text[:start]+('本文将**可重复性**定义为同一团队按相同研究程序重新运行；同机跨脚本结果属于这一层。'
        '**可复现性**要求不同团队依据披露信息获得可比较的结果，目前操作者的团队独立性未核验，因而尚未建立这一层证据。'
        '**跨平台复跑**指冻结材料在不同硬件和操作系统上的技术检验：Windows AMD64 返回结果支持这一事实；'
        '文中“不同机器可复现性”仅用作该技术层面的描述，不等同于不同团队可复现性。'
        '**科学结论的可复制性**还要求新的任务或研究设计支持相同科学关系，当前亦未建立。')+text[end:]
    # Additional claims fit in the existing evidence table without adding another main table.
    row='| 协议普遍节省计算或能够对 PPO/DQN/A2C 排名。 |'
    text=replace_once(text,row,
        '| 20 种子非分辨边界与合成实现一致，较大预算可分辨特定强效应。 | 第 5.19 节、补充材料 S18；五个 Bernoulli 情景、三套计划、每情景 10,000 次重复。 | 事后模型校准；不是 RL 经验功效或完整比较族的模拟覆盖证据。 |\n'
        '| 顺序诊断未发现校正后的异常，但不能确证独立性。 | 第 5.6.3 节、补充材料 S16；公开所有不可计算项目和原始/校正 p 值。 | 探索性假设检查，未改变主分析。 |\n'+row)
    text=replace_once(text,'## 参考文献',
        '贝叶斯敏感性分析需要先明确有界或混合分布的观测模型、先验、诊断及模型检查；当前没有拟合这类后验，不报告建议中的示例后验概率。跨研究整合则需处理估计对象、任务、归一化、调参及停止策略的异质性，并显式建模可能的选择偏差；仅汇总本稿区间或任务均值不足以形成有效的元分析。这些是待独立研究的问题，而非本文已完成的结果。\n\n## 参考文献')
    text=text.replace(
        '本地发布记录中的仓库地址为 https://github.com/upcmill/rl-reliability-cost-frontiers；当前公开可访问性及仓库版本与本稿材料的对应关系[待核实]；永久 DOI 和发布许可证[待补充]。',
        '研究材料公开于 https://github.com/upcmill/rl-reliability-cost-frontiers，归档概念 DOI 为 https://doi.org/10.5281/zenodo.23949004。概念 DOI 指向该归档的最新发布版本；版本记录、文件清单和校验信息见 DOI 落地页。')
    text=text.replace(
        '**数据与代码可用性。** 源代码、预注册文件、种子级原始 CSV、JSON 摘要、arm64 wheel 归档和审计命令均整理在随文提供的研究材料中。本地发布记录中的仓库地址为 https://github.com/upcmill/rl-reliability-cost-frontiers；当前公开可访问性及仓库版本与本稿材料的对应关系[待核实]；永久 DOI 和发布许可证[待补充]。材料包分别报告同机可重复性与不同机器复跑，尚不宣称不同团队按披露信息完成的可复现性。',
        '**数据与代码可用性。** 源代码、预注册文件、种子级原始 CSV、JSON 摘要、arm64 wheel 归档和审计命令已公开于 https://github.com/upcmill/rl-reliability-cost-frontiers，并归档于 Zenodo 概念 DOI https://doi.org/10.5281/zenodo.23949004。该概念 DOI 指向最新发布版本，具体版本 DOI 和许可证见记录元数据。材料包分别报告同机可重复性与不同机器复跑，尚不宣称不同团队按披露信息完成的可复现性。')

    text=replace_once(text,'### 4.2 算法与等强度候选网格','### 4.2 算法与候选配置网格')
    text=text.replace(
        '每个算法—任务单元使用相同的四候选网格，每个候选配置使用五个验证种子：',
        '每个算法—任务单元评估四个候选配置，每个候选配置使用五个验证种子。各单元的候选数量、验证种子数和训练预算相同；这不表示搜索空间、计算量或调优强度等价：')
    text=replace_once(text,
        '每个算法—任务单元拥有相同的四候选验证网格；选定配置在打开密封测试数据前冻结。',
        '每个算法—任务单元评估四个候选配置、每个候选五个验证种子；选定配置在打开密封测试数据前冻结。这里的相同仅指候选数量和验证种子数，不表示搜索空间、计算量或调优强度等价。')
    text=text.replace('### 5.22 未披露新种子上的事后前瞻验证',
                      '### 5.22 新种子上的事后前瞻验证')
    text=text.replace('在查看 V1–V5 结果后冻结 V7 方案',
                      '在查看 V1–V6 结果后冻结 V7 方案')
    text=text.replace('扩展的四候选网格缓解了 早期诊断 的调优限制',
                      '四候选网格比早期两候选诊断提供了更多选择')
    text=text.replace('队列现在具有精确有限状态 oracle 和切换时刻 sanity check',
                      '队列现已通过精确有限状态 oracle 和切换时刻检查')
    text=text.replace('第 5.19 节在保留原始主分析的前提下报告边际敏感性',
                      '第 5.18 节在保留原始主分析的前提下报告边际敏感性')
    text=text.replace('第 5.18 节、补充材料 S18；五个 Bernoulli 情景',
                      '第 5.19 节、补充材料 S18；五个 Bernoulli 情景')
    text=text.replace('  材料索引见补充材料 S15', ' 材料索引见补充材料 S15')
    text=text.replace('多智能体任务、稀疏奖励/长时域任务、视觉输入和一般非平稳任务均未被本研究系统覆盖。 多智能体任务',
                      '多智能体任务、稀疏奖励/长时域任务、视觉输入和一般非平稳任务均未被本研究系统覆盖。多智能体任务')
    text=text.replace('本轮依据同一批主研究观测', '本研究依据同一批主研究观测')
    text=text.replace('本轮对主研究 15 个任务—算法单元', '本研究对主研究 15 个任务—算法单元')
    text=text.replace('本轮提供无需网络的命令行计算器', '研究材料提供无需网络的命令行计算器')
    text=text.replace('审稿后执行', '事后执行')
    text=replace_once(text,'**关键词：**',
        '**正文与补充材料导航。** 方法与定理见第 3 节及补充材料 S2；实验设计、原始数据与字段说明见第 4 节及 S3–S4；配置选择敏感性见第 5.9 节及 S5；依赖、阈值和预算诊断见第 5–6 节及 S8、S16–S20；各补充章节和文件索引见 S15。新增任务族、任务特定阈值和独立团队复现仍属于后续研究。\n\n**关键词：**')
    text += '''\n\n## 附录 D。新任务的实际边际与精度目标选择框架\n\n本框架用于新研究设计，不为原研究中未记录的阈值补造依据。首先明确决策对象和种子级指标，确认原始回报是否有可辩护的上下界；若归一化包含截断，应直接在预先定义的指标尺度上评估阈值，不能用简单线性换算解释被截断观测。\n\n其次，依据应用损失、收益或领域专家事前判断，确定原始尺度上最小值得采取行动的差异 δ。记录判断者、依据、决策后果及不确定范围。若没有效用模型或可信领域判断，应把 δ 标记为待定的设计参数，报告多组合理候选值，而不是借助已观察测试差异、标准化效应量或未核实文献事后选值。\n\n若归一化是无截断的仿射变换，且范围为 [L,U]，可将 δ 转为 m=δ/(U−L)。例如，主研究的 m=0.05 在 CartPole、MountainCar 和 Taxi 的原始尺度分别对应 25、10 和 101 个回报单位；这些换算展示同一比例在不同指标上的单位差异，不表示这些差异具有相同实际价值，也不证明原阈值合理。应同时保留原始尺度的 δ，便于解释和复核。\n\nw 是区间总宽度的精度目标，不是第二个效用边际。应依据决策所需的估计精度、错误后果及可承担成本确定可接受的不确定性，再将其映射到预先定义的估计尺度。可报告不同 w 下的解析预算与敏感性结果；必要样本阈值不是达到目标功效的充分样本量。\n\n最后，在打开密封测试数据前冻结 m、w、归一化边界、比较族、检查点和 alpha 分配，并运行解析可行性审计。若目标与预算不相容，应调整尚未执行的设计或明确将研究定位为分辨率诊断。本文没有为新任务确定领域效用阈值，也没有验证任何通用的 m 或 w 数值。\n'''
    text += '''

### D.4 快速参考：设置 m 与 w 的事前清单

**五步速查框**

1. **定义决策与 δ。** 用原始指标单位写明何种改进会改变行动，并记录判断依据及其不确定范围。
2. **核对指标边界并换算 m。** 仅在有依据的无截断仿射范围 [L,U] 下使用 `m=δ/(U−L)`；否则在预先定义的估计尺度上设定阈值。
3. **独立确定 w。** 说明何种区间宽度足以支持目标决策；w 是精度目标，不是效用边际或功效保证。
4. **运行事前预算审计。** 固定比较族、检查点和 alpha 支出，分别检查边际决定与宽度目标是否可达。
5. **揭盲前冻结。** 登记 δ、m、w、指标边界、选择规则、预算与停止规则；预算不可行时调整尚未执行的设计或将研究定位为分辨率诊断。

若无法获得可信的专家判断或成本模型，不指定通用默认值；可在测试揭盲前选取有依据的候选范围并报告敏感性，若连范围也无法辩护，则把阈值标为未校准，不作确认性优越性判断。

**表 D4-1。事前敏感性网格示例及宽度规划量**

| 示例 m | 示例 w | 末次检查点未截断宽度充分规划数/臂 |
|---:|---:|---:|
| 0.03 | 0.05 | 33,154 |
| 0.05 | 0.10 | 8,289 |
| 0.10 | 0.20 | 2,073 |

注：规划数按主研究 15 项比较、四个检查点及原可求和 alpha 支出计算；该列只由 w、alpha 和区间公式决定，m 不改变宽度规划数。它们是未截断指标下的充分宽度规划数，不是经验功效、达到功效的样本量或通用推荐值；三个配对只作敏感性示例，不代表“保守/中等/宽松”标准。

'''
    return text


def additions():
    order=load('order_diagnostics'); synth=load('synthetic_calibration'); plan=load('planning_sensitivity'); scale=load('threshold_scale')
    s=['## S16 原始密封记录的顺序诊断','',
       '本诊断在审稿后执行；输入为主研究 15 个单元各 20 个测试记录，依原始 CSV 的单元内行次序。'
       '没有墙钟时间戳。生成计划、检验族与随机种子见 `round3_analysis/ANALYSIS_PLAN.md`；'
       '代码为 `round3_diagnostics.py`，输出为 `round3_analysis/order_diagnostics.json`。', '',
       '游程检验在样本中位数上下二分，剔除相等值。给定 n₊、n₋，共有 C(n₊+n₋,n₊) 个等概率符号排列；'
       '偶数游程 R=2k 的计数为 2C(n₊−1,k−1)C(n₋−1,k−1)，奇数 R=2k+1 的计数为 '
       'C(n₊−1,k)C(n₋−1,k−1)+C(n₊−1,k−1)C(n₋−1,k)。两侧尾部按 |R−E(R)| 定义，'
       'E(R)=1+2n₊n₋/(n₊+n₋)；无任一符号时不可计算。', '',
       '一阶统计量 r₁=Σᵢ₌₁ⁿ⁻¹(xᵢ−x̄)(xᵢ₊₁−x̄)/Σᵢ₌₁ⁿ(xᵢ−x̄)²。'
       '固定值多集并独立置换顺序 9,999 次，以绝对值不小于观测值的次数 b 计算 (b+1)/10000；'
       '种子 20261104，NumPy PCG64，按排序单元用 SeedSequence 派生流。分母为零则不可计算。'
       'Holm 对 30 项 p 排序，依次乘以剩余比较数并取累计最大值、截断至 1；不可计算项用 p=1 纳入。', '']
    rows=[]
    for r in order['rows']:
        runs=r['runs'];lag=r['lag1']
        rows.append([r['env_id']+'/'+r['algorithm'],runs['ties_dropped'],
                     f"{runs['p']:.6f}" if runs['status']=='computed' else '不可计算',
                     f"{lag['r1']:.6f}" if lag['r1'] is not None else '不可计算',
                     f"{lag['p']:.4f}" if lag['r1'] is not None else '不可计算',
                     f"{runs['holm_p_30_tests']:.4f} / {lag['holm_p_30_tests']:.4f}"])
    s.append(table('表 S16-1。顺序诊断的全部单元', ['单元','剔除中位同值数','游程原始 p','r₁','排列原始 p','Holm p：游程 / 排列'],rows))
    s+=['全部校正项目未拒绝；不可计算不等于 p=1 的实质证据，表中校正值 1 仅用于完整计入比较族。'
         '这些检验既不能证明独立，也不能识别共享状态或时间漂移的具体原因。', '',
         '## S17 阈值尺度、任务特征与队列解释', '',
         '### S17.1 实际安装任务的特征清单', '',
         '主研究任务空间与时域从实际 Gymnasium 1.4.0 环境对象和自建队列构造读取；'
         '输出及源模块 SHA-256 见 `round3_analysis/environment_features.json`。范围扩展规格另见 S10、S14 的预注册和运行记录。'
         '这是类型与语义清单，没有参照总体的覆盖百分比。', '']
    s.append(table('表 S17-1。九个基础环境及两个观测掩码变体的特征与证据地位',['任务','观测类型 / 动作空间','奖励结构概述','证据组与测试规模'],[
        ['CartPole-v1','Box(4) / Discrete(2)','每步生存奖励，稠密','主研究；20 个测试种子/算法'],
        ['Acrobot-v1','Box(6) / Discrete(3)','非终止步代价，终止步为零','主研究；20 个测试种子/算法'],
        ['MountainCar-v0','Box(2) / Discrete(3)','每步 −1，达到目标终止','主研究；20 个测试种子/算法'],
        ['Taxi-v4','Discrete(500) / Discrete(6)','步代价、非法操作惩罚及成功奖励','主研究；20 个测试种子/算法'],
        ['NonstationaryQueue-v0','Box(3) / Discrete(2)','队列与服务成本，阶段到达率切换','主研究；20 个测试种子/算法'],
        ['Pendulum-v1','Box(3) / Box(1)','逐步控制代价，稠密','单任务范围扩展；20 个测试种子/算法；1 项比较'],
        ['MountainCarContinuous-v0','Box(2) / Box(1)','控制代价及成功终止奖励','单任务范围扩展；20 个测试种子/算法；1 项比较'],
        ['CliffWalking-v1','Discrete(48) / Discrete(4)','逐步代价与悬崖惩罚，稠密','V6 独立任务族；200 个测试种子/算法'],
        ['FrozenLake-v1','Discrete(16) / Discrete(4)','终止成功奖励，稀疏；4×4、可滑冰','V6 独立任务族；200 个测试种子/算法'],
        ['MaskedCartPole-v1','Box(4)，速度坐标 1、3 置零 / Discrete(2)','沿用 CartPole 奖励','观测掩码变体族；20 个测试种子/算法'],
        ['MaskedAcrobot-v1','Box(6)，角速度坐标 4、5 置零 / Discrete(3)','沿用 Acrobot 奖励','观测掩码变体族；20 个测试种子/算法']]))
    s+=['注：主研究的五任务、15 项比较共享族级 α=0.05；Pendulum 与 MountainCarContinuous 各自为单比较族；CliffWalking 与 FrozenLake 的六项比较共享独立族级 α=0.05；两个观测掩码变体另组成独立六比较族，α=0.05。掩码规格来自 `FINAL_PREREGISTRATION_PARTIAL_OBSERVABILITY.md` 和 `partial_observable_env.py`，不增加基础环境数。补充设置均不并入主研究族。观测空间的离散状态数与连续 Box 维数不可直接等同。任务清单仅描述已执行范围，不代表对 RL 任务总体的代表性。','']
    s+=['### S17.2 设计边际相对于观测离散程度的尺度','',
        's_pooled=√((s_A²+s_B²)/2)，因为每臂均为 n=20。表列 m/s_pooled 而非观测均值差/s_pooled；'
        '二者不可混淆。本表使用事后样本标准差，仅帮助理解尺度，不能据此宣称预先阈值具有实际效用。'
        '完整输出：`round3_analysis/threshold_scale.json`。', '']
    s.append(table('表 S17-2。m=0.05 的标准化尺度',['任务','算法对','合并样本 SD','m / SD'],[
        [r['environment'],r['comparison'],f"{r['pooled_sd']:.6f}",f"{r['margin_over_pooled_sd']:.6f}" if r['margin_over_pooled_sd'] is not None else '未定义（SD=0）'] for r in scale['rows']]))
    s+=['### S17.3 队列机制假设与待收集证据','']
    s.append(table('表 S17-3。可检验解释与证据缺口',['解释假设','当前可见信息','仍需的证据'],[
        ['冻结策略行为导致平均差异','不同序列的点估计均为正；仅限已测试任务和程序','动作、占用/服务成本分解，预先指定策略或训练消融；新种子评估'],
        ['A2C 存在失败模式混合','A2C 种子间 SD 较大，但聚合回报不识别具体模式','逐策略轨迹及失败定义；聚类/分类必须避免由结果反推验证标准'],
        ['序列组成影响停止时点','跟踪与新序列在相同 n 下有不同点估计与越界状态','预先声明的多条独立序列及停止时点分布；不能重复使用已经披露的种子']]))
    s+=['## S18 已知效应的合成校准','',
        '每情景重复 10,000 次，PCG64 seed=20261103；五个情景各有独立 SeedSequence 流。'
        '同情景的三套计划复用同一模拟序列的前缀，比较计划之间并非独立；未对计划间差异作统计检验。'
        '每次重复生成两臂各 1000 个独立 Bernoulli 样本，按各计划检查、锁定首次决定。'
        '同时覆盖指所有计划内检查点覆盖已知 Δ；等于边际时的优越性计为错误。'
        '所有参数、原始计数及 Wilson 区间见 `round3_analysis/synthetic_calibration.json`。','']
    sr=[]
    for r in synth['rows']:
        rate=r['rates']['a_superior'];ci=rate['wilson95'];c=r['counts']
        sr.append([f"{r['p_a']:.2f}/{r['p_b']:.2f}",r['looks'][-1],
                   f"{c['a_superior']}/10000",f"[{ci[0]:.6f}, {ci[1]:.6f}]",
                   c['unresolved'],f"{r['mean_terminal_n']:.2f}",f"{10000-c['simultaneous_covered']} / {c['false_superiority']}"])
    s.append(table('表 S18-1。校准的全部计数与停止成本',['pA / pB','最大 n','A 优越计数','决定率 95% Wilson CI','未决计数','平均终止 n','非覆盖 / 错误优越'],sr))
    s+=['所有单元的 B 优越和仅精度决定计数均为 0。Wilson 区间是有限重复模拟误差的边际区间，'
         '不作多个情景的同时校准声明。没有将单比较模拟覆盖称为完整比较族覆盖。','',
         '## S19 检查点、支出与宽度敏感性','',
         '比较级 alpha=0.05/15；固定 m=.05。原方案 a_k=alpha_cmp·6/(π²k²)；'
         '前置方案将 1/k² 在有限 K 内归一化，均匀方案权重 1/K，后置方案将 k² 归一化。'
         '后面三者花完相同比较预算，原方案有剩余，因此不能把所有差异解释成纯粹的时间分配效应。'
         '完整的逐次 alpha、半径、必要种子与三个宽度规划数见 `round3_analysis/planning_sensitivity.json`。','']
    names={'original_summable':'原可求和','front_loaded':'有限前置','uniform':'均匀','back_loaded':'后置'}
    s.append(table('表 S19-1。相同预算下的解析设计对照',['最大 n / K','支出','支出份额','最大半径和','末次半径和','末次可能优越必要 n','末次未截断 w=.10 规划 n'],[
        [f"{r['looks'][-1]} / {len(r['looks'])}",names[r['schedule']],f"{r['spent_fraction']:.6f}",f"{r['max_radius']:.6f}",f"{r['last_radius']:.6f}",r['necessary_superiority_n_by_look'][-1],r['untruncated_precision_n_last']['0.1']] for r in plan['rows']]))
    s.append(table('表 S19-2。敏感性证据矩阵',['设计维度','实际检查范围','证据种类','位置'],[
        ['比较数 J','1、3、9、15、30','解析规划，非经验功效','S2 表 S2-1'],
        ['实际边际 m','0、.025、.05、.10、.20、.30、.50','固定主数据重算及解析阈值','S13 表 S13-1'],
        ['目标宽度 w','.05、.10、.20','本轮解析未截断宽度规划；不声称此前已运行','S19 JSON 完整数值'],
        ['检查点数 K','2、4、8；各最大 n=200','解析设计；另保留原 n=20 四次计划','S19 表 S19-1'],
        ['alpha 支出','原可求和、有限前置、均匀、后置','固定预算及支出份额公开','S19 表 S19-1'],
        ['归一化边界','原方案及已有 11 种变换','事后数据重算','第 5.9 节；S5、S10'],
        ['验证种子','5、10、20；四候选网格','已有选择敏感性观察','S5'],
        ['训练/评估预算','4096/16384 步；5/10 评估回合','已有固定配置诊断','S10']]))
    s+=['## S20 可执行设计清单与离线计算器','',
        '下面步骤面向新研究，不能事后修复既有隐藏测试复用。命令行工具 `budget_calculator.py` '
        '只依赖 Python 标准库，无在线页面或容器发布假设。','']
    s.append(table('表 S20-1。评估设计检查清单',['步骤','必须明确的决策','无法满足时的处理'],[
        ['1 定义目标','独立训练运行、条件选定程序、指标及范围','重新定义研究问题；不把回合或训练阶段当独立种子'],
        ['2 检查采样','独立性、共同目标、有界性及可能漂移','重设计采样或采用适配模型；不能自动套用本稿区间'],
        ['3 冻结方案','候选、选择、J、K、alpha、m、w','仅作探索性报告；不声称未定义的序贯错误保证'],
        ['4 解析可行性','每次半径、最大下界、最小截断宽度','新数据前调设计，或明确刻画非分辨边界'],
        ['5 功效与成本','与目标分布相符的模拟/外部先验及硬件计时','必要阈值不能当充分样本数；不填入虚构耗时'],
        ['6 执行和披露','记录全部种子、失败、配置、版本、决定和来源','保留缺口；区分同团队重复、跨平台与不同团队复现']]))
    s+=['示例：`python3 budget_calculator.py --looks 5 10 15 20 --comparisons 15 --margin 0.05 --width 0.10`。'
         '严格优越性的必要整数阈值使用 floor(2 log(4/alpha_k)/(1−m)²)+1；'
         '未截断宽度的充分规划数为 ceil(8 log(4/alpha_k)/w²)。二者目的不同，不是保证检出的推荐种子数。','']
    return '\n\n'.join(s)


def supplement_index(supp,paths):
    sections=list(re.finditer(r'^## (S\d+) (.+)$',supp,re.M))
    rows=[]
    for i,m in enumerate(sections):
        sid,title=m.groups()
        segment=supp[m.end():sections[i+1].start() if i+1<len(sections) else len(supp)]
        count=len({p for p in re.findall(r'`([^`]+)`',segment) if (ROOT/p).is_file()})
        status='12 篇全文关键方法已比较；非穷尽性检索' if sid=='S1' else '已提供；按本节证据边界使用'
        if sid in ('S16','S18'):status='本轮事后诊断，原始计数及代码已提供'
        rows.append([sid,title,count,'主文对应 S 编号/章节',status])
    matrix=table('表 S15-2。补充材料章节与完整性状态',['编号','内容','节内直接列出文件数','引用方式','状态'],rows)
    navigation=table('表 S15-1。按读者问题查找内容',['我想找','位置'],[
        ['核心定理与证明','正文第 3 节；补充材料 S2'],
        ['主研究设计、原始数据与结果','正文第 4 节、第 5.1–5.5 节；补充材料 S3–S4'],
        ['逐单元配置选择稳定性','正文第 5.9 节；补充材料 S5 表 S5-4'],
        ['种子顺序/依赖诊断','正文第 5.6.3 节；补充材料 S8、S16'],
        ['补充任务与任务特征','正文第 5.13 节、附录 A–C；补充材料 S10、S14、S17'],
        ['同预算序贯区间对照','正文第 5.21 节；补充材料 S21'],
        ['新种子验证','正文第 5.22 节；补充材料 S22'],
        ['如何为新研究设置阈值和预算','正文第 6.3 节、附录 D；补充材料 S20'],
        ['逐文件清单与校验值','本节 S15 文件索引及 `round3_analysis/SUPPLEMENT_FILE_MANIFEST.csv`'],
    ])
    intro=('快速查找：协议和证明见 S2；主研究原始数据与选择敏感性见 S3–S5；运行成本见 S6；'
           '种子依赖与范围扩展见 S8、S14；阈值、任务特征和机制限制见 S17；合成校准与解析规划见 S18–S20；'
           '现代序贯区间对照见 S21，V7 新种子诊断见 S22。每个章节是本配套文件中的实际章节；原始数据和脚本的逐文件大小、SHA-256 及用途见 '
           '`round3_analysis/SUPPLEMENT_FILE_MANIFEST.csv`。统计的是随本稿引用的证据子集，不包含全部依赖 wheel。'
           '无公开 Docker 镜像、Conda 求解记录或 CI 执行结果，不提供虚构安装地址。\n\n')
    return supp.replace('## S15 开放材料索引与生成说明','## S15 开放材料索引与生成说明\n\n'+intro+navigation+'\n\n'+matrix,1)


def main():
    main_md=revise_main_literature(revise_main())
    supp=(BASE/'SUPPLEMENTARY_FORMAL_ZH.md').read_text()
    supp=supp.replace(
        '公开可访问性、发布版本及 DOI 未由本轮联网核验。',
        '2026-11-05 已核验公开仓库、Zenodo 概念 DOI `10.5281/zenodo.23949004`、当前版本和文件校验；详见 `PUBLIC_ARCHIVE_VERIFICATION.md`。')
    supp=supp.replace('章节 S1–S15','章节 S1–S22')
    supp=supp.replace('章节 S1–S20','章节 S1–S22')
    supp=supp.replace('直接产物核对：`python3 audit_formal_round2.py`','第三轮直接产物核对：`python3 audit_formal_round3.py`')
    supp+='\n'+additions()
    supp=supp.replace('未完成新的远程全文获取。因此，','本轮再次请求 arXiv 全文与 GitHub 仓库，但远程访问未成功；未完成新的远程全文获取。因此，')
    supp=revise_supplement(supp)
    main_md,supp=update_modern_comparison(main_md,supp)
    stability_md,stability_counts=selection_stability_table()
    supp=replace_once(supp,'## S6 运行时间与可靠性—成本前沿',
                      stability_md+'\n\n## S6 运行时间与可靠性—成本前沿')
    main_md=main_md.replace(
        '完整选择频率和熵见补充材料 S5 表 S5-1。',
        '完整选择频率和熵见补充材料 S5 表 S5-1，逐单元描述分类见表 S5-4。10 个候选均值不完全并列的单元中，主选择重采样保留率较高（≥70%）的有 '
        f"{stability_counts['high']} 个，中等（50%–<70%）有 {stability_counts['moderate']} 个，较低（<50%）有 {stability_counts['low']} 个；另 {stability_counts['uninformative']} 个单元候选均值完全并列，频率由确定性并列顺序产生，不能解释为稳定证据。低保留率单元包括 CartPole/PPO、Acrobot/PPO、Queue/PPO 和 Queue/A2C，说明所选配置对验证样本构成敏感，结论限于各自实际选定配置。",1)
    main_md=main_md.replace('### 4.2 算法与等强度候选网格', '### 4.2 算法与候选配置网格')
    main_md=main_md.replace(
        '每个算法—任务单元使用相同的四候选网格，每个候选配置使用五个验证种子：',
        '每个算法—任务单元评估四个候选配置，每个候选配置使用五个验证种子。各单元的候选数量、验证种子数和训练预算相同；这不表示搜索空间、计算量或调优强度等价：')
    main_md=main_md.replace(
        '每个算法—任务单元拥有相同的四候选验证网格；选定配置在打开密封测试数据前冻结。',
        '每个算法—任务单元评估四个候选配置、每个候选五个验证种子；选定配置在打开密封测试数据前冻结。这里的相同仅指候选数量和验证种子数，不表示搜索空间、计算量或调优强度等价。')
    main_md=main_md.replace('### 5.22 未披露新种子上的事后前瞻验证',
                            '### 5.22 新种子上的事后前瞻验证')
    main_md=main_md.replace('在查看 V1–V5 结果后冻结 V7 方案',
                            '在查看 V1–V6 结果后冻结 V7 方案')
    main_md=main_md.replace('扩展的四候选网格缓解了 早期诊断 的调优限制',
                            '四候选网格比早期两候选诊断提供了更多选择')
    main_md=main_md.replace('队列现在具有精确有限状态 oracle 和切换时刻 sanity check',
                            '队列现已通过精确有限状态 oracle 和切换时刻检查')
    main_md=main_md.replace('第 5.19 节在保留原始主分析的前提下报告边际敏感性',
                            '第 5.18 节在保留原始主分析的前提下报告边际敏感性')
    main_md=main_md.replace('第 5.18 节、补充材料 S18；五个 Bernoulli 情景',
                            '第 5.19 节、补充材料 S18；五个 Bernoulli 情景')
    main_md=main_md.replace('  材料索引见补充材料 S15', ' 材料索引见补充材料 S15')
    main_md=main_md.replace('见 补充材料', '见补充材料').replace('由 补充材料', '由补充材料')
    main_md=main_md.replace('原始数据 逐行复制', '原始数据逐行复制')
    main_md=main_md.replace('以及 确定性预算检查', '以及确定性预算检查')
    main_md=main_md.replace('最后一个检查点上测量的成本。 事后', '最后一个检查点上测量的成本。事后')
    main_md=main_md.replace('这构成了该', '这表明该')
    main_md=main_md.replace('由补充材料 S4 从 `metric_raw` 自动生成。',
                            '所选种子的原始回报摘要见补充材料 S4。')
    main_md=main_md.replace('机器生成的表格副本见补充材料 S4，由补充材料 S4 生成。', '')
    main_md=main_md.replace('表格及生成脚本见补充材料 S4。', '完整种子级记录及字段说明见补充材料 S4。')
    main_md=main_md.replace('诊断报告、机器可读输出及生成脚本见补充材料 S5。',
                            '完整重采样规格和逐单元结果见补充材料 S5。')
    main_md=main_md.replace('本文不通过挑选已发表论文的回报差或通用标准化效应阈值，追认为原预注册建立其未记录的科学依据。',
                            '本文不以已发表论文的回报差或通用标准化效应阈值，替代原预注册中未记录的科学依据。')

    # Remove repeated machine-time accounting from the introduction; the full
    # accounting remains in the dedicated results subsection.
    main_md=main_md.replace(
        '主研究 600 次记录运行的执行时间之和约为 0.116 小时（验证与测试各 300 次；不含软件安装、复跑及扩展实验）。第 5.5.2 节区分调参与测试成本，第 5.17 节另报大预算扩展成本。\n\n', '')

    # Replace production notes with reader-facing archive and supplementary
    # material descriptions. The release DOI was checked against Zenodo API.
    old_open_materials=('研究材料公开于 https://github.com/upcmill/rl-reliability-cost-frontiers，归档概念 DOI 为 https://doi.org/10.5281/zenodo.23949004。'
        '概念 DOI 指向该归档的最新发布版本；版本记录、文件清单和校验信息见 DOI 落地页。'
        ' 材料索引见补充材料 S15；源文件哈希和环境元数据随原始记录保留。具体期刊关于代码、数据、补充文件和文章类型的政策：[待核实]。')
    new_open_materials=('研究代码与数据归档于 GitHub（https://github.com/upcmill/rl-reliability-cost-frontiers）和 Zenodo。'
        '归档概念 DOI 为 https://doi.org/10.5281/zenodo.23949004；本文对应的 v3.0.4 版本 DOI 为 '
        'https://doi.org/10.5281/zenodo.23966546。Zenodo 记录标示的许可证为 CC BY 4.0。'
        '补充材料索引见补充材料 S15，逐文件归档清单及校验信息见公开仓库。')
    main_md=main_md.replace(old_open_materials,new_open_materials)
    main_md=main_md.replace(
        '**数据与代码可用性。** 源代码、预注册文件、种子级原始 CSV、JSON 摘要、arm64 wheel 归档和审计命令均整理在随文提供的研究材料中。研究材料公开于 https://github.com/upcmill/rl-reliability-cost-frontiers，归档概念 DOI 为 https://doi.org/10.5281/zenodo.23949004。概念 DOI 指向该归档的最新发布版本；版本记录、文件清单和校验信息见 DOI 落地页。材料包分别报告同机可重复性与不同机器复跑，尚不宣称不同团队按披露信息完成的可复现性。',
        '**数据与代码可用性。** 源代码、预注册文件、种子级原始 CSV、JSON 摘要、依赖归档及审计命令均已公开。GitHub 仓库为 https://github.com/upcmill/rl-reliability-cost-frontiers；Zenodo 概念 DOI 为 https://doi.org/10.5281/zenodo.23949004，本文对应的 v3.0.4 版本 DOI 为 https://doi.org/10.5281/zenodo.23966546。Zenodo 记录标示的许可证为 CC BY 4.0。材料包分别报告同机可重复性与不同机器复跑，尚未建立不同团队依据披露信息完成的可复现性。')
    main_md=main_md.replace(
        '## 2 相关工作',
        '## 2 相关工作',1)
    main_md=main_md.replace(
        '[L17] Patterson, A., Neumann, S., White, M., and White, A. (2024). Empirical Design in Reinforcement Learning. Journal of Machine Learning Research, 25(318), 1–63. 全文核读版本：arXiv:2304.01315v2（2024-10-29）；JMLR 题录已核验.',
        '[L17] Patterson, A., Neumann, S., White, M., & White, A. (2024). Empirical design in reinforcement learning. *Journal of Machine Learning Research*, 25(318), 1–63. https://jmlr.org/papers/v25/23-0183.html.')
    main_md=main_md.replace(
        '[L18] Howard, S. R., Ramdas, A., McAuliffe, J., and Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. The Annals of Statistics, 49(2), 1055–1080. DOI: 10.1214/20-AOS1991. 全文核读版本：arXiv:1810.08240v9（2022-08-06）；章节及定理编号按该版本。',
        '[L18] Howard, S. R., Ramdas, A., McAuliffe, J., & Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. *The Annals of Statistics*, 49(2), 1055–1080. https://doi.org/10.1214/20-AOS1991. 全文核读版本：arXiv:1810.08240v9（2022-08-06）。')
    main_md=main_md.replace(
        '[L19] Maurer, A., & Pontil, M. (2009). Empirical Bernstein Bounds and Sample Variance Penalization. arXiv:0907.3740v1. Theorem 4 is used for the fixed-time i.i.d. baseline; Theorem 11 is not used.',
        '[L19] Maurer, A., & Pontil, M. (2009). Empirical Bernstein bounds and sample variance penalization. arXiv:0907.3740v1. https://doi.org/10.48550/arXiv.0907.3740.')
    main_md=main_md.replace(
        '6. **区分可重复性和可复现性。** 同一团队重新运行支持可重复性；不同团队依据披露信息重新获得结果才支持本文所用的可复现性定义。不同机器测试单独作为跨平台复跑证据报告。',
        '6. **区分可重复性和可复现性。** 同一团队重新运行支持可重复性；不同团队依据披露信息重新获得结果才支持本文所用的可复现性定义。不同机器测试单独作为跨平台复跑证据报告。')
    main_md=main_md.replace(
        '在查看结果后提出的本项审稿回应分析',
        '在查看结果后开展的事后分析')
    main_md=main_md.replace('本轮取得 12 篇关键文献的全文并核读与本研究直接相关的方法及定理。',
                            '本文核读了 12 篇关键文献中与研究问题直接相关的方法及定理。')
    main_md=main_md.replace('完整投稿应披露实际测试了哪一级证据；缺少独立证据时，应保留更强标签为未解决。',
                            '因此，本文分别报告已完成的跨平台复跑，并将尚未检验的独立团队复现列为局限。')
    main_md=main_md.replace('而非本轮已完成的结果。', '而非本文已完成的结果。')
    main_md=main_md.replace('比 早期诊断 更强', '比早期两候选诊断选择更多')
    main_md=main_md.replace('  的调优', ' 的调优')
    main_md=main_md.replace('原始表所选种子的原始回报摘要见补充材料 S4。',
                            '所选种子的原始回报摘要见补充材料 S4。')
    main_md=main_md.replace('与早期两个候选配置等价版本相比', '与早期两候选版本相比')
    main_md=main_md.replace('四个候选配置和每候选五个验证种子比 早期诊断 更强，但仍然有限。',
                            '四个候选配置和每候选五个验证种子提供了明确但有限的选择预算。')

    main_md=replace_section(main_md,'### 5.6 补充统计诊断','### 5.6.1 种子依赖性假设压力测试','''### 5.6 补充统计诊断

![图 5。[0,1] 指标下的 Hoeffding 区间宽度解析规划；不是观测样本需求。](manuscript_figures/fig_budget_frontier.png)

解析规划和模拟校准均支持一个有限结论：在所测试的有界生成场景中，主研究预算下的区间保持保守，但 20 个种子无法达到预设决定阈值。5,000 次重复的对称、混合和偏斜情景同时覆盖率为 0.9998–1.0000；另一组 80 个分布—效应—alpha 单元未观察到覆盖失败或错误优越性。有限模拟不能证明任意 RL 种子分布下的覆盖保证。

解析半径显示了预算限制：在单比较 alpha=0.05 下，达到宽度 0.10 首次检查约需每臂 3,904 个种子；正式族级分配下首次和末次检查分别约需 6,071 和 8,289 个。它们是该区间构造的规划量，不是经验需求或通用样本下界。完整校准网格及逐单元结果见补充材料 S9。
''')
    main_md=replace_section(main_md,'### 5.7 替代区间与配对诊断','### 5.7.1 验证后选择 alpha 支出诊断','''### 5.7 替代区间与配对诊断

基于存储 pilot 的正态、bootstrap、配对和经验 Bernstein 结果均为派生诊断，不与主研究合并，也不能估计覆盖率。Acrobot pilot 的 5,000 次重新配对显示，部分配对方法的决定计数会随配对方式变化；这支持主分析不按相同整数种子配对，因为研究没有建立共同随机数关系。主要程序仍为无配对 Hoeffding 区间。

下表报告该 pilot 的终止决定计数。它描述单一存储样本在不同算法下的重算结果，不是独立实验或方法假阳性率估计。

**表 18。替代区间先导诊断**

| 区间方法 | B 优越 | 仅精度决定 | 最大预算仍未决 | 平均使用种子数 |
|---|---:|---:|---:|---:|
| 正态 | 16 | 121 | 4,863 | 9.867 |
| 配对 bootstrap | 143 | 222 | 4,635 | 9.642 |
| Empirical Bernstein | 0 | 0 | 5,000 | 10.000 |
| 配对 Hoeffding | 0 | 0 | 5,000 | 10.000 |
''')
    main_md=replace_section(main_md,'### 5.7.1 验证后选择 alpha 支出诊断','### 5.8 数据字典与分析单位','''### 5.7.1 验证后选择 alpha 支出诊断

四种有效 alpha 支出方案先由验证数据选择，再用新密封序列评价。在四类模拟场景、每类 2,000 次重复中，未观察到同时覆盖失败或错误优越性；所选方案的平均成本分别为 200.00、50.00、121.53 和 175.20，最佳固定方案为 200.00、50.00、119.88 和 173.98。该事后诊断没有稳定改善成本，不改变主研究设计，也不支持普遍效率结论。完整规格见补充材料 S9。
''')
    main_md=replace_section(main_md,'### 5.8 数据字典与分析单位','### 5.9 主研究结论的事后稳健性','''### 5.8 数据字典与分析单位

每行原始记录对应一个算法、任务、配置、数据划分和训练种子；检查点及评估回合先聚合为种子级指标。原始回报、归一化指标、评估种子基值、运行时间和状态均有字段记录。验证行用于配置选择，测试行只在选定配置冻结后用于比较，因此推断单位是完整训练运行，而不是评估回合或检查点。字段定义见补充材料 S3。
''')
    main_md=replace_section(main_md,'### 5.9 主研究结论的事后稳健性','### 5.10 队列环境的解析 oracle 与切换时刻检查','''### 5.9 主研究结论的事后稳健性

![图 6。验证种子从 5 个增加到 10 个时的选择稳定性；红色单元表示变化。](manuscript_figures/fig_tuning_stability.png)

![图 7。11 种归一化方案均为 15/15 未决；事后诊断。](manuscript_figures/fig_normalization_sensitivity.png)

在冻结主研究序列上改变实际边际、目标宽度和最大预算，所测试设置均为 15/15 `max_budget_inconclusive`；11 种替代归一化边界也得到相同决定。正态和 bootstrap 的部分决定属于未预注册诊断，未作为确认性结果。四个检查点的区间宽度中位数依次为 2.0000、2.0000、2.0000 和 1.9199，显示预算非分辨并非单一阈值设定造成。完整边界及区间敏感性矩阵见补充材料 S5。

配置选择对验证预算和候选网格敏感。相较早期两候选版本，扩展四候选网格在 15 个单元中的 6 个改变了选择；验证种子由 5 增至 10 时有 4/15 改变，由 5 增至 20 的独立扩展有 7/15 改变。已有 20,000 次联合行重采样中，主研究所选配置的重采样选择频率在 15 个单元为 0.3963–1.0000，完整选择频率和熵见补充材料 S5 表 S5-1。该频率描述五个已观测验证行的重采样敏感性，不是配置为全局最优的概率；5→10→20 的变化比例同样不是总体稳定概率。配置选择的不稳定限制对未见验证样本或候选网格的外推，但不改变命题 1–2 条件于验证数据及实际选定配置的覆盖陈述。\n''')
    main_md=replace_once(main_md,
        '族 alpha 为 0.05，每个比较分配 `0.05/15 = 0.0033333333333333335`。',
        '族 alpha 为 0.05，每个比较分配 `0.05/15 = 0.0033333333333333335`。15 项比较均在预注册中作为共同主要比较提出，且没有事先确定优先级或可信权重，因此采用透明的 Bonferroni 等额分配控制族错误率；等额分配不表示各比较具有相同科学重要性或实质等价。若新研究有事先论证的优先级，可在查看测试数据前预注册加权分配。')
    main_md=replace_once(main_md,
        '在固定任务族、训练预算、选定配置和测试种子的条件下，评估回合从五个增加到十个没有改变任何族级决定。',
        '在固定任务族、训练预算、选定配置和测试种子的条件下，评估回合从五个增加到十个没有改变任何族级决定。该变化只检验当前面板下的测量敏感性，不能据此认定五回合对其他任务或策略普遍充分。')
    main_md=replace_once(main_md,
        '## 9 主张—证据表',
        '## 9 主张—证据表\n\n本表区分三类证据：主研究是预注册确认性分析；V4/V5/V7 等新增种子分析是在固定任务面板上的扩展或事后分辨率诊断；模拟、区间替代、阈值和检查点重算是方法诊断。后两类可检验特定计算或已披露程序的敏感性，但不能替代新任务族抽样、独立团队复现或主研究预注册证据。本文没有完成 Atari/视觉输入、Montezuma 等稀疏奖励或 MuJoCo 等高维连续控制实验，因此不将这些环境写作本文的实证支持。')
    proposition_numbers={0:2,1:1,2:3,3:4}
    corollary_numbers={0:1,1:2,2:3,3:4,4:5,5:6}
    main_md=re.sub(r'命题\s+([0-3])',
                   lambda m:f'命题 {proposition_numbers[int(m.group(1))]}',main_md)
    main_md=re.sub(r'推论\s+([0-5])',
                   lambda m:f'推论 {corollary_numbers[int(m.group(1))]}',main_md)
    main_md=main_md.replace('。 多智能体任务', '。多智能体任务')
    main_md=re.sub(r'^\[L17\].*$',
                   '[L17] Patterson, A., Neumann, S., White, M., & White, A. (2024). Empirical design in reinforcement learning. *Journal of Machine Learning Research*, 25(318), 1–63. https://jmlr.org/papers/v25/23-0183.html.',
                   main_md,flags=re.M)
    main_md=main_md.replace('。 可直接运行', '。可直接运行')
    main_md=main_md.replace('范围内。 因而', '范围内。因此')
    main_md=main_md.replace('问题。 事后同预算', '问题。事后同预算')
    main_md=main_md.replace('和 大预算分辨成本扩展', '和大预算分辨成本扩展')
    main_md=re.sub(r'([。；，：]) +(?![A-Za-z0-9`$|])', r'\1', main_md)
    main_md=main_md.replace('并用命题 1、', '并用命题 1、')
    main_md=re.sub(r'^(\[L18\].*?) 全文核读版本：arXiv:1810\.08240v9（2022-08-06）。$', r'\1', main_md, flags=re.M)
    main_md=re.sub(r'观察到同时覆盖失败事件数范围为 [^，。]+，错误优越族事件数范围为 [^。]+。',
                   '所有方法—情景—计划单元均未观察到同时覆盖失败（0/10,000）或错误优越族事件（0/10,000）。',
                   main_md)
    main_md=number_references_by_first_citation(main_md)
    main_md,supp=revise_fourth_review(main_md,supp)
    main_md,supp=revise_fifth_review(main_md,supp)
    main_md,supp=revise_sixth_review(main_md,supp)
    paths=set(json.loads((BASE/'ROUND2_EDITORIAL_MANIFEST.json').read_text())['indexed_files'])
    paths.add('fourth_review_revision.py')
    paths.update(['fifth_review_revision.py','sixth_review_revision.py','round5_analysis/V5_V7_COMPARISON.json',
                  'round6_analysis/V7_METHOD_SUMMARY.json','round6_analysis/V5_V7_DEPENDENCE.json',
                  'round6_analysis/SCOPE_SEED_RANGES.json','round6_analysis/REGISTERED_DEPENDENCE_STRESS.json',
                  'sb3_formal_v1/raw_seed_metrics.csv','sb3_formal_v2/raw_seed_metrics.csv'])
    paths.update('round3_analysis/'+name for name in [
        'ANALYSIS_PLAN.md','ANALYSIS_MANIFEST.json','synthetic_calibration.json',
        'order_diagnostics.json','planning_sensitivity.json','threshold_scale.json',
        'environment_features.json','NETWORK_VERIFICATION_STATUS.md'])
    paths.update(['round3_diagnostics.py','test_round3_diagnostics.py','budget_calculator.py',
                  'test_budget_calculator.py','generate_round3_manuscript.py','generate_round3_figures.py',
                  'inventory_round3_environments.py','audit_formal_round3.py',
                  'ROUND3_REPRODUCTION_GUIDE_ZH.md','Makefile.review'])
    paths.update(['fulltext_literature_revision.py','KEY_LITERATURE_FULLTEXT_COMPARISON_ZH.md',
                  'literature_fulltext/RELATED_WORK_MAIN.md','literature_fulltext/COMPARISON_S1.md',
                  'literature_fulltext/2026-11-03/SOURCES.json'])
    paths.update(['modern_sequential_intervals.py','test_modern_sequential_intervals.py',
                  'run_modern_sequential_comparison.py','modern_comparison_manuscript.py',
                  'plot_modern_interval_comparison.py','requirements-sequential.txt',
                  'sequential_comparison_v1/ANALYSIS_PLAN.md','sequential_comparison_v1/INPUT_HASHES.json',
                  'sequential_comparison_v1/PLAN_LOCK.json',
                  'sequential_comparison_v1/results_v2/RUN_MANIFEST.json',
                  'sequential_comparison_v1/results_v2/real_intervals.csv',
                  'sequential_comparison_v1/results_v2/real_pair_decisions.csv',
                  'sequential_comparison_v1/results_v2/real_summary.json',
                  'sequential_comparison_v1/results_v2/simulation_summary.json',
                  'sequential_comparison_v1/RECOMPUTATION_AUDIT_V2.json',
                  'sequential_comparison_v1/RECOMPUTATION_AUDIT_V2.json',
                  'V7_PROSPECTIVE_VALIDATION_PLAN.md','V7_CONFIRMATION_LOCK.json',
                  'freeze_v7_confirmation.py','v7_confirmatory_runner.py',
                  'analyze_v7_confirmation.py','test_v7_confirmation_analysis.py',
                  'sb3_v7_confirmation/raw_seed_metrics.csv',
                  'sb3_v7_confirmation/run_config.json',
                  'sb3_v7_confirmation/analysis/intervals.csv',
                  'sb3_v7_confirmation/analysis/summary.json',
                  'sb3_v7_confirmation/analysis/ANALYSIS_MANIFEST.json',
                  'audit_v7_confirmation.py','V7_CONFIRMATION_AUDIT.json',
                  'verify_modern_sequential_rerun.py',
                  'KEY_LITERATURE_FULLTEXT_COMPARISON_ZH.md','FULLTEXT_COMPARISON_AUDIT.json',
                  'wheels/scipy-1.15.3-cp311-cp311-macosx_12_0_arm64.whl'])
    paths.update(str(p.relative_to(ROOT)) for p in (ROOT/'sequential_comparison_v1/results_v2').glob('replicate_outcomes_*.npz'))
    with (ANALYSIS/'SUPPLEMENT_FILE_MANIFEST.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['path','bytes','sha256','purpose'])
        for p in sorted(paths):
            file=ROOT/p
            if not file.is_file():raise FileNotFoundError(file)
            w.writerow([p,file.stat().st_size,hashlib.sha256(file.read_bytes()).hexdigest(),'round3 diagnostic/editorial' if p.startswith('round3_') else 'cited evidence or supporting source'])
    supp=supplement_index(supp,paths)
    for stem,md in [('MANUSCRIPT_FORMAL_ZH',main_md),('SUPPLEMENTARY_FORMAL_ZH',supp)]:
        (ROOT/f'{stem}.md').write_text(md,encoding='utf-8')
        build_docx(md,ROOT/f'{stem}.docx')
    report=ROOT/'KEY_LITERATURE_FULLTEXT_COMPARISON_ZH.md'
    build_docx(report.read_text(),report.with_suffix('.docx'))
    print('Wrote round-three Chinese manuscript and supplement (Word and Markdown).')


if __name__=='__main__':main()

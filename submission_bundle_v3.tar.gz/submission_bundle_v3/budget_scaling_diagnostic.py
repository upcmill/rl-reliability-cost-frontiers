#!/usr/bin/env python3
"""Run a fixed-configuration training-budget sensitivity diagnostic.

This diagnostic reuses the configurations selected by the sealed v3 protocol
and evaluates the same test training seeds at a larger budget.  It is kept
separate from the v3 primary analysis: no validation data or v3 decisions are
changed by this script.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
from itertools import combinations
from pathlib import Path

import gymnasium as gym
import importlib.metadata
import torch

from pilot_protocol import ProtocolConfig, sequential_decision
from sb3_pilot import ALGORITHMS, ADDITIONAL_ENV_IDS, DEFAULT_ENV_IDS, QUEUE_ENV_ID, train_curve
from sequential_sb3_runner_v3 import CONFIGS


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reference-dir",
        default="sb3_formal_v3",
        help="v3 directory containing summary.json and selected configurations",
    )
    parser.add_argument(
        "--environment-ids",
        default=",".join((*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)),
    )
    parser.add_argument("--test-seeds", type=int, default=20)
    parser.add_argument("--test-seed-base", type=int, default=20000)
    parser.add_argument("--timesteps", type=int, default=16384)
    parser.add_argument("--checkpoints", type=int, default=4)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--family-alpha", type=float, default=0.05)
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    parser.add_argument("--output-dir", default="sb3_budget_scaling_v3")
    args = parser.parse_args()
    args.environment_ids_resolved = tuple(x.strip() for x in args.environment_ids.split(",") if x.strip())
    supported = set((*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID))
    unsupported = sorted(set(args.environment_ids_resolved) - supported)
    if unsupported:
        parser.error(f"unsupported environment IDs: {', '.join(unsupported)}")
    if args.test_seeds < 1 or args.checkpoints < 1 or args.timesteps < args.checkpoints:
        parser.error("invalid test-seed, checkpoint, or timestep settings")
    if not 0 < args.family_alpha < 1:
        parser.error("family-alpha must be in (0, 1)")
    return args


def selected_config_ids(reference_dir: Path, environment_ids: tuple[str, ...]) -> dict[str, dict[str, str]]:
    payload = json.loads((reference_dir / "summary.json").read_text(encoding="utf-8"))
    selected: dict[str, dict[str, str]] = {}
    for env_id in environment_ids:
        selected[env_id] = {}
        for algorithm in ALGORITHMS:
            key = f"{env_id}:{algorithm}"
            if key not in payload["summary"]:
                raise KeyError(f"missing v3 summary cell: {key}")
            config_id = payload["summary"][key]["selected_config"]
            if config_id not in CONFIGS:
                raise KeyError(f"unknown configuration in v3 summary: {config_id}")
            selected[env_id][algorithm] = config_id
    return selected


def main() -> None:
    args = parse_args()
    env_ids = args.environment_ids_resolved
    reference_dir = Path(args.reference_dir)
    selected = selected_config_ids(reference_dir, env_ids)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = [args.timesteps * i // args.checkpoints for i in range(1, args.checkpoints + 1)]
    comparison_count = len(env_ids) * 3
    comparison_alpha = args.family_alpha / comparison_count
    protocol = ProtocolConfig(
        alpha=comparison_alpha,
        practical_margin=args.practical_margin,
        initial_seeds=min(5, args.test_seeds),
        batch_size=5,
        max_seeds=args.test_seeds,
        target_width=args.target_width,
        interval_method="hoeffding_unpaired",
        bootstrap_resamples=1000,
    )

    fields = [
        "env_id", "algorithm", "config_id", "split", "seed", "train_seed",
        "evaluation_seed_base", "metric_normalized", "metric_raw",
        "runtime_seconds", "status",
    ]
    records: list[dict] = []
    summary: dict[str, dict] = {}
    comparisons: list[dict] = []

    for env_id in env_ids:
        metrics = {algorithm: [] for algorithm in ALGORITHMS}
        curves = {algorithm: [] for algorithm in ALGORITHMS}
        for algorithm in ALGORITHMS:
            config_id = selected[env_id][algorithm]
            config = CONFIGS[config_id]
            for seed_offset in range(args.test_seeds):
                train_seed = args.test_seed_base + seed_offset
                result = train_curve(env_id, algorithm, train_seed, config, checkpoints, args.eval_episodes)
                metrics[algorithm].append(result["metric_normalized"])
                curves[algorithm].append({"seed": seed_offset, "train_seed": train_seed, **result})
                records.append({
                    "env_id": env_id,
                    "algorithm": algorithm,
                    "config_id": config_id,
                    "split": "test_budget_scaling",
                    "seed": seed_offset,
                    "train_seed": train_seed,
                    "evaluation_seed_base": result["evaluation_seed_base"],
                    "metric_normalized": result["metric_normalized"],
                    "metric_raw": result["metric_raw"],
                    "runtime_seconds": result["runtime_seconds"],
                    "status": "ok",
                })
            summary[f"{env_id}:{algorithm}"] = {
                "selected_config": config_id,
                "test_metrics": metrics[algorithm],
                "curves": curves[algorithm],
            }
        for algorithm_a, algorithm_b in combinations(ALGORITHMS, 2):
            comparison = f"{algorithm_a}_vs_{algorithm_b}"
            comparisons.append({
                "env_id": env_id,
                "comparison": comparison,
                "decision": sequential_decision(metrics[algorithm_a], metrics[algorithm_b], protocol),
            })

    try:
        sb3_version = importlib.metadata.version("stable-baselines3")
    except importlib.metadata.PackageNotFoundError:
        sb3_version = "unknown"
    payload = {
        "status": "supplementary_budget_scaling_diagnostic",
        "warning": "Exploratory fixed-configuration diagnostic; does not alter preregistered v3 analysis.",
        "reference_dir": str(reference_dir),
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "gymnasium": gym.__version__,
        "stable_baselines3": sb3_version,
        "mps_available": bool(torch.backends.mps.is_available()),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "run_config": {
            "environment_ids": list(env_ids),
            "test_seeds": args.test_seeds,
            "test_seed_base": args.test_seed_base,
            "timesteps": args.timesteps,
            "checkpoints": args.checkpoints,
            "checkpoints_resolved": checkpoints,
            "eval_episodes": args.eval_episodes,
            "family_alpha": args.family_alpha,
            "comparison_alpha": comparison_alpha,
            "execution_mode": "full_replay_fixed_v3_selection",
        },
        "selected_configurations": selected,
        "candidate_configs": CONFIGS,
        "protocol": vars(protocol),
        "summary": summary,
        "comparisons": comparisons,
    }
    with (output_dir / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    (output_dir / "summary.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    (output_dir / "run_config.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output_dir), "rows": len(records), "comparisons": len(comparisons)}, indent=2))


if __name__ == "__main__":
    main()

import unittest

from audit_reliability_cost_frontier import main


class ReliabilityCostFrontierTests(unittest.TestCase):
    def test_frontier_audit_runs(self):
        # The audit raises on any mismatch and is deterministic from stored rows.
        main()


if __name__ == "__main__":
    unittest.main()

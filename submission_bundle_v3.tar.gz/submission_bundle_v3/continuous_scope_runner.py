#!/usr/bin/env python3
"""Run the preregistered MountainCarContinuous-v0 scope supplement."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
import time
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
from stable_baselines3 import A2C, PPO

from pilot_protocol import ProtocolConfig, sequential_decision
from sequential_sb3_runner_v3 import CONFIGS, lock_resolved_decisions


ALGORITHMS = ("PPO", "A2C")
ENV_ID = "MountainCarContinuous-v0"
RAW_LOWER = -100.0
RAW_UPPER = 100.0


def make_model(algorithm: str, env, seed: int, config: dict):
    common = dict(seed=seed, env=env, verbose=0, device="cpu")
    if algorithm == "PPO":
        return PPO("MlpPolicy", n_steps=config["n_steps"], batch_size=config["batch_size"],
                   n_epochs=1, learning_rate=config["learning_rate"], **common)
    if algorithm == "A2C":
        return A2C("MlpPolicy", n_steps=config["n_steps"],
                   learning_rate=config["learning_rate"], **common)
    raise ValueError(algorithm)


def evaluate(model, seed: int, episodes: int) -> tuple[float, list[float]]:
    env = gym.make(ENV_ID)
    returns = []
    for episode in range(episodes):
        obs, _ = env.reset(seed=seed + episode)
        done = False
        total = 0.0
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            total += float(reward)
        returns.append(total)
    env.close()
    return float(np.mean(returns)), returns


def normalize(values: list[float]) -> list[float]:
    return [max(0.0, min(1.0, (value - RAW_LOWER) / (RAW_UPPER - RAW_LOWER))) for value in values]


def train_curve(algorithm: str, seed: int, config: dict, checkpoints: list[int], episodes: int) -> dict:
    env = gym.make(ENV_ID)
    model = make_model(algorithm, env, seed, config)
    raw, curves, evaluation_seeds = [], [], []
    trained = 0
    started = time.perf_counter()
    for checkpoint in checkpoints:
        model.learn(total_timesteps=checkpoint - trained, reset_num_timesteps=False)
        trained = checkpoint
        evaluation_seed = seed + 1_000_000 + checkpoint
        value, returns = evaluate(model, evaluation_seed, episodes)
        raw.append(value)
        curves.append(returns)
        evaluation_seeds.append(evaluation_seed)
    model.env.close()
    normalized = normalize(raw)
    return {
        "metric_normalized": float(np.mean(normalized)),
        "metric_raw": float(np.mean(raw)),
        "checkpoint_normalized": normalized,
        "checkpoint_raw": raw,
        "evaluation_seeds": evaluation_seeds,
        "evaluation_seed_base": seed + 1_000_000,
        "episode_returns": curves,
        "runtime_seconds": time.perf_counter() - started,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validation-seeds", type=int, default=5)
    parser.add_argument("--test-seeds", type=int, default=20)
    parser.add_argument("--initial-test-seeds", type=int, default=5)
    parser.add_argument("--test-batch-size", type=int, default=5)
    parser.add_argument("--timesteps", type=int, default=4096)
    parser.add_argument("--checkpoints", type=int, default=4)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--output-dir", default="sb3_continuous_mountaincar")
    args = parser.parse_args()
    checkpoints = [args.timesteps * i // args.checkpoints for i in range(1, args.checkpoints + 1)]
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    records, summary = [], {}
    for algorithm in ALGORITHMS:
        validation = {}
        for config_id, base_config in CONFIGS.items():
            values = []
            for seed_offset in range(args.validation_seeds):
                result = train_curve(algorithm, 10_000 + seed_offset, {**base_config}, checkpoints, args.eval_episodes)
                values.append(result["metric_normalized"])
                records.append({"algorithm": algorithm, "config_id": config_id, "split": "validation", "seed": seed_offset, "train_seed": 10_000 + seed_offset, **{k: result[k] for k in ("metric_normalized", "metric_raw", "runtime_seconds")}})
            validation[config_id] = values
        selected = max(CONFIGS, key=lambda key: sum(validation[key]) / len(validation[key]))
        summary[algorithm] = {"selected_config": selected, "validation": validation, "test_metrics": [], "curves": []}

    metrics = {algorithm: [] for algorithm in ALGORITHMS}
    locked, trace, final = {}, [], None
    for batch_start in range(0, args.test_seeds, args.test_batch_size):
        batch_end = min(args.test_seeds, batch_start + args.test_batch_size)
        for seed_offset in range(batch_start, batch_end):
            for algorithm in ALGORITHMS:
                selected = summary[algorithm]["selected_config"]
                result = train_curve(algorithm, 20_000 + seed_offset, {**CONFIGS[selected]}, checkpoints, args.eval_episodes)
                metrics[algorithm].append(result["metric_normalized"])
                summary[algorithm]["test_metrics"].append(result["metric_normalized"])
                summary[algorithm]["curves"].append({"seed": seed_offset, "train_seed": 20_000 + seed_offset, **result})
                records.append({"algorithm": algorithm, "config_id": selected, "split": "test", "seed": seed_offset, "train_seed": 20_000 + seed_offset, **{k: result[k] for k in ("metric_normalized", "metric_raw", "runtime_seconds")}})
        protocol = ProtocolConfig(alpha=0.05, practical_margin=0.05, initial_seeds=args.initial_test_seeds, batch_size=args.test_batch_size, max_seeds=batch_end, target_width=0.10, interval_method="hoeffding_unpaired")
        provisional = {"PPO_vs_A2C": sequential_decision(metrics["PPO"][:batch_end], metrics["A2C"][:batch_end], protocol)}
        current = lock_resolved_decisions(provisional, locked, batch_end)
        trace.append({"n": batch_end, "decisions": current})
        if locked or batch_end == args.test_seeds:
            final = current
            break

    payload = {
        "status": "continuous_scope_expansion_supplement",
        "warning": "Separate supplementary scope diagnostic; not pooled with v3 primary family or Pendulum-v1.",
        "environment_id": ENV_ID, "raw_bounds": [RAW_LOWER, RAW_UPPER],
        "algorithms": list(ALGORITHMS), "candidate_configs": CONFIGS,
        "python_version": platform.python_version(), "python_arch": platform.machine(),
        "platform": platform.platform(), "torch": torch.__version__,
        "gymnasium": gym.__version__, "stable_baselines3": importlib.metadata.version("stable-baselines3"),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "run_config": vars(args) | {"checkpoints_resolved": checkpoints, "interval_method": "hoeffding_unpaired", "comparison_alpha": 0.05},
        "summary": summary, "comparison": {"final": final, "stop_trace": trace},
    }
    fields = ["algorithm", "config_id", "split", "seed", "train_seed", "metric_normalized", "metric_raw", "runtime_seconds"]
    with (output / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(records)
    (output / "run_config.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    (output / "summary.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(output), "comparison": payload["comparison"], "selected": {a: summary[a]["selected_config"] for a in ALGORITHMS}}, indent=2))


if __name__ == "__main__":
    main()

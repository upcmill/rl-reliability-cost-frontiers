#!/usr/bin/env python3
"""Audit the data-derived validation tuning-cost summary."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    validation_rows = [row for row in rows if row["split"] == "validation" and row["status"] == "ok"]
    payload = json.loads((ROOT / "VALIDATION_TUNING_COST_V3.json").read_text(encoding="utf-8"))
    expected_total = sum(float(row["runtime_seconds"]) for row in validation_rows)
    algorithm_rows = payload.get("algorithm_summaries", [])
    counts_ok = sorted((row["algorithm"], row["n"]) for row in algorithm_rows) == [
        ("A2C", 100),
        ("DQN", 100),
        ("PPO", 100),
    ]
    status = (
        payload.get("status") == "descriptive_validation_tuning_cost_only"
        and payload.get("rows") == 300
        and len(validation_rows) == 300
        and len(algorithm_rows) == 3
        and counts_ok
        and math.isclose(expected_total, float(payload["total_seconds"]), rel_tol=0.0, abs_tol=1e-10)
    )
    print(json.dumps({"status": "PASS" if status else "FAIL", "rows": len(validation_rows), "algorithms": len(algorithm_rows), "total_matches_raw": math.isclose(expected_total, float(payload["total_seconds"]), rel_tol=0.0, abs_tol=1e-10)}, indent=2))
    if not status:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

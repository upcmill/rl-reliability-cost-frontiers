#!/usr/bin/env python3
"""Independent reproduction of one stored SB3 pilot environment.

This script intentionally does not import the main pilot runner. It reads the
stored configuration and reruns the selected test configurations for one
environment, then reports metric differences against the sealed run.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
from stable_baselines3 import A2C, DQN, PPO

from nonstationary_queue_env import ENV_ID as QUEUE_ENV_ID

def make_model(algorithm: str, env, seed: int, config: dict):
    common = dict(seed=seed, env=env, verbose=0, device="cpu")
    if algorithm == "PPO":
        return PPO(
            "MlpPolicy",
            n_steps=config["n_steps"],
            batch_size=config["batch_size"],
            n_epochs=1,
            learning_rate=config["learning_rate"],
            **common,
        )
    if algorithm == "DQN":
        return DQN(
            "MlpPolicy",
            buffer_size=config["buffer_size"],
            learning_starts=config["learning_starts"],
            batch_size=config["batch_size"],
            learning_rate=config["learning_rate"],
            train_freq=4,
            gradient_steps=1,
            **common,
        )
    if algorithm == "A2C":
        return A2C(
            "MlpPolicy",
            n_steps=config["n_steps"],
            learning_rate=config["learning_rate"],
            **common,
        )
    raise ValueError(f"unknown algorithm: {algorithm}")


def evaluate(model, env_id: str, seed: int, episodes: int) -> float:
    env = gym.make(env_id)
    returns = []
    for episode in range(episodes):
        obs, _ = env.reset(seed=seed + episode)
        done = False
        total = 0.0
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            if isinstance(action, np.ndarray) and action.size == 1:
                action = action.item()
            obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            total += float(reward)
        returns.append(total)
    env.close()
    return float(np.mean(returns))


def normalize_returns(env_id: str, values: list[float]) -> list[float]:
    if env_id == "CartPole-v1":
        lower, upper = 0.0, 500.0
    elif env_id == "Acrobot-v1":
        lower, upper = -500.0, 0.0
    elif env_id == QUEUE_ENV_ID:
        lower, upper = -200.0 * 10.25, 0.0
    elif env_id == "MountainCar-v0":
        lower, upper = -200.0, 0.0
    elif env_id == "Taxi-v4":
        lower, upper = -2000.0, 20.0
    else:
        raise ValueError(f"no normalization bounds registered for {env_id}")
    return [max(0.0, min(1.0, (value - lower) / (upper - lower))) for value in values]


def reproduce_curve(
    env_id: str,
    algorithm: str,
    train_seed: int,
    config: dict,
    checkpoints: list[int],
    eval_episodes: int,
) -> dict:
    env = gym.make(env_id)
    model = make_model(algorithm, env, train_seed, config)
    values = []
    evaluation_seeds = []
    trained = 0
    for checkpoint in checkpoints:
        model.learn(total_timesteps=checkpoint - trained, reset_num_timesteps=False)
        trained = checkpoint
        evaluation_seed = train_seed + 1_000_000 + checkpoint
        values.append(evaluate(model, env_id, evaluation_seed, eval_episodes))
        evaluation_seeds.append(evaluation_seed)
    model.env.close()
    normalized = normalize_returns(env_id, values)
    return {
        "metric_normalized": float(np.mean(normalized)),
        "metric_raw": float(np.mean(values)),
        "checkpoint_normalized": normalized,
        "checkpoint_raw": values,
        "evaluation_seeds": evaluation_seeds,
        "evaluation_seed_base": train_seed + 1_000_000,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-dir", default="sb3_pilot_results_round4")
    parser.add_argument("--env-id", default="CartPole-v1")
    parser.add_argument("--output", default="sb3_pilot_results_round4/independent_reproduction.json")
    args = parser.parse_args()

    reference_dir = Path(args.reference_dir)
    reference = json.loads((reference_dir / "summary.json").read_text(encoding="utf-8"))
    run_config = reference["run_config"]
    checkpoints = run_config["checkpoints_resolved"]
    eval_episodes = run_config["eval_episodes"]
    rows = []
    algorithms = tuple(reference.get("algorithm_ids", ("PPO", "DQN")))
    for algorithm in algorithms:
        selected = reference["summary"][f"{args.env_id}:{algorithm}"]["selected_config"]
        config = reference["candidate_configs"][selected]
        stored = reference["summary"][f"{args.env_id}:{algorithm}"]["test_metrics"]
        reproduced = []
        for seed in range(run_config["test_seeds"]):
            result = reproduce_curve(
                args.env_id,
                algorithm,
                20_000 + seed,
                config,
                checkpoints,
                eval_episodes,
            )
            reproduced.append(result)
            rows.append({"algorithm": algorithm, "seed": seed, **result})
        stored_mean = float(np.mean(stored))
        reproduced_metrics = [row["metric_normalized"] for row in reproduced]
        rows.append({
            "algorithm": algorithm,
            "summary": True,
            "selected_config": selected,
            "stored_mean": stored_mean,
            "reproduced_mean": float(np.mean(reproduced_metrics)),
            "mean_absolute_metric_difference": float(np.mean(np.abs(np.asarray(reproduced_metrics) - np.asarray(stored)))),
        })

    payload = {
        "status": "independent_reproduction_only",
        "warning": "One-environment reproduction; no publication claim.",
        "environment": args.env_id,
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "torch": torch.__version__,
        "reference_script_sha256": reference.get("script_sha256"),
        "reproduction_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "rows": rows,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

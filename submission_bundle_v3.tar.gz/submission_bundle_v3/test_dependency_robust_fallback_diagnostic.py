import random
import unittest

from dependency_robust_fallback_diagnostic import (
    block_sequence,
    complete_block_means,
    run_condition,
)


class DependencyRobustFallbackTests(unittest.TestCase):
    def test_complete_block_means_discard_partial_trailing_block(self):
        values = block_sequence(random.Random(7), 4, 20)
        means = complete_block_means(values, 4, 10)
        self.assertEqual(len(means), 2)
        self.assertTrue(all(0.0 <= value <= 1.0 for value in means))

    def test_condition_is_deterministic_and_reports_effective_blocks(self):
        first = run_condition(5, 20, 99)
        second = run_condition(5, 20, 99)
        self.assertEqual(first, second)
        self.assertEqual(first["effective_blocks_by_look"], [10, 20, 30, 40])
        self.assertGreaterEqual(first["known_block_fallback"]["simultaneous_coverage"], 0.0)
        self.assertLessEqual(first["known_block_fallback"]["simultaneous_coverage"], 1.0)


if __name__ == "__main__":
    unittest.main()

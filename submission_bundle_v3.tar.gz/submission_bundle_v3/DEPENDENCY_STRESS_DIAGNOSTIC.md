# Seed-Dependence Stress Diagnostic

This supplementary Monte Carlo diagnostic probes the within-algorithm
seed-independence assumption used by the finite-look Hoeffding interval.
Each arm is a block-correlated Bernoulli sequence with marginal mean
0.5; the two arms are generated independently and the true difference is
zero. Block size 1 is the independent reference. This is a controlled
assumption stress test, not an RL result and not evidence of external
reproducibility.

- Replicates per condition: `5000`
- Looks: `[50, 100, 150, 200]`; alpha: `0.05`
- Practical margin: `0.1`; true difference: `0.0`

## Results

| Block size | Effective blocks at n=200 | Simultaneous coverage | 95% Wilson interval | False-superiority rate | 95% Wilson interval | Mean terminal seeds |
|---:|---:|---:|---|---:|---|---:|
| 1 | 200 | 1.0000 | [0.9992, 1.0000] | 0.0000 | [0.0000, 0.0008] | 200.00 |
| 2 | 100 | 0.9980 | [0.9963, 0.9989] | 0.0000 | [0.0000, 0.0008] | 200.00 |
| 5 | 40 | 0.9304 | [0.9230, 0.9371] | 0.0162 | [0.0131, 0.0201] | 197.74 |
| 10 | 20 | 0.7552 | [0.7431, 0.7669] | 0.1414 | [0.1320, 0.1513] | 180.91 |
| 20 | 10 | 0.4752 | [0.4614, 0.4891] | 0.3328 | [0.3199, 0.3460] | 159.16 |
| 50 | 4 | 0.1244 | [0.1155, 0.1338] | 0.7756 | [0.7638, 0.7869] | 101.67 |

The independent reference is a calibration condition, not a proof of
the theorem. Increasing block size reduces the effective number of
independent observations while the nominal radius still uses n=200.
Coverage loss and false-superiority decisions therefore illustrate why
the theorem must remain conditional on the seed-independence assumption.
The diagnostic does not estimate the dependence structure of any RL
environment and does not provide a correction for dependent training
runs.

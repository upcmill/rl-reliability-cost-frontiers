#!/usr/bin/env python3
"""Audit the actual round-two formal artifacts, not the legacy bilingual drafts."""
from __future__ import annotations

import ast
import csv
import hashlib
import itertools
import json
import math
import re
import statistics
from pathlib import Path

from docx import Document

import generate_machine_learning_word as formatter
from reference_sequential_interval import alpha_spend, decide, unpaired_hoeffding_interval

ROOT = Path(__file__).resolve().parent


def tables(markdown):
    return [m[0].strip() for m in re.finditer(r'^\|[^\n]*(?:\n\|[^\n]*)*', markdown, re.M)]


def numbers(text):
    text = re.sub(r'\bS\d+(?:[.-]\d+)*', '', text)
    return re.findall(r'(?<![A-Za-z])[-−]?\d+(?:[.,]\d+)*', text)


def verify_shared_content(stem):
    md = (ROOT / f'{stem}.md').read_text()
    doc = Document(ROOT / f'{stem}.docx')
    parsed = [formatter.parse_table(t.splitlines()) for t in tables(md)]
    expected_tables = [[header, *rows] for header, rows in parsed]
    actual_tables = [[[c.text for c in row.cells] for row in t.rows] for t in doc.tables]
    assert actual_tables == expected_tables, f'{stem}: Word table content differs'
    expected_paragraphs = []
    display_equations = []
    images = []
    lines = md.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        i += 1
        line = line.strip()
        if not line or line.startswith('|'): continue
        if line.startswith('```'): continue
        if line == r'\[':
            equation = []
            while i < len(lines) and lines[i].strip() != r'\]':
                equation.append(lines[i].strip())
                i += 1
            assert i < len(lines), f'{stem}: unclosed display equation'
            i += 1
            display_equations.append(len(expected_paragraphs))
            expected_paragraphs.append(formatter.clean_inline(' '.join(equation)))
            continue
        if line.startswith('!['):
            caption, path = re.fullmatch(r'!\[(.*?)\]\((.*?)\)', line).groups()
            expected_paragraphs.append(caption)
            images.append(path)
            assert (ROOT / path).is_file()
            continue
        if line.startswith('#'):
            expected_paragraphs.append(line.lstrip('# '))
            continue
        if line.startswith('- '): line = line[2:]
        expected_paragraphs.append(formatter.clean_inline(line))
    actual_paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    assert expected_paragraphs == actual_paragraphs, f'{stem}: paragraphs missing or changed'
    nonempty_doc_paragraphs = [p for p in doc.paragraphs if p.text.strip()]
    for index in display_equations:
        assert nonempty_doc_paragraphs[index].alignment == 1, f'{stem}: display equation is not centered'
    assert len(doc.inline_shapes) == len(images)
    return {'tables': len(doc.tables), 'images': len(images),
            'nonempty_paragraphs': len(actual_paragraphs), 'markdown_word_text_and_tables_match': True}


def rows(path):
    with (ROOT / path).open(newline='') as f:
        return list(csv.DictReader(f))


def queue(rows_, n):
    result = {}
    for algo in ('DQN', 'A2C'):
        subset = sorted([r for r in rows_ if r['env_id'] == 'NonstationaryQueue-v0'
                         and r['algorithm'] == algo and r['split'] != 'validation'],
                        key=lambda r: int(r['train_seed']))[:n]
        assert len(subset) == n
        result[algo] = [float(r['metric_normalized']) for r in subset]
    return result


def main():
    main_md = (ROOT / 'MANUSCRIPT_FORMAL_ZH.md').read_text()
    supp_md = (ROOT / 'SUPPLEMENTARY_FORMAL_ZH.md').read_text()
    manifest = json.loads((ROOT / 'ROUND2_EDITORIAL_MANIFEST.json').read_text())
    report = {'scope': 'actual MANUSCRIPT_FORMAL_ZH and SUPPLEMENTARY_FORMAL_ZH; local artifact checks only'}
    report['main'] = verify_shared_content('MANUSCRIPT_FORMAL_ZH')
    report['supplement'] = verify_shared_content('SUPPLEMENTARY_FORMAL_ZH')
    assert report['main']['tables'] == 22
    assert report['main']['images'] == 14
    assert [int(n) for n in re.findall(r'^\*\*表 (\d+)。', main_md, re.M)] == list(range(1, 23))
    assert [int(n) for n in re.findall(r'^!\[图 (\d+)。', main_md, re.M)] == list(range(1, 15))
    for appendix in ('A', 'B', 'C'):
        assert len(re.findall(rf'^## 附录 {appendix}。', main_md, re.M)) == 1
    assert not re.search(r'补充材料(?! S\d)', main_md)
    available_sections = set(re.findall(r'^## (S\d+) ', supp_md, re.M))
    for sid in re.findall(r'补充材料 (S\d+)', main_md): assert sid in available_sections
    for sid in re.findall(r'表 (S\d+-\d+)', main_md): assert f'**表 {sid}。' in supp_md
    assert 'arXiv:1804.06893v2' in main_md and 'arXiv:1912.05663v2' in main_md
    assert 'https://jmlr.org/papers/v22/20-1364.html' in main_md
    assert not re.search(r'(?:https?://\S*|arXiv:\S*)早期诊断', main_md)
    old = (ROOT / 'revision_history/round1_before_round2/MANUSCRIPT_FORMAL_ZH.md').read_text()
    old_tables, new_tables = tables(old), tables(main_md)
    for item in manifest['moved_tables']:
        assert item['table_markdown'] in supp_md
        assert numbers(old_tables[item['original_table']-1]) == numbers(item['table_markdown'])
    # Check numeric tokens of retained tables, excluding rewritten literature and inserted overview.
    moved_indices = {entry['original_table'] for entry in manifest['moved_tables']}
    new_without_scope = new_tables[:7] + new_tables[8:]
    for (old_index, old_table), new_table in zip(
            [(i, t) for i, t in enumerate(old_tables, 1) if i not in moved_indices], new_without_scope):
        if old_index == 2: continue
        assert numbers(old_table) == numbers(new_table), f'Table {old_index}: numeric change'
    report['transferred_tables'] = [x['supplement_table'] for x in manifest['moved_tables']]
    report['retained_and_transferred_table_numbers_preserved'] = True
    for path in manifest['indexed_files']:
        assert (ROOT / path).is_file(), path
        assert f'`{path}`' in supp_md
    report['existing_indexed_files'] = len(manifest['indexed_files'])

    tree = ast.parse((ROOT / 'generate_machine_learning_word.py').read_text())
    source = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'CN_MARKDOWN' for t in n.targets))
    source_references = re.findall(r'^\[L\d+\].*$', source, re.M)
    references = re.findall(r'^\[L\d+\].*$', main_md, re.M)
    normalized = [r.replace(' 最终期刊信息[待核实]。', '').replace(' Full-text method comparison [待核实].', '')
                  for r in source_references]
    assert references == normalized
    assert len(references) == 16
    verification = (ROOT / 'LITERATURE_VERIFICATION.md').read_text()
    for ref in references:
        for doi in re.findall(r'DOI: (\S+)', ref):
            assert doi.rstrip('.') in verification
        for arxiv_id in re.findall(r'arXiv:(\d+\.\d+(?:v\d+)?)', ref):
            assert arxiv_id in verification
    body = main_md.split('## 参考文献')[0]
    citations = set()
    for group in re.findall(r'\[(L\d+(?:\s*,\s*L\d+)*)\]', body):
        citations.update(map(int, re.findall(r'L(\d+)', group)))
    assert citations == set(range(1, 17)), citations
    report['references'] = {'count': 16, 'all_cited_in_body': True,
                            'match_local_verified_source': True,
                            'new_full_text_or_online_verification': False}

    raw = rows('sb3_formal_v3/raw_seed_metrics.csv')
    assert len(raw) == 600 and all(r['status'] == 'ok' for r in raw)
    cost = {s: math.fsum(float(r['runtime_seconds']) for r in raw if r['split'] == s)
            for s in ('validation', 'test')}
    assert all(math.isclose(cost[s], manifest['runtime_seconds'][s]) for s in cost)
    assert f'{sum(cost.values())/3600:.3f} 小时' in main_md
    report['recomputed_primary_cost'] = dict(cost, total_hours=sum(cost.values())/3600)
    comp_alpha = .05/15
    radius = lambda n, k: 2*math.sqrt(math.log(4/alpha_spend(comp_alpha, k))/(2*n))
    old_q = queue(raw, 20)
    new_q = queue(rows('sb3_v4_extension/raw_seed_metrics.csv'), 200)
    old_difference = statistics.mean(old_q['DQN']) - statistics.mean(old_q['A2C'])
    estimate, lower, upper = unpaired_hoeffding_interval(new_q['DQN'], new_q['A2C'], alpha_spend(comp_alpha, 1))
    diagnostic = {'new_difference': estimate, 'new_lower': lower, 'new_upper': upper,
                  'new_radius': radius(200, 1), 'new_threshold': .05+radius(200, 1),
                  'old_difference': old_difference, 'old_difference_with_new_radius': old_difference-radius(200, 1),
                  'hypothetical_30_seed_fifth_look_radius': radius(30, 5)}
    for key, val in diagnostic.items():
        assert f'{val:.6f}' in main_md, (key, val)
    assert lower > .05 and old_difference-radius(200, 1) < .05
    report['queue_and_hypothetical_budget_recomputed'] = diagnostic
    report['normalization_threshold_conversions'] = {
        task: {'m_raw': width*.05, 'w_raw': width*.10}
        for task, width in [('CartPole', 500), ('Acrobot', 500), ('MountainCar', 200), ('Taxi', 2020), ('Queue', 2050)]}
    sensitivity = json.loads((ROOT / 'margin_sensitivity_v3.json').read_text())
    test = [r for r in raw if r['split'] == 'test']
    for entry in sensitivity['rows']:
        m = entry['margin']
        for k in range(1, 5):
            expected = math.floor(2*math.log(4/alpha_spend(comp_alpha, k))/(1-m)**2)+1
            assert expected == entry['necessary_seeds_for_possible_superiority'][str(k)]
        unresolved = 0
        for env in sorted({r['env_id'] for r in test}):
            samples = {a: [float(r['metric_normalized']) for r in sorted(test, key=lambda r: int(r['seed']))
                           if r['env_id'] == env and r['algorithm'] == a]
                       for a in ('PPO', 'DQN', 'A2C')}
            for a, b in itertools.combinations(samples, 2):
                stopped = False
                for k, n in enumerate((5, 10, 15, 20), 1):
                    _, lo, hi = unpaired_hoeffding_interval(samples[a][:n], samples[b][:n], alpha_spend(comp_alpha, k))
                    if decide(lo, hi, m, .10) != 'continue': stopped = True; break
                if not stopped: unresolved += 1
        assert unresolved == 15 == entry['observed_v3_decision_counts_at_target_width_0.10']['max_budget_inconclusive']
    report['margin_plot_source_recomputed_from_raw'] = True
    paths = ['MANUSCRIPT_FORMAL_ZH.md', 'MANUSCRIPT_FORMAL_ZH.docx',
             'SUPPLEMENTARY_FORMAL_ZH.md', 'SUPPLEMENTARY_FORMAL_ZH.docx',
             'sb3_formal_v3/raw_seed_metrics.csv', 'sb3_v4_extension/raw_seed_metrics.csv',
             'margin_sensitivity_v3.json', 'FINAL_PREREGISTRATION_V3.md']
    report['sha256'] = {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
    report['limitations'] = ['Word text/tables/images checked structurally; full pagination not visually rendered.',
                            'No new full-text literature verification or repository/DOI availability verification.',
                            'Author declarations remain pending confirmation; English draft not regenerated.']
    report['status'] = 'PASS'
    (ROOT / 'FORMAL_ROUND2_AUDIT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('sha256',)}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

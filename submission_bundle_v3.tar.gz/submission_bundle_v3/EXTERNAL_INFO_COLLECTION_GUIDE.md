# 投稿信息获取与归档指南

作者信息保留 `[待补充]` 是允许的，但投稿前必须由作者本人确认。以下
信息不能由工作区或 Codex 推断，必须从权威平台、作者所在机构或独立筛选
者处取得。

## 1. 公开代码和数据归档

推荐流程是 GitHub 代码仓库加 Zenodo DOI。也可以使用机构仓储、OSF 或
Figshare，但必须获得一个无需登录即可访问的永久 URL 或 DOI。

### 需要准备的内容

- 源代码、预注册文件、锁定依赖和复现说明；
- `sb3_formal_v3/raw_seed_metrics.csv` 及外部 Windows 复跑原始 CSV；
- JSON 汇总、审计报告、源文件哈希和提交包哈希；
- `README`、引用方式、版本号和发布日期；
- 许可证文件，例如代码许可证和数据/文档许可证；
- 删除本地路径、账号、密钥和不应公开的日志信息。

### 推荐操作

1. 在 GitHub 创建私有或公开仓库，先检查是否包含密钥和机器私有路径。
2. 将当前提交包解压到仓库，补充 `LICENSE` 和引用说明。
3. 创建不可变 release/tag，例如 `v3.0.0`。
4. 在 Zenodo 中连接该 GitHub 仓库并发布 release，获得 DOI。
5. 用浏览器的无登录窗口检查 DOI/URL 可以访问，并下载一次归档。
6. 计算下载归档的 SHA-256，与 `submission_bundle_v3.tar.gz.sha256` 比较。
7. 将 DOI、URL、release/tag、许可证和归档 SHA-256 填入
   `SUBMISSION_METADATA_TEMPLATE.md`。

不要把本地 `submission_bundle_v3.tar.gz` 称为公开归档；本地文件只有在
外部平台发布后才满足这一门槛。

## 2. 独立文献筛选

当前工作区已有 OpenAlex、Crossref 和 arXiv 的发现记录，但这不等于完整
系统检索。建议通过学校图书馆或机构账号取得以下数据库导出：

| 数据库 | 需要保存的资料 |
|---|---|
| Web of Science | 检索式、日期、筛选条件、结果数、完整 RIS/CSV 导出 |
| Scopus | 检索式、日期、筛选条件、结果数、完整 CSV/RIS/BibTeX 导出 |
| IEEE Xplore | 检索式、日期、结果数、导出记录和 DOI |
| ACM Digital Library | 检索式、日期、结果数、BibTeX/CSV 导出 |
| Google Scholar | 检索式、日期、结果页记录；遵守平台导出和访问限制 |

每次导出应保存到新的日期目录，例如
`literature_search_raw/2026-11-01_external_screening/`，并记录：

- 数据库名称和网址；
- 检索日期和时区；
- 完整检索式；
- 时间范围、语言和文献类型过滤器；
- 返回记录数；
- 原始导出文件 SHA-256；
- 去重规则和去重后记录数。

### 第二筛选者

第二位研究者应在看到第一位的决定前，独立对去重后的标题/摘要记录标记：

```text
include / exclude / uncertain
reason_code:
direct_method_overlap / RL_reliability / sequential_inference /
reproducibility / application_only / not_relevant / full_text_needed
```

双方完成后再进行冲突仲裁。需要归档：

- 第一筛选者表；
- 第二筛选者表；
- 冲突清单；
- 仲裁决定和规则；
- 最终纳入/排除表；
- DOI、标题和去重键。

在这些资料完成前，论文中的“首次提出”“文献中没有类似方法”等句子必须
保留 `[待核实]`，只能使用当前已验证的窄范围表述。

## 3. 期刊官方信息

投稿前从 Springer 的 _Machine Learning_ 官方 journal page 和 submission
guidelines 页面核对：

- 当前文章类型和字数/格式要求；
- Data Availability Statement 要求；
- 代码、数据和补充材料政策；
- APC 和 Open Choice 条款；
- 当前 SCI/SCIE 收录状态和 JCR 信息；
- 投稿系统要求的作者贡献、基金、利益冲突和伦理声明。

保存网页 PDF 或 HTML、访问日期和 URL。JCR 和 Web of Science 信息优先从
机构订阅页面或 Clarivate 官方页面取得，不要引用第三方排名网站。

## 4. 作者与声明字段

这些字段必须由作者提供：

- 姓名、单位、通讯邮箱、ORCID；
- CRediT 贡献角色；
- 基金名称、项目编号和资助机构；
- 利益冲突声明；
- 代码/数据许可证；
- 通讯作者确认的 Data Availability Statement。

如果某字段确实不适用，应由作者明确写出 `Not applicable`，不要由代理人
猜测。当前模板见 `SUBMISSION_METADATA_TEMPLATE.md`。

## 5. 外部复跑身份记录

不同机器复跑已经通过审计，但返回材料没有独立核验操作者的机构身份。若
希望把证据表述为“独立团队复现”，还需要操作者提供：

- 姓名或团队标识；
- 单位和联系方式；
- 与原作者的关系声明；
- 复跑日期、机器和环境元数据；
- “未访问参考结果目录”的声明。

在此之前，论文应使用“不同机器复现冻结协议”这一较窄表述，不应写成
“独立团队完成科学结论复制”。

## 6. 归档后的回填位置

获得信息后，按以下位置回填：

| 信息 | 回填文件 |
|---|---|
| DOI/公开 URL/许可证 | `SUBMISSION_METADATA_TEMPLATE.md`、声明部分、README、出版包索引 |
| 数据库导出和筛选结果 | `LITERATURE_SEARCH_LOG.md`、`LITERATURE_SCREENING_TABLE.md` |
| 期刊政策和指标 | `JOURNAL_SELECTION_MEMO.md`、投稿信和检查清单 |
| 作者与声明 | `SUBMISSION_METADATA_TEMPLATE.md`、中英文稿、Word 稿 |
| 外部操作者信息 | `复跑结果/EXTERNAL_RERUN_AUDIT.md` 和元数据模板 |

回填后重新运行 `submission_readiness_audit.py`、Word 对齐审计和提交包构建
脚本，并记录新的提交包 SHA-256。

## 7. 可直接使用的公开存档模板

`PUBLIC_DEPOSITION_README.md` 说明归档范围、证据边界和发布前的待补字段；
`CITATION_CFF_TEMPLATE.yml` 是可复制到公开代码仓库的 Citation File
Format 模板。两者中的作者、DOI、URL、日期和许可证均为 `[待补充]`，只有
在作者或仓库平台确认后才能回填。


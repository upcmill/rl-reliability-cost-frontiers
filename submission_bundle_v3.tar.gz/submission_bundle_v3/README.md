# RL Evaluation Protocol: Formal v3 Package

This directory contains a staged RL evaluation study. The current primary
candidate is the preregistered formal v3 expanded-grid study. Earlier pilot,
v1, and v2 artifacts remain available for audit and are not pooled with v3.

The prototype is intentionally standard-library-only. It tests the decision
logic and exposes failure modes before adding Gymnasium or Stable-Baselines3.
The normal-approximation interval in `pilot_protocol.py` is **not** the final
statistical method for a paper; the production protocol must use a
pre-registered confidence sequence or another method with a documented
coverage argument.

Run the unit checks:

```bash
./.rl-arm64-venv/bin/python -m unittest -v
```

Run the statistical pilot:

```bash
python3 pilot_protocol.py --replicates 1000 --output pilot_results.json
```

To inspect a paired bootstrap candidate:

```bash
python3 pilot_protocol.py --interval-method bootstrap --bootstrap-resamples 500 --replicates 1000 --output pilot_bootstrap_results.json
```

To inspect a conservative bounded-data candidate:

```bash
python3 pilot_protocol.py --interval-method empirical_bernstein --replicates 1000 --output pilot_eb_results.json
```

Run the joint-coverage simulation:

```bash
python3 coverage_simulation.py --replicates 500 --output coverage_results.json
```

Budget and precision can be scanned without editing code, for example:

```bash
python3 pilot_protocol.py --interval-method empirical_bernstein --initial-seeds 10 --batch-size 10 --max-seeds 200 --target-width 0.10 --replicates 1000 --output pilot_eb_200.json
```

The pilot compares a fixed maximum-seed protocol with a sequential protocol
under normal, heavy-tailed, heteroscedastic, and mixture score distributions.
It reports false-superiority rates and the number of seeds used. The normal
interval is an efficiency baseline, the bootstrap interval is a resampling
baseline, and the empirical-Bernstein interval is a conservative candidate
whose exact sequential coverage still needs a formal proof. None of these
pilot outputs claim anything about RL algorithms until the same protocol is
connected to fixed-budget RL runs.

Run the dependency-free tabular RL smoke test:

```bash
python3 rl_pilot.py --seeds 20 --episodes 300 --output rl_pilot_results.json
```

This only verifies the data path from actual seeded learning runs into the
protocol. It is explicitly not a benchmark result for the proposed paper.

Run the train/validation/test matrix pilot:

```bash
python3 matrix_runner.py --validation-seeds 5 --test-seeds 20 --output-dir matrix_results
```

The matrix searches a small pre-declared set of four configurations on
validation seeds, then evaluates only the selected configuration on disjoint
test seeds. It writes `summary.json` plus one raw row per seed/configuration to
`raw_seed_metrics.csv`. This is still a tabular pilot; the final study must
expand the environment suite and freeze the statistical method before making
publication claims.

Run the real Gymnasium/Stable-Baselines3 pilot with the current protocol:

```bash
./.rl-arm64-venv/bin/python sb3_pilot.py \
  --validation-seeds 5 --test-seeds 10 --initial-test-seeds 5 \
  --test-batch-size 5 --timesteps 4096 --checkpoints 4 \
  --eval-episodes 5 --interval-method hoeffding \
  --output-dir sb3_pilot_results_round4
```

Reproduce CartPole using the separate runner and compare every stored test
metric:

```bash
./.rl-arm64-venv/bin/python independent_reproduction.py \
  --reference-dir sb3_pilot_results_round4 --env-id CartPole-v1
```

The SB3 run and independent reproduction remain pilot evidence only.

`sb3_pilot.py` is a complete sealed-test replay: it trains all requested test
seeds and then recomputes the stopping decision, so its seed count is not an
observed compute saving. To measure actual sequential execution cost, use:

```bash
./.rl-arm64-venv/bin/python sequential_sb3_runner.py \
  --environment-ids CartPole-v1 \
  --validation-seeds 5 --test-seeds 10 --initial-test-seeds 5 \
  --test-batch-size 5 --timesteps 4096 --checkpoints 4 \
  --eval-episodes 5 --family-alpha 0.05 \
  --interval-method normal --output-dir sb3_sequential_results
```

This runner trains and evaluates both algorithms batch by batch and records a
`stop_trace`; normal/bootstrap stopping is diagnostic and does not have the
formal arbitrary-distribution guarantee of `hoeffding_unpaired`.

The current paper structure, claim-evidence mapping, and reviewer self-check
are in `MANUSCRIPT_DRAFT_V3.md`, `CLAIM_EVIDENCE_MATRIX.md`, and
`REVIEWER_SELF_AUDIT_V3.md`.

The controlled nonstationary task is documented in `RL_ENVIRONMENT.md`; its
implementation and tests are `nonstationary_queue_env.py` and
`test_nonstationary_queue.py`.

The strict v3 reviewer audit is in `REVIEWER_SELF_AUDIT_V3.md`. It records the
main rejection risks, required strengthening experiments, and the current
weakest evidence-chain link.

The frozen formal protocol is `FINAL_PREREGISTRATION.md`. The corresponding
three-environment, three-algorithm execution is in `sb3_formal_v1/`.

The formal v1 results and limitations are summarized in `FORMAL_V1_REPORT.md`.

The verified literature boundary is recorded in `LITERATURE_VERIFICATION.md`.
The screened-candidate decisions are recorded in
`LITERATURE_SCREENING_TABLE.md`; this is an audit record, not an exhaustive
systematic review.
The exact formal runtime, archived wheel hashes, code hashes, and reproduction
commands are recorded in `REPRODUCTION_MANIFEST.md`.
The corresponding audited BibTeX entries are in `REFERENCES_VERIFIED.bib`.
The current evidence-bounded manuscript draft is `MANUSCRIPT_DRAFT_PILOT.md`.
The formula, implementation, coverage, and limitation audit is
`METHOD_AUDIT.md`.
The prioritized path from pilot to submission is `SUBMISSION_GAP_PLAN.md`.
The v2 formal report, manuscript, manifest, and reviewer audit remain archived
`FORMAL_V2_REPORT.md`, `MANUSCRIPT_DRAFT_V2.md`,
`REPRODUCTION_MANIFEST_V2.md`, and `REVIEWER_SELF_AUDIT_V2.md`.
The v3 formal report and package index are `FORMAL_V3_REPORT.md` and
`PUBLICATION_PACKAGE_INDEX.md`.
The expanded tuning sensitivity is documented in `TUNING_STRENGTH_REPORT.md`.

The prospective twenty-validation-seed tuning extension is documented in
`FINAL_PREREGISTRATION_TUNING_EXTENSION_V1.md` and audited by
`audit_tuning_stability_v20.py`. It uses validation seeds 11000--11019 and
changes 7/15 selections relative to v3. This is supplementary evidence of
selection sensitivity, not a universal twenty-seed rule or a replacement for
the v3 primary estimand.

Monte Carlo uncertainty intervals for the coverage and tradeoff simulations
are stored in `coverage_results_round2_with_mc_ci.json` and
`unpaired_tradeoff_results_round1_with_mc_ci.json`.

The statistical and pairing audit is documented in `STATISTICAL_AUDIT_V3.md`.
The paired-sequence sensitivity analysis can be reproduced with:

```bash
./.rl-arm64-venv/bin/python pairing_sensitivity.py \
  --reference-dir sb3_pilot_results_round4 --permutations 5000
```

The recommended formal baseline is the order-invariant independent-sample
interval:

```bash
./.rl-arm64-venv/bin/python sb3_pilot.py \
  --interval-method hoeffding_unpaired \
  --output-dir sb3_pilot_results_unpaired
```

The v3 primary execution command and external rerun procedure are in
`REPRODUCTION_MANIFEST_V3.md`. The v3 study is not a claim of algorithm
superiority or guaranteed publication: all 15 primary comparisons were
maximum-budget inconclusive, and the completed replay is same-machine
cross-script repeatability rather than independent-team reproducibility.

For a sealed rerun by another machine or team, use
`EXTERNAL_RERUN_HANDOFF_ZH.md` and build the result-independent kit with
`build_external_rerun_kit.py`. The generated `external_rerun_kit_v3.tar.gz`
contains the frozen source, lock files, wheel cache, metadata collector, and
result packager; its SHA-256 is recorded in
`external_rerun_kit_v3.tar.gz.sha256`. It deliberately excludes the v3
reference outputs. `validate_external_rerun.py` is run only after the external
operator returns raw outputs and the author supplies the private reference
directory.

The returned Windows rerun is archived under `复跑结果/`. Its audit is
`复跑结果/EXTERNAL_RERUN_AUDIT.md` and the machine-readable record is
`复跑结果/EXTERNAL_RERUN_AUDIT.json`. The audit covers 600 raw rows, output
and runtime-source hashes, 15 selected-configuration matches, and 15 matched
terminal decisions. Fourteen cells are numerically identical to the macOS
reference; the `Acrobot-v1:DQN` cell has mean absolute difference 0.00105 and
maximum absolute difference 0.01640. This supports different-machine
reproducibility of the frozen protocol, while independent-team identity and
new-task-family scientific replication remain unverified.

A separately preregistered continuous-control scope diagnostic is documented in
`FINAL_PREREGISTRATION_CONTINUOUS_SUPPLEMENT.md` and
`CONTINUOUS_SUPPLEMENT_REPORT.md`. It evaluates PPO/A2C on `Pendulum-v1` and
is not pooled with the v3 primary family. A second continuous-action scope
diagnostic and a fixed-mask partial-observation diagnostic are documented in
`CONTINUOUS_SCOPE_EXPANSION_REPORT.md` and
`PARTIAL_OBSERVABILITY_SCOPE_REPORT.md`; neither is a generalization claim.

The supplementary calibration grid is reproducible with:

```bash
./.rl-arm64-venv/bin/python calibration_grid.py --replicates 3000
```

It is diagnostic Monte Carlo evidence, not a proof of arbitrary-distribution
coverage or statistical power.

The current submission candidate is audited by `submission_readiness_audit.py`.
The report is written to `SUBMISSION_READINESS_AUDIT.md` and
`SUBMISSION_READINESS_AUDIT.json`. It distinguishes completed internal
evidence and the completed Windows AMD64 different-machine rerun from gates
that still require external action: a public repository or DOI, independent
literature screening, and completion of author/declaration metadata.

The remaining information sources and archival steps are mapped in
`EXTERNAL_INFO_COLLECTION_GUIDE.md`. Author names, affiliations, contact
details, funding, conflicts, and contributions remain `[待补充]` until the
authors provide them; they must not be inferred from local files.

For direct author handoff, use `AUTHOR_EXTERNAL_INFO_INTAKE_ZH.md`. It lists
each required field, its authoritative source, the evidence to retain, and the
file locations to update after confirmation.

Before public deposition, run `python3 audit_public_archive_safety.py`. It
scans the exact archive member list for local absolute paths and common
credential markers; a passing result is recorded in
`PUBLIC_ARCHIVE_SANITIZATION_AUDIT.json`.

The post-v3 queue budget follow-up is run and audited separately:

```bash
./.rl-arm64-venv/bin/python audit_queue_budget_followup.py
```

It contains 800 fixed-configuration test rows (400 DQN and 400 A2C), reuses
the v3 20-seed prefix, and stops at 400 total seeds for the queue DQN--A2C
comparison. This is a single-task, post-v3 resolution-cost diagnostic; it is
not a universal seed rule, general algorithm ranking, or external rerun.

The post-v4 v5 resolution-cost extension is also separate from the v3 primary
family. It uses frozen v3 configurations and seeds 30400--31399, collects the
complete 1,000-seed sequence for each of 15 cells, and audits prefix decisions
at 200, 400, 600, 800, and 1,000 seeds. Four comparisons reach a terminal
prefix decision and eleven remain unresolved at 1,000. These are observed
sample-resolution costs, not compute savings, prospective power, universal
seed requirements, or algorithm rankings. Reproduce it with:

```bash
./.rl-arm64-venv/bin/python v5_budget_extension.py --output-dir sb3_v5_extension
./.rl-arm64-venv/bin/python audit_v5_extension.py
```

The data-derived secondary tables and selection diagnostic can be regenerated
without rerunning RL training:

```bash
python3 generate_raw_return_table.py
python3 generate_effect_size_table.py
python3 generate_seed_distribution_table.py
python3 validation_selection_uncertainty.py
```

The validation-selection output is a post-hoc description of the five observed
validation rows; its bootstrap frequencies are not population probabilities.

The practical-margin sensitivity diagnostic reuses the frozen v3 test rows and
changes only the margin. It reports analytic necessary thresholds and observed
decision counts; it is post-hoc evidence rather than a new confirmatory family:

```bash
./.rl-arm64-venv/bin/python margin_sensitivity_v3.py
./.rl-arm64-venv/bin/python -m unittest -v test_margin_sensitivity_v3.py
```

The machine-specific runtime accounting and the combined reliability--cost
frontier are regenerated and checked directly from the stored v3 test rows:

```bash
python3 generate_runtime_cost_table.py
python3 audit_runtime_cost_table.py
python3 generate_reliability_cost_frontier.py
python3 audit_reliability_cost_frontier.py
```

The frontier combines analytic interval geometry with cumulative recorded
wall-clock cost at the four predeclared looks. It is a protocol accounting
artifact, not a cross-hardware efficiency benchmark or empirical power curve.

Family-size planning is also available as a deterministic analytic diagnostic:

```bash
python3 generate_design_planning_sensitivity.py
python3 audit_design_planning_sensitivity.py
```

`DESIGN_PLANNING_SENSITIVITY_V3.md` varies the closed comparison family from
1 to 30 while holding the total family alpha, look schedule, practical margin,
and width target fixed. It contains no RL observations and is not an empirical
power curve.

To create the current uploadable source/artifact archive, run:

```bash
python3 build_submission_bundle.py
```

This produces `submission_bundle_v3.tar.gz` and its SHA-256 sidecar. The
archive is prepared for Zenodo, OSF, or a public repository; it is not itself a
public deposition and its local path must not be cited as a public URL.

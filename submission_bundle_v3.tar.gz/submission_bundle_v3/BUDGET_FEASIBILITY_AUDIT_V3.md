# v3 Pre-study Budget Feasibility Audit

This artifact audits whether the frozen bounded interval could possibly
reach either v3 decision threshold before RL test data are collected.
It uses only the registered family size, alpha spending, metric bound,
practical margin, and target width; it reads no RL observations.

## Frozen inputs

- Family alpha: `0.05` across `15` comparisons.
- Comparison alpha: `0.0033333333333333335`.
- Looks per arm: `[5, 10, 15, 20]`.
- Metric range: `[0.0, 1.0]`.
- Practical margin: `0.05`.
- Target width: `0.1`.

## Feasibility table

| Look | Seeds/arm | Radius sum | Max possible lower endpoint | Min clipped width | Superiority possible? | Precision possible? | Necessary seeds/arm for superiority | Seeds/arm for target width |
|---:|---:|---:|---:|---:|:---:|:---:|---:|---:|
| 1 | 5 | 1.742157 | -0.742157 | 1.742157 | false | false | 17 | 6,071 |
| 2 | 10 | 1.339707 | -0.339707 | 1.339707 | false | false | 20 | 7,180 |
| 3 | 15 | 1.142220 | -0.142220 | 1.142220 | false | false | 22 | 7,829 |
| 4 | 20 | 1.017859 | -0.017859 | 1.017859 | false | false | 23 | 8,289 |

## Interpretation

The audit returns `false` for both decision-feasibility columns at every
v3 look. Thus the v3 cap forces an unresolved outcome for every bounded
dataset under the registered rule. The necessary seed thresholds are
strict feasibility thresholds only: crossing one makes a decision
possible, not probable. The target-width thresholds are worst-case
Hoeffding planning values and are not empirical RL requirements.

The audit is a pre-study design check. It does not replace the
conditional coverage proof, validate seed independence, estimate power,
or support a universal rule for other intervals or task families.

Machine-readable source: `generate_budget_feasibility_audit.py` and
`BUDGET_FEASIBILITY_AUDIT_V3.json`.

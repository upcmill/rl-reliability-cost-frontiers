# External v3 Rerun Audit

Status: **PASS**

This report audits a sealed rerun returned from a Windows AMD64 machine. It is evidence of a different-machine rerun; it does not verify the operator's institutional independence and does not create a public archive.

## Scope and integrity

- Rows: 600 (300 validation; 300 test).
- Test cells: 15; environments: Acrobot-v1, CartPole-v1, MountainCar-v0, NonstationaryQueue-v0, Taxi-v4; algorithms: A2C, DQN, PPO.
- Output checksum manifest: PASS.
- Runtime source hashes: PASS.
- Post-rerun documentation hash updates: REPRODUCTION_MANIFEST_V3.md.
- Schema errors: 0.

## Runtime

- External machine: Windows 10, AMD64.
- External Python: 3.11.18.
- External packages: NumPy 2.2.6, PyTorch 2.14.1, Gymnasium 1.4.0, SB3 2.9.2.
- Accelerator status: {'cuda_available': False, 'mps_available': False, 'torch_device_count': 0}.

## Comparison with macOS v3 reference

- Selected configurations: MATCH for all 15 cells.
- Terminal decisions: MATCH for all 15 comparisons.
- Zero-difference cells: 14/15.
- Nonzero-difference cells: 1/15.
- Maximum cell mean absolute metric difference: 0.001050.
- Maximum seed-level absolute metric difference: 0.016400.

The only nonzero cell is `Acrobot-v1:DQN`: mean absolute normalized-metric difference 0.001050 and maximum absolute difference 0.016400. All 15 terminal decisions remain `max_budget_inconclusive`.

## Evidence boundary

The returned handoff states that the operator did not access the author reference directory and that the frozen command parameters were unchanged. The machine and operating system differ from the original Apple Silicon macOS run. This closes the different-machine rerun gate, subject to preserving the raw archive and metadata. It does not verify that the operator was an independent research team, and it does not close the public-archive, literature-screening, or author-declaration gates.

"""Evidence-bounded manuscript additions for the locked post-hoc comparison."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'sequential_comparison_v1/results_v2'
V7_RESULTS = ROOT / 'sb3_v7_confirmation/analysis/summary.json'


def load_results():
    return (json.loads((RESULTS / 'real_summary.json').read_text()),
            json.loads((RESULTS / 'simulation_summary.json').read_text()))


def method_name(name):
    return {
        'H-original': '原 Hoeffding', 'H-finite': '有限归一化 Hoeffding',
        'H-uniform': '均匀支出 Hoeffding', 'EB-uniform': '固定时点经验 Bernstein',
        'CS-normal': '正态混合 CS', 'CS-EB-stitch': '经验 Bernstein 拼接 CS',
        'CS-EB-gamma': 'Gamma 混合经验 Bernstein CS',
        'CS-EB-gamma-rho0.1': 'Gamma CS，rho×0.1', 'CS-EB-gamma-rho10': 'Gamma CS，rho×10'}[name]


def fmt_counts(row):
    c = row['counts']
    return f"{c['a_superior']}/{c['b_superior']}/{c['precision_only']}/{c['unresolved']}"


def evidence_table(real):
    rows = []
    for dataset in ('primary20', 'extension400', 'extension1000'):
        for r in real['summaries']:
            if r['dataset'] != dataset:
                continue
            rows.append('| ' + ' | '.join([dataset, method_name(r['method']), fmt_counts(r),
                f"{r['mean_final_width']:.3f}", str(r['counterfactual_shared_training_runs']),
                f"{r['counterfactual_prefix_runtime_seconds']:.1f}"]) + ' |')
    return ('**表 S21-1。真实数据重分析的完整主要计数**\n\n'
        '| 数据序列 | 方法 | A优越/B优越/仅精度/未决 | 平均最终区间宽度 | 去重训练运行数 | 记录运行时间和(s) |\n'
        '|---|---|---:|---:|---:|---:|\n' + '\n'.join(rows) + '\n\n'
        '区间列按 15 个任务—算法比较作描述性平均；不对任务族抽样总体作推断。训练运行数按共享算法臂的最大停止前缀去重，'
        '不是实际已节省运行数。表中计时是原 CSV `runtime_seconds` 按前缀相加，不是实测串行墙钟耗时。')


def simulation_table(sim):
    rows = []
    order = ('primary20', 'extension400', 'extension1000')
    for scenario in ('null-high', 'null-low', 'margin-boundary', 'moderate-high',
                     'moderate-low', 'heteroscedastic', 'rare-failure', 'shared-null'):
        for method in ('H-original', 'H-finite', 'H-uniform', 'EB-uniform', 'CS-normal', 'CS-EB-stitch', 'CS-EB-gamma'):
            parts = []
            for plan in order:
                r = next(x for x in sim['rows'] if x['scenario'] == scenario and x['dataset_plan'] == plan and x['method'] == method)
                cov = r['rates']['covered']['count']
                err = r['rates']['false_superiority']['count']
                res = r['rates']['any_correct_superiority']['count']
                parts.append(f"{cov}/{err}/{res}")
            rows.append('| ' + ' | '.join([scenario, method_name(method), *parts]) + ' |')
    return ('**表 S21-2。完整 15 比较族合成校准主要计数**\n\n'
        '| 情景 | 方法 | n≤20 覆盖/错误优越/有优越决定 | n≤400 覆盖/错误优越/有优越决定 | n≤1000 覆盖/错误优越/有优越决定 |\n'
        '|---|---|---:|---:|---:|\n' + '\n'.join(rows) + '\n\n'
        '每个单元格式为“同时覆盖重复数/至少一个错误优越的重复数/至少一个正确优越的重复数”，总重复数均为 10,000。'
        '“同时覆盖”要求该方法在该计划的所有检查点同时覆盖全部 15 个真差异。详细错误率 Wilson 区间、仅精度决定、'
        '未决数、停止分布、宽度、配对运行成本和随机输入归档于 `sequential_comparison_v1/results_v2/simulation_summary.json` '
        '及同目录的压缩逐重复结果。该模型矩阵不是 RL 经验功效或跨情景保证。')


def main_additions():
    real, sim = load_results()
    by = {(x['dataset'], x['method']): x for x in real['summaries']}
    base = by['extension1000', 'H-original']
    eb = by['extension1000', 'EB-uniform']
    stitch = by['extension1000', 'CS-EB-stitch']
    gamma = by['extension1000', 'CS-EB-gamma']
    v4base = by['extension400', 'H-original']
    v4gamma = by['extension400', 'CS-EB-gamma']
    sim_cov = [r['rates']['covered']['count'] for r in sim['rows']]
    sim_wrong = [r['rates']['false_superiority']['count'] for r in sim['rows']]
    sim_units = len(sim['rows'])
    z = 1.959963984540054
    n_mc = sim['rows'][0]['rates']['covered']['total']
    upper = z * z / (n_mc + z * z)
    return f'''### 5.21 同目标、同错误预算的序贯区间事后比较

在查看结果后提出的本项审稿回应分析，沿用同一条件估计对象、15 项比较族、每比较 α=0.05/15、实际边际 0.05、目标宽度 0.10、配置、完整训练运行观测和共同检查点。比较了原 Hoeffding、有限归一化和均匀支出 Hoeffding、固定检查点经验 Bernstein [L19]、正态混合置信序列，以及 Howard 等的拼接和 Gamma 混合经验 Bernstein 置信序列[L18]。各方法分别以 α=0.05 控制同一比较族；这不是七种方法合并后的额外总体保证。具体方差过程、预测值、边界常数和参数冻结见补充材料 S21 与事后分析计划。

主研究 20 个测试种子中，九个主要/敏感性设定均为 15/15 未决，因而现代序贯边界没有解除原主研究的预算非分辨；20 种子下不可能获得两阈值决定的解析结论仍成立。400 种子扩展中，原 Hoeffding 有 1 项优越决定、14 项未决；固定时点经验 Bernstein、拼接 CS 与主设 Gamma CS 均有 4 项 A 优越、2 项 B 优越、9 项未决。Gamma CS 的去重反事实前缀为 {v4gamma['counterfactual_shared_training_runs']:,} 次运行，较原方法 {v4base['counterfactual_shared_training_runs'] - v4gamma['counterfactual_shared_training_runs']:,} 次；该序列实际 6,000 次训练均已完成，不能把差额报告为已实现节省。

在 1,000 种子扩展中，原方法为 3 项 A 优越、1 项 B 优越、11 项未决；固定时点经验 Bernstein 为 {eb['counts']['a_superior']} 项 A 优越、{eb['counts']['b_superior']} 项 B 优越、{eb['counts']['precision_only']} 项仅精度决定、{eb['counts']['unresolved']} 项未决；拼接 CS 和主设 Gamma CS 均为 {stitch['counts']['a_superior']} 项 A 优越、{stitch['counts']['b_superior']} 项 B 优越、{stitch['counts']['precision_only']} 项仅精度决定、{stitch['counts']['unresolved']} 项未决。Gamma CS 的去重反事实前缀为 {gamma['counterfactual_shared_training_runs']:,}/{base['observed_full_test_training_runs']:,} 次训练，记录运行时间按前缀相加为 {gamma['counterfactual_prefix_runtime_seconds']:.1f} 秒，相比原方法 {base['counterfactual_prefix_runtime_seconds']:.1f} 秒。因所有种子均已执行，这仅是反事实停止轨迹；也没有把逐比较停止数相加以重复计算共享臂。

此任务族的方差自适应方法在部分扩展比较上缩短了区间并改变了停止分类，但优势并不均匀：具体结果随比较和分布变化，零效应、高离散及小样本条件下可仍未决。rho×0.1/×10 的敏感性结果列于补充表 S21-1，不用于选择性报告。有限的既有任务族不能区分“原区间保守”与“该任务的种子分布适合经验方差界”这两种解释。

完整族模拟使用八种预设生成分布、每种 10,000 次重复、三种预算计划和七种主要方法，共 {sim_units} 个方法—情景—计划单元。观察到同时覆盖失败事件数范围为 {sim['rows'][0]['rates']['covered']['total'] - max(sim_cov)}–{sim['rows'][0]['rates']['covered']['total'] - min(sim_cov)}/{sim['rows'][0]['rates']['covered']['total']}，错误优越族事件数范围为 {min(sim_wrong)}–{max(sim_wrong)}/{sim['rows'][0]['rates']['covered']['total']}。零事件对应单元 Wilson 95% 区间上界约 {upper:.6f}；这只是有限模拟的 Monte Carlo 精度，不能代替定理。模拟支持的是在所列边际分布、共享臂结构和独立重复假设下的代码及行为校准，不是强化学习真实种子分布上的功效或覆盖率证明。

![图 15。共同检查点上的区间宽度对照。三面板分别为主研究、400 种子和 1,000 种子扩展；曲线为 15 项比较的中位区间宽度，误差带为四分位范围。置信序列额外提供任意时刻保证，但本比较仅在共同的预定检查点判定。](manuscript_figures/fig_modern_interval_comparison.png)

''' + evidence_table(real) + '\n\n' + simulation_table(sim) + '\n'


def update_manuscripts(main_text, supplement_text):
    real, _ = load_results()
    addition = main_additions()
    addition = addition.split('**表 S21-1。真实数据重分析的完整主要计数**', 1)[0]
    addition += ('详细逐比较结果、停止前缀成本及完整模拟矩阵见补充材料 S21，'
                 '原始 CSV/JSON/NPZ、分析代码与哈希清单均随本项目材料提供。\n')
    main_text = main_text.replace('![图 15。两个固定离散任务、每算法 200 个种子的最终区间；六个比较均未决。]',
        '![图 16。两个固定离散任务、每算法 200 个种子的最终区间；六个比较均未决。]', 1)
    anchor = '\n## 6 讨论\n'
    if main_text.count(anchor) != 1:
        raise ValueError('main discussion anchor changed')
    main_text = main_text.replace(anchor, '\n' + addition + anchor, 1)
    v7 = json.loads(V7_RESULTS.read_text())
    outcome = v7['primary_fixed_panel_outcome']
    v7_methods = {row['method']: row for row in v7['method_summaries']}
    baseline = v7_methods['H-original']
    gamma = v7_methods['CS-EB-gamma']
    base_resolved = 15 - baseline['decision_counts_at_1000']['unresolved']
    gamma_resolved = 15 - gamma['decision_counts_at_1000']['unresolved']
    v7_section = (f"""### 5.22 未披露新种子上的事后前瞻验证

为检验既有区间宽度差异是否延续，在查看 V1–V5 结果后冻结 V7 方案，并在新种子 31,400–32,399 上执行五任务、三算法共 15,000 次训练。所选配置、训练预算、检查点、归一化指标、比较族、五个检查时点和 Gamma CS 参数沿用已披露设置；方案和代码哈希在采集前锁定。该验证是在既有结果启发后开展的新种子验证，不是原始预注册确认，也不是不同团队复现。

在预先指定的 15 项固定比较中，Gamma CS 的 1,000 种子最终区间宽度均小于原 Hoeffding；Gamma 减 Hoeffding 的平均宽度差为 {outcome['mean_final_width_difference_gamma_minus_original']:.4f}，中位差为 {outcome['median_final_width_difference_gamma_minus_original']:.4f}。Gamma CS 达到优越性或精度停止规则的比较为 {gamma_resolved}/15，Hoeffding 为 {base_resolved}/15；Gamma CS 的未决数为 {gamma['decision_counts_at_1000']['unresolved']}，Hoeffding 为 {baseline['decision_counts_at_1000']['unresolved']}。前缀训练数按共享算法臂去重后分别为 {gamma['counterfactual_deduplicated_shared_runs']:,} 和 {baseline['counterfactual_deduplicated_shared_runs']:,}，但本验证实际完成全部 15,000 次训练，前缀差异只是反事实停止轨迹。

这些结果为当前五任务固定面板上的区间宽度差异提供新种子支持；15 项并非随机抽样任务，不能据此作任务总体推断，也不能将其当作置信覆盖率的经验验证。种子序列、原始记录、逐比较结果、分析代码和终端退出状态说明见补充材料 S22。""")
    anchor = '\n## 6 讨论\n'
    if main_text.count(anchor) != 1:
        raise ValueError('V7 discussion anchor changed')
    main_text = main_text.replace(anchor, '\n' + v7_section + anchor, 1)
    old_conclusion = ('最后，事前可行性审计提供了一个可复现的事前决策点。对主研究而言，它会在观察任何 RL 结果前标记 20 个种子的上限无法达到两个注册阈值。'
        '因此，审计使所选统计证书的成本在实验开始前可见，同时把经验功效、任务族有效性和独立性假设保留为相互独立的问题。')
    new_conclusion = (old_conclusion + ' 事后同预算区间比较进一步表明，现代方差自适应工具在部分较大预算扩展上改变了停止结果并降低了反事实前缀成本，'
        '但不改变 20 种子主结论；这些差异依赖任务族、观测方差和预先固定的置信序列调节参数，尚不足以支持普遍的效率优势。')
    if main_text.count(old_conclusion) != 1:
        raise ValueError('conclusion anchor changed')
    main_text = main_text.replace(old_conclusion, new_conclusion, 1)
    refs = ('[L18] Howard, S. R., Ramdas, A., McAuliffe, J., and Sekhon, J. (2021). Time-uniform, nonparametric, nonasymptotic confidence sequences. '
        'The Annals of Statistics, 49(2), 1055–1080. DOI: 10.1214/20-AOS1991. 全文核读版本：arXiv:1810.08240v9（2022-08-06）；章节及定理编号按该版本。')
    add = ('\n\n[L19] Maurer, A., & Pontil, M. (2009). Empirical Bernstein Bounds and Sample Variance Penalization. '
        'arXiv:0907.3740v1. Theorem 4 is used for the fixed-time i.i.d. baseline; Theorem 11 is not used.')
    if main_text.count(refs) != 1:
        raise ValueError('Howard reference anchor changed')
    main_text = main_text.replace(refs, refs + add, 1)
    # Add one evidence row to the existing claim-to-evidence table without changing its numbering.
    claim = '| 协议普遍节省计算或能够对 PPO/DQN/A2C 排名。 | 跨任务和预算的校准证据。 | 不支持。 |'
    row = ('| 同目标、同预算序贯工具对照在大预算扩展中改变部分停止分类，但主研究仍全部未决。 '
           '| 第 5.21 节、补充材料 S21、同机可执行分析及 15 比较族合成校准。 '
           '| 对现有任务族的事后证据；不构成普遍效率排序或真实分布覆盖证明。 |\n')
    if main_text.count(claim) != 1:
        raise ValueError('claim-to-evidence anchor changed')
    main_text = main_text.replace(claim, row + claim, 1)
    supplement_text += '\n\n## S21 同目标、同预算序贯区间比较\n\n'
    supplement_text += ('本节是 2026-11-03 冻结分析计划后的事后研究，不追认为原预注册。'
        '完整计划、错误预算账本、实现、确定性测试、输入哈希、逐检查点区间、停止决定、8 种模拟情景全部计数及运行环境见 '
        '`sequential_comparison_v1/`。本节报告固定配置的条件均值差；不包括重复调参流程的不确定性，也不把 15 比较族的模拟重复当作 RL 种子数据。\n\n'
        '经验 Bernstein 固定时点界使用 Maurer–Pontil 定理4；双算法和双侧合计四个单侧失败事件，故每侧使用 '
        '`delta=alpha_k/4` 并在对数项中得到 `log(8/alpha_k)`。其每臂半径为 '
        '`sqrt(2*s_n^2*log(8/alpha_k)/n)+7*log(8/alpha_k)/(3*(n-1))`；n=1 时按无信息界处理。'
        'Howard 等的正态混合 CS 每臂半径为 '
        '`sqrt((v+rho)*log((v+rho)/((alpha/2)^2*rho))/n^2)`，其中 `v=n/4`、alpha 为比较级错误预算，'
        'rho 按预先声明的终点 intrinsic time 规则固定。其余置信序列使用正态混合边界式(14)、'
        '定理4的可预测残差方差过程和定理1式(8)的拼接边界，或附录命题9的 Gamma–exponential mixture。'
        '经验 Bernstein CS 的预测残差过程为 `V_t=sum_{i<=t}(X_i-xhat_i)^2`，'
        '边界半径 `u(V_t)/t`，单侧 crossing probability 为比较级 alpha 的四分之一。'
        '拼接边界取式(8)：`u(v)=sqrt(k1^2*v*ell+k2^2*c^2*ell^2)+k2*c*ell`，'
        '`ell=log(zeta(s)/alpha)+s*log(1+log(v/m0)/log(eta))`；参数 `eta=2, s=1.4, m0=1, c=1`。'
        '预测器首值为 0.5，后续为过去观测均值。Gamma 混合边界按 Howard 等附录命题9/式(65)数值求解单调根。'
        '比较边界均采用共同检查点、共同差值、共同实用边际和同一逐方法族级错误预算。固定时点经验 Bernstein 与 CS 的非分辨/决定行为不是新的方法保证，'
        '而是引用定理在冻结观测上的应用。\n\n')
    supplement_text += evidence_table(real) + '\n\n' + simulation_table(load_results()[1])
    supplement_text += ('\n\n**数值稳定性。** Gamma 混合边界通过对数形式计算并对单调根作二分；代表性根与 mpmath 50 位计算核对。'
        '浮点容差检查不构成形式化的向外舍入证明。所有实证结论均按当前双精度实现复核。\n\n'
        '**解释限制。** 同一新种子序列被所有方法重用，因此方法间比较是配对的描述性重算，不是独立样本实验。'
        '调节参数在查看本次重算前依照预定公式冻结；附加 rho 敏感性结果完整列于表 S21-1。'
        '模拟每次生成五任务、三算法的完整家族并共用参与多个比较的算法臂。各方法按自身定理分别获得每比较 alpha；'
        '不同方法不是额外乘入的七重家族，也未据其中表现择优提出确认性结论。'
        '本轮完整运行在同机独立目录重跑后，四个 CSV/JSON 汇总文件逐字节一致，八个 NPZ 归档的全部数组逐值一致；'
        '该核对建立同团队同机可重复性，不是不同团队可复现性。详见 `sequential_comparison_v1/RECOMPUTATION_AUDIT_V2.json`。\n\n'
        '**复跑命令。** 在已安装 Python 3.11、NumPy 2.2.6、SciPy 1.15.3 的独立环境中，运行：\n\n'
        '```sh\nPYTHONPATH="$(pwd):$(pwd)/.rl-arm64-venv/lib/python3.11/site-packages" \\\n+  ./.seq-analysis-venv/bin/python run_modern_sequential_comparison.py \\\n+  --output sequential_comparison_v1/reproduced --replicates 10000 \\\n+  --seed 20261103 --batch-size 100\n```\n\n'
        '输入与分析代码哈希由程序执行前后的断言检查；输出目录须不存在。复跑过程不会启动新的 RL 训练。\n')
    command_start = supplement_text.index('**复跑命令。**')
    command_end = supplement_text.index('输入与分析代码哈希', command_start)
    command = ('**复跑命令。** 在已安装 Python 3.11、NumPy 2.2.6、SciPy 1.15.3 的独立环境中，运行 '
        '`PYTHONPATH="$(pwd):$(pwd)/.rl-arm64-venv/lib/python3.11/site-packages" ./.seq-analysis-venv/bin/python '
        'run_modern_sequential_comparison.py --output sequential_comparison_v1/reproduced --replicates 10000 '
        '--seed 20261103 --batch-size 100`。\n\n')
    supplement_text = supplement_text[:command_start] + command + supplement_text[command_end:]
    v7 = json.loads(V7_RESULTS.read_text())
    pair_rows = '\n'.join('| ' + ' | '.join([
        row['environment'], row['comparison'], f"{row['original_final_width']:.4f}",
        f"{row['gamma_final_width']:.4f}",
        f"{row['paired_width_difference_gamma_minus_original']:.4f}",
        row['original_terminal'], row['gamma_terminal'], str(row['gamma_stop_n'])]) + ' |'
        for row in v7['pairwise_primary_results'])
    v7_section = f"""

## S22 未披露新种子的前瞻验证

本项验证在既有结果已知后提出，故称为事后前瞻新种子验证，不追认为原始预注册。方案于新测试序列生成前冻结；哈希锁、选定配置、执行代码和分析脚本见 `V7_CONFIRMATION_LOCK.json`、`V7_PROSPECTIVE_VALIDATION_PLAN.md`、`v7_confirmatory_runner.py` 与 `analyze_v7_confirmation.py`。验证使用五个原任务、PPO/DQN/A2C、原冻结的 15 个任务—算法比较和配置；测试训练种子为 31,400–32,399，每个单元 1,000 个种子，训练 4,096 步，在 1,024、2,048、3,072、4,096 步检查，每个检查点五个评估回合。新种子与 V3、V4、V5 范围不重叠。

主要描述性对照是 Gamma 混合经验 Bernstein CS 相对原 Hoeffding 的 1,000 种子最终区间宽度差，15 项固定比较均逐项报告；不将比较对当成独立抽样总体，不计算其伪重复显著性检验。Gamma CS 在 15/15 项的最终区间更窄，平均差为 {v7['primary_fixed_panel_outcome']['mean_final_width_difference_gamma_minus_original']:.4f}，中位差为 {v7['primary_fixed_panel_outcome']['median_final_width_difference_gamma_minus_original']:.4f}。Gamma CS 的终止计数为 4 项 A 优越、2 项 B 优越、5 项仅精度决定、4 项未决；原 Hoeffding 为 3、1、0、11 项。Gamma CS 和原方法的去重反事实共享训练前缀分别是 11,800 和 14,600 次，但完整 15,000 次训练均已完成，不能称为实际节省。

**表 S22-1。V7 新种子序列上的逐比较最终宽度与停止决定**

| 任务 | 比较 | Hoeffding 宽度 | Gamma CS 宽度 | 宽度差 | Hoeffding 决定 | Gamma CS 决定 | Gamma 停止种子数 |
|---|---|---:|---:|---:|---|---|---:|
{pair_rows}

输入 CSV 共 15,000 行、15 个单元各 1,000 条；训练种子范围、唯一性、运行状态、所选配置和评估种子派生均经独立审计。机器可读逐检查点结果和摘要位于 `sb3_v7_confirmation/analysis/intervals.csv`、`sb3_v7_confirmation/analysis/summary.json`；输入/输出哈希见 `sb3_v7_confirmation/analysis/ANALYSIS_MANIFEST.json`，独立复算和哈希核查结果见 `V7_CONFIRMATION_AUDIT.json`。运行元数据为 `sb3_v7_confirmation/run_config.json`，原始训练记录为 `sb3_v7_confirmation/raw_seed_metrics.csv`。

训练进程在全部行写入且运行元数据状态已设为 `COMPLETED` 后，终端 JSON 状态打印因 `flush` 参数传给 `json.dumps` 而以非零状态退出；数据文件仍有 15,000 个成功行，哈希和分析产物完整。该输出错误不改变训练结果或分析，但应在复跑日志中披露。该项证据是同团队、同工作站新种子复跑；不能证明不同团队可复现、未知 RL 种子分布上的覆盖，或对其他任务的普遍效率优势。
"""
    supplement_text += v7_section
    return main_text, supplement_text

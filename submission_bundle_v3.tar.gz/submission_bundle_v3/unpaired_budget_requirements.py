#!/usr/bin/env python3
"""Analytic worst-case budget requirements for the unpaired Hoeffding baseline."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from pilot_protocol import alpha_spend


def equal_sample_width(alpha: float, look: int, n: int) -> float:
    """Width of the clipped interval before endpoint clipping, for n per arm."""
    look_alpha = alpha_spend(alpha, look)
    radius = math.sqrt(2.0 * math.log(4.0 / look_alpha) / n)
    return 2.0 * radius


def seeds_for_width(alpha: float, look: int, target_width: float) -> int:
    look_alpha = alpha_spend(alpha, look)
    return math.ceil(8.0 * math.log(4.0 / look_alpha) / (target_width**2))


def seeds_for_superiority(alpha: float, look: int, true_difference: float, margin: float) -> int | None:
    gap = abs(true_difference) - margin
    if gap <= 0.0:
        return None
    look_alpha = alpha_spend(alpha, look)
    return math.floor(2.0 * math.log(4.0 / look_alpha) / (gap**2)) + 1


def seeds_for_possible_superiority(alpha: float, look: int, margin: float) -> int | None:
    """Necessary sample size for any bounded data to possibly cross the margin.

    With metrics in [0, 1], the largest observed difference is one. The
    interval can only have a lower endpoint above ``margin`` if its unpaired
    radius sum is strictly smaller than ``1 - margin``. The returned value is
    a necessary resolution threshold, not a guarantee that a decision occurs.
    """
    if margin >= 1.0:
        return None
    look_alpha = alpha_spend(alpha, look)
    gap = 1.0 - margin
    return math.floor(2.0 * math.log(4.0 / look_alpha) / (gap**2)) + 1


def total_seeds_for_width(alpha: float, look: int, target_width: float) -> int:
    """Minimum total seeds under the radius-minimizing balanced allocation."""
    if target_width <= 0.0:
        raise ValueError("target_width must be positive")
    look_alpha = alpha_spend(alpha, look)
    return math.ceil(16.0 * math.log(4.0 / look_alpha) / (target_width**2))


def total_seeds_for_possible_superiority(alpha: float, look: int, margin: float) -> int | None:
    """Necessary total-seed threshold when two arms are allocated optimally."""
    if margin >= 1.0:
        return None
    look_alpha = alpha_spend(alpha, look)
    gap = 1.0 - margin
    return math.floor(4.0 * math.log(4.0 / look_alpha) / (gap**2)) + 1


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--looks", default="1,2,4,10,20")
    parser.add_argument("--output", default="unpaired_budget_requirements.json")
    args = parser.parse_args()
    looks = [int(item) for item in args.looks.split(",") if item]
    rows = []
    for look in looks:
        row = {
            "look": look,
            "alpha_look": alpha_spend(args.alpha, look),
            "seeds_per_algorithm_for_width": seeds_for_width(args.alpha, look, args.target_width),
            "width_at_20_seeds": equal_sample_width(args.alpha, look, 20),
            "width_at_100_seeds": equal_sample_width(args.alpha, look, 100),
            "superiority_requirements": {
                str(delta): seeds_for_superiority(
                    args.alpha, look, delta, args.practical_margin
                )
                for delta in (0.06, 0.10, 0.20, 0.30)
            },
            "minimum_seeds_for_possible_bounded_superiority": seeds_for_possible_superiority(
                args.alpha, look, args.practical_margin
            ),
            "minimum_total_seeds_for_possible_bounded_superiority": total_seeds_for_possible_superiority(
                args.alpha, look, args.practical_margin
            ),
            "total_seeds_for_width_under_balanced_allocation": total_seeds_for_width(
                args.alpha, look, args.target_width
            ),
        }
        rows.append(row)
    payload = {
        "status": "analytic_budget_requirement_only",
        "warning": "Worst-case Hoeffding planning calculations, not observed RL results or a necessary lower bound.",
        "assumptions": {
            "alpha": args.alpha,
            "target_width": args.target_width,
            "practical_margin": args.practical_margin,
            "equal_independent_sample_sizes": True,
            "metric_range": "[0, 1]",
        },
        "rows": rows,
    }
    Path(args.output).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

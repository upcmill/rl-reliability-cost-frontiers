#!/usr/bin/env python3
"""Validate a sealed v3 rerun without changing the primary artifacts.

The validator checks the external-run schema and compares seed-level metrics
with the frozen v3 reference. A successful validation is a schema/comparison
result only; it does not turn a same-machine run into external evidence.
"""

from __future__ import annotations

import argparse
import csv
import json
import platform
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision


ENVIRONMENTS = (
    "CartPole-v1",
    "Acrobot-v1",
    "MountainCar-v0",
    "Taxi-v4",
    "NonstationaryQueue-v0",
)
ALGORITHMS = ("PPO", "DQN", "A2C")
EXPECTED_CONFIG_IDS = {
    "lr3e4_long",
    "lr1e4_long",
    "lr3e4_short",
    "lr1e4_short",
}


def load_payload(directory: Path) -> dict:
    path = directory / "summary.json"
    if not path.is_file():
        raise FileNotFoundError(f"missing {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def load_rows(directory: Path) -> list[dict[str, str]]:
    path = directory / "raw_seed_metrics.csv"
    if not path.is_file():
        raise FileNotFoundError(f"missing {path}")
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def cell_metrics(rows: list[dict[str, str]], split: str) -> dict[tuple[str, str], dict[int, float]]:
    cells: dict[tuple[str, str], dict[int, float]] = {}
    for row in rows:
        if row.get("split") != split:
            continue
        key = (row["env_id"], row["algorithm"])
        cells.setdefault(key, {})[int(row["train_seed"])] = float(row["metric_normalized"])
    return cells


def check_schema(rows: list[dict[str, str]], payload: dict) -> list[str]:
    errors: list[str] = []
    if len(rows) != 600:
        errors.append(f"expected 600 rows, found {len(rows)}")
    if sum(row.get("split") == "validation" for row in rows) != 300:
        errors.append("validation row count is not 300")
    if sum(row.get("split") == "test" for row in rows) != 300:
        errors.append("test row count is not 300")
    if {row.get("env_id") for row in rows} != set(ENVIRONMENTS):
        errors.append("environment set differs from the frozen v3 family")
    if {row.get("algorithm") for row in rows} != set(ALGORITHMS):
        errors.append("algorithm set differs from the frozen v3 family")
    for row in rows:
        try:
            value = float(row["metric_normalized"])
            if not 0.0 <= value <= 1.0:
                errors.append(f"metric outside [0,1] at {row.get('env_id')}:{row.get('algorithm')}:{row.get('train_seed')}")
        except (KeyError, ValueError):
            errors.append("metric_normalized is missing or non-numeric")
            break

    run_config = payload.get("run_config", {})
    expected = {
        "validation_seeds": 5,
        "test_seeds": 20,
        "initial_test_seeds": 5,
        "test_batch_size": 5,
        "timesteps": 4096,
        "checkpoints": 4,
        "eval_episodes": 5,
    }
    for name, value in expected.items():
        if run_config.get(name) != value:
            errors.append(f"run_config.{name}={run_config.get(name)!r}, expected {value!r}")
    if payload.get("environment_ids") != list(ENVIRONMENTS):
        errors.append("payload environment_ids order differs from the frozen v3 order")
    if payload.get("algorithm_ids") != list(ALGORITHMS):
        errors.append("payload algorithm_ids order differs from the frozen v3 order")
    if set(payload.get("candidate_configs", {})) != EXPECTED_CONFIG_IDS:
        errors.append("candidate configuration IDs differ from the frozen four-candidate grid")

    validation = cell_metrics(rows, "validation")
    test = cell_metrics(rows, "test")
    for key in ((env, algo) for env in ENVIRONMENTS for algo in ALGORITHMS):
        if set(validation.get(key, {})) != set(range(10000, 10005)):
            errors.append(f"validation seeds differ at {key[0]}:{key[1]}")
        if set(test.get(key, {})) != set(range(20000, 20020)):
            errors.append(f"test seeds differ at {key[0]}:{key[1]}")
    return sorted(set(errors))


def compare_to_reference(
    rows: list[dict[str, str]],
    payload: dict,
    reference: dict,
    reference_rows: list[dict[str, str]],
) -> dict:
    external_cells = cell_metrics(rows, "test")
    reference_cells = cell_metrics(reference_rows, "test")
    differences = []
    for env_id in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            key = (env_id, algorithm)
            ext = external_cells.get(key, {})
            ref = reference_cells.get(key, {})
            deltas = [ext[seed] - ref[seed] for seed in sorted(set(ext) & set(ref))]
            selected = payload.get("summary", {}).get(f"{env_id}:{algorithm}", {}).get("selected_config")
            ref_selected = reference.get("summary", {}).get(f"{env_id}:{algorithm}", {}).get("selected_config")
            differences.append(
                {
                    "env_id": env_id,
                    "algorithm": algorithm,
                    "external_selected_config": selected,
                    "reference_selected_config": ref_selected,
                    "selected_config_match": selected == ref_selected,
                    "matched_seed_count": len(deltas),
                    "mean_absolute_metric_difference": sum(abs(delta) for delta in deltas) / len(deltas) if deltas else None,
                    "maximum_absolute_metric_difference": max((abs(delta) for delta in deltas), default=None),
                }
            )

    run_config = payload.get("run_config", {})
    protocol = ProtocolConfig(
        alpha=float(run_config.get("comparison_alpha", 0.05 / 15.0)),
        practical_margin=0.05,
        initial_seeds=5,
        batch_size=5,
        max_seeds=20,
        target_width=0.10,
        interval_method="hoeffding_unpaired",
    )
    decisions = []
    for env_id in ENVIRONMENTS:
        for first, second in (("PPO", "DQN"), ("PPO", "A2C"), ("DQN", "A2C")):
            a = payload.get("summary", {}).get(f"{env_id}:{first}", {}).get("test_metrics", [])
            b = payload.get("summary", {}).get(f"{env_id}:{second}", {}).get("test_metrics", [])
            if len(a) == 20 and len(b) == 20:
                external_decision = sequential_decision(a, b, protocol)["decision"]
            else:
                external_decision = "unavailable"
            reference_a = reference["summary"][f"{env_id}:{first}"]["test_metrics"]
            reference_b = reference["summary"][f"{env_id}:{second}"]["test_metrics"]
            reference_decision = sequential_decision(reference_a, reference_b, protocol)["decision"]
            decisions.append(
                {
                    "comparison": f"{env_id}:{first}_vs_{second}",
                    "external_decision": external_decision,
                    "reference_decision": reference_decision,
                    "decision_match": external_decision == reference_decision,
                }
            )
    return {
        "cell_differences": differences,
        "decision_comparison": decisions,
        "all_selected_configurations_match": all(item["selected_config_match"] for item in differences),
        "all_decisions_match": all(item["decision_match"] for item in decisions),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--external-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--reference-dir", default="sb3_formal_v3")
    args = parser.parse_args()

    external_dir = Path(args.external_dir)
    reference_dir = Path(args.reference_dir)
    payload = load_payload(external_dir)
    rows = load_rows(external_dir)
    reference = load_payload(reference_dir)
    reference_rows = load_rows(reference_dir)
    errors = check_schema(rows, payload)
    comparison = compare_to_reference(rows, payload, reference, reference_rows) if not errors else None
    report = {
        "status": "PASS" if not errors else "SCHEMA_ERROR",
        "warning": "A local validation pass is not evidence of an independent external rerun.",
        "external_dir": str(external_dir),
        "reference_dir": str(reference_dir),
        "operator_runtime": {
            "python_version": platform.python_version(),
            "python_arch": platform.machine(),
        },
        "schema_errors": errors,
        "comparison": comparison,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    if errors:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

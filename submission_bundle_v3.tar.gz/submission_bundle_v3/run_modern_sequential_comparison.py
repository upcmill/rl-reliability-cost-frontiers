"""Execute the locked post-hoc interval comparison; never overwrites outputs."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path

import numpy as np
import scipy

from modern_sequential_intervals import (COMPARISON_ALPHA, DECISIONS, METHODS, PAIRS,
    SENSITIVITY, locked_decisions, normal_rho, pair_intervals, shared_arm_prefixes,
    sufficient_statistics)
from reference_sequential_interval import alpha_spend, unpaired_hoeffding_interval

ROOT = Path(__file__).resolve().parent
PLAN = ROOT / 'sequential_comparison_v1'
ENVS = ('CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Taxi-v4', 'NonstationaryQueue-v0')
ALGORITHMS = ('PPO', 'DQN', 'A2C')
DATASETS = (
    ('primary20', 'sb3_formal_v3', 'test', (5, 10, 15, 20), 20000),
    ('extension400', 'sb3_v4_extension', 'extension_test', (200, 400), 30000),
    ('extension1000', 'sb3_v5_extension', 'extension_test', (200, 400, 600, 800, 1000), 30400),
)
SCENARIOS = (
    ('null-high', (.5, .5, .5), 'bernoulli', None),
    ('null-low', (.5, .5, .5), 'uniform', (.02, .02, .02)),
    ('margin-boundary', (.55, .50, .45), 'bernoulli', None),
    ('moderate-high', (.70, .50, .30), 'bernoulli', None),
    ('moderate-low', (.70, .50, .30), 'uniform', (.02, .02, .02)),
    ('heteroscedastic', (.70, .50, .30), 'uniform', (.01, .45, .20)),
    ('rare-failure', (.99, .94, .89), 'bernoulli', None),
    ('shared-null', (.5, .5, .5), 'shared', None),
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def csv_write(path, rows):
    with Path(path).open('w', newline='', encoding='utf-8') as file:
        w = csv.DictWriter(file, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)


def wilson(successes, count):
    z = 1.959963984540054
    p = successes / count
    d = 1 + z * z / count
    c = (p + z * z / (2 * count)) / d
    h = z * math.sqrt(p * (1 - p) / count + z * z / (4 * count ** 2)) / d
    return [max(0., c - h), min(1., c + h)]


def sample_summary(values):
    values = np.asarray(values, float)
    sd = float(np.std(values, ddof=1)) if len(values) > 1 else 0.
    return {'mean': float(np.mean(values)), 'sd': sd, 'mc_se': sd / math.sqrt(len(values)),
            'quantiles_0_25_50_75_100': np.quantile(values, [0, .25, .5, .75, 1]).tolist()}


def verify_sources():
    hashes = json.loads((PLAN / 'INPUT_HASHES.json').read_text())
    for p, expected in hashes.items():
        if sha(ROOT / p) != expected:
            raise ValueError(f'Frozen input changed: {p}')
    lock = json.loads((PLAN / 'PLAN_LOCK.json').read_text())
    for p, expected in lock['hashes'].items():
        if sha(ROOT / p) != expected:
            raise ValueError(f'Plan/implementation changed after lock: {p}')
    return hashes, lock


def real_data(output):
    config = json.loads((ROOT / 'sb3_v5_extension/run_config.json').read_text())['selected_configurations']
    all_intervals, all_pairs, summaries, validation = [], [], [], []
    for name, directory, split, looks, seed0 in DATASETS:
        with (ROOT / directory / 'raw_seed_metrics.csv').open() as file:
            raw = [r for r in csv.DictReader(file) if r['split'] == split]
        x = np.zeros((5, 3, looks[-1]))
        runtimes = np.zeros_like(x)
        for t, env in enumerate(ENVS):
            for a, algo in enumerate(ALGORITHMS):
                rows = sorted([r for r in raw if (r['env_id'], r['algorithm']) == (env, algo)], key=lambda r: int(r['train_seed']))
                assert len(rows) == looks[-1]
                assert [int(r['train_seed']) for r in rows] == list(range(seed0, seed0 + looks[-1]))
                assert all(r['status'] == 'ok' and r['config_id'] == config[env + ':' + algo] for r in rows)
                x[t, a] = [float(r['metric_normalized']) for r in rows]
                runtimes[t, a] = [float(r['runtime_seconds']) for r in rows]
        assert len(raw) == 15 * looks[-1]
        assert np.all(np.isfinite(runtimes)) and np.all(runtimes >= 0)
        stats = sufficient_statistics(x, looks)
        checked = 0
        for method in METHODS + SENSITIVITY:
            est, lower, upper = pair_intervals(stats, looks, method)
            terminal, stops, stop_indices = locked_decisions(lower, upper, looks)
            prefixes = shared_arm_prefixes(stops)
            prefix_runtime = sum(float(runtimes[t, a, :prefixes[t, a]].sum()) for t in range(5) for a in range(3))
            for t, env in enumerate(ENVS):
                for p, (a, b) in enumerate(PAIRS):
                    pair = ALGORITHMS[a] + ' - ' + ALGORITHMS[b]
                    kstop = int(stop_indices[t, p])
                    all_pairs.append({'dataset': name, 'method': method, 'environment': env, 'comparison': pair,
                        'terminal': DECISIONS[int(terminal[t, p])], 'stop_n': int(stops[t, p]),
                        'censored': bool(terminal[t, p] == 0), 'stop_lower': float(lower[t, p, kstop]),
                        'stop_upper': float(upper[t, p, kstop]), 'final_estimate': float(est[t, p, -1]),
                        'final_lower': float(lower[t, p, -1]), 'final_upper': float(upper[t, p, -1]),
                        'final_width': float(upper[t, p, -1] - lower[t, p, -1])})
                    for k, n in enumerate(looks):
                        if method == 'H-original':
                            expected = unpaired_hoeffding_interval(x[t, a, :n].tolist(), x[t, b, :n].tolist(), alpha_spend(COMPARISON_ALPHA, k + 1))
                            assert np.allclose([est[t, p, k], lower[t, p, k], upper[t, p, k]], expected, atol=1e-12, rtol=0)
                            checked += 1
                        all_intervals.append({'dataset': name, 'method': method, 'environment': env, 'comparison': pair,
                            'look': k + 1, 'n_per_arm': n, 'estimate': float(est[t, p, k]),
                            'lower': float(lower[t, p, k]), 'upper': float(upper[t, p, k]),
                            'width': float(upper[t, p, k] - lower[t, p, k]),
                            'at_or_before_locked_stop': bool(k <= kstop)})
            summaries.append({'dataset': name, 'method': method, 'role': 'primary' if method in METHODS else 'rho_sensitivity',
                'looks': list(looks), 'counts': {d: int(np.sum(terminal == i)) for i, d in enumerate(DECISIONS)},
                'stop_n_histogram': {str(n): int(np.sum(stops == n)) for n in looks},
                'mean_stop_n_censored_at_budget': float(stops.mean()),
                'mean_final_width': float((upper[..., -1] - lower[..., -1]).mean()),
                'median_final_width': float(np.median(upper[..., -1] - lower[..., -1])),
                'mean_width_at_each_look': (upper - lower).mean(axis=(0, 1)).tolist(),
                'shared_prefixes_by_environment_and_arm': prefixes.tolist(),
                'counterfactual_shared_training_runs': int(prefixes.sum()),
                'observed_full_test_training_runs': int(x.size),
                'counterfactual_prefix_runtime_seconds': prefix_runtime,
                'observed_full_test_runtime_seconds': float(runtimes.sum()),
                'runtime_interpretation': 'Sum of recorded serial run durations; not parallel elapsed time or realized saving',
                'rho_primary_rule': normal_rho(looks[-1])})
        validation.append({'dataset': name, 'valid_rows': len(raw), 'seed_range': [seed0, seed0 + looks[-1] - 1],
                           'frozen_config_matches': True, 'original_reference_intervals_checked': checked})
    csv_write(output / 'real_intervals.csv', all_intervals)
    csv_write(output / 'real_pair_decisions.csv', all_pairs)
    dump(output / 'real_summary.json', {'status': 'retrospective_not_confirmatory', 'summaries': summaries, 'validation': validation})


def synthetic(output, replicates, seed, batch_size):
    result = []
    streams = np.random.SeedSequence(seed).spawn(len(SCENARIOS))
    for (name, means, kind, widths), stream in zip(SCENARIOS, streams):
        start_time = time.monotonic()
        rng = np.random.default_rng(stream)
        records = {}
        for dataset, _, _, looks, _ in DATASETS:
            for method in METHODS:
                records[dataset + '__' + method] = {
                    'covered': np.empty(replicates, bool), 'false_superiority': np.empty(replicates, bool),
                    'any_correct_superiority': np.empty(replicates, bool), 'all_resolved': np.empty(replicates, bool),
                    'shared_runs': np.empty(replicates, np.int16), 'final_mean_width': np.empty(replicates),
                    'terminal': np.empty((replicates, 5, 3), np.int8),
                    'stop_n': np.empty((replicates, 5, 3), np.int16)}
        delta = np.array([means[a] - means[b] for a, b in PAIRS])
        for start in range(0, replicates, batch_size):
            size = min(batch_size, replicates - start)
            if kind == 'uniform':
                x = np.asarray(means)[None, None, :, None] + (rng.random((size, 5, 3, 1000)) * 2 - 1) * np.asarray(widths)[None, None, :, None]
            elif kind == 'shared':
                x = np.repeat(rng.binomial(1, .5, (size, 5, 1, 1000)), 3, axis=2)
            else:
                x = rng.binomial(1, np.asarray(means)[None, None, :, None], (size, 5, 3, 1000))
            all_looks = sorted({n for _, _, _, looks, _ in DATASETS for n in looks})
            full_stats = sufficient_statistics(x, all_looks)
            for dataset, _, _, looks, _ in DATASETS:
                idx = [all_looks.index(n) for n in looks]
                stat = {key: value[..., idx] for key, value in full_stats.items()}
                for method in METHODS:
                    _, lo, hi = pair_intervals(stat, looks, method)
                    terminal, stops, _ = locked_decisions(lo, hi, looks)
                    r = records[dataset + '__' + method]
                    sl = slice(start, start + size)
                    r['covered'][sl] = np.all((lo <= delta[None, None, :, None] + 1e-12) & (hi >= delta[None, None, :, None] - 1e-12), axis=(1, 2, 3))
                    wrong = ((terminal == 1) & (delta <= .05 + 1e-12)) | ((terminal == 2) & (delta >= -.05 - 1e-12))
                    r['false_superiority'][sl] = np.any(wrong, axis=(1, 2))
                    r['any_correct_superiority'][sl] = np.any(((terminal == 1) | (terminal == 2)) & ~wrong, axis=(1, 2))
                    r['all_resolved'][sl] = np.all(terminal != 0, axis=(1, 2))
                    r['shared_runs'][sl] = shared_arm_prefixes(stops).sum(axis=(1, 2))
                    r['final_mean_width'][sl] = (hi[..., -1] - lo[..., -1]).mean(axis=(1, 2))
                    r['terminal'][sl] = terminal
                    r['stop_n'][sl] = stops
            if (start + size) % 2000 == 0:
                print(json.dumps({'scenario': name, 'replicates_done': start + size}), flush=True)
        flat = {key + '__' + field: values for key, fields in records.items() for field, values in fields.items()}
        np.savez_compressed(output / ('replicate_outcomes_' + name + '.npz'), **flat)
        for dataset, _, _, looks, _ in DATASETS:
            reference = records[dataset + '__H-original']
            for method in METHODS:
                r = records[dataset + '__' + method]
                rates = {}
                for field in ('covered', 'false_superiority', 'any_correct_superiority', 'all_resolved'):
                    count = int(r[field].sum())
                    rates[field] = {'count': count, 'total': replicates, 'estimate': count / replicates,
                                    'wilson95': wilson(count, replicates)}
                result.append({'scenario': name, 'means': list(means), 'distribution': kind,
                    'half_widths': widths, 'dataset_plan': dataset, 'looks': list(looks), 'method': method,
                    'rates': rates, 'terminal_counts': {d: int(np.sum(r['terminal'] == i)) for i, d in enumerate(DECISIONS)},
                    'resolved_stop_n_histogram': {str(n): int(np.sum((r['stop_n'] == n) & (r['terminal'] != 0))) for n in looks},
                    'shared_runs': sample_summary(r['shared_runs']), 'final_mean_width': sample_summary(r['final_mean_width']),
                    'paired_shared_runs_difference_vs_original': sample_summary(r['shared_runs'].astype(float) - reference['shared_runs']),
                    'paired_width_difference_vs_original': sample_summary(r['final_mean_width'] - reference['final_mean_width']),
                    'sampling_unit': 'one complete 15-comparison family, not individual pair'})
        print(json.dumps({'scenario': name, 'completed': replicates, 'seconds': round(time.monotonic() - start_time, 3)}), flush=True)
    dump(output / 'simulation_summary.json', {'status': 'model_calibration_not_RL_power',
        'replicates_per_scenario': replicates, 'seed': seed, 'batch_size': batch_size, 'rng': 'NumPy PCG64/SeedSequence',
        'family_comparisons': 15, 'family_alpha_per_method_per_plan': .05,
        'coverage_scope': 'All 15 pairs at all common looks, separately for each method and plan',
        'rows': result})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--replicates', type=int, default=10000)
    parser.add_argument('--seed', type=int, default=20261103)
    parser.add_argument('--batch-size', type=int, default=100)
    parser.add_argument('--real-only', action='store_true')
    args = parser.parse_args()
    if args.replicates < 2 or args.batch_size < 1:
        parser.error('replicates >= 2 and batch-size >= 1 required')
    if args.output.exists():
        parser.error('output directory exists; use a new directory')
    hashes, lock = verify_sources()
    started = time.monotonic()
    args.output.mkdir(parents=True)
    real_data(args.output)
    if not args.real_only:
        synthetic(args.output, args.replicates, args.seed, args.batch_size)
    verify_sources()
    outputs = {p.name: sha(p) for p in args.output.iterdir() if p.is_file()}
    dump(args.output / 'RUN_MANIFEST.json', {
        'status': 'COMPLETED', 'retrospective': True, 'argv': sys.argv[1:], 'input_hashes': hashes,
        'plan_lock': lock, 'output_hashes': outputs, 'python': platform.python_version(),
        'numpy': np.__version__, 'scipy': scipy.__version__, 'platform': platform.platform(),
        'architecture': platform.machine(), 'elapsed_seconds': time.monotonic() - started,
        'raw_training_outputs_modified': False, 'new_RL_training_runs': 0,
        'independent_team_reproduction': False})
    print(json.dumps({'status': 'COMPLETED', 'output': str(args.output), 'seconds': time.monotonic() - started}), flush=True)


if __name__ == '__main__':
    main()

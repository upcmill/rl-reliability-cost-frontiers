import unittest
from budget_calculator import calculate

class BudgetCalculatorTests(unittest.TestCase):
    def test_registered_thresholds(self):
        rows=calculate([5,10,15,20])['rows']
        self.assertEqual([x['necessary_n_for_possible_superiority'] for x in rows],[17,20,22,23])
        self.assertTrue(all(not x['possible_superiority'] and not x['possible_precision'] for x in rows))
    def test_strict_boundary(self):
        self.assertFalse(calculate([1])['rows'][0]['possible_superiority'])
        self.assertEqual(calculate([1])['rows'][0]['maximum_lower_endpoint'],-1.)
    def test_invalid_inputs(self):
        for looks in ([],[0],[5,5],[10,5]):
            with self.assertRaises(ValueError):calculate(looks)
        with self.assertRaises(ValueError):calculate([20],margin=1)
        with self.assertRaises(ValueError):calculate([20],comparisons=0)

if __name__=='__main__':unittest.main()

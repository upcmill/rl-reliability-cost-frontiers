#!/usr/bin/env python3
"""Check that the English and Chinese Word manuscripts retain key claims."""

from __future__ import annotations

from pathlib import Path

from docx import Document


ROOT = Path(__file__).resolve().parent


def document_text(path: Path) -> str:
    document = Document(path)
    return "\n".join(paragraph.text for paragraph in document.paragraphs)


def main() -> None:
    checks = {
        "MANUSCRIPT_MACHINE_LEARNING_CORE_EN.docx": (
            "Proposition 0",
            "Corollary 0",
            "Corollary 4",
            "Corollary 5",
            "Proposition 2",
            "Proposition 3",
            "Definition 1",
            "15-comparison family",
            "candidate configurations",
            "0.05/15",
            "known-block dependence fallback",
            "Reliability--cost frontier",
            "Pre-study budget feasibility audit",
            "BUDGET_FEASIBILITY_AUDIT_V3.json",
            "0.058429",
            "VALIDATION_TUNING_COST_V3.json",
            "208.671",
        ),
        "MANUSCRIPT_MACHINE_LEARNING_EN.docx": (
            "Proposition 0",
            "Corollary 0",
            "Corollary 4",
            "Corollary 5",
            "Proposition 2",
            "Proposition 3",
            "Definition 1",
            "Validation-selected alpha-spending diagnostic",
            "15-comparison family",
            "candidate configurations",
            "0.05/15",
            "Known-block dependence fallback diagnostic",
            "Reliability--cost frontier",
            "Pre-study budget feasibility audit",
            "BUDGET_FEASIBILITY_AUDIT_V3.json",
            "0.058429",
            "VALIDATION_TUNING_COST_V3.json",
            "208.671",
        ),
        "MANUSCRIPT_MACHINE_LEARNING_ZH.docx": (
            "命题 0",
            "推论 0",
            "推论 4",
            "推论 5",
            "命题 2",
            "命题 3",
            "定义 1",
            "验证后选择 alpha 支出诊断",
            "十五个比较族",
            "四个候选配置",
            "0.05/15",
            "已知块依赖回退诊断",
            "可靠性—成本前沿",
            "事前预算可行性审计",
            "BUDGET_FEASIBILITY_AUDIT_V3.json",
            "0.058429",
            "VALIDATION_TUNING_COST_V3.json",
            "208.671",
        ),
    }
    for filename, markers in checks.items():
        text = document_text(ROOT / filename)
        missing = [marker for marker in markers if marker not in text]
        if missing:
            raise SystemExit(f"{filename}: missing manuscript anchors: {missing}")
    print("Word manuscript parity audit: PASS")
    print("English and Chinese manuscripts contain the theory, family-control, selection-boundary, validation-tuning-cost, and pre-study-feasibility anchors.")


if __name__ == "__main__":
    main()

import math
import unittest

from minimax_alpha_spending import minimax_allocations


class MinimaxAlphaSpendingTests(unittest.TestCase):
    def test_allocations_use_the_full_budget(self):
        result = minimax_allocations([5, 10, 15, 20], 0.05 / 15.0)
        self.assertAlmostEqual(result["allocation_sum"], 0.05 / 15.0, places=12)

    def test_radius_sums_are_equalized(self):
        result = minimax_allocations([5, 10, 15, 20], 0.05 / 15.0)
        radii = result["radius_sums"]
        self.assertLess(max(radii) - min(radii), 1e-10)

    def test_allocations_are_positive_and_bounded(self):
        result = minimax_allocations([5, 10, 15, 20], 0.05 / 15.0)
        self.assertTrue(all(value > 0.0 for value in result["allocations"]))
        self.assertTrue(all(value < 1.0 for value in result["allocations"]))


if __name__ == "__main__":
    unittest.main()

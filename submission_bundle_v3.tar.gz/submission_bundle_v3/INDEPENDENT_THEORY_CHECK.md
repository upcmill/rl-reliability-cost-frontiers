# Independent Theory Reimplementation Check

This report recomputes the v3 finite-look numerical consequences in a
separate implementation without importing the production interval or
budget-planning helpers. All listed checks match `THEORY_AUDIT_V3.json`.
It is an internal second implementation, not an external statistical
review and not a proof of seed independence or external reproducibility.

- Status: `PASS`
- Comparison alpha: `0.0033333333333333335`
- Looks: `[1, 2, 3, 4]`
- Recomputed radius sums: `[1.7421569548403883, 1.3397067962331703, 1.1422201606569, 1.0178588242230167]`
- Recomputed possible-superiority thresholds: `[17, 20, 22, 23]`

The implementation agrees with the reference audit on alpha spending,
radius values, width thresholds, balanced total-budget thresholds, and
the formal v3 non-resolution boundary.

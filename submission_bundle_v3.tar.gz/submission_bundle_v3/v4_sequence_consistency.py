#!/usr/bin/env python3
"""Compare the two disclosed queue seed sequences without pooling inference."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parent
ALPHA_CMP = 0.05 / 15
MARGIN = 0.05


def interval(values_a: list[float], values_b: list[float], look: int) -> dict[str, float | int | str]:
    n_a, n_b = len(values_a), len(values_b)
    alpha_k = ALPHA_CMP * 6.0 / (math.pi**2 * look**2)
    radius_a = math.sqrt(math.log(4.0 / alpha_k) / (2.0 * n_a))
    radius_b = math.sqrt(math.log(4.0 / alpha_k) / (2.0 * n_b))
    estimate = mean(values_a) - mean(values_b)
    lower = max(-1.0, estimate - radius_a - radius_b)
    upper = min(1.0, estimate + radius_a + radius_b)
    decision = "a_superior" if lower > MARGIN else "max_budget_inconclusive"
    return {
        "n": n_a,
        "estimate": estimate,
        "lower": lower,
        "upper": upper,
        "decision": decision,
        "mean_dqn": mean(values_a),
        "mean_a2c": mean(values_b),
    }


def load(path: Path, seed_limit: int) -> dict[str, float | int | str]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    rows = [row for row in rows if row.get("env_id") == "NonstationaryQueue-v0" and row.get("algorithm") in {"DQN", "A2C"}]
    by_algorithm: dict[str, list[float]] = {"DQN": [], "A2C": []}
    for row in rows:
        if int(row["seed"]) < seed_limit:
            by_algorithm[row["algorithm"]].append(float(row["metric_normalized"]))
    if len(by_algorithm["DQN"]) != seed_limit or len(by_algorithm["A2C"]) != seed_limit:
        raise ValueError(f"{path}: expected {seed_limit} rows per algorithm")
    look = 1 if seed_limit == 200 else 2
    return interval(by_algorithm["DQN"], by_algorithm["A2C"], look)


def main() -> None:
    sources = {
        "post_v3_prefix_followup": ROOT / "sb3_queue_budget_followup_v1/raw_seed_metrics.csv",
        "prospective_v4_new_seeds": ROOT / "sb3_v4_extension/raw_seed_metrics.csv",
    }
    rows = []
    for name, path in sources.items():
        for n in (200, 400):
            result = load(path, n)
            rows.append({"sequence": name, "look": n, **result})
    payload = {
        "status": "PASS",
        "scope": "descriptive cross-sequence consistency; no pooled inference",
        "alpha_cmp": ALPHA_CMP,
        "margin": MARGIN,
        "rows": rows,
        "interpretation": {
            "supported": [
                "Both disclosed queue sequences have positive DQN-minus-A2C estimates at n=200 and n=400.",
                "The v4 sequence is terminal at n=200; its n=400 value is descriptive continuation only.",
            ],
            "not_supported": [
                "independent-team or different-machine reproducibility",
                "pooled confirmatory inference across the two sequences",
                "universal seed requirements or general algorithm ranking",
            ],
        },
    }
    (ROOT / "V4_SEQUENCE_CONSISTENCY.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# V4 Queue Sequence Consistency Diagnostic",
        "",
        "This report compares two disclosed queue seed sequences without pooling their observations or changing either stopping rule.",
        "The post-v3 follow-up reuses the v3 20-seed prefix; the v4 sequence uses new seeds 30000--30399.",
        "",
        "| Sequence | n | DQN mean | A2C mean | Estimate (DQN - A2C) | Interval | Decision/status |",
        "|---|---:|---:|---:|---:|---|---|",
    ]
    for row in rows:
        status = row["decision"] if not (row["sequence"] == "prospective_v4_new_seeds" and row["look"] == 400) else "descriptive continuation; terminal decision locked at n=200"
        lines.append(
            f"| {row['sequence']} | {row['n']} | {row['mean_dqn']:.6f} | {row['mean_a2c']:.6f} | {row['estimate']:.6f} | [{row['lower']:.6f}, {row['upper']:.6f}] | {status} |"
        )
    lines.extend([
        "",
        "Both sequences have a positive DQN-minus-A2C estimate at 200 and 400 seeds. This is a descriptive consistency check for one controlled task and two frozen procedures.",
        "The v4 400-seed value is not a second decision: the predeclared state machine stopped at 200 and the terminal state remains locked.",
        "The result does not support pooled confirmatory inference, external reproducibility, a universal seed requirement, or a general algorithm ranking.",
        "",
        "Machine-readable output: `V4_SEQUENCE_CONSISTENCY.json`; source: `v4_sequence_consistency.py`.",
    ])
    (ROOT / "V4_SEQUENCE_CONSISTENCY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("V4 sequence consistency: PASS")
    print("V4_SEQUENCE_CONSISTENCY.md")
    print("V4_SEQUENCE_CONSISTENCY.json")


if __name__ == "__main__":
    main()

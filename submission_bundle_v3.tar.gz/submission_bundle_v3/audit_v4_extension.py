#!/usr/bin/env python3
"""Audit the prospective v4 new-seed extension and write a report."""

from __future__ import annotations

import csv
import hashlib
import json
import statistics
from itertools import combinations
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "sb3_v4_extension"
REFERENCE = ROOT / "sb3_formal_v3"
ENVIRONMENTS = ("CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0")
ALGORITHMS = ("PPO", "DQN", "A2C")


def main() -> None:
    metadata = json.loads((RUN / "run_config.json").read_text(encoding="utf-8"))
    rows = list(csv.DictReader((RUN / "raw_seed_metrics.csv").open(newline="", encoding="utf-8")))
    reference = json.loads((REFERENCE / "summary.json").read_text(encoding="utf-8"))["summary"]
    assert metadata["status"] == "v4_prospective_new_seed_extension"
    assert len(rows) == 6000, len(rows)
    assert {row["env_id"] for row in rows} == set(ENVIRONMENTS)
    assert {row["algorithm"] for row in rows} == set(ALGORITHMS)
    assert {row["split"] for row in rows} == {"extension_test"}
    assert {int(row["seed"]) for row in rows} == set(range(400))
    assert {int(row["train_seed"]) for row in rows} == set(range(30000, 30400))
    assert all(0.0 <= float(row["metric_normalized"]) <= 1.0 for row in rows)
    assert not ({int(row["train_seed"]) for row in rows} & set(range(20000, 20400)))

    values = {}
    selected = {}
    for env_id in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            key = f"{env_id}:{algorithm}"
            selected[key] = reference[key]["selected_config"]
            cell = [row for row in rows if row["env_id"] == env_id and row["algorithm"] == algorithm]
            assert len(cell) == 400, key
            assert {row["config_id"] for row in cell} == {selected[key]}, key
            values[(env_id, algorithm)] = [float(row["metric_normalized"]) for row in sorted(cell, key=lambda item: int(item["seed"]))]

    config = ProtocolConfig(
        alpha=0.05 / 15,
        practical_margin=0.05,
        initial_seeds=200,
        batch_size=200,
        max_seeds=400,
        target_width=0.10,
        interval_method="hoeffding_unpaired",
        bootstrap_resamples=1000,
    )
    recomputed = {}
    for env_id in ENVIRONMENTS:
        for algorithm_a, algorithm_b in combinations(ALGORITHMS, 2):
            recomputed[f"{env_id}:{algorithm_a}_vs_{algorithm_b}"] = sequential_decision(
                values[(env_id, algorithm_a)], values[(env_id, algorithm_b)], config
            )
    metadata_decisions = metadata["stop_traces"][-1]["decisions"]
    assert metadata_decisions == recomputed

    descriptive = {}
    for (env_id, algorithm), metric in values.items():
        descriptive[f"{env_id}:{algorithm}"] = {
            "n": len(metric),
            "mean": statistics.fmean(metric),
            "sample_sd": statistics.stdev(metric),
            "median": statistics.median(metric),
            "minimum": min(metric),
            "maximum": max(metric),
            "runtime_seconds": sum(float(row["runtime_seconds"]) for row in rows if row["env_id"] == env_id and row["algorithm"] == algorithm),
        }
    decisions = {key: value["decision"] for key, value in recomputed.items()}
    payload = {
        "status": "PASS",
        "rows": len(rows),
        "cell_count": len(descriptive),
        "new_seed_range": "30000-30399",
        "selected_configurations_match_v3": True,
        "no_seed_overlap_with_v3_or_queue_followup": True,
        "descriptive": descriptive,
        "recomputed_decisions": recomputed,
        "decision_counts": {state: list(decisions.values()).count(state) for state in sorted(set(decisions.values()))},
        "sha256": {
            "raw_seed_metrics.csv": hashlib.sha256((RUN / "raw_seed_metrics.csv").read_bytes()).hexdigest(),
            "run_config.json": hashlib.sha256((RUN / "run_config.json").read_bytes()).hexdigest(),
            "v4_prospective_extension.py": hashlib.sha256((ROOT / "v4_prospective_extension.py").read_bytes()).hexdigest(),
            "FINAL_PREREGISTRATION_V4_EXTENSION.md": hashlib.sha256((ROOT / "FINAL_PREREGISTRATION_V4_EXTENSION.md").read_bytes()).hexdigest(),
        },
        "interpretation": {
            "scope": "prospective new-seed extension with frozen v3-selected configurations",
            "positive_decision": "NonstationaryQueue-v0 DQN_vs_A2C at n=200",
            "not_supported": ["universal seed requirement", "general algorithm ranking", "external reproducibility"],
        },
    }
    (ROOT / "V4_EXTENSION_AUDIT.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    table_rows = []
    for key, result in recomputed.items():
        table_rows.append(f"| {key.replace(':', ' / ').replace('_vs_', ' − ')} | {result['n']} | {result['estimate']:.6f} | [{result['lower']:.6f}, {result['upper']:.6f}] | `{result['decision']}` |")
    report = """# Prospective v4 Seed-Budget Extension Report

This report audits the new-seed extension defined in
`FINAL_PREREGISTRATION_V4_EXTENSION.md`. It is separate from the v3 primary
analysis and is not a different-machine replication.

## Data integrity

The extension contains 6,000 rows: five tasks, three algorithms, and 400 test
seeds per cell. Training seeds are exactly 30000--30399 and do not overlap the
v3 or queue-follow-up ranges. Every cell uses the configuration selected by the
v3 validation stage; no extension tuning or test-data selection was performed.
All normalized metrics are in `[0,1]` and the full raw CSV is retained.

## Decisions

| Comparison | n at terminal/cap | Estimate | Family-adjusted interval | Decision |
|---|---:|---:|---|---|
""" + "\n".join(table_rows) + """

Only `NonstationaryQueue-v0` DQN−A2C reached a terminal superiority decision,
at the first 200-seed look (estimate `0.345322`, interval
`[0.069863, 0.620781]`). The remaining 14 comparisons reached the 400-seed cap
without superiority or target-precision decisions. The positive queue result
is evidence for this new seed sequence, fixed configuration, task, and budget;
it is not a general DQN ranking or a universal seed requirement.

The machine-readable audit is `V4_EXTENSION_AUDIT.json`; raw rows, source
hashes, and runtime metadata are in `sb3_v4_extension/`.
"""
    (ROOT / "V4_EXTENSION_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

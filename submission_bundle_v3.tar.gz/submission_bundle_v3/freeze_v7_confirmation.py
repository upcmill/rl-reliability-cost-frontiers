#!/usr/bin/env python3
"""Create the immutable source-hash lock for the V7 new-seed validation."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOCK = ROOT / "V7_CONFIRMATION_LOCK.json"
SOURCES = (
    "V7_PROSPECTIVE_VALIDATION_PLAN.md",
    "freeze_v7_confirmation.py",
    "v7_confirmatory_runner.py",
    "analyze_v7_confirmation.py",
    "test_v7_confirmation_analysis.py",
    "modern_sequential_intervals.py",
    "sb3_pilot.py",
    "sequential_sb3_runner_v3.py",
    "nonstationary_queue_env.py",
    "sb3_formal_v3/summary.json",
    "sb3_v5_extension/run_config.json",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    if LOCK.exists():
        raise SystemExit(f"refusing to overwrite frozen lock: {LOCK}")
    missing = [name for name in SOURCES if not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"missing frozen sources: {missing}")
    payload = {"status": "FROZEN_BEFORE_V7_SEED_GENERATION",
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed_range_inclusive": [31400, 32399],
        "hashes": {name: sha(ROOT / name) for name in SOURCES}}
    LOCK.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

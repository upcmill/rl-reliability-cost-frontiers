# v3 Descriptive Effect-Size Table

Generated from the frozen selected-configuration test metrics. The rows are descriptive and do not replace the primary family-wise intervals.

`mean_diff` is mean(A) - mean(B); `Cliff_delta` counts pairwise wins minus losses divided by 400; `standardized_diff` uses the pooled sample SD and is set to 0 when both sample SDs are zero.

| Environment | Comparison | Mean difference | Cliff delta | Standardized difference | Pooled SD |
|---|---|---:|---:|---:|---:|
| CartPole-v1 | PPO - DQN | 0.189420 | 1.000000 | 4.258948 | 0.044476 |
| CartPole-v1 | PPO - A2C | 0.012945 | 0.210000 | 0.212120 | 0.061027 |
| CartPole-v1 | DQN - A2C | -0.176475 | -1.000000 | -3.974165 | 0.044406 |
| Acrobot-v1 | PPO - DQN | -0.073785 | -0.115000 | -0.326542 | 0.225959 |
| Acrobot-v1 | PPO - A2C | 0.024175 | 0.020000 | 0.131986 | 0.183163 |
| Acrobot-v1 | DQN - A2C | 0.097960 | 0.135000 | 0.465278 | 0.210541 |
| MountainCar-v0 | PPO - DQN | -0.005687 | -0.100000 | -0.344475 | 0.016511 |
| MountainCar-v0 | PPO - A2C | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| MountainCar-v0 | DQN - A2C | 0.005687 | 0.100000 | 0.344475 | 0.016511 |
| Taxi-v4 | PPO - DQN | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| Taxi-v4 | PPO - A2C | 0.217571 | 0.650000 | 1.401326 | 0.155260 |
| Taxi-v4 | DQN - A2C | 0.217571 | 0.650000 | 1.401326 | 0.155260 |
| NonstationaryQueue-v0 | PPO - DQN | -0.130016 | -0.575000 | -0.817866 | 0.158969 |
| NonstationaryQueue-v0 | PPO - A2C | 0.169602 | 0.312500 | 0.620067 | 0.273521 |
| NonstationaryQueue-v0 | DQN - A2C | 0.299617 | 0.747500 | 1.346043 | 0.222591 |

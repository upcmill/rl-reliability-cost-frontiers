import itertools
import math
import unittest

import numpy as np

from round3_diagnostics import exact_runs, holm, radius, sequential_counts, spendings
from reference_sequential_interval import decide, unpaired_hoeffding_interval


class Round3DiagnosticsTests(unittest.TestCase):
    def test_runs_matches_exhaustive_permutations(self):
        seq=[0.,0.,0.,1.,1.,1.]
        d=exact_runs(seq)
        permutations=set(itertools.permutations(seq))
        expected=1+2*3*3/6
        observed=2
        count=sum(abs(1+sum(a!=b for a,b in zip(p,p[1:]))-expected)>=abs(observed-expected) for p in permutations)
        self.assertEqual(d['p'],count/len(permutations))

    def test_constant_is_not_evidence_of_independence(self):
        self.assertEqual(exact_runs([.5]*20)['status'],'undefined_degenerate')

    def test_equal_median_ties_are_dropped(self):
        result=exact_runs([0.,.5,.5,1.])
        self.assertEqual(result['ties_dropped'],2)
        self.assertEqual(result['p'],1.)

    def test_spending_budgets_and_normalization(self):
        for k in (2,4,8):
            for name in ('original_summable','front_loaded','uniform','back_loaded'):
                a=spendings(k,.05/15,name)
                self.assertLessEqual(sum(a),.05/15+1e-15)
                if name!='original_summable':self.assertAlmostEqual(sum(a),.05/15)

    def test_primary_budget_cannot_resolve_even_extreme_data(self):
        a=spendings(4,.05/15,'original_summable')
        ca=np.array([np.arange(1,21)])
        cb=np.zeros((1,20))
        result=sequential_counts(ca,cb,[5,10,15,20],a,1.)
        self.assertEqual(result['unresolved'],1)
        for n,ak in zip((5,10,15,20),a):
            self.assertGreaterEqual(radius(n,ak),.95)

    def test_strong_effect_positive_control(self):
        ca=np.array([np.arange(1,1001)])
        cb=np.zeros((1,1000))
        result=sequential_counts(ca,cb,[200,400,600,800,1000],spendings(5,.05/15,'original_summable'),1.)
        self.assertEqual(result['a_superior'],1)
        self.assertEqual(result['sum_terminal_n'],200)
        self.assertEqual(result['false_superiority'],0)

    def test_margin_boundary_counts_false_superiority(self):
        ca=np.array([np.arange(1,1001)])
        cb=np.zeros((1,1000))
        result=sequential_counts(ca,cb,[1000],spendings(1,.05/15,'original_summable'),.55-.5)
        self.assertEqual(result['false_superiority'],1)

    def test_holm_adjustment(self):
        self.assertEqual(holm([.01,.04,.03]),[.03,.06,.06])
        self.assertEqual(holm([1.,1.]),[1.,1.])

    def test_vectorized_simulation_matches_reference_replay(self):
        rng=np.random.default_rng(17)
        a=rng.binomial(1,.9,(20,200))
        b=rng.binomial(1,.5,(20,200))
        looks=[50,100,150,200]
        alphas=spendings(4,.05/15,'original_summable')
        counts={'a_superior':0,'b_superior':0,'precision_only':0,'unresolved':0}
        total_n=0
        for x,y in zip(a,b):
            final='unresolved';last_n=200
            for n,alpha in zip(looks,alphas):
                _,lo,hi=unpaired_hoeffding_interval(x[:n].tolist(),y[:n].tolist(),alpha)
                d=decide(lo,hi,.05,.10)
                if d!='continue':final=d;last_n=n;break
            counts[final]+=1;total_n+=last_n
        actual=sequential_counts(np.cumsum(a,axis=1),np.cumsum(b,axis=1),looks,alphas,.4)
        self.assertEqual({k:actual[k] for k in counts},counts)
        self.assertEqual(actual['sum_terminal_n'],total_n)


if __name__ == '__main__':
    unittest.main()

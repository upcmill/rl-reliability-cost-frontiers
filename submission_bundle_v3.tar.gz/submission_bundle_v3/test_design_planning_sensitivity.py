#!/usr/bin/env python3
"""Tests for the deterministic family-size planning diagnostic."""

from __future__ import annotations

import json
import unittest
from pathlib import Path

from generate_design_planning_sensitivity import (
    build_payload,
    look_alpha,
    radius_sum,
    width_seeds,
)


class DesignPlanningSensitivityTests(unittest.TestCase):
    def test_radius_increases_with_family_size(self) -> None:
        values = [radius_sum(0.05, m, 4, 20) for m in (1, 3, 9, 15, 30)]
        self.assertEqual(values, sorted(values))
        self.assertEqual(values, sorted(values, reverse=False))

    def test_alpha_is_exactly_partitioned(self) -> None:
        self.assertAlmostEqual(look_alpha(0.05, 15, 1), 0.0020264236728467556)

    def test_generated_artifact_matches_formula(self) -> None:
        payload = json.loads(
            Path("DESIGN_PLANNING_SENSITIVITY_V3.json").read_text(encoding="utf-8")
        )
        self.assertEqual(payload["status"], "analytic_family_size_sensitivity_only")
        self.assertEqual(len(payload["rows"]), 20)
        row = next(item for item in payload["rows"] if item["comparisons"] == 15 and item["look"] == 4)
        self.assertAlmostEqual(row["radius_sum"], radius_sum(0.05, 15, 4, 20))
        self.assertEqual(
            row["seeds_per_algorithm_for_width_target"], width_seeds(0.05, 15, 4, 0.10)
        )
        self.assertGreater(row["necessary_seeds_for_possible_superiority"], 20)

    def test_payload_is_deterministic(self) -> None:
        payload = build_payload(0.05, [1, 15], [1, 4], 0.05, 0.10, 20)
        self.assertEqual(payload["rows"][0]["comparisons"], 1)
        self.assertEqual(payload["rows"][-1]["look"], 4)


if __name__ == "__main__":
    unittest.main()

"""Generate Springer Machine Learning submission-oriented Word manuscripts.

The source of truth remains MANUSCRIPT_DRAFT_V3.md and the recorded artifacts.
This script only formats the material; it does not add experimental claims.
"""

from __future__ import annotations

import re
import os
from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get("ML_MANUSCRIPT_SOURCE", ROOT / "MANUSCRIPT_DRAFT_V3.md"))
FIGURES = ROOT / "manuscript_figures"

EN_REFERENCES = [
    "[L1] Henderson, P., Islam, R., Bachman, P., Pineau, J., Precup, D., & Meger, D. (2018). Deep Reinforcement Learning That Matters. Proceedings of the AAAI Conference on Artificial Intelligence, 32(1). https://doi.org/10.1609/aaai.v32i1.11694",
    "[L2] Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2018). How Many Random Seeds? Statistical Power Analysis in Deep Reinforcement Learning Experiments. arXiv:1806.08295. https://doi.org/10.48550/arXiv.1806.08295",
    "[L3] Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2019). A Hitchhiker's Guide to Statistical Comparisons of Reinforcement Learning Algorithms. arXiv:1904.06979. https://doi.org/10.48550/arXiv.1904.06979",
    "[L4] Agarwal, R., Schwarzer, M., Castro, P. S., Courville, A., & Bellemare, M. G. (2021). Deep Reinforcement Learning at the Edge of the Statistical Precipice. arXiv:2108.13264. https://doi.org/10.48550/arXiv.2108.13264. Final venue status [待核实].",
    "[L5] Hoeffding, W. (1963). Probability Inequalities for Sums of Bounded Random Variables. Journal of the American Statistical Association, 58(301), 13–30. https://doi.org/10.1080/01621459.1963.10500830",
    "[L6] Lan, K. K. G., & DeMets, D. L. (1983). Discrete Sequential Boundaries for Clinical Trials. Biometrika, 70(3), 659–663. https://doi.org/10.1093/biomet/70.3.659",
    "[L7] Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017). Proximal Policy Optimization Algorithms. arXiv:1707.06347. https://arxiv.org/abs/1707.06347",
    "[L8] Mnih, V., et al. (2015). Human-level control through deep reinforcement learning. Nature, 518, 529–533. https://doi.org/10.1038/nature14236",
    "[L9] Mnih, V., et al. (2016). Asynchronous Methods for Deep Reinforcement Learning. Proceedings of the 33rd International Conference on Machine Learning. https://arxiv.org/abs/1602.01783",
    "[L10] Towers, M., et al. (2025). Gymnasium: A Standard Interface for Reinforcement Learning Environments. Advances in Neural Information Processing Systems 38, 163114–163129. https://doi.org/10.52202/085713-4916",
    "[L11] Whiteson, S., Tanner, B., Taylor, M. E., & Stone, P. (2011). Protecting against evaluation overfitting in empirical reinforcement learning. 2011 IEEE Symposium on Adaptive Dynamic Programming and Reinforcement Learning (ADPRL), 120–127. https://doi.org/10.1109/ADPRL.2011.5967363. Full-text method comparison [待核实].",
    "[L12] Raffin, A., Hill, A., Gleave, A., Kanervisto, A., Ernestus, M., & Dorman, N. (2021). Stable-Baselines3: Reliable Reinforcement Learning Implementations. Journal of Machine Learning Research, 22(268), 1–8. https://jmlr.org/papers/v22/20-1364.html",
    "[L13] Zhang, C., Vinyals, O., Munos, R., & Bengio, S. (2018). A Study on Overfitting in Deep Reinforcement Learning. arXiv:1804.06893v2. https://doi.org/10.48550/arXiv.1804.06893",
    "[L14] Nagarajan, P., Warnell, G., & Stone, P. (2018). Deterministic Implementations for Reproducibility in Deep Reinforcement Learning. arXiv:1809.05676v5. https://doi.org/10.48550/arXiv.1809.05676",
    "[L15] Chan, S. C. Y., Fishman, S., Canny, J., Korattikara, A., & Guadarrama, S. (2019). Measuring the Reliability of Reinforcement Learning Algorithms. arXiv:1912.05663v2. https://doi.org/10.48550/arXiv.1912.05663",
    "[L16] Khamaru, K., Xia, E., Wainwright, M. J., & Jordan, M. I. (2022). Instance-Dependent Confidence and Early Stopping for Reinforcement Learning. arXiv:2201.08536. https://doi.org/10.48550/arXiv.2201.08536",
]


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_text(cell, text: str, bold: bool = False) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(text)
    run.bold = bold
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(9)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_page_number(paragraph) -> None:
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)


def configure_document(doc: Document, chinese: bool) -> None:
    section = doc.sections[0]
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(2.54)
    section.right_margin = Cm(2.54)
    section.header_distance = Cm(1.27)
    section.footer_distance = Cm(1.27)

    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman" if not chinese else "宋体"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体" if chinese else "Times New Roman")
    normal.font.size = Pt(11)
    normal.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.first_line_indent = Cm(0.5)

    for name, size, color in (("Title", 16, "1F1F1F"), ("Heading 1", 13, "1F1F1F"),
                              ("Heading 2", 11, "1F1F1F"), ("Heading 3", 11, "1F1F1F")):
        style = doc.styles[name]
        style.font.name = "Times New Roman" if not chinese else "黑体"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体" if chinese else "Times New Roman")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(12 if name != "Title" else 0)
        style.paragraph_format.space_after = Pt(6)

    if "Table Caption" not in [s.name for s in doc.styles]:
        caption = doc.styles.add_style("Table Caption", WD_STYLE_TYPE.PARAGRAPH)
    else:
        caption = doc.styles["Table Caption"]
    caption.font.name = "Times New Roman" if not chinese else "宋体"
    caption._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体" if chinese else "Times New Roman")
    caption.font.size = Pt(10)
    caption.font.bold = True
    caption.paragraph_format.space_before = Pt(6)
    caption.paragraph_format.space_after = Pt(3)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = header.add_run("Machine Learning | Submission preparation draft" if not chinese else "Machine Learning | 投稿准备稿")
    run.font.size = Pt(8)
    run.font.name = "Times New Roman" if not chinese else "宋体"
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run("Page ") if not chinese else footer.add_run("第 ")
    run.font.size = Pt(8)
    add_page_number(footer)
    if chinese:
        r = footer.add_run(" 页")
        r.font.size = Pt(8)


def clean_inline(text: str) -> str:
    text = re.sub(r"!\[([^]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", text)
    text = text.replace("**", "").replace("__", "")
    text = text.replace("`", "")
    text = text.replace("\\[", "[").replace("\\]", "]")
    # The Word generator does not typeset inline LaTeX. Convert the small
    # notation subset used in prose so the document never exposes `$...$`
    # delimiters or backslash-heavy source code to readers.
    text = text.replace("$", "")
    text = re.sub(r"\\(?:mathrm|operatorname|text|mathbb)\{([^{}]*)\}", r"\1", text)
    text = re.sub(r"\\frac\{([^{}]*)\}\{([^{}]*)\}", r"(\1)/(\2)", text)
    replacements = {
        r"\\Delta": "Δ", r"\\alpha": "α", r"\\pi": "π",
        r"\\in": "∈", r"\\leq": "≤", r"\\geq": "≥",
        r"\\mid": "|", r"\\cap": "∩", r"\\times": "×",
        r"\\sum": "sum", r"\\sqrt": "sqrt", r"\\exp": "exp",
        r"\\left": "", r"\\right": "", r"\\qquad": " ", r"\\,": " ",
        r"\\{": "{", r"\\}": "}", r"\\_": "_",
    }
    for pattern, replacement in replacements.items():
        text = re.sub(pattern, replacement, text)
    text = text.replace(r"\ ", " ").replace("Longrightarrow", "=>").replace(r"\ ", " ").replace(r"\=>", "=>")
    text = re.sub(r"\\([A-Za-z]+)", r"\1", text)
    return text.strip()


def parse_table(lines: list[str]) -> tuple[list[str], list[list[str]]]:
    rows = []
    for line in lines:
        if not line.strip() or set(line.strip()) <= {"|", "-", ":", " "}:
            continue
        cells = [clean_inline(x.strip()) for x in line.strip().strip("|").split("|")]
        rows.append(cells)
    return (rows[0], rows[1:]) if rows else ([], [])


def add_table(doc: Document, headers: list[str], rows: list[list[str]], caption: str | None = None) -> None:
    if caption:
        p = doc.add_paragraph(caption, style="Table Caption")
        p.paragraph_format.first_line_indent = Cm(0)
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.autofit = True
    for i, header in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], header, bold=True)
        set_cell_shading(table.rows[0].cells[i], "D9E2F3")
    for row in rows:
        cells = table.add_row().cells
        for i in range(len(headers)):
            set_cell_text(cells[i], row[i] if i < len(row) else "")
    for row in table.rows:
        for cell in row.cells:
            cell.margin_top = 60
            cell.margin_bottom = 60
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_body_paragraph(doc: Document, text: str, chinese: bool = False, style: str | None = None) -> None:
    p = doc.add_paragraph(style=style)
    p.paragraph_format.first_line_indent = Cm(0.5) if style is None else Cm(0)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    p.add_run(clean_inline(text))


def add_figure(doc: Document, filename: str, caption: str, chinese: bool = False) -> None:
    path = FIGURES / filename
    if not path.exists():
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run()
    run.add_picture(str(path), width=Cm(16.0))
    cap = doc.add_paragraph(caption, style="Table Caption")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.first_line_indent = Cm(0)
    cap.paragraph_format.space_after = Pt(8)


def add_formula_block(doc: Document, chinese: bool = False) -> None:
    formulas = [
        ("Estimand:" if not chinese else "估计对象：", "Δ(e,a,b) = E[Z(e,a,S) | D_val] − E[Z(e,b,S') | D_val]"),
        ("Normalized curve metric:" if not chinese else "归一化学习曲线指标：", "Z(e,a,s) = (1/4) Σ[t ∈ {1024, 2048, 3072, 4096}] NormReturn(e,a,s,t),   0 ≤ Z ≤ 1"),
        ("Comparison-level alpha spending:" if not chinese else "比较级 alpha 支出：", "α_k = α_cmp · 6/(π² k²),   α_cmp = 0.05/15"),
        ("Unpaired Hoeffding interval:" if not chinese else "无配对 Hoeffding 区间：", "I_k = [x̄_k − ȳ_k − r_A,k − r_B,k,  x̄_k − ȳ_k + r_A,k + r_B,k] ∩ [−1,1]"),
        ("Radius:" if not chinese else "区间半径：", "r_A,k = √(log(4/α_k)/(2 n_A,k)),   r_B,k = √(log(4/α_k)/(2 n_B,k))"),
        ("Worst-case equal-sample width:" if not chinese else "等样本最坏情形区间宽度：", "W(n,k) = 4 √(log(4/α_k)/(2n))"),
    ]
    for label, equation in formulas:
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(2)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(f"{label}  {equation}")
        r.font.name = "Cambria Math" if not chinese else "宋体"
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        r.font.size = Pt(10)


def add_front_matter(doc: Document, chinese: bool) -> None:
    title = "强化学习算法序贯评估的可靠性—成本前沿" if chinese else "Reliability--Cost Frontiers for Sequential Evaluation of Reinforcement Learning Algorithms"
    p = doc.add_paragraph(style="Title")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.add_run(title)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    r = p.add_run("Machine Learning（Springer）投稿准备稿；作者、单位和通讯作者信息待补充" if chinese
                  else "Submission-oriented manuscript for Machine Learning (Springer); author, affiliation, and corresponding-author fields to be completed")
    r.italic = True
    r.font.size = Pt(10)

    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)
    p.add_run("Formatting note: this is a single-column Springer-style preparation layout. Exact journal template, article type, indexing, and submission metadata must be checked on the submission date [待核实]." if not chinese else
              "版式说明：本文件采用单栏 Springer 风格投稿准备版式。具体期刊模板、文章类型、收录状态和投稿元数据需在投稿当日核对[待核实]。")
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.runs[0].font.size = Pt(9)

    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)
    p.add_run("Author(s): [待补充]    Affiliation(s): [待补充]    Corresponding author: [待补充]")
    p.runs[0].font.size = Pt(10)


def add_english_source(doc: Document) -> None:
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    i = 0
    table_index = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line:
            i += 1
            continue
        if line.startswith("# "):
            i += 1
            continue
        if line.startswith("## ") or line.startswith("### "):
            level = 1 if line.startswith("## ") else 2
            text = clean_inline(line.split(" ", 1)[1])
            doc.add_paragraph(text, style=f"Heading {level}")
            if text == "3. Estimand and Statistical Protocol":
                add_formula_block(doc, chinese=False)
            elif text == "4. Experimental Design":
                add_figure(doc, "fig_protocol.png", "Figure 1. Preregistered nested evaluation protocol and sealed-test decision schedule.")
            elif text == "5.2 Descriptive test means":
                add_figure(doc, "fig_heatmap.png", "Figure 2. Descriptive normalized test means for the selected configurations (n = 20 per cell); this figure is not an algorithm ranking.")
            elif text == "5.3 Formal intervals":
                add_figure(doc, "fig_intervals.png", "Figure 3. Point estimates and family-adjusted intervals for the 15 primary comparisons. All decisions were max_budget_inconclusive at n = 20.")
            elif text == "5.5.1 Validation-selection resampling diagnostic":
                add_figure(doc, "fig_selection_uncertainty.png", "Figure 9. Descriptive selection frequency under joint row bootstrap of the five validation seeds. This is a post-hoc instability diagnostic, not a population probability.")
            elif text in ("5.5 Supplementary statistical diagnostics", "5.6 Supplementary statistical diagnostics"):
                add_figure(doc, "fig_budget_frontier.png", "Figure 4. Analytic Hoeffding width as a planning diagnostic under the [0,1] bound; it is not an observed requirement or lower bound.")
            elif text == "5.9 Post-hoc robustness of the v3 conclusion":
                add_figure(doc, "fig_tuning_stability.png", "Figure 5. Configuration-selection stability when validation seeds increase from 5 to 10. Red cells changed selection; this is a post-hoc diagnostic.")
                add_figure(doc, "fig_normalization_sensitivity.png", "Figure 6. Number of maximum-budget inconclusive comparisons under 11 normalization schemes. All schemes retain 15/15 unresolved comparisons; this is a post-hoc diagnostic.")
            elif text == "5.11 Training-budget scaling diagnostic":
                add_figure(doc, "fig_budget_scaling.png", "Figure 7. Descriptive means at 4,096 and 16,384 training steps under fixed v3 selections. The diagnostic is not pooled with the primary estimand.")
            elif text == "5.12 Evaluation-episode sensitivity diagnostic":
                add_figure(doc, "fig_eval_episode_sensitivity.png", "Figure 8. Mean absolute normalized-metric change when evaluation episodes increase from 5 to 10 per checkpoint, matched by training seed.")
            elif text == "5.14 Fixed-configuration queue budget follow-up":
                add_figure(doc, "fig_queue_budget_followup.png", "Figure 10. Fixed-configuration queue follow-up: the DQN--A2C interval is inconclusive at 200 seeds and crosses the practical margin at 400 seeds. This is a post-v3 resolution-cost diagnostic.")
            elif text == "5.15 Prospective v4 new-seed extension":
                add_figure(doc, "fig_v4_extension.png", "Figure 11. Prospective v4 extension intervals on 400 new seeds per cell. Only the controlled queue DQN--A2C comparison reaches a terminal superiority decision at n = 200; the other 14 cells remain inconclusive at n = 400.")
            elif text == "5.17 v5 resolution-cost extension":
                add_figure(doc, "fig_v5_extension.png", "Figure 12. v5 resolution-cost extension with up to 1,000 new seeds per cell. Four comparisons reach terminal decisions at n = 200 or 800; eleven remain inconclusive at n = 1,000. This is a same-machine diagnostic, not a universal seed rule.")
            elif text == "5.19 Prospective v6 task-family extension":
                add_figure(doc, "fig_v6_extension.png", "Figure 13. v6 final-look intervals for two additional fixed discrete tasks at 200 seeds per algorithm. Dashed lines mark the practical margin; all six comparisons remain inconclusive.")
            if text == "References":
                for reference in EN_REFERENCES:
                    add_body_paragraph(doc, reference)
                break
            i += 1
            continue
        if line.startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i])
                i += 1
            headers, rows = parse_table(block)
            table_index += 1
            add_table(doc, headers, rows, f"Table {table_index}. {headers[0] if headers else 'Summary'}")
            continue
        if line.startswith("- "):
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.first_line_indent = Cm(0)
            p.add_run(clean_inline(line[2:]))
            i += 1
            continue
        if re.match(r"^\d+\. ", line):
            p = doc.add_paragraph(style="List Number")
            p.paragraph_format.first_line_indent = Cm(0)
            p.add_run(clean_inline(re.sub(r"^\d+\. ", "", line)))
            i += 1
            continue
        if line.startswith("```"):
            i += 1
            code = []
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i])
                i += 1
            i += 1
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.7)
            p.paragraph_format.first_line_indent = Cm(0)
            r = p.add_run("\n".join(code))
            r.font.name = "Menlo"
            r.font.size = Pt(8)
            continue
        if line.strip() == r"\[":
            equation = []
            i += 1
            while i < len(lines) and lines[i].strip() != r"\]":
                equation.append(lines[i].strip())
                i += 1
            if i < len(lines):
                i += 1
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Cm(0)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(4)
            r = p.add_run(clean_inline(" ".join(equation)))
            r.font.name = "Cambria Math"
            r.font.size = Pt(10)
            continue
        paragraph_lines = [line]
        i += 1
        while i < len(lines) and lines[i].strip():
            nxt = lines[i].lstrip()
            if (nxt.startswith("#") or nxt.startswith("|") or nxt.startswith("- ")
                    or re.match(r"^\d+\. ", nxt) or nxt.startswith("```")
                    or nxt.strip() == r"\["):
                break
            paragraph_lines.append(lines[i].strip())
            i += 1
        add_body_paragraph(doc, " ".join(paragraph_lines))


CN_MARKDOWN = r"""
## 摘要

强化学习（RL）基准比较受到训练随机种子、环境随机性、配置选择和重复中期检查的影响。本文研究序贯 RL 评估的可靠性—成本边界，而不是提出新的策略学习算法。研究协议在验证种子上选择配置、在密封测试前冻结配置，定义有界归一化学习曲线指标，并采用带有预先声明族级错误率分配的有限检查点无配对 Hoeffding 区间。选择不变性命题覆盖仅使用验证数据的配置选择，锁定停止引理覆盖不同预先声明检查点上的逐比较决策。本文在五个公开说明的离散动作任务上评估 PPO、DQN 和 A2C；15 个算法配对比较各使用四个候选配置、每个候选五个验证种子和 20 个密封测试种子。所有比较均达到最大预算，未达到优越性或 0.10 宽度精度决定。事前预算可行性审计和解析推论表明，该非分辨结果由有界区间和正式预算对指标范围内任何数据强制产生，因此不能解释为算法等价证据。同机独立实现重放与存储摘要一致；密封 Windows AMD64 复跑匹配全部 15 个选定配置和终止决定，其中 14/15 个单元的逐种子指标差异为零，另一个单元报告了平台差异。这支持冻结协议的不同机器可复现性，但不验证独立团队身份，也不构成新任务族上的科学结论复制。依赖压力测试显示相关种子观测会破坏名义区间；已知块回退只有在明确的独立块假设下才有效。本文因此给出针对披露任务和预算的条件性协议刻画，不建立普遍种子要求、算法排名或计算节省。

**关键词：** 强化学习；可复现性；统计推断；序贯评估；随机种子；有界置信区间。

## 1 引言

强化学习结果是训练种子、环境随机性、实现细节和评估回合共同作用下的随机量。因此，在一个种子上观察到的小点估计差异不一定能在新种子上保持。已有研究记录了深度 RL 中的可复现性和报告问题[L1]，发现深度 RL 智能体可能过拟合并出现训练—测试性能差异[L13]，并将实现层面的非确定性识别为性能方差来源[L14]。Chan 等人还提出了用于衡量 RL 可靠性及进行统计比较的工具[L15]。Khamaru 等人研究了用于策略/价值评估的实例依赖置信区间和数据依赖提前停止[L16]。其他研究分析了种子数量与统计功效[L2, L3]，并倡导报告不确定性和稳健聚合指标[L4]。这些工作说明评估需要更加谨慎，但没有给出普遍适用的种子数量，也没有验证本文的协议。

序贯评估提出了一个具体的可靠性—成本问题。如果在若干测试种子批次后重复检查比较结果，区间必须在每个预先声明的检查点保持有效。正态或 bootstrap 近似在有利分布下可能更窄，而有界分布无关区间在现实预算下可能过宽，无法判断具有实际意义的差异。配置调优又带来另一种乐观偏差，除非在打开密封测试数据前完成调优。

本文用可审计的嵌套协议刻画这一边界。每个算法—任务单元拥有相同的四候选验证网格；选定配置在打开密封测试数据前冻结。主要比较是边际期望归一化学习曲线指标的无配对差异，使用有界区间和有限检查点 alpha 分配。我们记录逐批次执行过程，保留所有验证候选和测试级指标，并单独报告可重复性与可复现性。

本文的贡献是对给定任务和预算下该协议的经验与方法学刻画。由于 Chan 等人已经研究 RL 可靠性指标与统计比较，本文将贡献限定为更窄的有限检查点、条件性验证后估计对象、密封测试和可靠性—成本分辨边界。本文在 `SYSTEMATIC_NOVELTY_REVIEW.md` 中记录了透明的范围综述，并在 `LITERATURE_SCREENING_TABLE.md` 中记录候选文献的筛选决定；相对于完整 RL 评估文献的广泛新颖性主张，仍需数据库导出和独立筛选后核实。研究提出以下受证据约束的结论：

1. 在明确的有界种子和有限检查点假设下，所述区间构造具有条件族错误率覆盖保证。
2. 在正式 v3 的 alpha 分配下，二十个种子对任何有界数据都无法触发优越性或 0.10 宽度精度决定；全部十五个观测比较与这一设计诱导的非分辨区一致。
3. 独立实现的同机运行器能够以记录的指标精度准确复现 v3 摘要。
4. 密封 Windows AMD64 复跑匹配全部 15 个选定配置和终止决定；14/15 个单元的逐种子指标差异为零，另一个单元报告平台差异。这支持冻结协议的不同机器可复现性，但不验证独立团队身份或新任务族科学复制。
5. 前瞻性新种子扩展显示，一个受控队列比较可在 200 个种子时超过预先声明的实际边际，而其余 14 个单元到 400 个种子仍未解决；该结果作为范围明确的预算观察报告，不作为普遍要求。
6. 有限检查点 minimax alpha 支出引理刻画了有界区间的早期—后期分辨率权衡，不改变预注册的 v3 决定规则。
7. 事前预算可行性审计把有界半径公式转化为密封测试前的可执行检查；该审计是协议设计工具，不是经验功效或普遍种子要求。

### 1.1 研究问题与证据类型假设

本文将四个经常被合并为算法性能结论的问题分开。每个问题有不同的证据标准，观测结果不能替代理论证明或外部复现。

| 问题 | 假设或预期 | 证据类型与判定规则 |
|---|---|---|
| RQ1。有限检查点区间是否控制条件估计对象的错误率？ | H1：在指标有界、检查点固定、条件于验证选择且每个算法自身种子独立的条件下，区间具有所述条件族级覆盖率。 | 形式命题与证明；RL 数据不用于证明定理。 |
| RQ2。正式 v3 预算能否分辨具有实际意义的差异？ | H2：在 v3 分配下，任何有界数据到 20 个种子都不能触发 0.05 优越性边际或 0.10 精度规则。 | 由确定性代码检查的解析推论；15 个观测未决单元只作一致性检查。 |
| RQ3。冻结任务—算法比较之间的分辨成本是否异质？ | H3：增加公开的新种子预算可以解决部分冻结比较，而其他比较仍未解决；该模式依赖任务，不是普遍种子规则。 | v4 和 v5 新种子诊断；报告为观测停止成本，不解释为经验功效或总体规律。 |
| RQ4。第二个实现能否复现存储摘要？ | H4：同机独立实现能够复现存储摘要；密封 Windows 复跑检验冻结协议的不同机器可复现性，但不等于独立团队科学复制。 | 同机行级复现、Windows 原始输出、环境元数据和 15/15 决定匹配；独立团队身份与新任务族复制仍未验证。 |

这些假设限定了证据范围，而不是预设积极的算法排名。尤其是 H2 的负分辨结果由设计推导，H3 和 H4 是依赖冻结产物与可复现性边界的描述性检查。

本文不主张任何算法普遍优越，不主张二十个种子在所有任务中普遍充分或必要，也不主张研究已经由独立团队复现。

## 2 相关工作

Henderson 等人指出深度 RL 结果可能受到随机种子、环境非确定性和报告选择的影响[L1]。Zhang 等人报告了深度 RL 过拟合及训练—测试性能差异[L13]，Nagarajan 等人则将训练非确定性作为可复现性的来源进行拆解[L14]。Chan 等人提出了针对训练变异性与风险的可靠性指标和统计比较工具[L15]。Khamaru 等人提供了关于实例依赖置信区间与提前停止的相邻理论[L16]。Colas 等人分析了种子数量、统计功效以及比较所需的假设[L2, L3]。Agarwal 等人强调少量运行的深度 RL 评估具有显著不确定性，建议使用不确定性区间、性能剖面和稳健聚合指标[L4]。Whiteson 等人将评估过拟合明确作为经验 RL 中的一个问题[L11]，这也构成本文分离验证选择与密封测试的动机。本文使用 Hoeffding 有界变量不等式作为集中结果[L5]，并以可求和的有限检查点支出方案作为序贯统计背景[L6]。

本文的已核实文献表保持较短，候选文献的纳入与排除理由单独记录，以免把一般算法比较误写成对本文协议新颖性的证据。由于 Chan 等人已经研究 RL 可靠性指标与统计比较，本文将贡献限定为更窄的有限检查点、条件性验证后估计对象、密封测试和可靠性—成本分辨边界。相对于完整 RL 评估文献的广泛新颖性主张，仍需数据库导出和独立筛选后核实，详见 `LITERATURE_VERIFICATION.md` 和 `LITERATURE_SCREENING_TABLE.md`。

表 1 明确给出贡献边界。表中关于“未建立”的表述仅针对已核实的摘要或元数据；标注[待核实]的地方仍需全文方法比较。

| 工作 | 主要对象 | 可靠性或统计贡献 | 验证/测试分离 | 有限检查点族级控制 | 分辨成本前沿 |
|---|---|---|---|---|---|
| Henderson 等人[L1] | 深度 RL 实验实践 | 可复现性、非确定性和报告问题 | 已核实记录未建立 | 已核实记录未建立 | 已核实记录未建立 |
| Colas 等人[L2, L3] | 种子数量和算法比较 | 功效、错误、效应量和检验假设诊断 | 不是本文的条件性选定配置估计对象 | 已核实记录未建立 | 不是本文的停止成本分析 |
| Zhang 等人[L13]、Whiteson 等人[L11] | 过拟合与评估保护 | 训练/测试泛化和评估过拟合动机 | 相关分离原则；方法重叠[待核实] | [待核实] | [待核实] |
| Nagarajan 等人[L14] | 实现非确定性 | 确定性训练和可复现性分析 | 不是本文的验证/测试协议 | 已核实记录未建立 | 已核实记录未建立 |
| Chan 等人[L15] | RL 可靠性度量 | 变异性/风险指标和统计比较工具 | 已核实摘要未建立 | 已核实摘要未建立 | 已核实摘要未建立 |
| Khamaru 等人[L16] | 理论策略/价值评估 | 实例依赖置信区间和数据依赖提前停止 | 不是本文的训练种子选择/测试估计对象 | 不是本文的基准族控制 | 理论停止规则，不是本文的经验分辨成本前沿 |
| 本文 | 条件性选定程序比较 | 预先声明有限检查点的有界无配对区间 | 仅验证选择，随后使用密封测试种子 | 固定检查点和比较族的族级 alpha 分配 | 冻结任务与预算下的观测停止/分辨成本 |

### 2.1 本研究针对的评估失效模式

本文将 RL 基准报告中经常混淆的四类失效模式分开处理。第一，**种子不确定性**使单次训练不能可靠代表结果分布。第二，**选择乐观偏差**发生在同一批观测既用于选择配置又用于最终比较时。第三，**可选停止**会在未预先分配错误预算时提高出现有利结果的机会。第四，**比较族扩展**会在看到早期结果后增加任务或算法对。密封测试种子处理选择乐观偏差，固定检查点处理可选停止，显式的 15 个比较族处理事后扩展。该设计不能消除训练非确定性，也不能保证候选网格包含理想配置。

### 2.2 贡献定位与适用范围

本文是评估协议刻画，而不是算法论文。集中不等式和 alpha 支出属于已有统计工具，本文不声称重新发明它们。本文的贡献在于明确组合条件性验证后估计对象、密封测试流程、有限检查点族级控制和可审计的 RL 执行，并记录保守区间何时无法在给定预算下回答实际问题。范围综述支持这一定位，但相对于全部 RL 评估研究的确切新颖性仍需独立筛选后核实。这种保守定位使审稿人能够根据估计对象、协议和证据评价负结果，而不是根据未经支持的新优化器主张评价论文。

## 3 估计对象与统计协议

对于任务 `$e$`、算法 `$a$`、仅使用验证数据选出的配置 `$c(e,a)$` 和训练预算 `$T$`，定义

`Z_{e,a,s} = (1/4) * sum_{t in {1024, 2048, 3072, 4096}} NormReturn_{e,a,s,t} in [0,1]`。

无序算法对 `$a,b$` 的主要估计对象是条件边际差异：

`Delta_{e,a,b} = E[Z_{e,a,S} | D_val] - E[Z_{e,b,S'} | D_val]`。

其中 `$S` 和 `$S'` 是独立的训练种子抽样，`$D_val$` 包含用于选择配置的全部验证观测。相同的整数种子标签不代表共同随机数，因此主要区间不配对种子标签。

族包含五个任务和三个无序算法对，共十五个比较。族 alpha 为 0.05，每个比较分配 `0.05/15 = 0.0033333333333333335`。在 `$k in {1,2,3,4}$` 个检查点、测试种子数 `$n_k in {5,10,15,20}$` 后，比较级支出为 `alpha_k = alpha_cmp * 6/(pi^2 k^2)`。对独立且位于 `[0,1]` 的序列，半径为 `r_A,k = sqrt(log(4/alpha_k)/(2 n_A,k))` 和 `r_B,k = sqrt(log(4/alpha_k)/(2 n_B,k))`，区间为 `I_k = [xbar_k - ybar_k - r_A,k - r_B,k, xbar_k - ybar_k + r_A,k + r_B,k]` 与 `[-1,1]` 的交集。

实际优越性边际为 0.05，目标区间宽度为 0.10。只有当区间在预先声明的实际边际之外排除相反方向时，才声明优越性；精度决定要求宽度不超过 0.10。否则运行器继续到下一个预先声明的检查点；二十个种子后仍未解决的比较标记为 `max_budget_inconclusive`。终止决定被锁定，不能被后续批次覆盖。

### 3.1 条件估计对象的解释

对 `$D_val$` 条件化意味着，目标是给定已观测验证数据后，由冻结验证规则实际选出的配置在新训练种子抽样下的期望测试指标。它比“无限超参数空间中的最优配置”更窄，也不同于对所有候选配置做无条件平均。该区间回答的是两个冻结后的选定程序在新训练种子下有多大差异，而不是经过无限调优后哪个算法会胜出。

同样的区分适用于任务族。族级结论条件于预先声明的 15 个任务—算法比较，不能在观察 v3 区间后再增加任务，也不能把五个任务视作所有 RL 环境的随机样本。

### 命题 0（密封测试下的选择不变性）

令 `G` 为任意可测的配置选择规则，它仅将验证数据 `$D_val$` 映射为每个任务—算法单元的一个冻结配置。假设 `G` 可能选出的每个配置都满足命题 1 所需的密封测试种子有界性和独立性条件，并且指标、检查点方案、alpha 分配和比较族在打开密封测试数据前已经固定，则选择之后仍有相同的条件覆盖率：

`P(Delta(G(D_val)) 在所有 I_k 中 | D_val) >= 1 - alpha_cmp`。

证明思路是固定一个验证数据实现值 `d`。此时 `G(d)` 在打开测试数据之前已经是常数，因此命题 1 可以逐点应用；其浓度常数不依赖配置名称。于是对几乎所有 `d`，条件失败概率至多为 `alpha_cmp`；再对验证数据分布积分，即得到随机选定程序的相应无条件结论。因为候选配置只用于选择而不进入密封测试区间，所以不需要对候选网格再作并集界。

该命题是验证后选择的条件性结论，不保证无限搜索空间中的最优配置。如果选择规则使用了密封测试行，或在观察测试数据后改变指标、检查点方案或比较族，该结论不适用。

### 推论 0（验证后选择的族级控制）

若命题 0 对 `m` 个预先声明的任务—算法比较分别成立，且第 `j` 个比较分配错误水平 `alpha_cmp,j`，则在完整验证数据条件下，使用并集界可得

`P(所有选定程序区间同时覆盖其目标 | D_val) >= 1 - sum_j alpha_cmp,j`。

因此，v3 的 `alpha_cmp = 0.05/15` 即使每个单元在验证阶段考察四个候选配置，也能将预先声明的十五个比较族控制在 0.05。候选数量不进入该并集界，因为候选观测只用于选择，不作为密封测试比较。若增加任务、算法对、指标或事后分析，就形成新的比较族，必须重新定义族并分配 alpha。

### 命题 2（锁定有限检查点停止下的有效性）

对一个比较，令 `tau` 为预先声明状态机产生的第一个终止检查点；若达到最大预算仍未终止，则记为 `K+1`，并定义报告索引 `bar_tau = min(tau, K)`，因此报告区间始终是实际存在的 `I_bar_tau`。令 `E = {Delta 在所有预先声明的 I_k 中}`。若命题 1 成立，则终止或最后检查点报告的区间仍以至少 `1-alpha_cmp` 的条件概率覆盖目标。

**证明思路。** `tau` 只由截至所选检查点已经揭示的测试行决定；在事件 `E` 上每一个预先声明的区间都覆盖 `Delta`，因此实现的 `I_bar_tau` 也覆盖 `Delta`。所以 `{Delta 不在 I_bar_tau}` 是 `E` 的补集的子集。对固定比较族再次使用并集界，即使各比较在不同检查点终止，族级错误率仍不超过 `sum_j alpha_cmp,j`。锁定后删除后续行不会增加错误项，但该结论不允许未注册检查点、事后阈值或事后扩展比较族。

### 命题 3（已知块依赖下的回退区间）

假设在给定验证数据和选定配置后，每个算法臂的观测可以划分为已知且不重叠的块；每个完整块均值位于 `[0,1]`，并且每个臂内的块均值相互独立且具有共同的臂级均值。在第 `$k$` 个检查点，只保留两臂可用的完整块，分别记为 `q_A,k` 和 `q_B,k`，并将无配对 Hoeffding 区间应用于块均值，半径为 `sqrt(log(4/alpha_k)/(2q_A,k))` 和 `sqrt(log(4/alpha_k)/(2q_B,k))`。则命题 1 的有限检查点和族级覆盖结论仍然成立。

**证明思路。** 将完整块均值视为命题 1 中的有界独立观测，直接应用相同的两臂、有限检查点和族级并集界。丢弃末尾不完整块，避免将一个相关片段当作独立观测。该回退要求块划分已知且块均值独立；未知或重叠块、块间残余相关以及未建模的 RL 过程依赖均不在结论内。其代价是有效样本量降低、区间变宽。

### 定义 1（可靠性—成本前沿）

对固定检查点和 alpha 支出方案，将前沿定义为点集 `(C_k, R_k)`：`C_k` 是达到第 `$k$` 个检查点的累计记录运行成本，`R_k` 是两个无配对 Hoeffding 半径之和。`R_k` 是有界指标假设下的分布无关设计坐标；`C_k` 只适用于披露的机器、实现和配置。前沿是报告对象，不是经验功效曲线；即使比较提前停止，也必须从预先声明的所有检查点构造完整前沿。

### 3.2 可审计的状态机决定规则

对每个无序算法对，运行器从空的密封测试记录开始。在第 `$k$` 个检查点追加五个新种子，计算两个样本均值并构造 `$I_k$`，然后按以下互斥顺序处理：

1. 若下端点大于实际边际，声明第一个算法具有实际优越性。
2. 若上端点小于负的实际边际，声明第二个算法具有实际优越性。
3. 若区间宽度不超过 0.10，声明比较达到精度但不声明优越性。
4. 否则继续到下一个固定检查点。

第一个终止状态被锁定。若最后一个检查点仍没有终止状态，记录为 `max_budget_inconclusive`。该顺序防止后续描述性更新覆盖预先声明规则下的决定；实现测试覆盖终止锁定和无配对区间的顺序不变性。

**算法 1。密封测试有限检查点评估器。** 该状态机与具体编程语言无关。配置选择只读取验证行；每次检查点只追加一个新的密封测试种子批次，并为每个种子返回一个有界指标：

1. 对每个任务和算法，用验证均值从候选网格中选择配置，并在打开任何密封测试行前冻结配置。
2. 为每个任务—算法单元维护共享的密封行；在第 `$k$` 个检查点，只对仍有开放比较的单元追加 `n[k]-n[k-1]` 个新种子。
3. 对每个开放的无序算法对计算均值差和截断到 `[-1,1]` 的无配对区间。
4. 依次检查第一个算法优越、第二个算法优越、达到精度但不优越；第一个终止状态被锁定。
5. 若最后检查点仍未终止，输出 `max_budget_inconclusive`，并保留状态、停止检查点、原始行、区间和配置标识。一个训练行只生成一次，可被同一任务中的多个算法对复用。

精度分支在两个优越性分支之后执行，因此实际优越性不会被重新标记为仅达到精度。锁定后的后续行不改变决定记录；保留的原始行和停止轨迹可以在不重新训练的情况下重算每个区间。

### 3.3 为什么采用无配对区间

具有相同整数标签的训练运行不一定共享环境转移、框架随机数流或优化轨迹。按种子标签配对会引入材料中没有建立的共同随机数解释。因此主要估计使用独立边际均值，并支持不同样本量。配对方法只作为统计审计中的诊断比较，不把任意重新配对后的行为作为主要结果。

### 3.4 Minimax alpha 支出作为设计诊断

可求和的幂级数支出方案是有效的，但没有针对明确的分辨目标进行优化。对第 `$k$` 个检查点的等样本情形，定义 `q_k = log(4/alpha_k) / n_k`、`R_k = sqrt(2 q_k)`，其中 `R_k` 是两个无配对 Hoeffding 半径之和。给定检查点样本数 `n_1,...,n_K` 和比较级预算 `alpha_cmp`，使 `max_k R_k` 最小的 minimax 设计由下式给出：`4 * sum_k exp(-n_k tau) = alpha_cmp`，以及 `alpha_k* = 4 exp(-n_k tau)`。

理由是，若要求 `q_k <= tau`，则每个检查点必须分配至少 `4 exp(-n_k tau)` 的 alpha。因此更小的 tau 在总预算下不可行，而上述分配使所有 `q_k` 相等。该结果是有界区间的规划引理，不是新的覆盖定理，也不是 RL 经验功效主张。

在 v3 的检查点和比较级 alpha 下，minimax 方案将半径和均衡为 1.684151，而预注册幂级数方案的最坏半径和为 1.742157。代价是牺牲最后检查点的锐度（1.684151 对 1.017859）以降低最早检查点半径。两种方案在 20 个种子时都不能达到 0.05 实际优越性边际或 0.10 目标宽度，因此 v3 确认性分析保留预注册的支出方案。完整数值和确定性代码见 `MINIMAX_ALPHA_SPENDING.md`、`MINIMAX_ALPHA_SPENDING.json` 和 `minimax_alpha_spending.py`；单元测试验证预算耗尽和半径均衡。

### 命题 1（条件有限检查点覆盖）

给定验证数据和选定配置，若每个算法的密封指标在其自身训练种子之间独立且位于 `[0,1]`，则在任意有限个预先声明的检查点、且 `sum_k alpha_k <= alpha_cmp` 时，`I_k` 以至少 `1-alpha_cmp` 的概率同时覆盖 `Delta_{e,a,b}`。对十五个预先声明的比较使用并集界，可得族覆盖率至少为 0.95。该并集界步骤不要求两个算法序列之间或不同比较之间相互独立。v3 是检查点为 5、10、15、20 的 `K=4` 特例。

**证明。** Hoeffding 不等式给出每个检查点下两个样本均值各自至多为 `alpha_k/2` 的双侧失败概率。对两个均值使用并集界，失败概率至多为 `alpha_k`；再对四个固定检查点求和，得到至多 `alpha_cmp`。在所有均值界同时成立的事件上，相减得到 `Delta in I_k`；由于两个条件均值都位于 `[0,1]`，目标差异位于 `[-1,1]`，区间端点截断不会移除目标。将 `0.05/15` 分配给每个预先声明的比较并再次使用并集界，得到族级失败概率至多为 `0.05`，不需要算法之间或比较之间相互独立。条件化依赖于配置选择和检查点方案在验证数据阶段固定，密封测试序列在选择后才被打开。该结果不覆盖测试数据复用、事后指标或检查点选择、数据依赖的任务族扩展或环境漂移；它是有限检查点结果，不是 anytime 置信序列。

更具体地，对算法 A 有 `2 exp(-2 n_A,k r_A,k^2) = alpha_k/2`，算法 B 同理。当所有检查点的两个均值界同时成立时，两个不等式相减即可得到每个 `I_k` 覆盖 `Delta_{e,a,b}`；由于真实差异属于 `[-1,1]`，端点截断不会移除目标。对单个比较的补集使用 `sum_k alpha_k` 界，对 15 个预先声明的比较再使用一次并集界即可得到族级结论。条件化成立的原因是选定配置和检查点方案仅由验证数据决定，密封测试序列在选择完成后才被使用。

### 推论 1（等样本区间宽度规划）

当两个算法各有 `n` 个样本时，未截断区间宽度为 `W_k(n) = 4 sqrt(log(4/alpha_k)/(2n))`；要达到宽度 `w`，每个算法至少需要 `ceil(8 log(4/alpha_k) / w^2)` 个种子。对 `w=0.10`，单比较 alpha `0.05` 在第一个检查点需要 3,904 个种子，而 v3 比较级 alpha `0.05/15` 需要 6,071 个；在第 4 个检查点，两者分别为 6,122 和 8,289 个。正式 v3 分配下，20 个种子时未截断宽度在第一个检查点为 1.7422、最后一个检查点为 2.0357，报告区间再截断到 `[-1,1]`。这些是有界界的解析规划值，不是 RL 样本需求或下界。

下表将单比较诊断与正式族级分配分开。宽度列是每个算法 20 个种子时的未截断最坏情形宽度，不是 RL 运行中观测到的宽度。

| 错误分配 | 检查点 | 达到宽度 <= 0.10 所需的每算法种子数 | 20 个种子的未截断宽度 |
|---|---:|---:|---:|
| 单比较，alpha = 0.05 | 1 | 3,904 | 1.3971 |
| 单比较，alpha = 0.05 | 4 | 6,122 | 1.7496 |
| 正式 v3 族级，alpha_cmp = 0.05/15 | 1 | 6,071 | 1.7422 |
| 正式 v3 族级，alpha_cmp = 0.05/15 | 4 | 8,289 | 2.0357 |

### 推论 2（正式预算下的非分辨区）

在正式 v3 分配的最后一个检查点，两个算法各有 20 个样本时，两个区间半径之和为

`R_4 = r_A,4 + r_B,4 = 1.0178588242`。

对于任意观测到的有界均值差 `$d in [-1,1]$`，截断区间 `$[d-R_4,d+R_4] cap [-1,1]$` 不可能声明第一个算法优越，因为其可能达到的最大下端点为 `$1-R_4=-0.0178588242<0.05$`；反方向同理。其可能达到的最小截断宽度为 `$min(2,R_4)=1.0178588242>0.10$`，所以精度规则也不可能触发。更早的检查点具有更大的半径和，因此同样不能作出决定。由此，在严格的正式 v3 规则下，任何有界数据集在二十个种子时都会被记录为 `max_budget_inconclusive`。这是协议分辨率结果，不是算法相等的证据，也不是 RL 种子需求的普遍下界。

### 推论 3（任何有界数据可能触发优越性决定的必要阈值）

同一个半径论证给出可复用的设计阈值。在第 `$k$` 个检查点，若每个算法有相同的 `$n$` 个样本且实际边际为 `$m$`，有界均值差的最大可能值为 1。因此，当 `$R_k(n)=2 sqrt(log(4/alpha_k)/(2n)) >= 1-m` 时，任何有界数据都不可能触发第一个方向的优越性决定。换言之，有界数据只有在 `$n > 2 log(4/alpha_k)/(1-m)^2` 时才可能超过边际。

满足严格不等式的最小整数是必要的分辨阈值，而不是充分的统计功效计算。在正式 v3 比较级 alpha `0.05/15` 和 `$m=0.05$` 下，第 1--4 个检查点的阈值分别为每个算法 17、20、22 和 23 个种子。v3 的检查点为 5、10、15 和 20，因此没有一个检查点可能超过该边际；推论 2 是该一般结果的特例。确定性实现为 `unpaired_budget_requirements.py` 中的 `seeds_for_possible_superiority`，并由 `test_possible_superiority_threshold_matches_v3_boundary` 覆盖。

### 推论 4（验证后选择 alpha 支出）

令 `H` 为有限个预先声明的有限检查点 alpha 支出方案。若每个方案 `h` 都满足 `sum_k alpha_{h,k} <= alpha_cmp`，且区间构造满足命题 1；再令 `H(D_val)` 只使用验证数据选择一个方案，并在打开密封测试行前冻结它，则条件于验证数据，所选方案产生的区间序列以至少 `1-alpha_cmp` 的概率覆盖其条件目标。

**证明思路。** 固定一个验证数据实现值后，所选方案是常数，命题 1 可直接应用于该方案的固定检查点和 alpha 水平。条件失败概率至多为 `alpha_cmp`；对验证数据积分得到随机选择方案的结论。预先声明的比较族仍使用同一个并集界，不需要对候选方案再作并集界，因为方案在密封测试前选择，且不作为独立测试比较。该结论不使本身无覆盖保证的候选方案有效，也不支持普遍的成本节省主张。

### 推论 5（两算法半径的平衡分配）

在固定检查点和比较级 alpha `alpha_k` 下，若密封种子总数为 `N=n_A+n_B`，无配对半径和为 `R(n_A,n_B) = sqrt(log(4/alpha_k)/2) * (n_A^(-1/2) + n_B^(-1/2))`。由 `x^(-1/2)` 的凸性，固定 `N` 时该表达式在 `n_A=n_B=N/2` 处最小。因此，在半径最小的平衡分配下，宽度目标 `w` 至少需要 `ceil(16 log(4/alpha_k)/w^2)` 个总种子；实际边际为 `m` 时，任何有界数据可能超过优越性边际的必要总种子阈值为 `floor(4 log(4/alpha_k)/(1-m)^2)+1`。

该结果是所述区间的最坏情形预算规划，不是 RL 经验功效或普遍样本需求，也不说明每种实现的训练时间或计算成本都应完全相等。

### 3.5 事前预算可行性审计

前述推论可以在任何密封测试运行之前检查注册预算是否在结构上无法回答研究问题。我们将该检查实现为算法 2。对每个预先声明的检查点，审计计算半径和、任意 `[0,1]` 有界均值差可能产生的最大下端点 `1 - R_k`，以及任意有界差异可能产生的最小截断区间宽度 `min(2, R_k)`。随后分别报告超过实际边际 `m` 的优越性是否可能，以及达到目标宽度 `w` 是否可能，同时输出推论 1 和推论 3 的必要种子阈值。

**算法 2。事前有界分辨率可行性审计。** 输入指标范围、封闭的比较族、alpha 支出、检查点、实际边际和目标宽度：

1. 在每个注册检查点计算比较级 alpha 和 `R_k`。
2. 仅当 `1 - R_k > m` 时将 `possible_superiority_k` 设为真。
3. 仅当 `min(2, R_k) <= w` 时将 `possible_precision_k` 设为真。
4. 输出必要种子阈值；若注册上限低于设计目标，则在收集数据前标记预算不可行，除非研究明确旨在刻画无法分辨的边界。

对于冻结的 v3 输入，四个检查点的两个可行性标志均为假。超过实际优越性边际的必要阈值为每臂 17、20、22 和 23 个种子；达到目标宽度的阈值为每臂 6,071、7,180、7,829 和 8,289 个种子。这些数值是注册有界区间的确定性结果，不估计功效，也不暗示普遍种子要求。机器可读审计为 `BUDGET_FEASIBILITY_AUDIT_V3.json`，生成器和测试为 `generate_budget_feasibility_audit.py` 与 `test_budget_feasibility_audit.py`。

### 3.6 假设登记表与可证伪检查

覆盖率结论只有在其假设可见时才有意义。下表将每个假设与当前材料中最强的检查关联起来，并说明检查无法排除的剩余失效模式。

| 编号 | 区间所需假设 | 当前检查 | 剩余失效模式 |
|---|---|---|---|
| A1 | 配置选择和所有指标选择只由验证数据决定，不使用密封测试数据。 | 不相交的验证/测试种子范围、冻结配置和 600 行拆分审计。 | 未记录的手工修改或隐藏测试复用会破坏条件解释。 |
| A2 | 条件于选定配置，每个算法的密封种子指标是具有共同边际均值的独立抽样。 | 唯一种子范围、显式种子派生和运行元数据；单次安装无法证明独立性。 | 相关种子、共享隐藏状态或软件耦合会使名义覆盖率结论不适用。 |
| A3 | 归一化指标预先固定并属于 `[0,1]`。 | 预先声明的任务边界、范围检查、原始回报保留和归一化敏感性诊断。 | 事后修改边界或指标会改变估计对象并使记录区间失效。 |
| A4 | 检查点、alpha 支出、实际边际和精度规则在打开密封测试前固定。 | 冻结预注册、状态机测试和停止轨迹重算。 | 额外的未注册检查点或阈值需要新的错误预算。 |
| A5 | 主要主张的 15 个比较族在分析中保持封闭。 | 预注册和产物清单明确列出五个任务与三个无序算法对。 | 看到结果后增加任务、算法或比较会破坏族级控制。 |
| A6 | 报告序列中的任务实现和软件环境保持稳定。 | 版本锁、源文件哈希、环境元数据和同机复现。 | 硬件、软件包或环境版本变化可能改变目标程序；仍需外部复现。 |

当前材料对 A1、A3、A4 和 A5 有直接产物检查；A2 和 A6 仍部分属于经验假设。因此覆盖率主张保持条件性，同机可重复性也不称为外部可复现性。该登记表是披露和证伪指南，不是声称单次运行能够验证所有假设。

### 3.7 比较族规模的规划敏感性

在总族级错误率固定为 0.05 时，比较数从 1 增加到 15 或 30 会降低每个比较可用的 alpha，从而增加区间半径和达到目标精度所需的种子。下表在保持 v3 检查点、实际边际和宽度目标不变时，给出五种比较族规模的解析规划值。该表不使用 RL 观测，也不是经验功效曲线。

| 比较数 | 比较级 alpha | 第一个检查点半径 | 最后一个检查点半径 | 最后检查点可能超过优越性边际的必要每算法种子数 | 最后检查点达到宽度 <= 0.10 的每算法种子数 |
|---:|---:|---:|---:|---:|---:|
| 1 | 0.05000000 | 1.397101 | 0.874775 | 17 | 6,122 |
| 3 | 0.01666667 | 1.546394 | 0.935464 | 20 | 7,001 |
| 9 | 0.00555556 | 1.682492 | 0.992448 | 22 | 7,880 |
| 15 | 0.00333333 | 1.742157 | 1.017859 | 23 | 8,289 |
| 30 | 0.00166667 | 1.819992 | 1.051357 | 25 | 8,843 |

半径随比较数单调增加是并集界分配的解析结果，而不是某个 RL 任务的属性。它说明任务、算法、指标和检查点族应在数据收集前封闭；观察结果后再增加比较会改变错误预算与所需种子规模。机器可读推导和审计文件为 `DESIGN_PLANNING_SENSITIVITY_V3.json`、`DESIGN_PLANNING_SENSITIVITY_V3.md`、`generate_design_planning_sensitivity.py` 和 `audit_design_planning_sensitivity.py`。

## 4 实验设计

### 4.1 任务与归一化

冻结的任务族包括 `CartPole-v1`、`Acrobot-v1`、`MountainCar-v0`、`Taxi-v4` 和 `NonstationaryQueue-v0`。Gymnasium 版本为 1.4.0。五个任务的主要原始回报边界依次为 `[0,500]`、`[-500,0]`、`[-200,0]`、`[-2000,20]` 和 `[-2050,0]`；归一化将边界映射到 `[0,1]`，同时保留原始回报。由于已安装 Gymnasium 版本中 `Taxi-v3` 已弃用，使用 `Taxi-v4`。队列环境是一个容量为 10、时域为 200 的受控自建诊断任务，在第 100 步切换到达率，到达概率为 0.25 和 0.85，服务成本为 0.25。它不作为标准外部基准呈现。

### 4.2 算法与等强度候选网格

PPO[L7]、DQN[L8] 和 A2C[L9] 使用 Stable-Baselines3 2.9.2 实现，软件来源见[L12]。三者均采用 `MlpPolicy` 和 CPU 执行；PPO 与 DQN 使用批大小 64，而 A2C 使用声明的 `n_steps` rollout 设置，在该实现中没有 batch size 参数。每个算法—任务单元使用相同的四候选网格，每个候选配置使用五个验证种子：

| 配置 ID | 学习率 | `n_steps` | DQN 缓冲区 | DQN learning starts |
|---|---:|---:|---:|---:|
| `lr3e4_long` | 0.0003 | 256 | 5000 | 100 |
| `lr1e4_long` | 0.0001 | 256 | 5000 | 100 |
| `lr3e4_short` | 0.0003 | 128 | 10000 | 200 |
| `lr1e4_short` | 0.0001 | 128 | 10000 | 200 |

对 PPO 和 A2C，缓冲区与 learning-start 字段不使用。验证五个种子的均值用于选择候选配置；平局按确定性的首次插入顺序处理。所有密封测试指标打开前冻结选定配置。

### 4.3 种子、训练与评估

每个候选配置的验证训练种子为 10000—10004；选定配置的密封测试训练种子为 20000—20019。训练运行 4096 个环境步，并在 1024、2048、3072 和 4096 步进行评估。每个检查点使用五个评估回合。评估种子是训练种子和检查点的确定性函数，并存储在运行产物中。运行器在 5、10、15 和 20 个测试种子时执行每批五个种子的检查。

### 4.4 软件与计算

正式运行使用 Apple Silicon arm64 macOS 上的 Python 3.11.7、Gymnasium 1.4.0、Stable-Baselines3 2.9.2、PyTorch 2.14.1 和 NumPy 2.2.6；未使用 MPS（`mps_available=false`），执行在 CPU 上完成。精确平台字符串、运行器哈希、配置和原始输出记录在 `sb3_formal_v3/` 与 `REPRODUCTION_MANIFEST_V3.md` 中。

### 4.5 计算量核算与可复现性边界

主要族包含 15 个算法—任务单元，每个选定配置使用 20 个测试种子，因此密封测试包含 300 次算法—任务训练运行。验证阶段为 15 个单元 × 4 个候选 × 5 个种子 = 300 次运行，主 CSV 共 600 行。每次运行训练 4096 个环境步，在四个检查点用五个回合评估。这些数字描述已执行研究，不表示同一预算适用于其他任务族。

运行器记录真实序贯执行，而不是先完整运行 20 个种子再假装提前停止。v3 中所有比较都使用了四个批次，因为没有比较达到终止状态。因此正式研究展示的是保守决定无法解决时的计算成本，而不是已经观察到的计算节省。独立复现脚本在同一台机器上重新生成密封摘要，检验的是跨脚本可重复性；返回的 Windows AMD64 密封复跑进一步检验了不同机器上的冻结协议可复现性，但不验证独立团队身份或新任务族复制。

以下协议不变量在提交包被视为可提交之前进行检查。它们是执行约束，不是额外的统计假设。

| 不变量 | 要求 | 审计证据 |
|---|---|---|
| 选择边界 | 每个选定配置只由验证行决定。 | 不相交的 split 标签、冻结配置字段和 600 行 v3 审计。 |
| 种子不相交 | 验证、v3 密封测试以及扩展序列没有重叠种子范围。 | v3、v4 和 v5 运行清单及范围检查。 |
| 检查点计划 | 每个检查点追加声明批次并使用声明的 alpha 支出。 | 停止轨迹、区间重算和状态机测试。 |
| 终止锁定 | 第一个终止决定不能被后续行覆盖。 | 单元测试和重算后的决定摘要。 |
| 指标来源 | 归一化指标可追溯到保留的原始回报和固定边界。 | 原始回报表、归一化清单和范围检查。 |
| 产物完整性 | 源哈希、原始行、摘要、环境元数据和命令共同归档。 | 提交归档和 SHA-256 侧车文件。 |

### 4.6 注册状态与分析来源

v3 研究在打开密封测试分析前已写入 `FINAL_PREREGISTRATION_V3.md`。连续控制和部分可观测范围组件分别拥有预注册文件，不静默并入 v3 族。较大预算的队列跟踪在 v3 结果之后启动，因此标记为 v3 之后诊断。v4 扩展在打开 30000--30399 种子前完成预注册，但其动机和任务族继承自 v3，因此报告为前瞻性新种子扩展，而不是独立复现。事后区间、归一化、训练预算、评估回合、调参稳定性和配对分析始终标记为诊断。该来源规则避免后续分析改变主要估计对象或将探索性证据静默升级。

## 5 结果

### 5.1 数据核算与决定

v3 CSV 包含 600 行：300 行验证数据（四个候选配置、五个种子、十五个算法—任务单元）和 300 行密封测试数据（一个选定配置、二十个种子、十五个单元）。全部十五个比较均达到二十个测试种子，且均为 `max_budget_inconclusive`。推论 2 表明，这一全部未决结果由正式有界界和预算结构性决定，而不是该任务族在二十个种子下经验功效低的估计。没有作出正式的优越性或精度决定。

在打开密封测试行之前，事前预算可行性审计已经得到相同结论：对于 `[0,1]` 中的任意指标序列，四个注册检查点都不可能超过 0.05 实际边际，也不可能达到 0.10 目标宽度。因此，15/15 个最终未决状态是对设计预测的执行核对，不是经验功效估计。

### 5.2 描述性测试均值

下表给出选定配置的归一化测试均值。这些数值仅用于描述固定预算下的结果，不能解释为一般算法排名。

| 环境 | PPO | DQN | A2C |
|---|---:|---:|---:|
| CartPole-v1 | 0.214320 | 0.024900 | 0.201375 |
| Acrobot-v1 | 0.108690 | 0.182475 | 0.084515 |
| MountainCar-v0 | 0.000000 | 0.005688 | 0.000000 |
| Taxi-v4 | 0.891089 | 0.891089 | 0.673519 |
| NonstationaryQueue-v0 | 0.792553 | 0.922569 | 0.622952 |

每个单元的选定配置记录在 `sb3_formal_v3/summary.json` 中，所有验证候选值均被保留。在该固定预算下，MountainCar 接近回报下限，因此描述性数值的区分能力有限。

### 5.2.1 原始回报摘要

为使归一化过程透明，我们同时在任务自身的原始回报尺度上报告同一批选定测试种子。由于不同任务的回报尺度不同，这些摘要不跨任务合并；它们是描述性证据，不改变主要有界估计对象。原始表由 `generate_raw_return_table.py` 从 `metric_raw` 自动生成。

| 环境 | 算法 | 原始均值 | 样本 SD | 中位数 | 最小值 | 最大值 |
|---|---|---:|---:|---:|---:|---:|
| CartPole-v1 | PPO | 107.160000 | 30.539003 | 97.050000 | 75.650000 | 219.250000 |
| CartPole-v1 | DQN | 12.450000 | 7.511080 | 9.725000 | 9.050000 | 39.450000 |
| CartPole-v1 | A2C | 100.687500 | 30.487875 | 90.750000 | 58.200000 | 162.700000 |
| Acrobot-v1 | PPO | -445.655000 | 100.347583 | -500.000000 | -500.000000 | -134.800000 |
| Acrobot-v1 | DQN | -408.762500 | 124.334260 | -500.000000 | -500.000000 | -170.950000 |
| Acrobot-v1 | A2C | -457.742500 | 81.882243 | -500.000000 | -500.000000 | -193.000000 |
| MountainCar-v0 | PPO | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| MountainCar-v0 | DQN | -198.862500 | 4.669917 | -200.000000 | -200.000000 | -179.100000 |
| MountainCar-v0 | A2C | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | PPO | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | DQN | -200.000000 | 0.000000 | -200.000000 | -200.000000 | -200.000000 |
| Taxi-v4 | A2C | -639.492500 | 443.534378 | -559.325000 | -1636.850000 | -200.000000 |
| NonstationaryQueue-v0 | PPO | -425.265625 | 460.855138 | -161.418750 | -1797.200000 | -158.550000 |
| NonstationaryQueue-v0 | DQN | -158.733750 | 4.147479 | -159.475000 | -168.512500 | -150.950000 |
| NonstationaryQueue-v0 | A2C | -772.948750 | 645.308638 | -644.543750 | -1796.862500 | -154.512500 |

机器生成的表格副本见 `RAW_RETURN_TABLE_V3.md`，由 `generate_raw_return_table.py` 生成。

### 5.3 正式区间

| 任务 | 比较 | 估计值 | 族调整区间 | 决定 |
|---|---|---:|---|---|
| CartPole-v1 | PPO − DQN | 0.1894 | [−0.8284, 1.0000] | 无法作出结论 |
| CartPole-v1 | PPO − A2C | 0.0129 | [−1.0000, 1.0000] | 无法作出结论 |
| CartPole-v1 | DQN − A2C | −0.1765 | [−1.0000, 0.8414] | 无法作出结论 |
| Acrobot-v1 | PPO − DQN | −0.0738 | [−1.0000, 0.9441] | 无法作出结论 |
| Acrobot-v1 | PPO − A2C | 0.0242 | [−0.9937, 1.0000] | 无法作出结论 |
| Acrobot-v1 | DQN − A2C | 0.0980 | [−0.9199, 1.0000] | 无法作出结论 |
| MountainCar-v0 | PPO − DQN | −0.0057 | [−1.0000, 1.0000] | 无法作出结论 |
| MountainCar-v0 | PPO − A2C | 0.0000 | [−1.0000, 1.0000] | 无法作出结论 |
| MountainCar-v0 | DQN − A2C | 0.0057 | [−1.0000, 1.0000] | 无法作出结论 |
| Taxi-v4 | PPO − DQN | 0.0000 | [−1.0000, 1.0000] | 无法作出结论 |
| Taxi-v4 | PPO − A2C | 0.2176 | [−0.8003, 1.0000] | 无法作出结论 |
| Taxi-v4 | DQN − A2C | 0.2176 | [−0.8003, 1.0000] | 无法作出结论 |
| Queue-v0 | PPO − DQN | −0.1300 | [−1.0000, 0.8878] | 无法作出结论 |
| Queue-v0 | PPO − A2C | 0.1696 | [−0.8483, 1.0000] | 无法作出结论 |
| Queue-v0 | DQN − A2C | 0.2996 | [−0.7182, 1.0000] | 无法作出结论 |

表中的 `Queue-v0` 是 `NonstationaryQueue-v0` 的缩写。数值由 `familywise_cost_summary.json` 四舍五入得到，该 JSON 文件是权威产物。宽区间展示了本预算下有界方法的成本边界，但不证明算法之间相等。

### 5.3.1 描述性效应量

作为有界区间的补充，我们报告同一批 20 个种子样本的描述性效应量。`均值差` 为均值(A) 减均值(B)；Cliff delta 为 400 个成对比较中胜负差除以 400，平局贡献为零；`标准化差异` 使用合并样本标准差。这些量是描述性的，不替代主要族级区间，也不构成算法排名。

| 环境 | 比较 | 均值差 | Cliff delta | 标准化差异 | 合并 SD |
|---|---|---:|---:|---:|---:|
| CartPole-v1 | PPO - DQN | 0.189420 | 1.000000 | 4.258948 | 0.044476 |
| CartPole-v1 | PPO - A2C | 0.012945 | 0.210000 | 0.212120 | 0.061027 |
| CartPole-v1 | DQN - A2C | -0.176475 | -1.000000 | -3.974165 | 0.044406 |
| Acrobot-v1 | PPO - DQN | -0.073785 | -0.115000 | -0.326542 | 0.225959 |
| Acrobot-v1 | PPO - A2C | 0.024175 | 0.020000 | 0.131986 | 0.183163 |
| Acrobot-v1 | DQN - A2C | 0.097960 | 0.135000 | 0.465278 | 0.210541 |
| MountainCar-v0 | PPO - DQN | -0.005687 | -0.100000 | -0.344475 | 0.016511 |
| MountainCar-v0 | PPO - A2C | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| MountainCar-v0 | DQN - A2C | 0.005687 | 0.100000 | 0.344475 | 0.016511 |
| Taxi-v4 | PPO - DQN | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| Taxi-v4 | PPO - A2C | 0.217571 | 0.650000 | 1.401326 | 0.155260 |
| Taxi-v4 | DQN - A2C | 0.217571 | 0.650000 | 1.401326 | 0.155260 |
| NonstationaryQueue-v0 | PPO - DQN | -0.130016 | -0.575000 | -0.817866 | 0.158969 |
| NonstationaryQueue-v0 | PPO - A2C | 0.169602 | 0.312500 | 0.620067 | 0.273521 |
| NonstationaryQueue-v0 | DQN - A2C | 0.299617 | 0.747500 | 1.346043 | 0.222591 |

机器生成的表格副本见 `EFFECT_SIZE_TABLE_V3.md`，由
`generate_effect_size_table.py` 生成。

### 5.4 同机可重复性

独立复现脚本重新生成十五个算法—任务单元的全部二十个密封种子。存储摘要与复现摘要之间每个单元的平均归一化指标绝对差均为 0.0。这支持在公开软件状态下的同机跨脚本可重复性。

### 5.4.1 不同机器密封复跑

主要分析冻结后，另一台 Windows 10 AMD64 机器执行了密封协议。返回元数据记录 Python 3.11.18、NumPy 2.2.6、PyTorch 2.14.1、Gymnasium 1.4.0 和 Stable-Baselines3 2.9.2，未使用 CUDA 或 MPS。返回归档包含 600 行原始记录（300 行验证、300 行测试），输出校验清单及所有运行时源文件哈希均与冻结运行匹配；`REPRODUCTION_MANIFEST_V3.md` 被审计为复跑后的文档更新。15 个选定配置和 15 个终止决定全部匹配。14/15 个单元的逐种子归一化指标差异为零；唯一非零单元为 `Acrobot-v1:DQN`，平均绝对差为 0.00105，最大绝对差为 0.01640。我们保留这些差异，不用四舍五入掩盖。该结果支持所披露软件和冻结任务族的不同机器可复现性，但不核验操作者的独立机构身份，也不测试新任务族。

### 5.5 种子级分布与配置选择

存储的测试指标说明了为什么不能只报告点估计。例如，选定 CartPole PPO 单元的均值为 0.214320、样本标准差为 0.061078；选定 Acrobot PPO 单元的均值为 0.108690、样本标准差为 0.200695。这些是记录的 20 个种子的描述性统计，不是具有外部有效性主张的总体方差估计。原始最小值、中位数、最大值和每个种子指标均保存在 `sb3_formal_v3/raw_seed_metrics.csv` 中。

完整的选定测试分布如下。标准差是 20 个训练种子的样本标准差；这些统计量是描述性的，不是针对更广泛任务总体的区间估计。

| 环境 | 算法 | 均值 | 样本 SD | 中位数 | 最小值 | 最大值 |
|---|---|---:|---:|---:|---:|---:|
| CartPole-v1 | PPO | 0.214320 | 0.061078 | 0.194100 | 0.151300 | 0.438500 |
| CartPole-v1 | DQN | 0.024900 | 0.015022 | 0.019450 | 0.018100 | 0.078900 |
| CartPole-v1 | A2C | 0.201375 | 0.060976 | 0.181500 | 0.116400 | 0.325400 |
| Acrobot-v1 | PPO | 0.108690 | 0.200695 | 0.000000 | 0.000000 | 0.730400 |
| Acrobot-v1 | DQN | 0.182475 | 0.248669 | 0.000000 | 0.000000 | 0.658100 |
| Acrobot-v1 | A2C | 0.084515 | 0.163764 | 0.000000 | 0.000000 | 0.614000 |
| MountainCar-v0 | PPO | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| MountainCar-v0 | DQN | 0.005687 | 0.023350 | 0.000000 | 0.000000 | 0.104500 |
| MountainCar-v0 | A2C | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| Taxi-v4 | PPO | 0.891089 | 0.000000 | 0.891089 | 0.891089 | 0.891089 |
| Taxi-v4 | DQN | 0.891089 | 0.000000 | 0.891089 | 0.891089 | 0.891089 |
| Taxi-v4 | A2C | 0.673519 | 0.219571 | 0.713205 | 0.179777 | 0.891089 |
| NonstationaryQueue-v0 | PPO | 0.792553 | 0.224807 | 0.921259 | 0.123317 | 0.922659 |
| NonstationaryQueue-v0 | DQN | 0.922569 | 0.002023 | 0.922207 | 0.917799 | 0.926366 |
| NonstationaryQueue-v0 | A2C | 0.622952 | 0.314785 | 0.685588 | 0.123482 | 0.924628 |

机器生成的表格副本见 `SEED_DISTRIBUTION_TABLE_V3.md`，由
`generate_seed_distribution_table.py` 生成。

配置选择也改变了测试均值的解释。验证网格是程序的一部分，而不是可忽略的细节：更换网格可能选出不同的冻结程序，从而改变条件估计对象。调优强度诊断显示，与早期两个候选配置等价版本相比，扩展四候选网格在 15 个算法—任务单元中的 6 个改变了选择。由于该诊断使用不同种子且不是 v3 密封分析，本文将其作为敏感性证据，不把它与主要性能结果合并。

### 5.5.1 验证选择重采样诊断

作为选择不确定性的第二个描述，我们在每个算法—任务单元内将五个验证种子行作为整体，在四个候选配置之间共同重采样 20,000 次。这样保留了所有候选配置使用相同五个种子标签这一事实。所得频率只描述当前验证样本的不稳定性，不是总体概率、全局最优概率或确认性证据。

| 环境 | 算法 | v3 选择 | 选择频率 | 次优频率 | 熵（nats） | 观测前两名差值 |
|---|---|---|---:|---:|---:|---:|
| CartPole-v1 | PPO | `lr3e4_short` | 0.4758 | 0.4559 | 0.8949 | 0.000080 |
| CartPole-v1 | DQN | `lr3e4_long` | 0.5579 | 0.4421 | 0.6864 | 0.000160 |
| CartPole-v1 | A2C | `lr3e4_short` | 0.5366 | 0.2780 | 1.1149 | 0.003180 |
| Acrobot-v1 | PPO | `lr1e4_long` | 0.3963 | 0.3610 | 1.0783 | 0.014240 |
| Acrobot-v1 | DQN | `lr1e4_short` | 0.6526 | 0.2571 | 0.8449 | 0.036600 |
| Acrobot-v1 | A2C | `lr1e4_long` | 0.6856 | 0.1973 | 0.8638 | 0.050700 |
| MountainCar-v0 | PPO | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| MountainCar-v0 | DQN | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| MountainCar-v0 | A2C | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | PPO | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | DQN | `lr3e4_long` | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | A2C | `lr3e4_long` | 0.7968 | 0.2031 | 0.5047 | 0.052931 |
| NonstationaryQueue-v0 | PPO | `lr1e4_short` | 0.4919 | 0.3156 | 1.0301 | 0.023963 |
| NonstationaryQueue-v0 | DQN | `lr3e4_short` | 0.7022 | 0.2979 | 0.6090 | 0.000398 |
| NonstationaryQueue-v0 | A2C | `lr1e4_short` | 0.4217 | 0.3302 | 1.0785 | 0.047257 |

机器生成的诊断报告见 `VALIDATION_SELECTION_UNCERTAINTY_V3.md`，机器可读输出为 `validation_selection_uncertainty_v3.json`，生成脚本为 `validation_selection_uncertainty.py`。

### 5.5.2 执行时间成本核算

#### 验证阶段调参成本

验证网格为每个算法分配相同数量的候选配置—种子运行：5 个环境 × 4 个候选
配置 × 5 个验证种子 = 每个算法 100 次运行，总计 300 行成功验证记录。在
Apple Silicon CPU 环境下，验证阶段记录总耗时为 208.671 秒（0.058 小时）。
A2C、DQN 和 PPO 的总耗时分别为 65.027、76.821 和 66.822 秒。这些数值记录
已执行的调参预算并说明行数相等；它们不证明计算难度相等，也不构成与硬件
无关的效率结论。机器可读数据和审计文件为 `VALIDATION_TUNING_COST_V3.json`、
`generate_validation_tuning_cost.py` 和 `audit_validation_tuning_cost.py`。

| 算法 | 候选—种子运行数 | 总耗时（小时） | 平均秒数/运行 | 样本 SD | 中位数秒数/运行 |
|---|---:|---:|---:|---:|---:|
| A2C | 100 | 0.018 | 0.650 | 0.226 | 0.577 |
| DQN | 100 | 0.021 | 0.768 | 0.196 | 0.705 |
| PPO | 100 | 0.019 | 0.668 | 0.215 | 0.602 |

原始 CSV 还记录了每个成功选定测试运行的墙钟耗时。在 Apple Silicon CPU
环境下，300 个密封测试行的记录总耗时为 210.345 秒（0.058 小时）。按算法
计算的平均单次耗时为：A2C 0.659 秒、DQN 0.758 秒、PPO 0.686 秒。这些数值
只描述本实现、硬件、训练时域和运行状态，不是跨硬件效率测量，也不支持算法
成本排名。

| 算法 | 测试运行数 | 总耗时（小时） | 平均秒数/运行 | 样本 SD | 中位数秒数/运行 |
|---|---:|---:|---:|---:|---:|
| A2C | 100 | 0.018 | 0.659 | 0.231 | 0.568 |
| DQN | 100 | 0.021 | 0.758 | 0.190 | 0.696 |
| PPO | 100 | 0.019 | 0.686 | 0.228 | 0.598 |

该核算只包括选定配置的测试种子训练运行，不合并验证运行、v3 之后的扩展或
未记录的排队与评估开销。它使成本轴可审计，并避免将“可靠性—成本前沿”误解
为独立于硬件的计算效率基准。完整的单元表和机器可读推导见
`RUNTIME_COST_TABLE_V3.md` 与 `RUNTIME_COST_TABLE_V3.json`，审计脚本为
`audit_runtime_cost_table.py`。

### 5.5.3 可靠性—成本前沿

为使标题中的“前沿”可计算，我们将区间的解析几何与达到每个预先声明检查点
的累计记录成本结合起来。在每个算法 5、10、15 和 20 个种子时，开放的 v3
比较族累计耗时分别为 0.014674、0.029352、0.043992 和 0.058429 小时。
这些数值是 15 个选定测试单元中前 n 行的总和。对应的最坏半径和从 1.742157
降至 1.017859，但最小可能截断宽度仍远大于 0.10。任何有界数据可能越过
0.05 实际边际所需的每算法种子数，由于后期 alpha 支出更严格，从首个检查点
的 17 增加到最后检查点的 23。

| 检查点 | 每算法种子数 | 半径和 | 最小截断宽度 | 可能优越性所需种子数 | 族级测试行数 | 累计耗时（小时） |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 5 | 1.742157 | 1.742157 | 17 | 75 | 0.014674 |
| 2 | 10 | 1.339707 | 1.339707 | 20 | 150 | 0.029352 |
| 3 | 15 | 1.142220 | 1.142220 | 22 | 225 | 0.043992 |
| 4 | 20 | 1.017859 | 1.017859 | 23 | 300 | 0.058429 |

该表是协议前沿而不是功效曲线：半径和必要阈值是分布无关的设计量，耗时则
依赖记录的 Apple Silicon CPU 环境。由于 v3 没有比较提前终止，这些累计值
表示所有单元保持开放时达到各检查点的成本，不表示另一种实现可以节省相同计算。
机器可读产物和审计脚本为 `RELIABILITY_COST_FRONTIER_V3.json`、
`generate_reliability_cost_frontier.py` 和 `audit_reliability_cost_frontier.py`。

### 5.6 补充统计诊断

在 v3 密封分析前进行的模拟被作为诊断报告，而不是误差控制的证明。在 5,000 次 Monte Carlo 重复和相同的 5/10/15/20 检查安排下，无配对 Hoeffding 区间在测试的对称与混合场景中的同时覆盖率为 1.0000（Monte Carlo 95% 区间 [0.9992, 1.0000]），在测试的偏斜场景中为 0.9998（[0.9989, 1.0000]）。这些结果与保守有界基线一致，但不建立对任意 RL 种子分布的覆盖结论。

在另一个 5,000 次重复的权衡诊断中，对 Bernoulli 和两点有界分布进行测试，真实差异从 0.00 到 0.20 的每个单元均未出现错误优越性决定，且所有重复均使用完整的 20 种子预算。零错误率估计的 Wilson 上界为 0.0008。该诊断提供了该配置保守且很少在 20 个种子前停止的规划证据，不证明普遍统计功效或计算节省。

解析最坏情形规划文件使用单比较 alpha `0.05`：在 `[0,1]` Hoeffding 界下，首次检查点达到宽度 0.10 约需每个算法 3,904 个种子，20 个种子时未截断宽度约为 1.40。正式 v3 族级分配更保守，在首次检查点对应为 6,071 个种子和 1.7422 的宽度，在最后检查点对应为 8,289 个种子和 2.0357 的宽度。这些是基于界的规划值，不是观察到的需求，也不是 RL 研究的下界。

为检验上述结论是否依赖于此前三个手工构造场景，我们在 v3 分析之后运行了一个固定校准网格。网格包含八类有界分布（Bernoulli、宽/窄两点分布、三种 Beta 浓度以及两种非对称尖峰分布）、从 `-0.20` 到 `0.20` 的五个真实差异，并对每个单元进行 3,000 次独立重复。我们同时评估单比较 alpha `0.05` 和正式 v3 的比较级 alpha `0.05/15`。在两种 alpha 下的全部 80 个单元中，模拟同时覆盖率最低为 1.0000，观察到的错误优越性率最高为 0.0000，所有重复均使用完整的 20 个种子预算。该有限网格中错误优越性率的合并 Wilson 上界为 `0.000032`。这些是指定场景集合上的描述性 Monte Carlo 结果，不证明任意分布下的覆盖率、统计功效或计算节省。完整规格和单元结果见 `CALIBRATION_GRID_REPORT.md`、`calibration_grid.json` 与 `calibration_grid.py`。

### 5.6.1 种子依赖性假设压力测试

有限检查点定理假设，在给定选定配置后，每个算法的密封种子指标是独立抽样。单纯的重放不能证明这一概率假设，因此我们进行了只改变臂内依赖性的受控压力测试。对每个算法臂，Bernoulli(0.5) 值在块大小为 `1`、`2`、`5`、`10`、`20` 或 `50` 的块内重复；两臂之间独立生成，真实差异为零。所有条件使用 alpha `0.05`、0.10 实际优越性边际、50/100/150/200 四个检查点和最多 200 个观测，每个条件进行 5,000 次固定种子 Monte Carlo 重复。

| 块大小 | n=200 时有效块数 | 同时覆盖率 | 95% Wilson 区间 | 错误优越性率 | 95% Wilson 区间 | 平均终止种子数 |
|---:|---:|---:|---|---:|---|---:|
| 1 | 200 | 1.0000 | [0.9992, 1.0000] | 0.0000 | [0.0000, 0.0008] | 200.00 |
| 2 | 100 | 0.9980 | [0.9963, 0.9989] | 0.0000 | [0.0000, 0.0008] | 200.00 |
| 5 | 40 | 0.9304 | [0.9230, 0.9371] | 0.0162 | [0.0131, 0.0201] | 197.74 |
| 10 | 20 | 0.7552 | [0.7431, 0.7669] | 0.1414 | [0.1320, 0.1513] | 180.91 |
| 20 | 10 | 0.4752 | [0.4614, 0.4891] | 0.3328 | [0.3199, 0.3460] | 159.16 |
| 50 | 4 | 0.1244 | [0.1155, 0.1338] | 0.7756 | [0.7638, 0.7869] | 101.67 |

块大小为 1 的独立条件是校准参考，而不是定理证明。随着块大小增加，名义半径仍使用原始计数 `n=200`，但有效独立值数量减少，因而出现覆盖率下降和错误优越性决定。这说明定理必须继续以种子独立性为条件。该替代模型不估计任何 RL 环境中的真实依赖结构，也不提供相关训练运行的修正方法。原始输出和生成器为 `DEPENDENCY_STRESS_DIAGNOSTIC.json` 与 `dependency_stress_diagnostic.py`。

### 5.6.2 已知块依赖回退诊断

当块划分已知且块均值独立时，命题 3 给出一个保守回退：丢弃末尾不完整块，并将相同区间应用于完整块均值。下表使用与前一压力测试相同的 5,000 次重复，对比按原始计数计算的区间和块感知区间。

| 块大小 | 各检查点有效块数 | 朴素覆盖率 | 回退覆盖率 | 朴素错误优越性 | 回退错误优越性 | 朴素平均终止 n | 回退平均终止 n |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | [50, 100, 150, 200] | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 200.00 | 200.00 |
| 2 | [25, 50, 75, 100] | 0.9982 | 1.0000 | 0.0002 | 0.0000 | 199.97 | 200.00 |
| 5 | [10, 20, 30, 40] | 0.9376 | 1.0000 | 0.0124 | 0.0000 | 198.25 | 200.00 |
| 10 | [5, 10, 15, 20] | 0.7706 | 1.0000 | 0.1370 | 0.0000 | 181.58 | 200.00 |
| 20 | [2, 5, 7, 10] | 0.4646 | 1.0000 | 0.3338 | 0.0000 | 158.16 | 200.00 |
| 50 | [1, 2, 3, 4] | 0.1264 | 1.0000 | 0.7812 | 0.0000 | 99.66 | 200.00 |

在全部测试块条件中，回退方法的模拟同时覆盖率为 1.0000，观察到的错误优越性率为 0.0000；代价是有效样本量减少，因而没有提前终止。这里的结果只适用于已知独立块模型，不是对未知 RL 依赖的证明或修正。产物为 `DEPENDENCY_ROBUST_FALLBACK.md`、`DEPENDENCY_ROBUST_FALLBACK.json`、`dependency_robust_fallback_diagnostic.py` 和 `test_dependency_robust_fallback_diagnostic.py`。

### 5.7 替代区间与配对诊断

材料包包含基于早期存储 pilot 产物的派生诊断。这些诊断不与 v3 样本合并，也不改变主要决定规则。在存储的 pilot 中，正态和 bootstrap 区间在某些单元能够较早作出优越性决定，而相同小预算下有界基线仍无法作出结论。这只是可靠性—效率权衡的示例，不证明正态或 bootstrap 区间在所有 RL 场景中无效。

配对诊断进一步说明了保留无配对主要分析的理由。它对一个存储的 PPO/DQN pilot 序列进行 5,000 次确定性重新配对。在 CartPole pilot 中，正态和 bootstrap 的决定在排列下保持不变；但 Acrobot 诊断显示至少一个配对方法的决定计数发生变化。该诊断不估计覆盖率，因为它重复使用一个存储样本，只改变配对方式。它的作用是说明配对结论可能依赖于正式运行并未建立的随机数对齐。

确切产物是 `sb3_pilot_results_round4/interval_sensitivity.json` 和 `sb3_pilot_results_round4/pairing_sensitivity.json`。两个文件都明确标注为派生 pilot 分析，而非投稿结果。因此 v3 只把它们作为方法设计证据，并保留无配对 Hoeffding 区间作为唯一主要程序。

Acrobot pilot 的 5,000 次重新配对得到以下终止决定计数：

| 区间方法 | B 优越 | 仅精度决定 | 最大预算仍未决 | 平均使用种子数 |
|---|---:|---:|---:|---:|
| 正态 | 16 | 121 | 4,863 | 9.867 |
| 配对 bootstrap | 143 | 222 | 4,635 | 9.642 |
| Empirical Bernstein | 0 | 0 | 5,000 | 10.000 |
| 配对 Hoeffding | 0 | 0 | 5,000 | 10.000 |

在正态和 bootstrap 配对计算中，重新排列 DQN 结果会改变决定；无配对方法按构造对这种排列保持不变。这些计数说明决定会依赖配对约定，但它们不是独立实验，也不是方法假阳性率的估计。

我们还将一个事后无配对 empirical-Bernstein 候选作为方差自适应替代方法进行诊断。在五个有界分布场景、每个单元 5,000 次重复下，其所有单元的同时覆盖率估计均为 1.0000（Monte Carlo 下界 0.99923），但在 5—20 个种子的预算下仍与 Hoeffding 基线一样宽。在零效应和 0.10 效应的 Bernoulli 决定单元中，两种方法的 5,000 次重复均达到最大预算且没有作出优越性决定。因此该候选提供的是负的效率结果，而不是新的确认性方法；公式和审计状态记录在 `UNPAIRED_EMPIRICAL_BERNSTEIN_DIAGNOSTIC.md`。

### 5.7.1 验证后选择 alpha 支出诊断

推论 4 将条件化论证从配置选择扩展到有效 alpha 支出方案的选择。我们在 v3 之后运行了一个诊断，预先定义幂级数、前置支出、后置支出和有限检查点 minimax 四种方案；用验证观测的 bootstrap 停止成本选择一个方案，再用新的密封序列评估所选方案。所有方案使用相同的比较级 alpha，检查点为 50、100、150 和 200 个观测，实际边际为 0.05，目标宽度为 0.20。

四类有界分布场景各进行 2,000 次 Monte Carlo 重复，所选方案没有观察到同时覆盖失败或错误优越性决定。零效应、大效应、偏斜效应和两点混合场景的所选平均成本分别为 200.00、50.00、121.53 和 175.20；最佳固定方案分别为 200.00、50.00、119.88 和 173.98。因此验证后选择在这些场景中保持了条件构造，但没有稳定改善成本。该诊断不是 RL 结果，不修改 v3 方案，也不支持普遍效率主张。原始输出和生成器为 `adaptive_spending_diagnostic.json` 与 `adaptive_spending_diagnostic.py`。

### 5.8 数据字典与分析单位

`sb3_formal_v3/raw_seed_metrics.csv` 的每一行代表一个算法、环境、配置、数据划分和训练种子。`metric_raw` 是原始回报尺度上的四检查点平均值；`metric_normalized` 是主要区间使用的有界值；`evaluation_seed_base` 记录确定性的评估种子构造；`runtime_seconds` 记录运行耗时；`status` 记录运行是否成功。验证行只用于候选选择，测试行只在选定配置冻结后使用。主要比较的单位是训练种子，而不是单个评估回合、检查点或跨算法合并的行。

该单位定义避免伪重复。检查点内的五个评估回合和学习曲线内的四个检查点先聚合成一个种子级指标，再比较两个算法均值。若把所有回合级观测当作独立样本，就会把相关测量错误计数为独立训练重复，并回答不同的统计问题。

### 5.9 v3 结论的事后稳健性

为检验主要无法作出结论的结果是否由实际边际或目标宽度选择造成，我们在冻结的 20 个种子序列上使用相同 alpha 支出和比较级 alpha 重新运行决定状态机。实际边际取 0.02、0.05、0.10，目标宽度取 0.05、0.10、0.20 时，九种设置全部得到 15/15 个 `max_budget_inconclusive` 决定。最大种子数限制为 5、10、15、20 的前缀分析同样均为 15/15 最大预算无法作出结论。这些是事后稳健性诊断，不替代预注册阈值。

同一冻结序列还可以进行区间方法敏感性比较。在相同序贯安排和比较级 alpha 下，正态诊断得到 1 个 `a_superior`、1 个 `b_superior`、4 个仅精度决定和 9 个最大预算未决；bootstrap 分别为 1、4、5、5。Empirical Bernstein、配对 Hoeffding 和无配对 Hoeffding 均为 15/15 最大预算无法作出结论。正态和 bootstrap 没有作为确认性结果，因为其序贯错误率没有针对 v3 RL 族进行预注册或独立校准。这说明主要负结果部分来自推断保守性选择，而这本身构成可靠性—成本分析的一部分。

四个主要检查点上，15 个比较的截断区间宽度的最小值、中位数和最大值分别为：5 个种子时 2.0000、2.0000、2.0000；10 个种子时 2.0000、2.0000、2.0000；15 个种子时 1.8770、2.0000、2.0000；20 个种子时 1.7182、1.9199、2.0000。大量区间停留在截断边界，解释了为什么中等描述性差异在该族级有界分配下无法形成正式决定。完整诊断见 `V3_ROBUSTNESS_ANALYSIS.md`，机器可读输出见 `sb3_formal_v3/v3_robustness_analysis.json`。

我们还基于原始四检查点回报，在每个任务使用一组主要边界、一组收紧边界和一组放宽边界重新计算冻结比较。全部 11 种方案均得到 15/15 个 `max_budget_inconclusive` 决定。该事后结果降低了主要负结果由单一归一化选择造成的担忧，但这些替代边界并不是确认性估计对象。边界、原始回报变换和每个决定记录在 `V3_NORMALIZATION_SENSITIVITY.md` 与 `v3_normalization_sensitivity.json` 中。

最后，我们用相同的四候选网格和训练预算，将验证种子从五个增加到十个，并使用二十个不相交的诊断测试种子检查配置选择稳定性。15 个算法—任务单元中有 4 个改变了选定配置：Acrobot/PPO、Acrobot/A2C、CartPole/DQN 和 NonstationaryQueue/DQN。4/15 是同机诊断比例，不是总体概率，也不说明任一网格达到最优。结果说明选定配置属于条件估计对象，不能把五个验证种子描述为普遍稳定的调参标准。完整记录见 `TUNING_STABILITY_V3_REPORT.md` 与 `sb3_tuning_strength_v3/summary.json`。

随后进行的工作区内前瞻性扩展将每个候选的验证种子增加到 20 个，仍使用相同四候选网格、训练预算和选择规则；新种子为 11000—11019，与 v3 及早期诊断不重叠。相对于 v3 的五种子选择，15 个单元中有 7 个发生变化：CartPole/PPO、CartPole/DQN、Acrobot/PPO、Acrobot/A2C、NonstationaryQueue/PPO、NonstationaryQueue/DQN 和 NonstationaryQueue/A2C。该 7/15 结果是固定任务族中的观测选择敏感性诊断，不是总体概率、最优性结论或普遍的二十种子规则。预注册、原始行、审计和报告见 `FINAL_PREREGISTRATION_TUNING_EXTENSION_V1.md`、`sb3_tuning_stability_v20/`、`TUNING_STABILITY_V20_AUDIT.json` 和 `TUNING_STABILITY_V20_REPORT.md`。

| 单元 | v3 选择（5 个验证种子） | 20 种子选择 |
|---|---|---|
| CartPole-v1 / PPO | `lr3e4_short` | `lr3e4_long` |
| CartPole-v1 / DQN | `lr3e4_long` | `lr3e4_short` |
| Acrobot-v1 / PPO | `lr1e4_long` | `lr3e4_long` |
| Acrobot-v1 / A2C | `lr1e4_long` | `lr1e4_short` |
| NonstationaryQueue-v0 / PPO | `lr1e4_short` | `lr3e4_short` |
| NonstationaryQueue-v0 / DQN | `lr3e4_short` | `lr3e4_long` |
| NonstationaryQueue-v0 / A2C | `lr1e4_short` | `lr3e4_short` |

| 单元 | v3 选择（5 个验证种子） | 诊断选择（10 个验证种子） |
|---|---|---|
| Acrobot-v1 / PPO | `lr1e4_long` | `lr1e4_short` |
| Acrobot-v1 / A2C | `lr1e4_long` | `lr3e4_short` |
| CartPole-v1 / DQN | `lr3e4_long` | `lr1e4_long` |
| NonstationaryQueue-v0 / DQN | `lr3e4_short` | `lr3e4_long` |

### 5.10 队列环境的解析 oracle 与切换时刻检查

由于 `NonstationaryQueue-v0` 是自建环境，我们用精确有限状态动态规划单独检查了其转移。令 `$V_t(q)$` 为时刻 `$t$`、队列长度 `$q$` 的最优期望回报，令 `$q'(q,a,u)$` 为披露的下一队列状态，`$p_t(u)$` 为阶段相关的到达概率，则递推为：

\[
V_H(q)=0,\qquad V_t(q)=\max_{a\in\{0,1\}}\sum_{u\in\{0,1\}}p_t(u)\left[-(q'(q,a,u)+c a)+V_{t+1}(q'(q,a,u))\right].
\]

在容量 10、时域 200、到达概率 `(0.25, 0.85)` 和服务成本 0.25 下，空队列初始状态的精确值与“队列非空才服务”策略在切换时刻 1、25、50、100、150、199 均在数值精度内一致。切换时刻 1、100、199 的值分别为 -211.5375、-137.2875 和 -63.0375。完整表格和状态—动作审计见 `QUEUE_ORACLE_DIAGNOSTIC.md` 与 `queue_oracle_diagnostic.json`。这验证了披露的受控环境，但不构成通用 RL 算法排名或外部有效性证据。

### 5.11 训练预算扩展诊断

我们使用 v3 为每个单元选定的配置和相同的 20 个密封训练种子，将训练预算单独增加到 16,384 个环境步，并在 4,096、8,192、12,288 和 16,384 步进行评估。该事后运行只改变训练预算，保持任务族、种子标签、归一化和族级决定规则不变，因此对应不同的条件估计对象，不与 4,096 步主要分析合并。

全部 15 个比较再次达到 20 个种子，并均为 `max_budget_inconclusive`。CartPole 的 PPO、DQN、A2C 归一化均值为 0.247110、0.044230、0.326340；Acrobot 为 0.157615、0.086975、0.092270；MountainCar 为 0.000000、0.000338、0.000000；Taxi 为 0.891089、0.891089、0.791165；队列为 0.805378、0.926907、0.695060。最终截断区间宽度范围为 1.7860—2.0000，中位数为 1.9386，均未接近 0.10 的目标宽度。相对 v3，最大的描述性变化为 CartPole/A2C（+0.124965）、Acrobot/DQN（-0.095500）和 Taxi/A2C（+0.117646）。

该诊断支持两个限定性结论：单独增加训练时域并不能使保守族级比较在 20 个种子下作出决定；训练时域是估计对象的一部分，而不是可忽略的设置。它不建立普遍功效曲线、通用训练预算或算法优越性。完整记录和命令见 `BUDGET_SCALING_DIAGNOSTIC.md` 与 `sb3_budget_scaling_v3/`。

### 5.12 评估回合数敏感性诊断

我们还使用 v3 选定配置和相同的 20 个密封训练种子，将每个检查点的评估回合数从五个增加到十个。训练步数、检查点、评估种子构造、归一化和族级决定规则保持不变。该事后运行包含 300 行测试数据，未与主要分析合并。

全部 15 个比较再次达到 20 个种子，并均为 `max_budget_inconclusive`。最终截断区间宽度为 1.7172—2.0000，中位数为 1.9124。CartPole 的 PPO、DQN、A2C 均值为 0.213380、0.024600、0.199738；Acrobot 为 0.107607、0.187470、0.081990；MountainCar 为 0.000000、0.006463、0.000000；Taxi 为 0.891089、0.891089、0.679138；队列为 0.793480、0.922541、0.621880。相对 v3，最大的单元均值变化为 Taxi/A2C（+0.005619）、Acrobot/DQN（+0.004995）和 Acrobot/A2C（-0.002525）。15 个单元均值的平均绝对变化为 0.0013，按相同训练种子计算的最大单元平均绝对差异为 Taxi/A2C 的 0.0345。

在固定任务族、训练预算、选定配置和测试种子的条件下，评估回合从五个增加到十个没有改变任何族级决定。这降低了主要未决结果完全由每个检查点五个评估回合造成的担忧，但不证明十个回合对其他任务、策略或指标普遍充分，也不构成外部可复现性证据。完整记录见 `EVAL_EPISODE_SENSITIVITY_DIAGNOSTIC.md` 与 `sb3_eval_episode_sensitivity_v3/`。

### 5.13 单独预注册的部分可观测范围诊断

为将执行范围扩展到部分可观测设置，我们单独运行了固定观测掩码诊断：`MaskedCartPole-v1` 将两个速度坐标替换为零，`MaskedAcrobot-v1` 将两个角速度坐标替换为零。该诊断保留 v3 的四候选配置网格、每候选五个验证种子、每个选定配置 20 个测试种子、4,096 步预算和四检查点指标；六个比较共享家族 alpha 0.05。这是固定掩码压力测试，不是标准 POMDP 基准。

原始文件共 240 行（120 行验证、120 行测试）。MaskedCartPole 上 PPO、DQN、A2C 的归一化测试均值为 0.077770、0.021035、0.070285；MaskedAcrobot 上为 0.014135、0.028190、0.028685。全部六个比较在 20 个种子时均为 `max_budget_inconclusive`，区间不支持算法等效结论。该次运行对完整 20 个种子进行全量重放，不提供提前停止成本证据。环境包装器、测试、预注册、原始产物和报告记录于 `partial_observable_env.py`、`FINAL_PREREGISTRATION_PARTIAL_OBSERVABILITY.md` 和 `PARTIAL_OBSERVABILITY_SCOPE_REPORT.md`。该诊断只扩展了执行范围，不支持一般部分可观测结论或外部可复现性。

### 5.14 固定配置队列预算跟踪诊断

正式 v3 结果表明，在族级 alpha 分配下，20 个种子无法分辨任何有界比较。为测量更大预算如何改变这一边界，同时不改变选定程序，我们在 `NonstationaryQueue-v0` 上开展了单独的 v3 之后跟踪。DQN 和 A2C 配置冻结为 v3 的选定配置（分别为 `lr3e4_short` 和 `lr1e4_short`），归一化的四检查点指标、实际边际和比较 alpha `0.05/15` 均保持不变。前 20 个测试指标从不可变的 v3 CSV 逐行复制并核对，另训练 380 个种子。预先声明的检查点为总测试种子数 200、400、600、800 和 1000，测试种子批次大小为 200。

200 个种子时比较仍未决（估计值 `0.318424`，区间 `[0.042965, 0.593883]`）。400 个种子时 DQN−A2C 估计值为 `0.338355`，族调整区间为 `[0.126528, 0.550180]`。由于下端点超过实际边际 `0.05`，状态机在 400 个种子时停止并声明 DQN 优越。400 个种子的描述性均值为 DQN `0.920646`（样本标准差 `0.012969`）和 A2C `0.582292`（样本标准差 `0.323813`）。图 10 显示了两个检查点及其截断区间。

该结果只为一个受控任务和一对冻结配置提供了分辨成本的具体观测上界。它不说明 400 个种子对其他任务足够，不说明 DQN 一般优于 A2C，也不具有新的预注册确认性族的证据地位。完整原始行、源哈希和重算审计见 `sb3_queue_budget_followup_v1/`、`QUEUE_BUDGET_FOLLOWUP_REPORT.md`、`QUEUE_BUDGET_FOLLOWUP_AUDIT.json` 和 `audit_queue_budget_followup.py`。

### 5.15 前瞻性 v4 新种子扩展

v3 之后的队列跟踪诊断复用了 v3 测试前缀。为在不改变选定程序的情况下获得前瞻性新种子观察，我们在打开 30000--30399 种子前预注册了 `FINAL_PREREGISTRATION_V4_EXTENSION.md`。扩展使用相同的五个任务、三个算法、四检查点归一化指标、族级 alpha `0.05/15`、实际边际 0.05 和无配对 Hoeffding 规则；所有 v3 选定配置均冻结，不进行扩展调参。扩展共包含 6,000 行原始数据（15 个任务—算法单元各 400 个种子），并预先声明 200 和 400 个种子两个检查点。

只有 `NonstationaryQueue-v0` 的 DQN−A2C 比较在第一次检查点达到终止决定：估计值为 `0.345322`，区间为 `[0.069863, 0.620781]`，决定为 `a_superior`。其余 14 个比较到 400 个种子时均未达到优越性或目标精度决定。完整决定表和完整性检查见 `V4_EXTENSION_REPORT.md`、`V4_EXTENSION_AUDIT.json` 和 `sb3_v4_extension/`；图 11 展示了扩展区间。

| v4 决定类别 | 比较数量 | 决定/上限种子数 | 代表性证据 |
|---|---:|---:|---|
| `a_superior` | 1 | 200 | 队列 DQN − A2C：0.345322，[0.069863, 0.620781] |
| `max_budget_inconclusive` | 14 | 400 | 其余任务—算法配对；完整区间见 `V4_EXTENSION_REPORT.md` |

该汇总表不构成合并效应估计，只记录决定状态，并将单元级原始数据和区间保留在审计产物中。

v4 与 v3 主要族具有不同的证据地位。它由 v3 的分辨边界推动，并沿用同一任务族，因此不能估计独立抽样任务上的表现；它也不证明 200 或 400 个种子对其他任务足够，不证明 DQN 一般优于 A2C，也不证明外部团队能够复现该结果。

### 5.16 跨种子序列一致性诊断

可以在不合并观测的情况下，将 v4 队列结果与 v3 之后的跟踪序列作描述性比较。跟踪序列复用了 v3 的 20 个种子前缀，而 v4 使用 30000--30399 的新种子。两条序列在 200 和 400 个种子时的 DQN−A2C 估计值均为正。跟踪序列从 200 个种子时的未决区间（`0.318424`，`[0.042965, 0.593883]`）到 400 个种子时的优越性决定（`0.338355`，`[0.126528, 0.550181]`）；v4 在 200 个种子时达到优越性（`0.345322`，`[0.069863, 0.620781]`），其 400 个种子值（`0.342329`，`[0.130503, 0.554156]`）只是描述性延续，因为终止状态已在 200 个种子时锁定。

该一致性是针对一个受控任务和两套冻结程序的诊断，不是合并确认性推断、独立团队可复现性、普遍种子预算或一般算法排名。完整数值和代码见 `V4_SEQUENCE_CONSISTENCY.md`、`V4_SEQUENCE_CONSISTENCY.json` 和 `v4_sequence_consistency.py`。

### 5.17 v5 分辨成本扩展

为在不改变 v3 估计对象的前提下测量 400 个种子之后的分辨边界，我们在打开不相交的新种子序列前预注册了 `FINAL_PREREGISTRATION_V5_EXTENSION.md`。v3 选定配置、4096 步训练预算、四检查点指标、每检查点五个评估回合、族级 alpha、实际边际和无配对 Hoeffding 规则均被冻结。新序列为每个单元 30400--31399 共 1000 个种子，在 200、400、600、800 和 1000 个种子时检查，共 15000 行原始数据。

15 个比较中有 4 个在达到 1000 个种子前终止：Taxi PPO−A2C 和 DQN−A2C 均在 800 个种子时达到优越性决定，NonstationaryQueue PPO−DQN 在 800 个种子时由第二个算法优越，NonstationaryQueue DQN−A2C 在 200 个种子时达到优越性决定。其余 11 个比较在 1000 个种子时仍为 `max_budget_inconclusive`。四个终止区间分别为 `[0.062306, 0.384182]`、`[0.062362, 0.384237]`、`[-0.392109, -0.070234]` 和 `[0.066282, 0.617200]`。这些结果只描述一个冻结任务族和一条新种子序列，不估计经验功效、普遍种子要求或一般算法排名。

| v5 决定类别 | 比较数量 | 决定/上限种子数 | 解释 |
|---|---:|---:|---|
| `a_superior` | 3 | 200 或 800 | 冻结程序下观察到的终止决定 |
| `b_superior` | 1 | 800 | 冻结程序下观察到的终止决定 |
| `max_budget_inconclusive` | 11 | 1000 | 保守区间下仍未决 |

该扩展强化了可靠性—成本刻画：增加预算可以分辨部分已披露效应，但成本依赖任务和比较对象，且到 1000 个种子仍有许多单元未决。它不把四个终止结果升级为确认性算法结论。完整决定表、原始行、停止轨迹和源文件哈希见 `V5_EXTENSION_AUDIT.md`、`V5_EXTENSION_AUDIT.json`、`sb3_v5_extension/` 和 `v5_budget_extension.py`。

对应的 v5 前沿把每个预先声明检查点的分辨模式显式化。解析半径从每算法 200 个种子时的 0.275459 降至 1000 个种子时的 0.147015；已分辨比较数在 600 个种子前保持为 1，在 800 个种子时增至 4。完整 15 单元序列的累计记录运行时间从 0.573089 小时增至 2.875854 小时。由于每个单元的 1000 行均已采集，这些时间是完整记录的成本核算，不是提前停止节省的实测时间。机器可读前沿及审计见 `V5_RELIABILITY_COST_FRONTIER.json`、`V5_RELIABILITY_COST_FRONTIER.md`、`generate_v5_reliability_cost_frontier.py` 和 `audit_v5_reliability_cost_frontier.py`。

| v5 检查点 | 每算法种子数 | 半径和 | 累计运行时间（小时） | 新增决定 | 已决定 | 未决定 |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 200 | 0.275459 | 0.573089 | 1 | 1 | 14 |
| 2 | 400 | 0.211826 | 1.149731 | 0 | 1 | 14 |
| 3 | 600 | 0.180601 | 1.725827 | 0 | 1 | 14 |
| 4 | 800 | 0.160938 | 2.302629 | 3 | 4 | 11 |
| 5 | 1000 | 0.147015 | 2.875854 | 0 | 4 | 11 |

### 5.18 实际边际敏感性诊断

实际边际和目标宽度在 v3 密封分析前已经冻结，但其科学含义并不普遍。因此我们只改变实际优越性边际为 `0.00`、`0.025`、`0.05`、`0.10`、`0.20`、`0.30` 和 `0.50`，重新计算 v3 状态机；族 alpha、四个检查点、0.10 目标宽度、区间方法和已存测试行均保持不变。这是事后敏感性诊断，不是新的确认性族。

| 边际 | 检查点 1 必要种子数 | 检查点 2 必要种子数 | 检查点 3 必要种子数 | 检查点 4 必要种子数 | 20 个种子内观测决定 |
|---:|---:|---:|---:|---:|---|
| 0.000 | 16 | 18 | 20 | 21 | 15 个 `max_budget_inconclusive` |
| 0.025 | 16 | 19 | 21 | 22 | 15 个 `max_budget_inconclusive` |
| 0.050 | 17 | 20 | 22 | 23 | 15 个 `max_budget_inconclusive` |
| 0.100 | 19 | 23 | 25 | 26 | 15 个 `max_budget_inconclusive` |
| 0.200 | 24 | 29 | 31 | 33 | 15 个 `max_budget_inconclusive` |
| 0.300 | 31 | 37 | 40 | 43 | 15 个 `max_budget_inconclusive` |
| 0.500 | 61 | 72 | 79 | 83 | 15 个 `max_budget_inconclusive` |

必要阈值列是任何有界数据可能越过边际的解析条件，不是功效或充分样本数计算。观测计数表明这批 v3 样本在所测试边际下都未决，但不建立普遍边际或未来样本行为。机器可读结果和生成器为 `margin_sensitivity_v3.json` 与 `margin_sensitivity_v3.py`。

## 6 讨论

主要结果是一个具有操作意义的负结果：在保守有界区间、四个预先声明的检查点、族 alpha 0.05 和 20 个测试种子的条件下，15 个比较均没有达到正式优越性或目标精度决定。推论 2 进一步说明，在正式 v3 分配下，这种未决状态对任何有界数据集都是数学上必然的。RL 运行因此验证了所选任务族上的执行和估计对象，但不估计二十个种子时的经验功效。这是协议分辨率结果，而不是 RL 种子数量的普遍下界。

该结果也说明了协议设计的边界。正式区间不是提前停止的承诺，而是揭示何时测试预算过小、无法作出分布无关决定的基线。在本研究中，非分辨性在观察任何 RL 结果之前就由半径计算决定；15 个比较全部达到最大预算验证了实现遵循这一边界，而不是一次未能产生正向算法排名的尝试。

事前预算可行性审计把这一观察转化为规划步骤：在训练密封测试种子之前，评估者可以判断注册上限在所选有界区间下是否可能越过实际边际或宽度目标。如果两个标志均为假，研究应增加预先登记的信息预算，或者明确声明研究目的是刻画无法分辨的边界。这样可以避免把结构上不可能的决定描述为经验功效失败。该审计只适用于输入的区间、alpha 分配、指标范围和阈值，不能替代其他程序的功效分析。

队列预算跟踪诊断提供了互补观察：当测试预算增加时，同一个具有条件覆盖保证的状态机最终可以分辨一个较大的观测差异。这不与 v3 推论矛盾，因为推论针对 20 个种子的上限，而跟踪实验使用不同的事后预算和不同的诊断范围。两者共同区分了三个容易混淆的量：假设下的区间有效性、固定预算下的分辨能力，以及分辨一个已观测任务比较的经验成本。

前瞻性 v4 扩展使用新种子而非只追加原始前缀，在第一次 200 个种子检查点再次观察到相同的队列方向，而另外 14 个比较到 400 个种子仍未解决。这降低了队列观察完全由复用 v3 前 20 个种子造成的担忧，但没有形成独立任务族抽样或外部可复现性；终止事件仍然条件于一个受控任务、两套冻结程序和所定义的指标。

v5 扩展提供了当前材料包中最完整的任务族内成本诊断：4 个比较在 200 或 800 个新种子时达到决定，11 个比较到 1000 个种子仍未决。由于它使用同一台机器、同一任务族和同一组选定配置，并由早期结果推动，它是预算分辨观察，不是独立复现或前瞻性功效曲线。其作用是说明分辨成本不能作为一个数字转移到其他 RL 任务或算法比较。

为保证审计性，运行器为每个单元完整收集了 1000 个种子。因此 200 或 800 是完整记录中的前缀分辨点，而不是停止剩余训练后实际节省的墙钟计算量；这里的成本是样本分辨成本，不是计算节省主张。

扩展的四候选网格缓解了 v2 的调优限制，但相较于算法特定的大规模优化仍然有限。因此研究支持等预算协议分析，不支持选定配置全局最优的主张。验证选择与测试推断保持分离，但任意超参数网格都会影响条件估计对象。

主要任务族混合了三个标准离散控制任务、一个离散 Taxi 诊断任务和一个自建队列任务。队列现在具有精确有限状态 oracle 和切换时刻 sanity check，但仍是受控诊断而非标准基准。单任务 Pendulum 连续控制补充实验在 `CONTINUOUS_SUPPLEMENT_REPORT.md` 中单独报告，没有并入主要族，且只包含 PPO/A2C；`MountainCarContinuous-v0` 作为另一项独立范围诊断。另有固定速度掩码的 CartPole 与 Acrobot 诊断，但这不代表一般 POMDP。主要任务族仍没有视觉任务。MountainCar 的回报下限以及 Taxi 的近似确定性均值降低了这些单元的信息量。队列的外部有效性仍然有限，因为它是自建任务，不能代表完整 RL 环境空间。

单独预注册的范围扩展加入 `MountainCarContinuous-v0`，使用 PPO 和 A2C，共 80 行数据，且不并入主要族。两个算法均选择 `lr1e4_short`；20 个测试种子的归一化均值分别为 PPO 0.499982、A2C 0.499859。PPO−A2C 估计值为 0.0001233，区间为 `[-0.8747, 0.8749]`，四个检查点均无法作出结论。单独的同机复现使两个均值的平均绝对指标差异均为 0.0。这增加了第二个连续动作任务的执行诊断，但不支持连续控制算法排名或外部可复现性。详见 `CONTINUOUS_SCOPE_EXPANSION_REPORT.md`。

### 6.3 定理支持的评估设计建议

形式化结果最适合在新的 RL 比较开始前作为设计约束使用。以下建议仅适用于本文研究的有界、有限检查点、双臂构造，不是所有置信区间或基准任务的普遍规则。

1. **在打开密封测试数据前封闭比较族并冻结 alpha 分配。** 族控制推论和命题 0 要求比较单元、检查点集合和仅基于验证数据的选择规则在测试数据打开前固定。因此，实践协议应预先登记任务—算法族、候选配置、逐单元 alpha 分配和停止阈值。这保护了区间的条件解释，但不能保护观察测试结果后扩展的比较族。

2. **在收集测试种子前计算必要分辨阈值。** 推论 2 和必要优越性阈值给出了任何有界数据可能越过实际边际或宽度目标所需的预算条件。如果预算上限低于该阈值，则未决结果由区间边界强制产生，应报告为设计限制，而不能作为算法等价的证据。该阈值是必要的解析条件，不是功效计算或普遍种子要求。

3. **固定总种子预算时采用平衡的两臂分配。** 推论 5 表明，在固定独立种子总数下，等量分配使两个 Hoeffding 半径之和的最坏情形最小。这是针对本文无配对区间的规划规则，并不意味着不同算法的墙钟时间相等、其他区间下的方差相等或经验 RL 功效更高。

4. **将配置选择、验证和密封测试保持为独立证据阶段。** 命题 0 支持对验证数据上选定的可测规则进行条件化，同时保留测试序列的覆盖陈述。因此应保留每个候选配置的验证记录、冻结选定配置，并禁止利用测试结果调参。该命题不支持从密封测试结果选择配置，也不支持声称候选网格达到全局最优。

5. **报告完整的可靠性—成本前沿，包括未决检查点。** 命题 2 为预先声明检查点上的锁定终止决定提供依据，而 v3/v5 诊断表明仅报告终止决定数量是不完整的。报告应列出每个检查点的半径、宽度目标、必要阈值、决定数量和观测运行时间，包括最大预算未决状态。运行时间必须标明机器和收集策略；前沿不能自动解释为硬件无关的计算节省主张。

6. **区分可重复性和可复现性。** 同机重放检查的是实现可重复性，不同机器或独立团队的密封重跑才是可复现性证据。覆盖证明本身不提供这两类证据。完整投稿应披露实际测试了哪一级证据；缺少独立证据时，应保留更强标签为未解决。

7. **在使用已知块回退前先诊断依赖。** 命题 3 的块回退只有在分析前已指定块划分、完整块均值有界且这些块均值在给定模型下独立抽样时才可使用。依赖压力测试可以揭示原始种子区间的脆弱性，但不能从 RL 轨迹反推出块结构。当依赖结构未知、块重叠或块间可能存在残余相关时，不得把回退写成修正；结果应标注为依赖于未验证的独立性假设，并报告有效样本量的不确定性。

这些建议是在给定假设下对协议构造和报告方式的推论，不表示本文已经建立普遍最优的评估器、RL 的最小种子数或一般算法排名。

## 7 局限与有效性威胁

**外部有效性。** 五个离散动作任务不能代表完整的 RL 基准空间。队列是受控自建任务。单独的 Pendulum、MountainCarContinuous 和固定掩码部分可观测诊断扩展了执行范围，但仍缺少视觉任务、一般 POMDP 族和大规模证据。

**调优强度。** 四个候选配置和每候选五个验证种子比 v2 更强，但仍然有限。将验证种子增加到十个后有 4/15 个选择发生变化，独立的二十种子扩展相对于 v3 又有 7/15 个选择发生变化。这些是固定任务族中的选择敏感性诊断，不是总体概率，也不证明二十个验证种子普遍足够。v3 配置应作为条件估计对象的一部分报告，不能描述为普遍稳定的调参标准。

**指标依赖性。** 归一化使用预先声明的任务回报边界。不同的科学上合理的边界会改变归一化估计对象，即使原始回报不变。原始回报已保留，且 11 种边界方案的事后敏感性分析均使 15 个比较在最大预算时无法作出结论；这些替代边界不是确认性估计对象。

**决定阈值。** 实际边际 0.05 和目标宽度 0.10 是在 v3 测试分析前冻结的设计选择，不是有意义 RL 改进或充分精度的普遍定义。未来研究应预注册任务特定的边际，并报告小型敏感性网格下的决定变化。

**评估时域。** 4096 步预算和四检查点平均值定义了本文研究的估计对象。MountainCar 在该预算下接近回报下限，更长时域可能回答不同问题。在单独的 16,384 步固定配置诊断中，15 个比较仍均在最大预算时无法作出结论，但若干描述性均值发生了明显变化。因此时域应被视为估计对象的一部分，该诊断未并入主要族。

**评估回合数。** 主要指标在每个检查点平均五个回合。十回合固定配置诊断保留了全部 15 个最大预算未决决定，且单元均值的总体变化较小，但不能为其他任务或策略建立通用回合数规则。

**统计假设。** 证明依赖于验证选择条件化、固定检查点、有界指标以及每个算法内部密封种子序列的独立性。环境漂移、隐藏测试复用和数据依赖的任务族扩展不在保证范围内。

**不可观测的依赖结构。** 块依赖压力测试和回退诊断使用受控替代数据，不能识别 RL 训练种子、评估回合或环境轨迹的真实依赖结构。因此，命题 3 只有在分析前已知并声明独立块划分时才适用，不能修复未知、重叠或块间残余依赖。在缺少这些信息时，有效样本量是不确定的，名义有限检查点区间必须继续明确条件于未验证的种子独立性假设。

**可复现性。** 零差异复现是同机跨脚本可重复性。返回的 Windows AMD64 运行提供了冻结协议的不同机器可复现性：15 个选定配置和终止决定全部匹配，14/15 个单元为零差异，另一个单元报告平台差异。操作者的独立机构身份未核验，运行也未测试新任务族；硬件和软件包元数据不能消除全部非确定性风险。

**前瞻性扩展范围。** v4 扩展使用新种子，并在打开这些种子前冻结了方案，但它由 v3 结果推动，沿用了 v3 任务族和选定配置。单个队列终止比较以及 14 个未决单元不能支持普遍预算或算法结论。

**v5 成本诊断范围。** v5 在 30400--31399 新种子上使用 200、400、600、800 和 1000 个种子检查点。4 个比较在 200 或 800 个新种子时终止，另外 11 个到 1000 个种子仍未决。该结果是同机、同任务族和冻结配置下的观察分辨成本，不是经验功效曲线、普遍种子要求、独立复现或算法排名。

**新颖性与期刊。** 既有研究已经提出 RL 可靠性指标和统计比较工具[L15]。本文有限检查点、条件性验证后估计对象和密封测试协议的确切差异，以及任何具体 SCI 期刊的适配性，需要完整且最新的文献与期刊审查[待核实]。本文不声称接收，也不保证发表。

**多层不确定性。** 区间覆盖的是给定假设下的条件种子分布，不量化任务族选择、归一化边界、算法实现、软件版本或超参数网格带来的不确定性。这些层面通过设计披露和敏感性分析处理，而不是把它们静默塞进同一个区间。

## 8 可复现性与开放材料

材料包包含预注册文件、运行器源代码、受控环境源代码、原始 CSV、JSON 摘要、复现输出、源文件哈希和软件元数据。主要文件包括 `FINAL_PREREGISTRATION_V3.md`、`sequential_sb3_runner_v3.py`、`independent_reproduction.py`、`sb3_formal_v3/raw_seed_metrics.csv`、`sb3_formal_v3/familywise_cost_summary.json`、`sb3_formal_v3/independent_reproduction_summary.json`、`DEPENDENCY_STRESS_DIAGNOSTIC.md` 和 `REPRODUCTION_MANIFEST_V3.md`。连续控制补充实验有独立的预注册、运行器、原始输出和复现清单，并保留同机可重复性与外部可复现性的区分。

### 8.1 可复现性层级

材料包使用三个不同标签。**可重复性**表示同一团队能够用公开脚本和同一台机器重新生成报告摘要；15 个主要单元均得到零记录平均绝对指标差异的支持。**不同机器可复现性**表示冻结材料在不同操作系统和硬件平台上能够产生可比较的原始指标；Windows AMD64 密封复跑提供了这一证据，但操作者的独立机构身份未核验，因此不将其称为独立团队可复现性。**科学结论的可复制性**表示新的安装或任务族能够得到相同的可靠性—成本模式；当前尚未证明。区分这些标签是因为一个软件状态的精确重放不能检验全部三种性质。

### 8.2 投稿前披露项目

投稿前作者信息还需补充代码仓库或存档链接、许可证、作者贡献、基金、利益冲突和数据可用性声明[待补充]。当前材料包含源文件哈希和本地 wheel 哈希，但本身还不是公开存档。期刊当前关于代码、数据、补充文件和文章类型的政策需要在投稿日核对[待核实]。

## 9 主张—证据表

| 主张 | 证据 | 状态 |
|---|---|---|
| 在给定假设下，有限检查点区间具有条件族覆盖率。 | 命题 1、`METHOD_AUDIT.md`、实现测试。 | 条件性方法结果；建议独立统计审计。 |
| 在正式 v3 分配下，20 个种子对任何有界数据都不能触发优越性或 0.10 宽度精度决定。 | 推论 2、`ANALYTIC_NONRESOLUTION_NOTE_V3.md`、等样本半径计算，以及 `test_formal_v3_budget_is_structurally_non_resolving`。 | 协议分辨率的解析结果，不是 RL 样本量的普遍下界。 |
| v3 族包含 15 个比较、等候选验证选择和密封测试。 | `FINAL_PREREGISTRATION_V3.md`、`run_config.json`、600 行 CSV。 | 本次运行得到支持。 |
| v3 没有正式优越性或精度决定。 | `familywise_cost_summary.json`；15/15 最大预算无法作出结论。 | 得到支持。 |
| v5 扩展在 1000 个新种子内观察到 4 个终止决定，而 11/15 单元仍未决。 | `FINAL_PREREGISTRATION_V5_EXTENSION.md`、`sb3_v5_extension/`、`V5_EXTENSION_AUDIT.json`、`V5_EXTENSION_AUDIT.md`。 | 作为同机分辨成本诊断得到支持；不是经验功效、普遍种子要求、外部复现或算法排名。 |
| 选定配置的描述性均值按任务而异。 | `descriptive_summary.json`。 | 仅支持描述性解释，不是排名证据。 |
| 存储摘要可被同机第二个脚本重复。 | `independent_reproduction_summary.json`；15 个零差异单元。 | 得到支持。 |
| 种子独立性假设具有具体的失效模式诊断。 | `DEPENDENCY_STRESS_DIAGNOSTIC.json`、生成器和第 5.6.1 节六个条件的压力测试。 | 作为受控替代诊断得到支持；不估计 RL 环境中的依赖，也不修正相关训练运行。 |
| 已知块依赖结构具有保守回退。 | 命题 3 将相同的有界有限检查点构造应用于完整独立块均值；5,000 次配对压力测试报告原始计数与块感知覆盖率、错误优越性和有效样本量。 | `DEPENDENCY_ROBUST_FALLBACK.md`、`DEPENDENCY_ROBUST_FALLBACK.json`、生成器、测试和第 5.6.2 节。 | 仅在已知独立块模型下得到支持；不是 RL 依赖修正或实际已知块结构的证据。 |
| 同一流程可在一个连续动作任务上执行。 | 连续补充预注册、80 行产物和独立复现。 | 作为一个任务的范围诊断得到支持。 |
| 不同机器能够复现冻结协议。 | `复跑结果/EXTERNAL_RERUN_AUDIT.json`；15/15 配置和终止决定匹配，14/15 单元零逐种子差异，另一个单元有平台差异。 | 在披露任务族和软件状态范围内得到支持；独立团队身份和新任务族科学复制仍未验证。 |
| 协议普遍节省计算或能够对 PPO/DQN/A2C 排名。 | 跨任务和预算的校准证据。 | 不支持。 |

## 10 结论

v3 研究提供了一个关于保守序贯 RL 评估协议的预注册、可审计检验。采用扩展等候选验证、密封测试种子和族级有限检查点控制后，全部 15 个比较在 20 个测试种子时仍无法作出结论。正式预算推论表明，在该规则下这一结果对任何有界数据都是必然的；RL 运行验证的是选定任务族上的执行，而不是二十个种子时的经验功效。该结果刻画了此协议和基准族的可靠性—成本边界；Windows AMD64 密封复跑进一步支持冻结协议的不同机器可复现性，但不建立普遍种子预算、算法排名、计算节省、独立团队科学复制或新任务族外部有效性。单独的 Pendulum 补充实验表明流程可以在一个连续动作任务上运行，但其单任务、双算法范围不足以建立连续控制泛化。

v5 扩展将成本诊断扩展到完整冻结任务族：4 个比较在 200 或 800 个新种子时达到终止决定，11 个比较到 1000 个种子仍未决。这支持较窄的结论，即保守分辨成本随任务和算法比较而变化；它不支持一般优越性、1000 个种子普遍足够或新任务族科学复制。

种子依赖性压力测试提供了另一条边界证据：在保持边际均值不变的情况下引入臂内块相关，会使名义有限检查点区间失去覆盖并产生错误优越性决定。这不是对 RL 任务真实依赖结构的估计，但说明同机重放不能证明独立性假设成立。

最后，事前可行性审计提供了一个可复现的事前决策点。对 v3 而言，它会在观察任何 RL 结果前标记 20 个种子的上限无法达到两个注册阈值。因此，审计使所选统计证书的成本在实验开始前可见，同时把经验功效、任务族有效性和独立性假设保留为相互独立的问题。

## 11 声明

**作者贡献。** 概念设计、方法、软件、实验、形式分析、可视化和写作：`[待补充作者信息]`。

**经费。** 经费信息：`[待补充]`。当前工作区记录没有可核实的经费来源声明。

**利益冲突。** 作者声明：`[待补充]`。

**数据与代码可用性。** 源代码、预注册文件、种子级原始 CSV、JSON 摘要、arm64 wheel 归档和审计命令均整理在本研究工作区。公开代码仓库 DOI 或 URL 尚未分配，投稿前必须补充`[待补充]`。材料包区分同机跨脚本可重复性与独立复现，不宣称后者。

**伦理与 broader impact。** 本研究使用模拟控制环境，不包含人类参与者、个人数据或动物受试者。自建队列明确作为受控诊断任务，不被描述为真实部署或政策建议。主要潜在影响是方法学层面的：若忽略估计对象和局限性，读者可能过度外推保守区间或固定任务族的结论。

## 12 建议的后续研究

最有信息量的下一项研究应保留 v3 主要族，并新增一个单独预注册的任务族，而不是修改既有结果。它应至少加入一个连续控制任务和一个视觉或部分可观测任务，使用明确预算的更强调优网格，报告原始回报敏感性，并完成不同机器上的密封复现。统计比较必须在打开新测试种子前冻结，同时为每个候选区间报告经验覆盖率、停止成本和效应量校准。在这些步骤完成前，当前论文应继续限定为已展示的固定预算可靠性—成本边界。

## 参考文献

[L1] Henderson, P., Islam, R., Bachman, P., Pineau, J., Precup, D., & Meger, D. (2018). Deep Reinforcement Learning That Matters. *Proceedings of the AAAI Conference on Artificial Intelligence*, 32(1). DOI: 10.1609/aaai.v32i1.11694.

[L2] Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2018). How Many Random Seeds? Statistical Power Analysis in Deep Reinforcement Learning Experiments. arXiv:1806.08295. DOI: 10.48550/arXiv.1806.08295.

[L3] Colas, C., Sigaud, O., & Oudeyer, P.-Y. (2019). A Hitchhiker's Guide to Statistical Comparisons of Reinforcement Learning Algorithms. arXiv:1904.06979. DOI: 10.48550/arXiv.1904.06979.

[L4] Agarwal, R., Schwarzer, M., Castro, P. S., Courville, A., & Bellemare, M. G. (2021). Deep Reinforcement Learning at the Edge of the Statistical Precipice. arXiv:2108.13264. DOI: 10.48550/arXiv.2108.13264. 最终期刊信息[待核实]。

[L5] Hoeffding, W. (1963). Probability Inequalities for Sums of Bounded Random Variables. *Journal of the American Statistical Association*, 58(301), 13–30. DOI: 10.1080/01621459.1963.10500830.

[L6] Lan, K. K. G., & DeMets, D. L. (1983). Discrete Sequential Boundaries for Clinical Trials. *Biometrika*, 70(3), 659–663. DOI: 10.1093/biomet/70.3.659.

[L7] Schulman, J., Wolski, F., Dhariwal, P., Radford, A., & Klimov, O. (2017). Proximal Policy Optimization Algorithms. arXiv:1707.06347.

[L8] Mnih, V., et al. (2015). Human-level control through deep reinforcement learning. *Nature*, 518, 529–533. DOI: 10.1038/nature14236.

[L9] Mnih, V., et al. (2016). Asynchronous Methods for Deep Reinforcement Learning. *Proceedings of the 33rd International Conference on Machine Learning*. https://arxiv.org/abs/1602.01783.

[L10] Towers, M., et al. (2025). Gymnasium: A Standard Interface for Reinforcement Learning Environments. *Advances in Neural Information Processing Systems 38*, 163114–163129. DOI: 10.52202/085713-4916.

[L11] Whiteson, S., Tanner, B., Taylor, M. E., & Stone, P. (2011). Protecting against evaluation overfitting in empirical reinforcement learning. *2011 IEEE Symposium on Adaptive Dynamic Programming and Reinforcement Learning (ADPRL)*, 120–127. DOI: 10.1109/ADPRL.2011.5967363. Full-text method comparison [待核实].

[L12] Raffin, A., Hill, A., Gleave, A., Kanervisto, A., Ernestus, M., & Dorman, N. (2021). Stable-Baselines3: Reliable Reinforcement Learning Implementations. *Journal of Machine Learning Research*, 22(268), 1–8. https://jmlr.org/papers/v22/20-1364.html.

[L13] Zhang, C., Vinyals, O., Munos, R., & Bengio, S. (2018). A Study on Overfitting in Deep Reinforcement Learning. arXiv:1804.06893v2. DOI: 10.48550/arXiv.1804.06893.

[L14] Nagarajan, P., Warnell, G., & Stone, P. (2018). Deterministic Implementations for Reproducibility in Deep Reinforcement Learning. arXiv:1809.05676v5. DOI: 10.48550/arXiv.1809.05676.

[L15] Chan, S. C. Y., Fishman, S., Canny, J., Korattikara, A., & Guadarrama, S. (2019). Measuring the Reliability of Reinforcement Learning Algorithms. arXiv:1912.05663v2. DOI: 10.48550/arXiv.1912.05663.

[L16] Khamaru, K., Xia, E., Wainwright, M. J., & Jordan, M. I. (2022). Instance-Dependent Confidence and Early Stopping for Reinforcement Learning. arXiv:2201.08536. DOI: 10.48550/arXiv.2201.08536.
"""


def add_chinese_source(doc: Document) -> None:
    lines = CN_MARKDOWN.strip().splitlines()
    i = 0
    table_index = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line:
            i += 1
            continue
        if line.startswith("## ") or line.startswith("### "):
            level = 1 if line.startswith("## ") else 2
            text = clean_inline(line.split(" ", 1)[1])
            doc.add_paragraph(text, style=f"Heading {level}")
            if text == "3 估计对象与统计协议":
                add_formula_block(doc, chinese=True)
            elif text == "4 实验设计":
                add_figure(doc, "fig_protocol.png", "图 1。预注册嵌套评估协议与密封测试决定流程。", chinese=True)
            elif text == "5.2 描述性测试均值":
                add_figure(doc, "fig_heatmap.png", "图 2。选定配置的描述性归一化测试均值（每个单元 n = 20）；该图不构成算法排名。", chinese=True)
            elif text == "5.3 正式区间":
                add_figure(doc, "fig_intervals.png", "图 3。15 个主要比较的点估计与族调整区间；n = 20 时全部决定均为 max_budget_inconclusive。", chinese=True)
            elif text == "5.5.1 验证选择重采样诊断":
                add_figure(doc, "fig_selection_uncertainty.png", "图 9。五个验证种子联合行重采样下的描述性配置选择频率。这是事后不稳定性诊断，不是总体概率。", chinese=True)
            elif text in ("5.5 补充统计诊断", "5.6 补充统计诊断"):
                add_figure(doc, "fig_budget_frontier.png", "图 4。[0,1] 有界指标下的解析 Hoeffding 区间宽度规划诊断；它不是观察到的需求或下界。", chinese=True)
            elif text == "5.9 v3 结论的事后稳健性":
                add_figure(doc, "fig_tuning_stability.png", "图 5。验证种子从 5 个增加到 10 个时的配置选择稳定性。红色单元表示选择发生变化；这是事后诊断。", chinese=True)
                add_figure(doc, "fig_normalization_sensitivity.png", "图 6。11 种归一化方案下最大预算仍未决的比较数量。全部方案均为 15/15 未决；这是事后诊断。", chinese=True)
            elif text == "5.11 训练预算扩展诊断":
                add_figure(doc, "fig_budget_scaling.png", "图 7。固定 v3 选定配置下 4,096 步与 16,384 步的描述性均值。该诊断未与主要估计对象合并。", chinese=True)
            elif text == "5.12 评估回合数敏感性诊断":
                add_figure(doc, "fig_eval_episode_sensitivity.png", "图 8。每个检查点的评估回合从 5 个增加到 10 个时，按训练种子匹配的归一化指标平均绝对变化。", chinese=True)
            elif text == "5.14 固定配置队列预算跟踪诊断":
                add_figure(doc, "fig_queue_budget_followup.png", "图 10。固定配置队列跟踪诊断：DQN−A2C 区间在 200 个种子时未决，在 400 个种子时超过实际优越性边际。这是 v3 之后的分辨成本诊断。", chinese=True)
            elif text == "5.15 前瞻性 v4 新种子扩展":
                add_figure(doc, "fig_v4_extension.png", "图 11。前瞻性 v4 扩展在每个单元 400 个新种子上的区间。只有受控队列 DQN−A2C 比较在 n = 200 时达到终止优越性决定，其余 14 个单元在 n = 400 时仍未决。", chinese=True)
            elif text == "5.17 v5 分辨成本扩展":
                add_figure(doc, "fig_v5_extension.png", "图 12。v5 分辨成本扩展，每个单元最多 1000 个新种子。4 个比较在 n = 200 或 800 时达到终止决定，11 个比较在 n = 1000 时仍未决；这是同机诊断，不是普遍种子规则。", chinese=True)
            elif text == "5.19 前瞻性 v6 任务族扩展":
                add_figure(doc, "fig_v6_extension.png", "图 13。v6 扩展在两个固定离散任务上、每个算法 200 个种子的最终检查点区间。虚线表示实际边际；六个比较均未决。", chinese=True)
            i += 1
            continue
        if line.startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i])
                i += 1
            headers, rows = parse_table(block)
            table_index += 1
            add_table(doc, headers, rows, f"表 {table_index}。{headers[0] if headers else '汇总'}")
            continue
        if re.match(r"^\d+\. ", line):
            p = doc.add_paragraph(style="List Number")
            p.paragraph_format.first_line_indent = Cm(0)
            p.add_run(clean_inline(re.sub(r"^\d+\. ", "", line)))
            i += 1
            continue
        if line.startswith("- "):
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.first_line_indent = Cm(0)
            p.add_run(clean_inline(line[2:]))
            i += 1
            continue
        add_body_paragraph(doc, line, chinese=True)
        i += 1


def add_appendix(doc: Document, chinese: bool) -> None:
    doc.add_page_break()
    doc.add_paragraph("Appendix A. Continuous-control scope supplement" if not chinese else "附录 A。连续控制范围补充实验", style="Heading 1")
    paras = [
        "The separate Pendulum-v1 supplement uses PPO and A2C, four candidate configurations, five validation seeds per candidate, one selected configuration per algorithm, and 20 sealed test seeds. The raw artifact contains 80 rows. The PPO-minus-A2C estimate is -0.0009 with interval [-0.8757, 0.8739], and the decision is max_budget_inconclusive. Same-machine cross-script replay differences are 0.0 for both algorithms. This is a one-task scope diagnostic and does not support continuous-control generalization or external reproducibility." if not chinese else
        "单独的 Pendulum-v1 补充实验使用 PPO 和 A2C、四个候选配置、每个候选五个验证种子、每个算法一个选定配置和 20 个密封测试种子，原始产物共 80 行。PPO−A2C 的估计值为 −0.0009，区间为 [−0.8757, 0.8739]，决定为 max_budget_inconclusive。两个算法的同机跨脚本复现差异均为 0.0。这只是一个任务的范围诊断，不支持连续控制泛化或外部可复现性。",
        "Primary source: CONTINUOUS_SUPPLEMENT_REPORT.md; preregistration: FINAL_PREREGISTRATION_CONTINUOUS_SUPPLEMENT.md; reproduction manifest: REPRODUCTION_MANIFEST_CONTINUOUS_SUPPLEMENT.md." if not chinese else
        "主要来源：CONTINUOUS_SUPPLEMENT_REPORT.md；预注册：FINAL_PREREGISTRATION_CONTINUOUS_SUPPLEMENT.md；复现清单：REPRODUCTION_MANIFEST_CONTINUOUS_SUPPLEMENT.md。",
    ]
    for text in paras:
        add_body_paragraph(doc, text, chinese=chinese)
    doc.add_paragraph("Appendix B. MountainCarContinuous-v0 scope expansion" if not chinese else "附录 B。MountainCarContinuous-v0 范围扩展", style="Heading 1")
    scope_paras = [
        "The separately preregistered MountainCarContinuous-v0 supplement uses PPO and A2C, four candidate configurations, five validation seeds per candidate, one selected configuration per algorithm, and 20 sealed test seeds. Both algorithms selected lr1e4_short. The normalized test means were 0.499982 for PPO and 0.499859 for A2C. The PPO-minus-A2C estimate was 0.0001233 with interval [-0.8747, 0.8749]; all four looks were max_budget_inconclusive. Same-machine cross-script replay differences were 0.0 for both algorithms. This is a second continuous-action execution diagnostic, not a continuous-control ranking or external reproducibility result." if not chinese else
        "单独预注册的 MountainCarContinuous-v0 补充实验使用 PPO 和 A2C、四个候选配置、每个候选五个验证种子、每个算法一个选定配置和 20 个密封测试种子。两个算法均选择 lr1e4_short。归一化测试均值为 PPO 0.499982、A2C 0.499859；PPO−A2C 估计值为 0.0001233，区间为 [-0.8747, 0.8749]，四个检查点均为 max_budget_inconclusive。同机跨脚本复现中两个算法的差异均为 0.0。这是第二个连续动作任务的执行诊断，不是连续控制排名或外部可复现性结果。",
        "Primary source: CONTINUOUS_SCOPE_EXPANSION_REPORT.md; preregistration: FINAL_PREREGISTRATION_CONTINUOUS_SCOPE_EXPANSION.md; audit: audit_continuous_scope_artifacts.py." if not chinese else
        "主要来源：CONTINUOUS_SCOPE_EXPANSION_REPORT.md；预注册：FINAL_PREREGISTRATION_CONTINUOUS_SCOPE_EXPANSION.md；审计：audit_continuous_scope_artifacts.py。",
    ]
    for text in scope_paras:
        add_body_paragraph(doc, text, chinese=chinese)
    doc.add_paragraph("Appendix C. v6 task-family extension" if not chinese else "附录 C。v6 任务族扩展", style="Heading 1")
    add_figure(doc, "fig_v6_extension.png", "Figure 13. v6 final-look intervals for two additional fixed discrete tasks at 200 seeds per algorithm. Dashed lines mark the practical margin; all six comparisons remain inconclusive." if not chinese else "图 13。v6 扩展在两个固定离散任务上、每个算法 200 个种子的最终检查点区间。虚线表示实际边际；六个比较均未决。", chinese=chinese)
    v6_paras = [
        "The prospective v6 extension adds CliffWalking-v1 and a fixed 4 x 4 slippery FrozenLake-v1 task. It uses ten validation seeds per candidate, 200 test seeds per task--algorithm cell, 1,440 raw rows, and a separate six-comparison family alpha. All 24 finite-look decisions are recomputed from the raw CSV and all six remain max_budget_inconclusive at 200 seeds. The extension broadens execution scope only; it does not support cross-family power, algorithm ranking, external reproducibility, or scientific replication. CliffWalking evaluation is capped at 100 steps because its Gymnasium spec has no TimeLimit wrapper." if not chinese else
        "前瞻性 v6 扩展加入 CliffWalking-v1 和固定为 4×4、可滑冰的 FrozenLake-v1。每个候选使用十个验证种子，每个任务—算法单元使用 200 个测试种子，共 1,440 行原始记录，并单独分配六个比较的族级 alpha。全部 24 个有限检查点决定均由原始 CSV 重算，六个比较在 200 个种子时均为 max_budget_inconclusive。该扩展仅扩大执行范围，不支持跨任务族功效、算法排名、外部可复现性或科学复制。由于 CliffWalking 的 Gymnasium 规格没有 TimeLimit 包装器，其评估回合固定上限为 100 步。",
        "Primary source: FINAL_PREREGISTRATION_V6_TASK_FAMILY.md; report and audit: sb3_v6_task_family/V6_TASK_FAMILY_EXTENSION_REPORT.md and sb3_v6_task_family/V6_TASK_FAMILY_AUDIT.json." if not chinese else
        "主要来源：FINAL_PREREGISTRATION_V6_TASK_FAMILY.md；报告和审计：sb3_v6_task_family/V6_TASK_FAMILY_EXTENSION_REPORT.md、sb3_v6_task_family/V6_TASK_FAMILY_AUDIT.json。",
    ]
    for text in v6_paras:
        add_body_paragraph(doc, text, chinese=chinese)


def make_doc(path: Path, chinese: bool) -> None:
    doc = Document()
    configure_document(doc, chinese)
    add_front_matter(doc, chinese)
    doc.add_page_break()
    if chinese:
        add_chinese_source(doc)
    else:
        add_english_source(doc)
    add_appendix(doc, chinese)
    doc.save(path)


if __name__ == "__main__":
    output_en = Path(os.environ.get("ML_OUTPUT_EN", ROOT / "MANUSCRIPT_MACHINE_LEARNING_EN.docx"))
    output_zh = Path(os.environ.get("ML_OUTPUT_ZH", ROOT / "MANUSCRIPT_MACHINE_LEARNING_ZH.docx"))
    make_doc(output_en, chinese=False)
    make_doc(output_zh, chinese=True)
    print(f"Generated {output_en.name}")
    print(f"Generated {output_zh.name}")

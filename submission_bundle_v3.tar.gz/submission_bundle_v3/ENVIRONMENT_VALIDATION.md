# Environment Validation Record

This record documents the interpreter used for the stored RL artifacts and
the verification boundary for the current workstation. It is part of the
reproducibility package; it is not evidence of an external rerun.

## Recorded research environment

The formal artifacts were produced with:

- host: Apple Silicon macOS, arm64;
- interpreter: `.rl-arm64-venv/bin/python`;
- Python: 3.11.7;
- NumPy: 2.2.6;
- Gymnasium: 1.4.0;
- Stable-Baselines3: 2.9.2;
- PyTorch: 2.14.1;
- execution device: CPU (`mps_available=false`).

The exact package lock and wheel hashes are recorded in
`requirements-rl-lock.txt` and `REPRODUCTION_MANIFEST_V3.md`.

## Verification command

The supported command is:

```bash
./.rl-arm64-venv/bin/python -m unittest -v
```

An earlier 2026-10-31 pass recorded 48 tests. The current package, including
the v6 task-family artifact checks, records 55 tests passing with the same
interpreter. The artifact audits were also run with the same interpreter:

```bash
./.rl-arm64-venv/bin/python audit_v3_artifacts.py
./.rl-arm64-venv/bin/python audit_v4_extension.py
./.rl-arm64-venv/bin/python audit_v5_extension.py
./.rl-arm64-venv/bin/python audit_continuous_scope_artifacts.py
./.rl-arm64-venv/bin/python audit_partial_observable_scope.py
```

## System-Python boundary

The bare system command `python3 -m unittest -v` is not a valid substitute on
this machine. Its NumPy binary is x86_64 while the active system interpreter
is arm64, and that environment does not contain Gymnasium. Running the suite
with that interpreter therefore produces import errors before the tests are
collected. This is an environment-selection failure, not a failed result from
the research test suite. External operators must record their own interpreter,
architecture, package versions, and any deviations rather than treating this
local note as evidence of cross-machine reproducibility.


# Minimax Finite-Look Alpha Spending

For equal sample sizes at look k, let `q_k = log(4/alpha_k) / n_k`; the unpaired Hoeffding radius sum is `sqrt(2 q_k)`. Under `sum alpha_k <= alpha`, minimizing the maximum radius is equivalent to minimizing `max q_k`.

The minimax threshold `tau` is the unique positive solution of `4 * sum_k exp(-n_k * tau) = alpha`. The corresponding allocation is `alpha_k* = 4 exp(-n_k * tau)`, which equalizes all radius sums. This follows because any schedule with `q_k <= tau` must allocate at least `4 exp(-n_k tau)` to look k.

Inputs: sample sizes `[5, 10, 15, 20]`, comparison alpha `0.003333333333333334`.

| Look | n | Minimax alpha | Minimax radius sum | Power-series alpha | Power-series radius sum |
|---:|---:|---:|---:|---:|---:|
| 1 | 5 | 0.00333055786844 | 1.684151 | 0.00202642367285 | 1.742157 |
| 2 | 10 | 2.77315392876e-06 | 1.684151 | 0.000506605918212 | 1.339707 |
| 3 | 15 | 2.30903740946e-09 | 1.684151 | 0.000225158185872 | 1.142220 |
| 4 | 20 | 1.92259567816e-12 | 1.684151 | 0.000126651479553 | 1.017859 |

The minimax schedule has worst-case radius sum `1.684151`; the preregistered power-series schedule has `1.742157` for this v3 look sequence.
The minimax schedule is a design diagnostic. The v3 confirmatory analysis keeps its preregistered power-series spending, and no RL decisions are recomputed under the alternative schedule.

Machine-readable output: `MINIMAX_ALPHA_SPENDING.json`; source: `minimax_alpha_spending.py`.

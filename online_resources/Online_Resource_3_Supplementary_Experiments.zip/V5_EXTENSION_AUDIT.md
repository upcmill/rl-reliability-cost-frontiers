# v5 Extension Audit

Status: **PASS**

- 15,000 rows across 15 task--algorithm cells.
- New training seeds are exactly 30400--31399 and do not overlap v3 or v4.
- Every cell uses its frozen v3-selected configuration.
- Decision counts: {"a_superior": 3, "b_superior": 1, "max_budget_inconclusive": 11}.
- Scope: post-v4 same-machine resolution-cost diagnostic; no pooled or external inference.

## Recomputed decisions

| Comparison | n at terminal/cap | Estimate | Family-adjusted interval | Decision |
|---|---:|---:|---|---|
| CartPole-v1 / PPO − DQN | 1000 | 0.174549 | [0.027534, 0.321563] | `max_budget_inconclusive` |
| CartPole-v1 / PPO − A2C | 1000 | 0.004607 | [-0.142408, 0.151622] | `max_budget_inconclusive` |
| CartPole-v1 / DQN − A2C | 1000 | -0.169942 | [-0.316956, -0.022927] | `max_budget_inconclusive` |
| Acrobot-v1 / PPO − DQN | 1000 | -0.047662 | [-0.194677, 0.099352] | `max_budget_inconclusive` |
| Acrobot-v1 / PPO − A2C | 1000 | 0.000168 | [-0.146846, 0.147183] | `max_budget_inconclusive` |
| Acrobot-v1 / DQN − A2C | 1000 | 0.047830 | [-0.099184, 0.194845] | `max_budget_inconclusive` |
| MountainCar-v0 / PPO − DQN | 1000 | -0.000598 | [-0.147612, 0.146417] | `max_budget_inconclusive` |
| MountainCar-v0 / PPO − A2C | 1000 | 0.000000 | [-0.147015, 0.147015] | `max_budget_inconclusive` |
| MountainCar-v0 / DQN − A2C | 1000 | 0.000598 | [-0.146417, 0.147612] | `max_budget_inconclusive` |
| Taxi-v4 / PPO − DQN | 1000 | -0.000044 | [-0.147059, 0.146971] | `max_budget_inconclusive` |
| Taxi-v4 / PPO − A2C | 800 | 0.223244 | [0.062306, 0.384182] | `a_superior` |
| Taxi-v4 / DQN − A2C | 800 | 0.223299 | [0.062362, 0.384237] | `a_superior` |
| NonstationaryQueue-v0 / PPO − DQN | 800 | -0.231172 | [-0.392109, -0.070234] | `b_superior` |
| NonstationaryQueue-v0 / PPO − A2C | 1000 | 0.130962 | [-0.016053, 0.277977] | `max_budget_inconclusive` |
| NonstationaryQueue-v0 / DQN − A2C | 200 | 0.341741 | [0.066282, 0.617200] | `a_superior` |

The machine-readable recomputation and source hashes are in `V5_EXTENSION_AUDIT.json`.

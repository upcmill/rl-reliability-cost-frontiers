#!/usr/bin/env python3
"""Diagnostic for validation-selected finite-look alpha spending.

The diagnostic compares several pre-defined spending schedules. A schedule is
selected from validation observations by a bootstrap estimate of expected
stopping cost, then applied to a fresh sealed test sequence. Every schedule
spends at most the same comparison-level alpha, so the experiment illustrates
the conditional selection argument without changing the v3 confirmatory run.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Scenario:
    name: str
    values_a: tuple[tuple[float, float], ...]
    values_b: tuple[tuple[float, float], ...]

    @property
    def delta(self) -> float:
        return sum(value * probability for value, probability in self.values_a) - sum(
            value * probability for value, probability in self.values_b
        )


def draw(distribution: tuple[tuple[float, float], ...], rng: random.Random) -> float:
    threshold = rng.random()
    cumulative = 0.0
    for value, probability in distribution:
        cumulative += probability
        if threshold <= cumulative:
            return value
    return distribution[-1][0]


def mean(values: list[float]) -> float:
    return sum(values) / len(values)


def schedule_candidates(sample_sizes: list[int], alpha: float) -> dict[str, list[float]]:
    if not sample_sizes or any(n <= 0 for n in sample_sizes):
        raise ValueError("sample sizes must be positive")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must lie in (0, 1)")
    k = len(sample_sizes)
    raw = {
        "power_series": [6.0 / (math.pi**2 * (i + 1) ** 2) for i in range(k)],
        "front_loaded": [0.60, 0.25, 0.10, 0.05][:k],
        "late_loaded": [0.05, 0.15, 0.30, 0.50][:k],
    }
    if k != 4:
        raise ValueError("the diagnostic currently defines four-look candidates")
    raw["minimax"] = [
        4.0 * math.exp(-sample_size * _minimax_tau(sample_sizes, alpha)) / alpha
        for sample_size in sample_sizes
    ]
    schedules = {}
    for name, weights in raw.items():
        total = sum(weights)
        schedules[name] = [alpha * weight / total for weight in weights]
    return schedules


def _minimax_tau(sample_sizes: list[int], alpha: float) -> float:
    low, high = 0.0, 1.0

    def required(value: float) -> float:
        return 4.0 * sum(math.exp(-n * value) for n in sample_sizes)

    while required(high) > alpha:
        high *= 2.0
    for _ in range(200):
        mid = (low + high) / 2.0
        if required(mid) > alpha:
            low = mid
        else:
            high = mid
    return (low + high) / 2.0


def interval(delta_hat: float, n: int, alpha_look: float) -> tuple[float, float]:
    radius = 2.0 * math.sqrt(math.log(4.0 / alpha_look) / (2.0 * n))
    return max(-1.0, delta_hat - radius), min(1.0, delta_hat + radius)


def decision_cost(
    values_a: list[float],
    values_b: list[float],
    sample_sizes: list[int],
    schedule: list[float],
    margin: float,
    width: float,
) -> tuple[int, str, list[tuple[float, float]]]:
    intervals: list[tuple[float, float]] = []
    for n, alpha_look in zip(sample_sizes, schedule):
        lower, upper = interval(mean(values_a[:n]) - mean(values_b[:n]), n, alpha_look)
        intervals.append((lower, upper))
        if lower > margin:
            return n, "a_superior", intervals
        if upper < -margin:
            return n, "b_superior", intervals
        if upper - lower <= width:
            return n, "precise_inconclusive", intervals
    return sample_sizes[-1], "max_budget_inconclusive", intervals


def selected_schedule(
    validation_a: list[float],
    validation_b: list[float],
    sample_sizes: list[int],
    schedules: dict[str, list[float]],
    bootstrap_replicates: int,
    margin: float,
    width: float,
    rng: random.Random,
) -> tuple[str, dict[str, float]]:
    costs: dict[str, float] = {}
    for name, schedule in schedules.items():
        sampled_costs = []
        for _ in range(bootstrap_replicates):
            indices_a = [rng.randrange(len(validation_a)) for _ in validation_a]
            indices_b = [rng.randrange(len(validation_b)) for _ in validation_b]
            boot_a = [validation_a[i] for i in indices_a]
            boot_b = [validation_b[i] for i in indices_b]
            cost, _, _ = decision_cost(
                boot_a, boot_b, sample_sizes, schedule, margin, width
            )
            sampled_costs.append(cost)
        costs[name] = mean(sampled_costs)
    best = min(costs, key=lambda name: (costs[name], name))
    return best, costs


def wilson_upper_zero(successes: int, trials: int, z: float = 1.959963984540054) -> float:
    if trials <= 0:
        raise ValueError("trials must be positive")
    denominator = 1.0 + z * z / trials
    center = (successes + z * z / (2.0 * trials)) / denominator
    half = z * math.sqrt((successes * (trials - successes) / trials + z * z / 4.0) / trials) / denominator
    return center + half


def run(args: argparse.Namespace) -> dict[str, object]:
    sample_sizes = [50, 100, 150, 200]
    alpha = 0.05
    margin = args.margin
    width = args.width
    schedules = schedule_candidates(sample_sizes, alpha)
    scenarios = [
        Scenario("null_bernoulli", ((0.0, 0.5), (1.0, 0.5)), ((0.0, 0.5), (1.0, 0.5))),
        Scenario("large_effect", ((1.0, 0.95), (0.0, 0.05)), ((0.0, 0.95), (1.0, 0.05))),
        Scenario("skewed_effect", ((1.0, 0.90), (0.0, 0.10)), ((1.0, 0.50), (0.0, 0.50))),
        Scenario("two_point_mixture", ((0.1, 0.90), (0.9, 0.10)), ((0.1, 0.50), (0.9, 0.50))),
    ]
    scenario_results = []
    for scenario_index, scenario in enumerate(scenarios):
        rng = random.Random(args.seed + scenario_index * 100003)
        coverage_failures = 0
        false_superiority = 0
        selected_counts = {name: 0 for name in schedules}
        selected_costs = []
        all_schedule_costs = {name: [] for name in schedules}
        for _ in range(args.replicates):
            validation_a = [draw(scenario.values_a, rng) for _ in range(args.validation_size)]
            validation_b = [draw(scenario.values_b, rng) for _ in range(args.validation_size)]
            name, _ = selected_schedule(
                validation_a,
                validation_b,
                sample_sizes,
                schedules,
                args.bootstrap_replicates,
                margin,
                width,
                rng,
            )
            selected_counts[name] += 1
            test_a = [draw(scenario.values_a, rng) for _ in range(sample_sizes[-1])]
            test_b = [draw(scenario.values_b, rng) for _ in range(sample_sizes[-1])]
            cost, decision, intervals = decision_cost(
                test_a, test_b, sample_sizes, schedules[name], margin, width
            )
            selected_costs.append(cost)
            if not all(lower <= scenario.delta <= upper for lower, upper in intervals):
                coverage_failures += 1
            if (decision == "a_superior" and scenario.delta <= margin) or (
                decision == "b_superior" and scenario.delta >= -margin
            ):
                false_superiority += 1
            for candidate, schedule in schedules.items():
                candidate_cost, _, _ = decision_cost(
                    test_a, test_b, sample_sizes, schedule, margin, width
                )
                all_schedule_costs[candidate].append(candidate_cost)
        trials = args.replicates
        scenario_results.append(
            {
                "scenario": scenario.name,
                "true_delta": scenario.delta,
                "replicates": trials,
                "coverage_failures": coverage_failures,
                "coverage_estimate": 1.0 - coverage_failures / trials,
                "coverage_failure_wilson_upper": wilson_upper_zero(coverage_failures, trials),
                "false_superiority_count": false_superiority,
                "false_superiority_rate": false_superiority / trials,
                "selected_schedule_counts": selected_counts,
                "selected_mean_cost": mean(selected_costs),
                "candidate_mean_costs": {
                    name: mean(costs) for name, costs in all_schedule_costs.items()
                },
            }
        )
    output = {
        "status": "diagnostic_only",
        "sample_sizes": sample_sizes,
        "alpha": alpha,
        "margin": margin,
        "width": width,
        "validation_size": args.validation_size,
        "bootstrap_replicates": args.bootstrap_replicates,
        "replicates": args.replicates,
        "seed": args.seed,
        "schedules": schedules,
        "results": scenario_results,
        "interpretation": {
            "supported": [
                "A spending schedule may be selected using validation data and evaluated on a sealed test sequence under the same conditional union-bound logic.",
                "The reported coverage and stopping costs describe only the listed bounded simulation scenarios.",
            ],
            "not_supported": [
                "universal efficiency or power claims",
                "a replacement for the preregistered v3 schedule",
                "empirical coverage for arbitrary RL seed distributions",
            ],
        },
    }
    return output


def write_report(payload: dict[str, object], path: Path) -> None:
    lines = [
        "# Validation-Selected Alpha-Spending Diagnostic",
        "",
        "This is a post-v3 diagnostic. Four fixed finite-look schedules share the same comparison-level alpha. A bootstrap estimate from validation observations selects one schedule, and a fresh sealed test sequence evaluates it. The experiment illustrates conditional selection validity; it does not amend the v3 confirmatory family.",
        "",
        f"Sample sizes: `{payload['sample_sizes']}`; alpha: `{payload['alpha']}`; margin: `{payload['margin']}`; width target: `{payload['width']}`; validation size: `{payload['validation_size']}`; bootstrap replicates: `{payload['bootstrap_replicates']}`; Monte Carlo replicates per scenario: `{payload['replicates']}`.",
        "",
        "## Candidate schedules",
        "",
        "| Schedule | Alpha allocations |",
        "|---|---|",
    ]
    for name, values in payload["schedules"].items():
        lines.append(f"| `{name}` | " + ", ".join(f"{value:.8g}" for value in values) + " |")
    lines.extend([
        "",
        "## Results",
        "",
        "| Scenario | True delta | Selected coverage | Wilson upper bound on failure | False-superiority rate | Selected mean cost | Best fixed mean cost |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ])
    for result in payload["results"]:
        best = min(result["candidate_mean_costs"].values())
        lines.append(
            f"| `{result['scenario']}` | {result['true_delta']:.3f} | {result['coverage_estimate']:.4f} | {result['coverage_failure_wilson_upper']:.6f} | {result['false_superiority_rate']:.4f} | {result['selected_mean_cost']:.2f} | {best:.2f} |"
        )
    lines.extend([
        "",
        "The selected schedule is conditioned on validation observations, so the simulation is consistent with the sealed-test selection argument when every candidate schedule satisfies the same finite-look error budget. The numbers are diagnostic Monte Carlo observations, not a theorem about arbitrary RL distributions or a claim that validation selection always reduces cost.",
        "",
        "Machine-readable output: `adaptive_spending_diagnostic.json`; source: `adaptive_spending_diagnostic.py`.",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--replicates", type=int, default=2000)
    parser.add_argument("--bootstrap-replicates", type=int, default=100)
    parser.add_argument("--validation-size", type=int, default=200)
    parser.add_argument("--seed", type=int, default=271828)
    parser.add_argument("--margin", type=float, default=0.05)
    parser.add_argument("--width", type=float, default=0.20)
    parser.add_argument("--output", default="adaptive_spending_diagnostic.json")
    args = parser.parse_args()
    if args.replicates <= 0 or args.bootstrap_replicates <= 0 or args.validation_size <= 0:
        raise SystemExit("replicates, bootstrap-replicates, and validation-size must be positive")
    if args.validation_size < 200:
        raise SystemExit("validation-size must be at least the largest diagnostic look (200)")
    if not 0.0 <= args.margin < 1.0 or not 0.0 < args.width <= 2.0:
        raise SystemExit("margin must be in [0,1), and width must be in (0,2]")
    payload = run(args)
    output = ROOT / args.output
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    write_report(payload, ROOT / "ADAPTIVE_SPENDING_DIAGNOSTIC.md")
    print(output)
    print(ROOT / "ADAPTIVE_SPENDING_DIAGNOSTIC.md")


if __name__ == "__main__":
    main()

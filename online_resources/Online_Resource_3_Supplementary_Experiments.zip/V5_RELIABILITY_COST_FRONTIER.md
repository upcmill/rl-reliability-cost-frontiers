# v5 Reliability--Cost Frontier

This table combines the analytic unpaired-Hoeffding radius with the
cumulative runtime of the complete stored v5 sequence. The radius is a
distribution-free design quantity; runtime is machine-specific. Because
all 1,000 rows per cell were collected, cumulative runtime is not an
observed compute saving from early stopping.

- Source rows: `raw_seed_metrics.csv`
- Family: `15` comparisons; family alpha `0.05`
- Decision counts: `{"a_superior": 3, "b_superior": 1, "max_budget_inconclusive": 11}`

| Look | Seeds/algorithm | Radius sum | Min clipped width | Family rows | Runtime (hours) | New decisions | Resolved | Unresolved |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 200 | 0.275459 | 0.275459 | 3000 | 0.573089 | 1 | 1 | 14 |
| 2 | 400 | 0.211826 | 0.211826 | 6000 | 1.149731 | 0 | 1 | 14 |
| 3 | 600 | 0.180601 | 0.180601 | 9000 | 1.725827 | 0 | 1 | 14 |
| 4 | 800 | 0.160938 | 0.160938 | 12000 | 2.302629 | 3 | 4 | 11 |
| 5 | 1000 | 0.147015 | 0.147015 | 15000 | 2.875854 | 0 | 4 | 11 |

The four terminal decisions are the observed v5 outcomes for the frozen
task family and new seed sequence. This artifact is descriptive: it is
not a prospective power curve, universal seed rule, algorithm ranking,
or external reproducibility result.

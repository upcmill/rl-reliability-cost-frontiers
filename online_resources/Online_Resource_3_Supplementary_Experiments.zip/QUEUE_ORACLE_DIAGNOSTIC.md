# Queue Oracle and Switch-Time Diagnostic

The queue task is a controlled diagnostic rather than a standard benchmark.
This supplement checks its dynamics with an exact finite-horizon dynamic
program, without using the RL implementations or their test results.

For each queue length and time step, the dynamic program evaluates both actions
under the disclosed arrival probabilities and service cost, then applies the
Bellman recursion. It supplies an exact oracle value for the empty initial
state. The diagnostic also evaluates three fixed policies: always idle, always
serve, and serve only when the queue is nonempty. Switch steps 1, 25, 50, 100,
150, and 199 are evaluated with all other parameters fixed.

The generated JSON contains the oracle value, each fixed-policy value, the gap
between the oracle and the nonempty-service rule, and the number of state-time
actions on which the oracle differs from that rule. These results validate the
task specification and expose sensitivity to the nonstationarity location;
they do not establish a ranking of PPO, DQN, or A2C and are not pooled with the
primary family-level inference.

Run:

```bash
python3 queue_oracle_diagnostic.py --output queue_oracle_diagnostic.json
```

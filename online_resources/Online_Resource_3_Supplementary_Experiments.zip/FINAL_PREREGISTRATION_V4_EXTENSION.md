# Prospective v4 Seed-Budget Extension

This document freezes a follow-up extension before opening its new test-seed
sequence. It is a separate study component, not a replacement for the frozen
v3 analysis and not an independent-machine replication.

## Scope and provenance

The extension uses the same five tasks and three algorithms as v3:
`CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`, and
`NonstationaryQueue-v0`, with PPO, DQN, and A2C. The v3 validation-selected
configuration for each task--algorithm cell is frozen and copied from
`sb3_formal_v3/summary.json`; no new tuning or test-data selection is allowed.
The extension was motivated by the v3 analytic non-resolution boundary and is
therefore an explicitly prospective budget extension, not a claim that its
task family was selected independently of v3.

## New sealed test sequence

The extension uses previously unused training seeds `30000`--`30399` for every
task and algorithm. The first look contains 200 seeds per algorithm and the
second look contains 400 seeds per algorithm. Training uses 4,096 environment
steps, checkpoints at 1,024, 2,048, 3,072, and 4,096, and five evaluation
episodes per checkpoint. The normalized four-checkpoint metric and v3 reward
bounds are unchanged.

## Statistical rule

The primary interval is the unpaired Hoeffding interval. Family alpha is 0.05
over the 15 task--algorithm comparisons, giving comparison alpha `0.05/15`.
Look-level spending is `alpha_k = alpha_cmp * 6/(pi^2 k^2)` at total sample
sizes 200 and 400. The practical superiority margin is 0.05 and the target
width is 0.10. Decisions are recomputed separately for each task and unordered
algorithm pair. The 400-seed cap is fixed before the new sequence is opened.

All three algorithms are trained in each batch so that shared algorithm metrics
remain available for all three pairwise comparisons. This shared execution is a
fixed-budget extension and is not presented as pair-specific compute savings.

## Primary reporting

Report every cell's raw seed metric, selected configuration, interval at each
look, decision state, runtime, software version, hardware, source hash, and
failures. The extension's results must remain separate from v3's 20-seed
primary family. A terminal extension decision is evidence for the disclosed
task, selected procedure, seed sequence, and budget only; it does not establish
a general algorithm ranking, universal seed requirement, or external
reproducibility.

## Deviations

Any change to tasks, algorithms, configurations, seeds, metric, bounds, alpha,
look schedule, margin, width target, or stopping interpretation is a deviation
and must be recorded before analysis. If the run fails, partial rows and the
failure log are retained; missing runs are not silently imputed.

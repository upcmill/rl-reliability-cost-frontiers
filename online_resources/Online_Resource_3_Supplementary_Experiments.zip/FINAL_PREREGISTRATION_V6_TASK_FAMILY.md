# v6 Prospective Task-Family Extension

This document freezes a new task-family extension before its training rows are
opened. It does not amend the v3 primary estimand or pool the new tasks with
the v3 family. The purpose is to test whether the disclosed evaluation
protocol can be executed on two additional standard discrete environments
with different observation encodings and reward scales.

## Scope and estimand

The extension contains `CliffWalking-v1` and `FrozenLake-v1` from Gymnasium
1.4.0. `FrozenLake-v1` is fixed to the default 4 x 4 map with
`is_slippery=True`; no map or environment option may be changed after this
registration. PPO, DQN, and A2C use the same four-candidate grid as v3. The
extension family contains six unordered algorithm comparisons, and its family
alpha is 0.05, allocated equally across those six comparisons. Results remain
conditional on these two tasks, this software version, and the disclosed
training and evaluation budget.

For each task--algorithm cell, the selected configuration is the candidate
with the largest mean normalized validation metric over ten validation seeds
per candidate. Test configurations are frozen before test rows are used. The
conditional target is the difference between the selected algorithms' expected
normalized four-checkpoint metrics under their respective sealed seed
distributions.

## Metrics and bounds

Each training run uses 4,096 environment steps and evaluates at 1,024, 2,048,
3,072, and 4,096 steps. Five evaluation episodes are averaged at each
checkpoint, and the four checkpoint means are averaged into one metric.
`CliffWalking-v1` returns are normalized from `[-100, 0]`; `FrozenLake-v1`
returns are normalized from `[0, 1]`. Values are clipped to `[0, 1]` only as a
range check; the bounds and environment options are fixed before execution.
Each evaluation episode is capped at 100 environment steps. This explicit cap
is required because `CliffWalking-v1` has no Gymnasium `TimeLimit` wrapper;
`FrozenLake-v1` has the same 100-step horizon in its default spec. Raw returns
and normalized values are retained.

## Seeds, looks, and decision rule

Validation training seeds are 40,000--40,009. Sealed extension test seeds are
41,000--41,199. Test looks occur at 50, 100, 150, and 200 seeds per algorithm,
adding batches of 50. The unpaired finite-look Hoeffding interval, practical
margin 0.05, target width 0.10, and first-terminal-state locking rule are the
same as v3. The comparison alpha is `0.05 / 6`, with the preregistered
`6/(pi^2 k^2)` spending schedule. The extension is a diagnostic of scope and
resolution cost; it is not a new algorithm comparison claim, a universal seed
rule, or a prospective power study.

## Analysis and disclosure

All validation candidates, raw test rows, evaluation seeds, runtime, selected
configuration, interval at every look, and terminal decision are archived.
The execution records the complete 200-seed sequence for every cell so that
all prefixes can be recomputed. No rows are pooled with v3, v4, or v5. Failed
runs, deviations, and environment-version differences are retained and
reported; missing rows are not imputed.

The extension may support only descriptive statements about execution,
selection, intervals, and observed resolution in these two tasks. It does not
support general PPO/DQN/A2C rankings, a universal seed budget, cross-family
power, or independent scientific replication.

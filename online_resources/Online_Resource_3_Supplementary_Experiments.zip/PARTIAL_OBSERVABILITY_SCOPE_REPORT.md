# Partially Observable Scope Diagnostic Report

This report summarizes the separately preregistered fixed-mask diagnostic. It is not pooled with v3 or the continuous-control supplements.

## Design and accounting

`MaskedCartPole-v1` masks CartPole velocity coordinates 1 and 3; `MaskedAcrobot-v1` masks angular-velocity coordinates 4 and 5. Each of six algorithm--task cells uses four candidates and five validation seeds per candidate, followed by 20 test seeds for the selected configuration. The raw CSV contains 240 rows: 120 validation and 120 test.

Training uses 4,096 steps, four checkpoints, and five evaluation episodes per checkpoint. The six comparisons share family alpha 0.05 (comparison alpha 0.0083333), with the same margin, target width, and interval construction as the preregistration. This run uses full replay for reporting; it does not measure early-stop compute savings.

## Selected configurations and descriptive means

| Environment | Algorithm | Selected configuration | Test mean | Sample SD |
|---|---|---|---:|---:|
| MaskedCartPole-v1 | PPO | `lr1e4_long` | 0.077770 | 0.013487 |
| MaskedCartPole-v1 | DQN | `lr3e4_short` | 0.021035 | 0.004976 |
| MaskedCartPole-v1 | A2C | `lr3e4_short` | 0.070285 | 0.018775 |
| MaskedAcrobot-v1 | PPO | `lr1e4_short` | 0.014135 | 0.045352 |
| MaskedAcrobot-v1 | DQN | `lr1e4_short` | 0.028190 | 0.066804 |
| MaskedAcrobot-v1 | A2C | `lr3e4_short` | 0.028685 | 0.070145 |

## Family decisions

| Environment | Comparison | Estimate | Family-adjusted interval | Decision |
|---|---|---:|---|---|
| MaskedCartPole-v1 | PPO - DQN | 0.056735 | [-0.915071, 1.000000] | max_budget_inconclusive |
| MaskedCartPole-v1 | PPO - A2C | 0.007485 | [-0.964321, 0.979291] | max_budget_inconclusive |
| MaskedCartPole-v1 | DQN - A2C | -0.049250 | [-1.000000, 0.922556] | max_budget_inconclusive |
| MaskedAcrobot-v1 | PPO - DQN | -0.014055 | [-0.985861, 0.957751] | max_budget_inconclusive |
| MaskedAcrobot-v1 | PPO - A2C | -0.014550 | [-0.986356, 0.957256] | max_budget_inconclusive |
| MaskedAcrobot-v1 | DQN - A2C | -0.000495 | [-0.972301, 0.971311] | max_budget_inconclusive |

All six comparisons are maximum-budget inconclusive at 20 seeds. The intervals do not show equivalence. This supports only that the fixed-mask workflow executed under this budget; it does not validate arbitrary partially observable tasks, establish algorithm rankings, or show external reproducibility.

The raw CSV and JSON records are authoritative. A separate script regenerated all six selected test-seed summaries on the same machine with zero mean absolute metric difference. This supports same-machine cross-script repeatability only. The runner used full replay of all 20 test seeds, so stop-time savings are not claimed.

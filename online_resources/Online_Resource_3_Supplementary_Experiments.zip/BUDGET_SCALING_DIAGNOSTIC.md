# v3 Training-Budget Scaling Diagnostic

This is a supplementary fixed-configuration diagnostic. It does not alter the
preregistered v3 primary analysis, its 4,096-step estimand, or its decisions.

## Design

- Tasks: the five v3 tasks (`CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`,
  `Taxi-v4`, and `NonstationaryQueue-v0`).
- Algorithms: PPO, DQN, and A2C.
- Configuration: the configuration selected by the v3 five-validation-seed
  procedure for each task--algorithm cell; no re-tuning was performed.
- Test seeds: the same sealed training seeds 20,000--20,019.
- Training budget: 16,384 environment steps, evaluated at 4,096, 8,192,
  12,288, and 16,384 steps.
- Evaluation: five episodes per checkpoint and the same normalized learning
  curve metric as v3.
- Inference: the same unpaired Hoeffding interval, four looks, comparison
  alpha `0.05 / 15`, practical margin 0.05, and target width 0.10.

The run contains 300 test rows and 15 task--algorithm comparisons. Because the
configuration was inherited from v3 and the budget was changed after the
primary analysis, all results below are exploratory sensitivity evidence.

## Results

All 15 comparisons reached the maximum of 20 test seeds and were
`max_budget_inconclusive` under the same decision rule. The 16,384-step
diagnostic therefore does not show that a larger training budget makes this
conservative family-level interval decisive at 20 seeds.

| Environment | PPO mean | DQN mean | A2C mean |
|---|---:|---:|---:|
| CartPole-v1 | 0.247110 | 0.044230 | 0.326340 |
| Acrobot-v1 | 0.157615 | 0.086975 | 0.092270 |
| MountainCar-v0 | 0.000000 | 0.000338 | 0.000000 |
| Taxi-v4 | 0.891089 | 0.891089 | 0.791165 |
| NonstationaryQueue-v0 | 0.805378 | 0.926907 | 0.695060 |

Relative to the 4,096-step v3 means, the largest absolute changes were
`+0.124965` for CartPole/A2C, `-0.095500` for Acrobot/DQN, and `+0.117646`
for Taxi/A2C. These are descriptive changes under a different training-budget
estimand; they are not evidence of algorithm superiority.

At the final look, the clipped interval widths ranged from 1.7860 to 2.0000
across the 15 comparisons (median 1.9386). The smaller widths in a few cells
did not reach the 0.10 precision target. The exact seed-level records and
configuration metadata are in `sb3_budget_scaling_v3/`.

## Interpretation and limits

The diagnostic strengthens the interpretation of v3 as a protocol-cost result:
increasing training steps alone did not resolve the conservative family-level
comparisons at 20 test seeds. It also shows why the training horizon must be
part of the estimand: changing the budget can alter descriptive means without
changing the statistical decision rule. The diagnostic does not estimate a
power curve, prove that 16,384 steps is sufficient or insufficient in general,
or justify pooling the 16,384-step results with v3. No claim about universal
seed requirements, algorithm rankings, or compute savings follows from this
run.

## Reproduction

```bash
./.rl-arm64-venv/bin/python budget_scaling_diagnostic.py \
  --reference-dir sb3_formal_v3 \
  --test-seeds 20 --timesteps 16384 --checkpoints 4 \
  --eval-episodes 5 --family-alpha 0.05 \
  --practical-margin 0.05 --target-width 0.10 \
  --output-dir sb3_budget_scaling_v3
```

The run used the same Apple Silicon CPU environment as v3. This is a
same-machine supplementary run, not external reproducibility evidence.

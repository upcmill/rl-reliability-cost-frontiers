# Continuous-Control Supplement Report

This report covers the preregistered `Pendulum-v1` supplement. It is separate
from the v3 primary family and is not pooled with its 15 comparisons.

## Design and accounting

The supplement uses PPO and A2C, because DQN does not accept the continuous
`Box` action space. Four candidate configurations receive five validation
seeds each. One selected configuration per algorithm receives 20 sealed test
seeds. The raw artifact contains 80 rows: 40 validation and 40 test.

`Pendulum-v1` has a 200-step horizon. The frozen implementation uses the
two-decimal raw-return bound `[-3254.72, 0]`, derived from the installed
environment's cost formula; normalized returns are clipped to `[0,1]` and raw
returns are retained. The unrounded lower endpoint is approximately
`-3254.72088`, so the explicit clipping remains the operative bounded-metric
guard for this rounded storage bound.

## Selected configurations and descriptive means

| Algorithm | Selected configuration | Test mean (normalized) |
|---|---|---:|
| PPO | `lr3e4_short` | 0.621773 |
| A2C | `lr3e4_long` | 0.622684 |

These values are descriptive for the fixed budget and selected configurations.
They do not establish continuous-control algorithm rankings.

## Formal comparison

The single preregistered comparison is PPO minus A2C with alpha 0.05. At 20
test seeds the estimate is `-0.0009` and the family-adjusted interval is
`[-0.8757, 0.8739]`; the decision is `max_budget_inconclusive`. The stop trace
at 5, 10, 15, and 20 seeds is stored in
`sb3_continuous_pendulum/summary.json`.

## Repeatability and limitations

The independent Pendulum replay regenerates both selected configurations on
the same machine. Both mean absolute normalized-metric differences are `0.0`.
This is same-machine cross-script repeatability, not independent-team or
different-machine reproducibility. The supplement has one continuous task and
two algorithms, so it is only a scope diagnostic. It does not support claims
about all continuous-control tasks or algorithms.

## Artifacts

- preregistration: `FINAL_PREREGISTRATION_CONTINUOUS_SUPPLEMENT.md`;
- runner: `continuous_pendulum_runner.py`;
- raw data and summary: `sb3_continuous_pendulum/`;
- independent replay: `independent_pendulum_reproduction.py`;
- replay summary: `sb3_continuous_pendulum/independent_reproduction.json`.

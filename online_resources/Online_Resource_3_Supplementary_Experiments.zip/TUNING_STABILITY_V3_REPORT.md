# v3 Tuning Stability Diagnostic

This report compares the frozen v3 five-validation-seed selection with a
separate ten-validation-seed rerun of the same four-candidate grid, training
budget, checkpoints, and evaluation episodes. The rerun uses diagnostic test
seeds 30000--30019 and does not alter the v3 sealed test sample.

## Design

The candidate grid is `lr3e4_long`, `lr1e4_long`, `lr3e4_short`, and
`lr1e4_short`. For each environment and algorithm, every candidate is trained
on ten validation seeds, the highest validation mean is selected with the same
deterministic tie rule, and the selected configuration is evaluated on twenty
disjoint diagnostic seeds. The complete artifact is
`sb3_tuning_strength_v3/summary.json` and the runner configuration is recorded
in that file.

## Selection stability

Four of the fifteen environment--algorithm cells changed selected
configuration relative to v3's five-seed selection:

| Cell | v3 selection (5 validation seeds) | Diagnostic selection (10 validation seeds) |
|---|---|---|
| Acrobot-v1 / PPO | `lr1e4_long` | `lr1e4_short` |
| Acrobot-v1 / A2C | `lr1e4_long` | `lr3e4_short` |
| CartPole-v1 / DQN | `lr3e4_long` | `lr1e4_long` |
| NonstationaryQueue-v0 / DQN | `lr3e4_short` | `lr3e4_long` |

The remaining eleven cells retained the same selected configuration. The
observed change rate is therefore 4/15 = 0.2667 for this same-machine,
same-grid diagnostic. It is a conditional selection-stability observation,
not a population probability and not evidence that either grid is optimal.

The diagnostic test means are descriptive only. They are not pooled with the
v3 family, and no additional superiority claim is made from them. The result
supports reporting the selected configuration and validation records as part
of the estimand, and it rules out describing the five-seed grid as a generally
stable tuning standard.

## Reproduction

```bash
./.rl-arm64-venv/bin/python tuning_strength_runner.py \
  --validation-seeds 10 --test-seeds 20 --timesteps 4096 \
  --checkpoints 4 --eval-episodes 5 \
  --output-dir sb3_tuning_strength_v3
```

The run used Python 3.11.7, Apple Silicon arm64 CPU execution, Gymnasium
1.4.0, Stable-Baselines3 2.9.2, PyTorch 2.14.1, and NumPy 2.2.6. It is a
same-machine diagnostic and does not upgrade the external reproducibility
claim.

# Validation-Selected Alpha-Spending Diagnostic

This is a post-v3 diagnostic. Four fixed finite-look schedules share the same comparison-level alpha. A bootstrap estimate from validation observations selects one schedule, and a fresh sealed test sequence evaluates it. The experiment illustrates conditional selection validity; it does not amend the v3 confirmatory family.

Sample sizes: `[50, 100, 150, 200]`; alpha: `0.05`; margin: `0.05`; width target: `0.2`; validation size: `200`; bootstrap replicates: `100`; Monte Carlo replicates per scenario: `2000`.

## Candidate schedules

| Schedule | Alpha allocations |
|---|---|
| `power_series` | 0.035121951, 0.0087804878, 0.003902439, 0.002195122 |
| `front_loaded` | 0.03, 0.0125, 0.005, 0.0025 |
| `late_loaded` | 0.0025, 0.0075, 0.015, 0.025 |
| `minimax` | 0.049382717, 0.00060966319, 7.5267062e-06, 9.2922301e-08 |

## Results

| Scenario | True delta | Selected coverage | Wilson upper bound on failure | False-superiority rate | Selected mean cost | Best fixed mean cost |
|---|---:|---:|---:|---:|---:|---:|
| `null_bernoulli` | 0.000 | 1.0000 | 0.043825 | 0.0000 | 200.00 | 200.00 |
| `large_effect` | 0.900 | 1.0000 | 0.043825 | 0.0000 | 50.00 | 50.00 |
| `skewed_effect` | 0.400 | 1.0000 | 0.043825 | 0.0000 | 121.53 | 119.88 |
| `two_point_mixture` | -0.320 | 1.0000 | 0.043825 | 0.0000 | 175.20 | 173.97 |

The selected schedule is conditioned on validation observations, so the simulation is consistent with the sealed-test selection argument when every candidate schedule satisfies the same finite-look error budget. The numbers are diagnostic Monte Carlo observations, not a theorem about arbitrary RL distributions or a claim that validation selection always reduces cost.

Machine-readable output: `adaptive_spending_diagnostic.json`; source: `adaptive_spending_diagnostic.py`.

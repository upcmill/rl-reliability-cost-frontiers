#!/usr/bin/env python3
"""Bootstrap the v3 validation-seed rows to describe selection instability."""

from __future__ import annotations

import csv
import json
import math
import random
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CONFIGS = ("lr3e4_long", "lr1e4_long", "lr3e4_short", "lr1e4_short")
ENVIRONMENTS = ("CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0")
ALGORITHMS = ("PPO", "DQN", "A2C")
REPLICATES = 20_000


def entropy(probabilities: list[float]) -> float:
    return max(0.0, -sum(p * math.log(p) for p in probabilities if p > 0.0))


def main() -> None:
    values: dict[tuple[str, str], dict[str, dict[int, float]]] = defaultdict(lambda: defaultdict(dict))
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["split"] == "validation":
                values[(row["env_id"], row["algorithm"])][row["config_id"]][int(row["seed"])] = float(row["metric_normalized"])

    results = []
    for cell_index, environment in enumerate(ENVIRONMENTS):
        for algorithm_index, algorithm in enumerate(ALGORITHMS):
            cell = values[(environment, algorithm)]
            if any(len(cell[config]) != 5 for config in CONFIGS):
                raise ValueError(f"expected five validation seeds for {environment}/{algorithm}")
            observed_means = {config: sum(cell[config].values()) / 5.0 for config in CONFIGS}
            observed_selected = max(CONFIGS, key=observed_means.__getitem__)
            counts = {config: 0 for config in CONFIGS}
            rng = random.Random(20261030 + 101 * cell_index + algorithm_index)
            for _ in range(REPLICATES):
                sampled_seeds = [rng.randrange(5) for _ in range(5)]
                means = {
                    config: sum(cell[config][seed] for seed in sampled_seeds) / 5.0
                    for config in CONFIGS
                }
                counts[max(CONFIGS, key=means.__getitem__)] += 1
            frequencies = {config: counts[config] / REPLICATES for config in CONFIGS}
            ranked = sorted(observed_means.values(), reverse=True)
            results.append({
                "environment": environment,
                "algorithm": algorithm,
                "observed_selected": observed_selected,
                "observed_means": observed_means,
                "bootstrap_selection_frequency": frequencies,
                "bootstrap_entropy_nats": entropy([frequencies[c] for c in CONFIGS]),
                "observed_top_two_gap": ranked[0] - ranked[1],
                "replicates": REPLICATES,
                "resampling_unit": "validation seed row across all four candidates",
            })

    payload = {
        "status": "descriptive_validation_selection_diagnostic",
        "warning": "Bootstrap frequencies describe instability in the five observed validation rows; they are not population probabilities or confirmatory evidence.",
        "source": "sb3_formal_v3/raw_seed_metrics.csv",
        "configs": list(CONFIGS),
        "replicates": REPLICATES,
        "rows": results,
    }
    (ROOT / "validation_selection_uncertainty_v3.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    lines = [
        "# v3 Validation-Selection Uncertainty Diagnostic",
        "",
        "This post-hoc diagnostic resamples the five validation-seed rows jointly across all four candidates. It describes instability in the observed validation sample; frequencies are not population probabilities and do not alter v3 selection or test inference.",
        "",
        f"Each cell uses {REPLICATES:,} deterministic bootstrap replicates. The resampling unit is a validation seed row, preserving the fact that all candidates were evaluated on the same five seed labels.",
        "",
        "| Environment | Algorithm | v3 selected | Selected frequency | Frequency of runner-up | Entropy (nats) | Observed top-two gap |",
        "|---|---|---|---:|---:|---:|---:|",
    ]
    for row in results:
        ranked = sorted(row["bootstrap_selection_frequency"].items(), key=lambda item: item[1], reverse=True)
        lines.append(
            f"| {row['environment']} | {row['algorithm']} | {row['observed_selected']} | "
            f"{row['bootstrap_selection_frequency'][row['observed_selected']]:.4f} | "
            f"{ranked[1][1]:.4f} | {row['bootstrap_entropy_nats']:.4f} | "
            f"{row['observed_top_two_gap']:.6f} |"
        )
    lines += [
        "",
        "The diagnostic reinforces that the selected configuration is part of the conditional estimand. It does not estimate the probability that a configuration is globally optimal, and it is not pooled with the sealed-test results.",
        "",
        "Machine-readable output: `validation_selection_uncertainty_v3.json`; generator: `validation_selection_uncertainty.py`.",
    ]
    (ROOT / "VALIDATION_SELECTION_UNCERTAINTY_V3.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(ROOT / "VALIDATION_SELECTION_UNCERTAINTY_V3.md")


if __name__ == "__main__":
    main()

# Partial-Observability Scope Diagnostic Preregistration

This is a separate scope diagnostic and will not be pooled with the formal v3
family or either continuous-control supplement. It tests whether the sealed
evaluation workflow executes when velocity information is masked from two
lightweight control tasks. The masked tasks are deterministic observation
wrappers around `CartPole-v1` and `Acrobot-v1`; they are diagnostic POMDP-like
settings, not new benchmark standards.

## Frozen design

- Environments: `MaskedCartPole-v1` (mask CartPole velocity coordinates 1 and
  3) and `MaskedAcrobot-v1` (mask Acrobot angular-velocity coordinates 4 and
  5).
- Algorithms: PPO, DQN, and A2C from Stable-Baselines3 2.9.2.
- Candidate grid: the same four configurations as v3; five validation seeds
  per candidate; the highest validation mean with first-insertion tie rule is
  frozen before test records are used.
- Validation training seeds: 40000--40004. Sealed test training seeds:
  50000--50019.
- Training: 4,096 environment steps; checkpoints 1,024, 2,048, 3,072, and
  4,096; five evaluation episodes per checkpoint.
- Test looks: 5, 10, 15, and 20 seeds in batches of five.
- Primary metric: the same task-specific normalized four-checkpoint mean as
  the corresponding unmasked task; raw returns are retained.
- Inference: unpaired Hoeffding interval with finite-look alpha spending,
  family alpha 0.05 across six algorithm--task comparisons, practical margin
  0.05, and target width 0.10.

## Claim boundary

The diagnostic can support only a statement that the disclosed workflow was
executed on these two fixed observation masks. It cannot establish general
partial-observability validity, algorithm ranking, a universal seed budget, or
external reproducibility. Results will be reported only after the runner,
raw CSV, summaries, and separate replay audit are complete.


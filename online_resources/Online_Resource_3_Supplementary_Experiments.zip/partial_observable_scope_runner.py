#!/usr/bin/env python3
"""Run the preregistered partially observable scope diagnostic."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
import time
from itertools import combinations
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch

import partial_observable_env  # noqa: F401
from pilot_protocol import ProtocolConfig, sequential_decision
from sb3_pilot import ALGORITHMS, make_model
from sequential_sb3_runner_v3 import CONFIGS


ENVIRONMENTS = ("MaskedCartPole-v1", "MaskedAcrobot-v1")


def normalize(environment_id: str, values: list[float]) -> list[float]:
    lower, upper = (0.0, 500.0) if "CartPole" in environment_id else (-500.0, 0.0)
    return [max(0.0, min(1.0, (value - lower) / (upper - lower))) for value in values]


def evaluate(model, environment_id: str, seed: int, episodes: int):
    env = gym.make(environment_id)
    returns = []
    for episode in range(episodes):
        observation, _ = env.reset(seed=seed + episode)
        done = False
        total = 0.0
        while not done:
            action, _ = model.predict(observation, deterministic=True)
            if isinstance(action, np.ndarray) and action.size == 1:
                action = action.item()
            observation, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            total += float(reward)
        returns.append(total)
    env.close()
    return float(np.mean(returns)), returns


def train_curve(environment_id, algorithm, train_seed, config, checkpoints, episodes):
    env = gym.make(environment_id)
    model = make_model(algorithm, env, train_seed, config)
    raw_values, normalized_values, episode_returns, evaluation_seeds = [], [], [], []
    started = time.perf_counter()
    trained = 0
    for checkpoint in checkpoints:
        model.learn(total_timesteps=checkpoint - trained, reset_num_timesteps=False)
        trained = checkpoint
        evaluation_seed = train_seed + 1_000_000 + checkpoint
        raw, returns = evaluate(model, environment_id, evaluation_seed, episodes)
        raw_values.append(raw)
        normalized_values.append(normalize(environment_id, [raw])[0])
        episode_returns.append(returns)
        evaluation_seeds.append(evaluation_seed)
    model.env.close()
    return {
        "metric_normalized": float(np.mean(normalized_values)),
        "metric_raw": float(np.mean(raw_values)),
        "checkpoint_normalized": normalized_values,
        "checkpoint_raw": raw_values,
        "episode_returns": episode_returns,
        "evaluation_seeds": evaluation_seeds,
        "evaluation_seed_base": train_seed + 1_000_000,
        "runtime_seconds": time.perf_counter() - started,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default="sb3_partial_observable_scope")
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    checkpoints = [1024, 2048, 3072, 4096]
    records, summary, comparisons = [], {}, []
    for environment_id in ENVIRONMENTS:
        validation, selected = {}, {}
        for algorithm in ALGORITHMS:
            validation[algorithm] = {}
            for config_id, config in CONFIGS.items():
                values = []
                for seed in range(5):
                    result = train_curve(environment_id, algorithm, 40000 + seed, config, checkpoints, 5)
                    values.append(result["metric_normalized"])
                    records.append({"env_id": environment_id, "algorithm": algorithm, "config_id": config_id, "split": "validation", "seed": seed, "train_seed": 40000 + seed, **{k: result[k] for k in ("evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds")}, "status": "ok"})
                validation[algorithm][config_id] = values
            selected[algorithm] = max(CONFIGS, key=lambda config_id: sum(validation[algorithm][config_id]) / 5.0)
        metrics = {algorithm: [] for algorithm in ALGORITHMS}
        curves = {algorithm: [] for algorithm in ALGORITHMS}
        for seed in range(20):
            for algorithm in ALGORITHMS:
                config_id = selected[algorithm]
                result = train_curve(environment_id, algorithm, 50000 + seed, CONFIGS[config_id], checkpoints, 5)
                metrics[algorithm].append(result["metric_normalized"])
                curves[algorithm].append({"seed": seed, "train_seed": 50000 + seed, **result})
                records.append({"env_id": environment_id, "algorithm": algorithm, "config_id": config_id, "split": "test", "seed": seed, "train_seed": 50000 + seed, **{k: result[k] for k in ("evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds")}, "status": "ok"})
        for algorithm in ALGORITHMS:
            summary[f"{environment_id}:{algorithm}"] = {"selected_config": selected[algorithm], "validation": validation[algorithm], "test_metrics": metrics[algorithm], "curves": curves[algorithm]}
        protocol = ProtocolConfig(alpha=0.05 / 6.0, practical_margin=0.05, initial_seeds=5, batch_size=5, max_seeds=20, target_width=0.10, interval_method="hoeffding_unpaired")
        for first, second in combinations(ALGORITHMS, 2):
            comparisons.append({"env_id": environment_id, "comparison": f"{first}_vs_{second}", "decision": sequential_decision(metrics[first], metrics[second], protocol)})
    payload = {"status": "partial_observable_scope_diagnostic", "warning": "Separate preregistered scope diagnostic; no general POMDP claim.", "python_version": platform.python_version(), "platform": platform.platform(), "torch": torch.__version__, "gymnasium": gym.__version__, "stable_baselines3": importlib.metadata.version("stable-baselines3"), "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "environment_ids": list(ENVIRONMENTS), "algorithm_ids": list(ALGORITHMS), "run_config": {"validation_seeds": 5, "test_seeds": 20, "validation_seed_base": 40000, "test_seed_base": 50000, "timesteps": 4096, "checkpoints": checkpoints, "eval_episodes": 5, "family_alpha": 0.05, "comparison_alpha": 0.05 / 6.0, "execution_mode": "full_replay_fixed_family"}, "candidate_configs": CONFIGS, "summary": summary, "comparisons": comparisons}
    fields = ["env_id", "algorithm", "config_id", "split", "seed", "train_seed", "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status"]
    with (output / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(records)
    for name in ("run_config.json", "summary.json"):
        (output / name).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

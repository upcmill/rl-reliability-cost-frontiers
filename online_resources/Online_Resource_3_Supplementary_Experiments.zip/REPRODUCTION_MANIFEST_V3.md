# Formal v3 Reproduction Manifest

This manifest defines the exact v3 artifact set. It distinguishes the
same-machine cross-script replay from the completed Windows AMD64 sealed
rerun. The external rerun is archived as a separate artifact and does not
replace the preregistered macOS v3 analysis.

## Frozen study

- Tasks: `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`,
  `NonstationaryQueue-v0`.
- Algorithms: PPO, DQN, A2C from Stable-Baselines3 2.9.2.
- Candidate configurations: `lr3e4_long`, `lr1e4_long`, `lr3e4_short`,
  `lr1e4_short`; five validation seeds per candidate.
- Selected configuration: highest validation mean; deterministic first-insertion
  tie rule.
- Validation training seeds: 10000--10004 per candidate.
- Sealed test training seeds: 20000--20019 per selected cell.
- Training budget: 4096 steps; checkpoints 1024, 2048, 3072, 4096.
- Evaluation: five episodes per checkpoint; four-checkpoint mean metric.
- Test looks: 5, 10, 15, and 20 seeds, batches of five.
- Family: 15 comparisons, family alpha 0.05, comparison alpha
  `0.0033333333333333335`.
- Primary interval: `hoeffding_unpaired`; practical margin 0.05; target width
  0.10.

## Runtime

The stored run reports Python 3.11.7, arm64 Apple Silicon macOS, Gymnasium
1.4.0, Stable-Baselines3 2.9.2, PyTorch 2.14.1, NumPy 2.2.6, CPU execution,
and `mps_available=false`. The exact platform string is in
`sb3_formal_v3/run_config.json`.

## Source identity

| File | SHA-256 |
|---|---|
| `sequential_sb3_runner_v3.py` | `e2ac2b731827ad251778f2420dd14f5664ca7d4f89b4436489bc183a919b574c` |
| `independent_reproduction.py` | `01ed66528f64d8283d15d84789f3900fb8eb8cec33c69f0cbb83cae24d6e930a` |
| `nonstationary_queue_env.py` | `a4bad08ba9e492b370c43dc24c364efab3ba7adc2de3a4d83460dd63d35ea739` |
| `requirements-rl.txt` | `69bd624a5cc1433f3653421b2de195e227e574d9c0fbb5b3791252cc58a71358` |

The v3 runner hash is also embedded in the run JSON. Hashes identify source
state; they do not guarantee identical hardware-level floating-point behavior.

`requirements-rl-lock.txt` records exact versions for all packages observed in
the formal arm64 environment. The original `requirements-rl.txt` remains the
human-readable top-level dependency specification; use the lock file when
matching the recorded installation and report any unavailable platform wheel.

Archived wheel hashes used for the arm64 environment are:

| Wheel | SHA-256 |
|---|---|
| `wheels/gymnasium-1.4.0-py3-none-any.whl` | `1cb947c59e7c72d8eabb2c2274c00cd20948e69f8452a9ef4092223be24fdf0e` |
| `wheels/numpy-2.2.6-cp311-cp311-macosx_11_0_arm64.whl` | `c820a93b0255bc360f53eca31a0e676fd1101f673dda8da93454a12e23fc5f7a` |
| `wheels/stable_baselines3-2.9.2-py3-none-any.whl` | `0b7db1789bea31d43b3e9be4f88abf639549b587f2bf2a2461ee9d3d77c68e96` |
| `wheels/torch-2.14.1-cp311-cp311-macosx_14_0_arm64.whl` | `b6074b130fd26bc50f5d171f07dfed70db22dd0c354ab34767729249f9e0f042` |

## Stored primary outputs

- `sb3_formal_v3/raw_seed_metrics.csv` (600 rows: 300 validation, 300 test);
- `sb3_formal_v3/run_config.json`;
- `sb3_formal_v3/summary.json`;
- `sb3_formal_v3/descriptive_summary.json`;
- `sb3_formal_v3/familywise_cost_summary.json`;
- `sb3_formal_v3/independent_reproduction_summary.json`;
- `sb3_formal_v3/independent_reproduction_{cartpole,acrobot,mountaincar,taxi,queue}.json`.
- `RAW_RETURN_TABLE_V3.md` and `generate_raw_return_table.py` provide a
  deterministic secondary summary of the raw-return column without changing
  the normalized primary estimand.

## Rerun commands

From this directory, after installing `requirements-rl.txt` in the same
environment:

```bash
./.rl-arm64-venv/bin/python sequential_sb3_runner_v3.py \
  --environment-ids CartPole-v1,Acrobot-v1,MountainCar-v0,Taxi-v4,NonstationaryQueue-v0 \
  --validation-seeds 5 --test-seeds 20 --initial-test-seeds 5 \
  --test-batch-size 5 --timesteps 4096 --checkpoints 4 \
  --eval-episodes 5 --family-alpha 0.05 \
  --practical-margin 0.05 --target-width 0.10 \
  --output-dir sb3_formal_v3_rerun
```

For each environment, reproduce the selected sealed configurations with the
separate script:

```bash
./.rl-arm64-venv/bin/python independent_reproduction.py \
  --reference-dir sb3_formal_v3 --env-id CartPole-v1 \
  --output sb3_formal_v3/reproduction_check_cartpole.json
```

Repeat the command for `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`, and
`NonstationaryQueue-v0`. The stored per-environment files were generated this
way. `independent_reproduction.py` is intentionally a separate implementation
from the formal runner, but it runs on the same machine in the current package.

## Artifact audit

Run the deterministic audit after a rerun or before submission:

```bash
./.rl-arm64-venv/bin/python audit_v3_artifacts.py
```

The audit checks row counts, split counts, task and algorithm sets, 15 final
decisions, 20 test seeds per cell, bounded metrics, and the 15 zero-difference
reproduction summaries. It does not prove external reproducibility or inspect
unrecorded machine state.

Before opening sealed test rows, run the deterministic pre-study feasibility
audit:

```bash
python3 generate_budget_feasibility_audit.py
./.rl-arm64-venv/bin/python -m unittest -q test_budget_feasibility_audit.py
```

This audit checks the registered radius extrema and necessary seed thresholds;
it is design evidence only and does not read or reinterpret the RL output.

## Reproducibility status

The current package demonstrates same-machine cross-script repeatability:
all 15 stored means match the separate reproduction with mean absolute metric
difference 0.0. A sealed rerun was subsequently completed on a Windows 10
AMD64 machine using Python 3.11.18, NumPy 2.2.6, PyTorch 2.14.1, Gymnasium
1.4.0, and Stable-Baselines3 2.9.2. It contains 600 rows, all 15 selected
configurations match, and all 15 terminal decisions match. Fourteen of 15
cells have zero seed-level metric differences; the remaining
`Acrobot-v1:DQN` cell has mean absolute difference 0.00105 and maximum
absolute difference 0.01640. All comparisons remain `max_budget_inconclusive`.
The returned handoff reports no reference-directory access and no failed rows.
This demonstrates different-machine reproducibility of the disclosed
software/protocol, but does not verify an independent team's identity or
replicate the scientific conclusion on a new task family. The external rerun
is treated as a new artifact and does not replace the primary v3 analysis.

The audit report is `复跑结果/EXTERNAL_RERUN_AUDIT.md` and its machine-readable
counterpart is `复跑结果/EXTERNAL_RERUN_AUDIT.json`. The raw external output,
final metadata, log, and output checksum manifest are under
`复跑结果/external_rerun_output/`; the returned Windows handoff and historical
installation logs are under `复跑结果/handoff_windows/`.

`REPRODUCTION_HASHES_V3.txt` records SHA-256 hashes for the core source,
preregistration, raw CSV, JSON, and supplementary diagnostic files. It is an
integrity manifest, not evidence of an external rerun.

The following deterministic summaries can be regenerated from the stored CSV
without retraining: `generate_seed_distribution_table.py`,
`generate_effect_size_table.py`, `generate_raw_return_table.py`, and
`validation_selection_uncertainty.py`. The last is explicitly a descriptive
post-hoc validation-selection diagnostic.

The separate partial-observation scope diagnostic is recorded in
`FINAL_PREREGISTRATION_PARTIAL_OBSERVABILITY.md` and
`PARTIAL_OBSERVABILITY_SCOPE_REPORT.md`. Its fixed-mask wrappers, runner,
tests, and 240-row raw artifact are separate from the v3 primary family.

## Supplementary calibration grid

`calibration_grid.py` runs the fixed supplementary Monte Carlo grid recorded
in `CALIBRATION_GRID_REPORT.md` and `calibration_grid.json`. It uses eight
bounded distribution families, five true differences (`-0.20`, `-0.10`,
`0.00`, `0.10`, `0.20`), 3,000 replicates per cell, the 5/10/15/20 look
schedule, and both alpha settings `0.05` and `0.05/15`. The first cell seed is
`920000` and increments deterministically by one for each cell. Re-run it with:

```bash
./.rl-arm64-venv/bin/python calibration_grid.py --replicates 3000
```

The grid is supplementary calibration evidence. It does not alter the v3
estimand, prove arbitrary-distribution coverage, or establish RL generalization.
The JSON and Markdown outputs were also regenerated with the local clean
`.venv/bin/python` interpreter and matched the formal-environment outputs
byte-for-byte. This is same-machine cross-interpreter repeatability for the
simulation script, not an external RL reproduction.

## Supplementary budget-scaling diagnostic

`BUDGET_SCALING_DIAGNOSTIC.md` and `budget_scaling_diagnostic.py` define a
post-hoc fixed-configuration run at 16,384 steps. It reuses v3 selected
configurations and test seeds, produces 300 test rows and 15 final decisions,
and is intentionally excluded from the 4,096-step primary estimand. The
artifact is a same-machine sensitivity run, not external reproducibility
evidence.

`EVAL_EPISODE_SENSITIVITY_DIAGNOSTIC.md` and
`eval_episode_sensitivity_diagnostic.py` define a second post-hoc
fixed-configuration run with ten evaluation episodes per checkpoint. It reuses
the v3 4,096-step selected configurations and test seeds, produces 300 test
rows and 15 final decisions, and is intentionally excluded from the primary
five-episode estimand. It is a same-machine sensitivity run, not external
reproducibility evidence.

Run `./.rl-arm64-venv/bin/python audit_supplementary_diagnostics.py` to verify both supplementary
directories. The resulting `SUPPLEMENTARY_DIAGNOSTIC_AUDIT.json` records the
row counts, seed range, inherited v3 selections, and final decision states.

`EXTERNAL_RERUN_PROTOCOL.md` is the independent-operator handoff. It defines
the sealed command, required machine metadata, acceptance checks, and reporting
template. `validate_external_rerun.py` performs the schema, seed-level
difference, selected-configuration, and decision-state checks described in the
handoff. `audit_external_rerun.py` adds output checksums, source-hash checks,
runtime metadata, and the evidence boundary. A validator self-test or local
replay alone would not upgrade same-machine repeatability to external
reproducibility; the returned Windows raw rerun now supplies that evidence.

## Post-v3 fixed-configuration budget follow-up

`followup_budget_queue.py`, `test_queue_budget_followup.py`, and
`sb3_queue_budget_followup_v1/` define a
separate resolution-cost diagnostic for `NonstationaryQueue-v0`. It reuses the
v3-selected DQN (`lr3e4_short`) and A2C (`lr1e4_short`) configurations and the
v3 test prefix 20000--20019, then appends seeds through 20399. The comparison
alpha remains `0.05/15`; looks are at 200, 400, 600, 800, and 1000 total test
seeds, with 4096 training steps and five evaluation episodes per checkpoint.
The observed run stops at 400 with a DQN-superior decision. This run was
initiated after v3 and is not part of the preregistered 15-comparison family.

Run the deterministic audit with:

```bash
./.rl-arm64-venv/bin/python audit_queue_budget_followup.py
```

The audit checks 800 rows, the v3 prefix equality, selected configurations,
bounded metrics, stop trace, and source hashes. It does not establish external
reproducibility or a universal seed requirement.

## Prospective v4 new-seed extension

`FINAL_PREREGISTRATION_V4_EXTENSION.md` freezes a separate extension using
training seeds `30000--30399` for every task and algorithm. It reuses the v3
selected configurations, 4,096-step training budget, four checkpoints, five
evaluation episodes, family alpha `0.05/15`, and the unpaired Hoeffding rule.
The two looks are at 200 and 400 seeds; no extension tuning is permitted.

The stored extension contains 6,000 rows in
`sb3_v4_extension/raw_seed_metrics.csv`, with runtime metadata in
`sb3_v4_extension/run_config.json`, summaries in `summary.json`, and the
recomputed integrity result in `V4_EXTENSION_AUDIT.json`. The observed result
is one terminal `a_superior` decision for `NonstationaryQueue-v0` DQN--A2C at
200 new seeds (`0.345322`, `[0.069863, 0.620781]`) and 14 maximum-budget
inconclusive comparisons at 400. This is a same-family prospective budget
observation, not an external rerun or universal seed requirement.

Run the audit with:

```bash
./.rl-arm64-venv/bin/python audit_v4_extension.py
```

The non-pooled cross-sequence consistency diagnostic is generated with:

```bash
./.rl-arm64-venv/bin/python v4_sequence_consistency.py
```

It compares the post-v3 follow-up and v4 queue sequences at 200 and 400 seeds.
The v4 400-seed value is descriptive because its terminal state was locked at
200. `V4_SEQUENCE_CONSISTENCY.md` and `V4_SEQUENCE_CONSISTENCY.json` do not
constitute an external replication or pooled confirmatory analysis.

The finite-look minimax alpha-spending planning diagnostic is generated with:

```bash
./.rl-arm64-venv/bin/python minimax_alpha_spending.py
```

It solves `4 * sum_k exp(-n_k * tau) = alpha_cmp` for the v3 look sizes and
reports the equalized worst-case radius beside the preregistered power-series
schedule. It is an analytical planning result; the v3 primary decisions remain
based on the preregistered spending rule. `test_minimax_alpha_spending.py`
checks budget exhaustion and radius equalization.

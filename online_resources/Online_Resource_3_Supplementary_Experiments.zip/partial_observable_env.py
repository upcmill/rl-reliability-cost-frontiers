#!/usr/bin/env python3
"""Registered fixed-mask partially observable Gymnasium diagnostics."""

from __future__ import annotations

import gymnasium as gym
import numpy as np
from gymnasium.envs.registration import EnvSpec


class FixedMaskObservation(gym.ObservationWrapper):
    """Replace selected observation coordinates by their neutral value."""

    def __init__(self, env: gym.Env, masked_indices: tuple[int, ...]):
        super().__init__(env)
        self.masked_indices = masked_indices
        low = np.asarray(self.observation_space.low, dtype=np.float32).copy()
        high = np.asarray(self.observation_space.high, dtype=np.float32).copy()
        low[list(masked_indices)] = 0.0
        high[list(masked_indices)] = 0.0
        self.observation_space = gym.spaces.Box(low=low, high=high, dtype=np.float32)

    def observation(self, observation):
        masked = np.asarray(observation, dtype=np.float32).copy()
        masked[list(self.masked_indices)] = 0.0
        return masked


def make_masked_cartpole(**kwargs):
    return FixedMaskObservation(gym.make("CartPole-v1", **kwargs), (1, 3))


def make_masked_acrobot(**kwargs):
    return FixedMaskObservation(gym.make("Acrobot-v1", **kwargs), (4, 5))


def register_environments() -> None:
    registrations = (
        ("MaskedCartPole-v1", make_masked_cartpole),
        ("MaskedAcrobot-v1", make_masked_acrobot),
    )
    for environment_id, entry_point in registrations:
        if environment_id not in gym.registry:
            gym.register(id=environment_id, entry_point=entry_point, max_episode_steps=500 if "CartPole" in environment_id else 500)


register_environments()


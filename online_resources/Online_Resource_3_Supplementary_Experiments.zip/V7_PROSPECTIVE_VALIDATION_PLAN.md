# V7 New-Seed Validation Plan

**Status:** frozen before generation of the V7 test sequence. This is a
prospective new-seed validation designed after the V1--V6 results were seen;
it is not a registration made before the original study and does not erase
that history.

## Question and scope

Does the observed interval-width and stopping behavior of the Gamma-mixture
empirical-Bernstein confidence sequence persist on a new seed sequence for
the same five tasks, three algorithms, and frozen configurations? The target
is the same conditional normalized four-checkpoint metric used in V3--V5.
The 15 task--algorithm comparisons are a fixed panel, not a random sample of
RL tasks. Results will be reported comparison by comparison and descriptively;
no task-population inference or independent-sample test across the 15 pairs
will be used.

## Frozen training data collection

- Tasks: `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`, and
  `NonstationaryQueue-v0`.
- Algorithms: PPO, DQN, and A2C.
- Configurations: the selected configuration for each task--algorithm cell
  from `sb3_formal_v3/summary.json`; no retuning, reselection, or task removal.
- New training seeds: integers 31,400 through 32,399 inclusive, shared across
  all task--algorithm cells. They do not overlap the V3, V4, or V5 seed ranges.
- Training: 4,096 environment steps; checkpoints at 1,024, 2,048, 3,072, and
  4,096; five deterministic evaluation episodes per checkpoint; existing
  normalization bounds and `train_curve` implementation unchanged.
- Expected data: 15,000 successful training rows. Preserve runtime, raw
  metric, normalized metric, configuration ID, train seed, evaluation seed
  base, and run status. Failed attempts are logged and retried only at the
  exact same task, algorithm, and seed; no replacement seed or imputation.
- Execution: CPU, same installed software stack, sequential runs. The runner
  flushes each completed row and may resume only from the same frozen lock.

## Frozen comparison

Use the common looks `200, 400, 600, 800, 1,000`, all 15 pairs, the same
normalized difference estimand, family alpha `0.05`, per-pair alpha
`0.05/15`, practical margin `0.05`, target width `0.10`, and locked first
terminal decision rule as the V1 comparison. Compare the seven primary
methods and two Gamma-rho sensitivities defined in
`modern_sequential_intervals.py`. The original Hoeffding method and the
Gamma-mixture empirical-Bernstein CS are the prespecified reference pair.

## Outcomes and reporting

The primary descriptive outcome is the paired difference in final interval
width (Gamma CS minus original Hoeffding) for each of the 15 comparisons at
1,000 seeds, alongside its mean and median over this fixed panel. Also report
all 15 widths and estimates, first terminal category and look, the number of
resolved comparisons, and deduplicated shared-arm prefix counts. Other methods
and earlier looks are secondary. Do not report a p-value treating the 15 pairs
as independent. The stopping counts and widths are observed properties of
this fixed panel and sequence; they do not establish coverage on unknown RL
seed distributions. Coverage statements remain limited to the assumptions and
calibrations already stated in the manuscript.

The descriptive replication criterion is met only if Gamma CS has a lower
mean final width than original Hoeffding on this new fixed panel. Regardless
of the criterion, report every pair and retain all outcomes. No claim of
actual computation savings is permitted because the complete sequence is
collected. Any deviation, interrupted run, failed attempt, or software drift
must be disclosed before interpreting results.

## Provenance and limits

Before execution, hash this plan, the runner, analysis code, interval code,
training code, V3 selected-configuration source, and V5 configuration. The
same-team run can demonstrate repeatability. It cannot establish independent
team reproducibility, universal efficiency, prospective power, or a general
algorithm ranking. Because the underlying prior results informed this
follow-up question, call it a prospective new-seed validation, not a fully
independent confirmatory study.

# V4 Queue Sequence Consistency Diagnostic

This report compares two disclosed queue seed sequences without pooling their observations or changing either stopping rule.
The post-v3 follow-up reuses the v3 20-seed prefix; the v4 sequence uses new seeds 30000--30399.

| Sequence | n | DQN mean | A2C mean | Estimate (DQN - A2C) | Interval | Decision/status |
|---|---:|---:|---:|---:|---|---|
| post_v3_prefix_followup | 200 | 0.920126 | 0.601702 | 0.318424 | [0.042965, 0.593883] | max_budget_inconclusive |
| post_v3_prefix_followup | 400 | 0.920646 | 0.582292 | 0.338355 | [0.126528, 0.550181] | a_superior |
| prospective_v4_new_seeds | 200 | 0.921405 | 0.576083 | 0.345322 | [0.069863, 0.620781] | a_superior |
| prospective_v4_new_seeds | 400 | 0.921273 | 0.578944 | 0.342329 | [0.130503, 0.554156] | descriptive continuation; terminal decision locked at n=200 |

Both sequences have a positive DQN-minus-A2C estimate at 200 and 400 seeds. This is a descriptive consistency check for one controlled task and two frozen procedures.
The v4 400-seed value is not a second decision: the predeclared state machine stopped at 200 and the terminal state remains locked.
The result does not support pooled confirmatory inference, external reproducibility, a universal seed requirement, or a general algorithm ranking.

Machine-readable output: `V4_SEQUENCE_CONSISTENCY.json`; source: `v4_sequence_consistency.py`.

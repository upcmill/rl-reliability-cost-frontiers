# Prospective Tuning-Stability Extension V1

## Purpose and scope

This document freezes a supplementary diagnostic before its execution. It
tests whether the four-candidate validation selection used by the v3 study is
stable when the validation sample is increased from five to twenty seeds. It
does not amend, pool with, or re-estimate the v3 confirmatory family.

The estimand is the selected configuration under a fixed candidate grid,
environment, algorithm, training budget, evaluation procedure, and validation
seed set. The result is a conditional selection-stability description. It is
not a probability that a configuration is optimal, a power calculation, or a
claim that twenty seeds is universally sufficient.

## Frozen design

- Environments: `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`,
  `NonstationaryQueue-v0`, and `Taxi-v4`.
- Algorithms: PPO, DQN, and A2C.
- Candidates: `lr3e4_long`, `lr1e4_long`, `lr3e4_short`, and `lr1e4_short`
  from `tuning_strength_runner.py`.
- Validation seeds: 20 per candidate, `train_seed` values 11000--11019.
  These do not overlap the v3 validation seeds or the earlier tuning
  diagnostics.
- Diagnostic test seeds: one per selected cell, `train_seed` 32000. These
  rows are descriptive bookkeeping only and are not used in any confirmatory
  inference.
- Training: 4096 total steps, four checkpoints, five evaluation episodes.
- Selection: largest mean normalized validation metric; ties use the runner's
  deterministic first-key rule.
- Runtime: the recorded CPU runtime is descriptive and machine-specific.

The runner must retain all candidate-level validation rows, selected
configuration IDs, validation summaries, source hash, package versions, and
the exact command. A failed run is recorded rather than silently replaced.

## Predeclared analyses

1. Compare each selected configuration with the v3 five-seed selection for all
   15 environment--algorithm cells.
2. Report the number and proportion of changed selections, with the cells
   listed explicitly.
3. Report candidate-level validation means and sample standard deviations for
   every cell; do not report only the winner.
4. Treat the 20-seed selection as a sensitivity diagnostic. No v3 test return,
   v4/v5 extension return, or diagnostic test row may be pooled into the v3
   family.

No hypothesis test, confidence interval, algorithm ranking, or universal seed
recommendation is planned for this extension. Any test-row summaries are
descriptive and remain outside the primary estimand.

## Evidence boundary

Agreement between five- and twenty-seed selections would support describing
the observed v3 selection as stable for this fixed family and grid. Any
changes would support the existing limitation that the v3 tuning budget is
selection-sensitive. Neither outcome establishes population-level tuning
stability or optimality.

## Reproduction command

```bash
./.rl-arm64-venv/bin/python tuning_strength_runner.py \
  --validation-seeds 20 --test-seeds 1 \
  --validation-seed-base 11000 --test-seed-base 32000 \
  --timesteps 4096 --checkpoints 4 --eval-episodes 5 \
  --output-dir sb3_tuning_stability_v20
```

The command, source hash, output hashes, and execution date are part of the
extension artifact. The extension remains supplementary even if all runs
complete successfully.

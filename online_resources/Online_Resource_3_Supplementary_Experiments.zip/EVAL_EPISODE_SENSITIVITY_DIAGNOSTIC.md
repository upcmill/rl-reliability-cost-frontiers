# v3 Evaluation-Episode Sensitivity Diagnostic

This is a supplementary fixed-configuration diagnostic. It does not alter the
preregistered v3 primary analysis, its five-episode evaluation design, or its
decisions.

## Design

- Tasks: `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`, and
  `NonstationaryQueue-v0`.
- Algorithms: PPO, DQN, and A2C.
- Configuration: the configuration selected by the v3 five-validation-seed
  procedure for each task--algorithm cell; no re-tuning was performed.
- Test seeds: the same sealed training seeds 20,000--20,019.
- Training budget and checkpoints: the v3 4,096 steps at 1,024, 2,048,
  3,072, and 4,096 steps.
- Evaluation: ten episodes per checkpoint instead of the v3 five episodes.
  The deterministic evaluation seed construction is unchanged; the extra
  episodes extend the same seeded sequence.
- Inference: the same unpaired Hoeffding interval, four looks, comparison
  alpha `0.05 / 15`, practical margin 0.05, and target width 0.10.

The run contains 300 test rows and 15 task--algorithm comparisons. Because the
episode count was changed after the primary analysis, all results below are
exploratory sensitivity evidence.

## Results

All 15 comparisons reached the maximum of 20 test seeds and were
`max_budget_inconclusive` under the same decision rule. The final clipped
interval widths ranged from 1.7172 to 2.0000 (median 1.9124), so no comparison
approached the 0.10 precision target.

| Environment | PPO mean | DQN mean | A2C mean |
|---|---:|---:|---:|
| CartPole-v1 | 0.213380 | 0.024600 | 0.199738 |
| Acrobot-v1 | 0.107607 | 0.187470 | 0.081990 |
| MountainCar-v0 | 0.000000 | 0.006463 | 0.000000 |
| Taxi-v4 | 0.891089 | 0.891089 | 0.679138 |
| NonstationaryQueue-v0 | 0.793480 | 0.922541 | 0.621880 |

Relative to the five-episode v3 means, the largest absolute changes were
`+0.005619` for Taxi/A2C, `+0.004995` for Acrobot/DQN, and `-0.002525` for
Acrobot/A2C. Across the 15 cells, the mean absolute change in the normalized
cell mean was 0.0013. The largest cell-level mean absolute difference across
the 20 matched training seeds was 0.0345 for Taxi/A2C; this is a descriptive
measure of evaluation aggregation sensitivity, not an estimate of population
error.

## Interpretation and limits

Within this fixed task family, training budget, selected configurations, and
test seeds, increasing evaluation episodes from five to ten did not change any
family-level decision. This reduces concern that the v3 maximum-budget result
is driven solely by using five evaluation episodes per checkpoint. It does not
prove that ten episodes are sufficient for other environments, policies, or
metrics, and it does not quantify dependence among episodes. The result is a
same-machine sensitivity run, not external reproducibility evidence.

## Reproduction

```bash
./.rl-arm64-venv/bin/python eval_episode_sensitivity_diagnostic.py \
  --reference-dir sb3_formal_v3 \
  --test-seeds 20 --timesteps 4096 --checkpoints 4 \
  --eval-episodes 10 --family-alpha 0.05 \
  --practical-margin 0.05 --target-width 0.10 \
  --output-dir sb3_eval_episode_sensitivity_v3
```

The exact raw rows, summary, and runtime metadata are in
`sb3_eval_episode_sensitivity_v3/`.

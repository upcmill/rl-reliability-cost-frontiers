#!/usr/bin/env python3
"""Run the frozen v6 two-task Gymnasium extension."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
import time
from itertools import combinations
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch

from pilot_protocol import ProtocolConfig, sequential_decision
from sb3_pilot import ALGORITHMS, make_model


ENVIRONMENTS = ("CliffWalking-v1", "FrozenLake-v1")
ALPHA = 0.05
CONFIGS = {
    "lr3e4_long": {"learning_rate": 3e-4, "batch_size": 64, "n_steps": 256, "buffer_size": 5000, "learning_starts": 100},
    "lr1e4_long": {"learning_rate": 1e-4, "batch_size": 64, "n_steps": 256, "buffer_size": 5000, "learning_starts": 100},
    "lr3e4_short": {"learning_rate": 3e-4, "batch_size": 64, "n_steps": 128, "buffer_size": 10000, "learning_starts": 200},
    "lr1e4_short": {"learning_rate": 1e-4, "batch_size": 64, "n_steps": 128, "buffer_size": 10000, "learning_starts": 200},
}
OUTPUT_DIR = Path("sb3_v6_task_family")
VALIDATION_BASE = 40_000
TEST_BASE = 41_000


def make_env(env_id: str):
    if env_id == "FrozenLake-v1":
        return gym.make(env_id, map_name="4x4", is_slippery=True)
    return gym.make(env_id)


def normalize(env_id: str, value: float) -> float:
    lower, upper = ((-100.0, 0.0) if env_id == "CliffWalking-v1" else (0.0, 1.0))
    return max(0.0, min(1.0, (value - lower) / (upper - lower)))


def evaluation_horizon(env_id: str) -> int:
    # CliffWalking-v1 has no Gymnasium TimeLimit wrapper; fixing the horizon
    # makes its evaluation budget explicit and prevents non-terminating paths.
    return 100


def train_curve(env_id: str, algorithm: str, train_seed: int, config: dict, checkpoints: list[int], episodes: int) -> dict:
    env = make_env(env_id)
    model = make_model(algorithm, env, train_seed, config)
    raw_checkpoints: list[float] = []
    normalized_checkpoints: list[float] = []
    episode_returns: list[list[float]] = []
    evaluation_seeds: list[int] = []
    trained = 0
    started = time.perf_counter()
    for checkpoint in checkpoints:
        model.learn(total_timesteps=checkpoint - trained, reset_num_timesteps=False)
        trained = checkpoint
        evaluation_seed = train_seed + 1_000_000 + checkpoint
        eval_env = make_env(env_id)
        returns: list[float] = []
        for episode in range(episodes):
            obs, _ = eval_env.reset(seed=evaluation_seed + episode)
            done = False
            total = 0.0
            for _ in range(evaluation_horizon(env_id)):
                action, _ = model.predict(obs, deterministic=True)
                if isinstance(action, np.ndarray) and action.size == 1:
                    action = action.item()
                obs, reward, terminated, truncated, _ = eval_env.step(action)
                done = terminated or truncated
                total += float(reward)
                if done:
                    break
            returns.append(total)
        eval_env.close()
        raw = float(np.mean(returns))
        raw_checkpoints.append(raw)
        normalized_checkpoints.append(normalize(env_id, raw))
        episode_returns.append(returns)
        evaluation_seeds.append(evaluation_seed)
    runtime = time.perf_counter() - started
    env.close()
    return {
        "metric_normalized": float(np.mean(normalized_checkpoints)),
        "metric_raw": float(np.mean(raw_checkpoints)),
        "checkpoint_normalized": normalized_checkpoints,
        "checkpoint_raw": raw_checkpoints,
        "episode_returns": episode_returns,
        "evaluation_seed_base": train_seed + 1_000_000,
        "evaluation_seeds": evaluation_seeds,
        "runtime_seconds": runtime,
    }


def protocol(max_seeds: int = 200) -> ProtocolConfig:
    return ProtocolConfig(
        alpha=ALPHA / (len(ENVIRONMENTS) * 3),
        practical_margin=0.05,
        initial_seeds=50,
        batch_size=50,
        max_seeds=max_seeds,
        target_width=0.10,
        interval_method="hoeffding_unpaired",
        bootstrap_resamples=1000,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--timesteps", type=int, default=4096)
    parser.add_argument("--eval-episodes", type=int, default=5)
    args = parser.parse_args()
    if args.timesteps != 4096 or args.eval_episodes != 5:
        parser.error("v6 is frozen at 4096 timesteps and five evaluation episodes")
    return args


def main() -> None:
    args = parse_args()
    torch.set_num_threads(1)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = [args.timesteps * i // 4 for i in range(1, 5)]
    records: list[dict] = []
    metrics: dict[tuple[str, str], list[float]] = {(env_id, algorithm): [] for env_id in ENVIRONMENTS for algorithm in ALGORITHMS}
    validation: dict[str, dict[str, dict[str, list[float]]]] = {}
    selected: dict[str, dict[str, str]] = {}

    for env_id in ENVIRONMENTS:
        validation[env_id] = {}
        selected[env_id] = {}
        for algorithm in ALGORITHMS:
            validation[env_id][algorithm] = {}
            for config_id, config in CONFIGS.items():
                values: list[float] = []
                for offset in range(10):
                    train_seed = VALIDATION_BASE + offset
                    result = train_curve(env_id, algorithm, train_seed, config, checkpoints, args.eval_episodes)
                    values.append(result["metric_normalized"])
                    records.append({"env_id": env_id, "algorithm": algorithm, "config_id": config_id, "split": "validation", "seed": offset, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})
                validation[env_id][algorithm][config_id] = values
            selected[env_id][algorithm] = max(CONFIGS, key=lambda config_id: (float(np.mean(validation[env_id][algorithm][config_id])), -list(CONFIGS).index(config_id)))

    for offset in range(200):
        train_seed = TEST_BASE + offset
        for env_id in ENVIRONMENTS:
            for algorithm in ALGORITHMS:
                config_id = selected[env_id][algorithm]
                result = train_curve(env_id, algorithm, train_seed, CONFIGS[config_id], checkpoints, args.eval_episodes)
                metrics[(env_id, algorithm)].append(result["metric_normalized"])
                records.append({"env_id": env_id, "algorithm": algorithm, "config_id": config_id, "split": "extension_test", "seed": offset, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})

    traces = []
    for n in (50, 100, 150, 200):
        cfg = protocol(n)
        decisions = {f"{env_id}:{a}_vs_{b}": sequential_decision(metrics[(env_id, a)][:n], metrics[(env_id, b)][:n], cfg) for env_id in ENVIRONMENTS for a, b in combinations(ALGORITHMS, 2)}
        traces.append({"n": n, "decisions": decisions})

    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    metadata = {
        "status": "v6_prospective_task_family_extension",
        "warning": "New same-machine task-family scope diagnostic; not pooled with v3 and not external replication.",
        "environment_ids": list(ENVIRONMENTS),
        "environment_options": {"FrozenLake-v1": {"map_name": "4x4", "is_slippery": True}},
        "algorithm_ids": list(ALGORITHMS),
        "candidate_configs": CONFIGS,
        "validation_seed_range": "40000-40009",
        "test_seed_range": "41000-41199",
        "run_config": {"timesteps": args.timesteps, "checkpoints": checkpoints, "eval_episodes": args.eval_episodes, "validation_seeds_per_candidate": 10, "test_seeds_per_algorithm": 200, "family_alpha": ALPHA, "comparison_alpha": ALPHA / 6, "practical_margin": 0.05, "target_width": 0.10, "look_sizes": [50, 100, 150, 200], "interval_method": "hoeffding_unpaired"},
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "gymnasium": gym.__version__,
        "stable_baselines3": importlib.metadata.version("stable-baselines3"),
        "mps_available": bool(torch.backends.mps.is_available()),
        "torch_num_threads": torch.get_num_threads(),
        "script_sha256": script_hash,
        "selected_configurations": {f"{env_id}:{algorithm}": config_id for env_id in ENVIRONMENTS for algorithm, config_id in selected[env_id].items()},
        "stop_traces": traces,
        "interpretation": {"scope": "two additional fixed Gymnasium discrete tasks", "not_supported": ["universal seed requirements", "general algorithm ranking", "prospective power", "external reproducibility"]},
    }
    fields = ["env_id", "algorithm", "config_id", "split", "seed", "train_seed", "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status"]
    with (args.output_dir / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    (args.output_dir / "run_config.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "summary.json").write_text(json.dumps({"metadata": metadata, "validation": validation, "selected": selected, "test_metrics": {f"{env_id}:{algorithm}": values for (env_id, algorithm), values in metrics.items()}}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": metadata["status"], "rows": len(records), "output_dir": str(args.output_dir)}))


if __name__ == "__main__":
    main()

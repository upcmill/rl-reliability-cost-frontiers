# v3 Raw-Return Normalization Sensitivity

This is a post-hoc robustness analysis on the frozen v3 test rows. It does not
alter the pre-registered `[0,1]` normalization or the primary family result.

The primary study maps each task's raw return to `[0,1]` using the bounds in
`REPRODUCTION_MANIFEST_V3.md`. This analysis reuses the stored raw
four-checkpoint means and changes the bounds for one environment at a time.
The alternative bounds are fixed in `v3_normalization_sensitivity.py`: a
tighter scale and a wider scale for each task. Values outside a bound are
clipped, exactly as in the primary implementation. The same 15-comparison
unpaired Hoeffding rule, comparison alpha `0.05/15`, looks at 5/10/15/20,
margin 0.05, and target width 0.10 are then applied.

The JSON output reports every decision, the decision-count summary, and the
fraction of comparisons that reach the maximum budget. Because the raw test
sample and alternative bounds were inspected after the primary analysis, the
results are robustness diagnostics rather than confirmatory evidence.

Run:

```bash
python3 v3_normalization_sensitivity.py \
  --input sb3_formal_v3/raw_seed_metrics.csv \
  --output v3_normalization_sensitivity.json
```

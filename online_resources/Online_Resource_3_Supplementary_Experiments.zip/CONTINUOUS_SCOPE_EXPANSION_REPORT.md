# Continuous-Control Scope Expansion Report

This report covers the separately preregistered `MountainCarContinuous-v0`
scope supplement. It is not pooled with the v3 primary family or the earlier
`Pendulum-v1` supplement.

## Design and accounting

The supplement used PPO and A2C, four candidate configurations, five
validation seeds per candidate, one selected configuration per algorithm, and
20 sealed test seeds. The raw artifact contains 80 rows: 40 validation and 40
test. The installed environment's action penalty is at most 0.1 per step and
the terminal reward is 100; the supplement used the conservative stored raw
bound `[-100, 100]` and clipped normalized metrics to `[0,1]`.

## Configuration and descriptive results

Both algorithms selected `lr1e4_short`. The 20-seed normalized test mean was
0.499982 for PPO (sample SD 0.000012) and 0.499859 for A2C (sample SD
0.000142). These values are descriptive for the fixed training budget. The
near-0.5 values reflect the selected normalization boundary and should not be
interpreted as performance rankings.

## Formal supplement comparison

The PPO-minus-A2C estimate at 20 test seeds was 0.0001233, with the unpaired
Hoeffding interval `[-0.8747, 0.8749]`. The decision was
`max_budget_inconclusive`. The stop trace at 5, 10, 15, and 20 seeds was also
inconclusive at every look.

## Repeatability and limitations

The separate replay script regenerated both selected configurations on the same
machine. Both mean absolute normalized-metric differences were 0.0. This is
same-machine cross-script repeatability, not external reproducibility. The
experiment contains one additional continuous task and two algorithms, so it
only broadens execution scope; it does not establish general continuous-control
validity.

## Artifacts

- Preregistration: `FINAL_PREREGISTRATION_CONTINUOUS_SCOPE_EXPANSION.md`;
- Runner: `continuous_scope_runner.py`;
- Raw data and summary: `sb3_continuous_mountaincar/`;
- Independent replay: `independent_continuous_scope_reproduction.py`;
- Audit: `audit_continuous_scope_artifacts.py`.

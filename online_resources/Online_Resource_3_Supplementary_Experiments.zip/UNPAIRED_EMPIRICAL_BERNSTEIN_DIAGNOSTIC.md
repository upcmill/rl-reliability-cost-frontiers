# Candidate Unpaired Empirical-Bernstein Diagnostic

This document records a post-hoc diagnostic of a variance-adaptive interval
candidate. It is deliberately outside the preregistered v3 confirmatory
analysis and does not change any primary result.

## Candidate

For each bounded algorithm mean, the candidate estimates the sample variance,
constructs a finite-sample empirical-Bernstein radius, and adds the two radii
for the unpaired mean difference. The implementation is in
`pilot_protocol.py`; the complete simulation is in
`unpaired_empirical_bernstein_diagnostic.py`.

The candidate was evaluated at the same alpha-spending schedule and looks as
the primary protocol: 5, 10, 15, and 20 test seeds, comparison alpha 0.05,
and practical margin 0.05. The diagnostic compares it with the existing
unpaired Hoeffding baseline.

## Design

The coverage experiment used 5,000 independent replicates per cell and five
bounded distributions with known mean differences: symmetric two-point,
skewed Beta, rare-extreme mixture, bounded heavy-tail Beta, and
heteroscedastic two-point distributions. At each look, coverage was checked
against the known population difference; simultaneous coverage required all
four intervals to contain that difference.

The decision experiment used 5,000 Bernoulli replicates for a null difference
of 0.0 and a positive difference of 0.10. It recorded sequential decisions,
false-superiority rate, superiority power, and the number of seeds used. All
proportions include 95% Wilson Monte Carlo intervals.

## Results

The candidate and Hoeffding baseline both had estimated simultaneous coverage
of 1.0000 in every distribution cell. The lower 95% Monte Carlo bound was
0.99923 in each cell. This is evidence of conservatism in the tested scenarios,
not a proof of finite-sample validity.

For both the null and 0.10-effect decision cells, both methods produced
5,000/5,000 `max_budget_inconclusive` outcomes, used 20.0 seeds on average,
and had an estimated false-superiority rate of 0.0000 (upper Wilson bound
0.00077 for the null cell). The candidate therefore did not improve decision
power or seed cost at the study budget.

## Interpretation and gate

The result does not support adding the candidate to the confirmatory method or
claiming a variance-adaptive efficiency improvement. The implementation is
retained for auditability and future work only. A future confirmatory use
would require, at minimum, an independently checked finite-sample/sequential
argument, a predeclared simulation protocol, and a budget at which the method
demonstrates useful power without violating its error target.

The main manuscript remains unchanged: the unpaired Hoeffding interval is the
formal baseline, all v3 decisions remain frozen, and the candidate is an
exploratory negative result.

## Reproduction

```bash
python3 unpaired_empirical_bernstein_diagnostic.py \
  --replicates 5000 \
  --output unpaired_empirical_bernstein_diagnostic.json
```

The JSON artifact records the configuration, scenario definitions, Wilson
intervals, and the interpretation gate.

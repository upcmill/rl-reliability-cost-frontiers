# Continuous Supplement Reproduction Manifest

## Frozen artifact

- preregistration: `FINAL_PREREGISTRATION_CONTINUOUS_SUPPLEMENT.md`;
- task: `Pendulum-v1`, Gymnasium 1.4.0;
- algorithms: PPO and A2C, Stable-Baselines3 2.9.2;
- validation: four candidates x five seeds (`10000`--`10004`);
- sealed test: selected configuration x 20 seeds (`20000`--`20019`);
- training: 4096 steps, checkpoints 1024/2048/3072/4096;
- evaluation: five episodes per checkpoint;
- interval: unpaired Hoeffding, alpha 0.05, looks 5/10/15/20;
- frozen rounded raw-return bound: `[-3254.72, 0]`; the unrounded analytical
  lower endpoint is approximately `-3254.72088`, and metric clipping enforces
  `[0,1]`.

## Source hashes

| File | SHA-256 |
|---|---|
| `continuous_pendulum_runner.py` | `0d52ae673a5b36db42b659db59453eb42d9a7f77f8cd5fc8138c2527b9275273` |
| `independent_pendulum_reproduction.py` | `a73a1daf9f0cd87405005fe2b42c88ff65794ab05ffd91c7fead833ba779c688` |
| `FINAL_PREREGISTRATION_CONTINUOUS_SUPPLEMENT.md` | `e440979608a530660cd46f2fba19c72a08e0adcaf055072368203c9bed724e7c` |

## Commands

```bash
./.rl-arm64-venv/bin/python continuous_pendulum_runner.py \
  --output-dir sb3_continuous_pendulum

./.rl-arm64-venv/bin/python independent_pendulum_reproduction.py \
  --reference-dir sb3_continuous_pendulum \
  --output sb3_continuous_pendulum/independent_reproduction.json
```

The stored run used Python 3.11.7, arm64 Apple Silicon macOS, PyTorch 2.14.1,
and CPU execution. The replay produced zero mean absolute normalized-metric
difference for both algorithms on the same machine. No external replay exists.

Run the package consistency audit:

```bash
./.rl-arm64-venv/bin/python audit_continuous_artifacts.py
```

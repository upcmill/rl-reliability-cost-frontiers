#!/usr/bin/env python3
"""Compute a minimax finite-look alpha-spending schedule analytically."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def minimax_allocations(n_per_algorithm: list[int], alpha: float) -> dict[str, object]:
    if not n_per_algorithm or any(n <= 0 for n in n_per_algorithm):
        raise ValueError("sample sizes must be positive")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must lie in (0,1)")

    def required_alpha(t: float) -> float:
        return 4.0 * sum(math.exp(-n * t) for n in n_per_algorithm)

    low, high = 0.0, 1.0
    while required_alpha(high) > alpha:
        high *= 2.0
    for _ in range(200):
        mid = (low + high) / 2.0
        if required_alpha(mid) > alpha:
            low = mid
        else:
            high = mid
    tau = (low + high) / 2.0
    allocations = [4.0 * math.exp(-n * tau) for n in n_per_algorithm]
    radii = [math.sqrt(2.0 * math.log(4.0 / a) / n) for n, a in zip(n_per_algorithm, allocations)]
    return {
        "sample_sizes": n_per_algorithm,
        "alpha": alpha,
        "tau": tau,
        "allocations": allocations,
        "allocation_sum": sum(allocations),
        "radius_sums": radii,
        "max_radius_sum": max(radii),
    }


def power_series_schedule(n_per_algorithm: list[int], alpha: float) -> dict[str, object]:
    allocations = [alpha * 6.0 / (math.pi**2 * (k + 1) ** 2) for k in range(len(n_per_algorithm))]
    radii = [math.sqrt(2.0 * math.log(4.0 / a) / n) for n, a in zip(n_per_algorithm, allocations)]
    return {
        "allocations": allocations,
        "allocation_sum": sum(allocations),
        "radius_sums": radii,
        "max_radius_sum": max(radii),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha", type=float, default=0.05 / 15.0)
    parser.add_argument("--sample-sizes", type=int, nargs="+", default=[5, 10, 15, 20])
    parser.add_argument("--output", default="MINIMAX_ALPHA_SPENDING.json")
    args = parser.parse_args()
    minimax = minimax_allocations(args.sample_sizes, args.alpha)
    power = power_series_schedule(args.sample_sizes, args.alpha)
    payload = {
        "status": "PASS",
        "objective": "minimize the maximum equal-sample unpaired Hoeffding radius sum across fixed looks",
        "minimax": minimax,
        "power_series": power,
        "interpretation": {
            "supported": [
                "The minimax allocation equalizes the radius sum across all listed looks under the bounded union-bound budget.",
                "The power-series allocation has a smaller final-look radius but a larger worst-case radius at the earliest look for v3 sample sizes.",
            ],
            "not_supported": [
                "This diagnostic does not amend the preregistered v3 analysis.",
                "It does not establish empirical RL power or a universally optimal stopping policy.",
            ],
        },
    }
    path = ROOT / args.output
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Minimax Finite-Look Alpha Spending",
        "",
        "For equal sample sizes at look k, let `q_k = log(4/alpha_k) / n_k`; the unpaired Hoeffding radius sum is `sqrt(2 q_k)`. Under `sum alpha_k <= alpha`, minimizing the maximum radius is equivalent to minimizing `max q_k`.",
        "",
        "The minimax threshold `tau` is the unique positive solution of `4 * sum_k exp(-n_k * tau) = alpha`. The corresponding allocation is `alpha_k* = 4 exp(-n_k * tau)`, which equalizes all radius sums. This follows because any schedule with `q_k <= tau` must allocate at least `4 exp(-n_k tau)` to look k.",
        "",
        f"Inputs: sample sizes `{args.sample_sizes}`, comparison alpha `{args.alpha:.16g}`.",
        "",
        "| Look | n | Minimax alpha | Minimax radius sum | Power-series alpha | Power-series radius sum |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for i, n in enumerate(args.sample_sizes):
        lines.append(
            f"| {i + 1} | {n} | {minimax['allocations'][i]:.12g} | {minimax['radius_sums'][i]:.6f} | {power['allocations'][i]:.12g} | {power['radius_sums'][i]:.6f} |"
        )
    lines.extend([
        "",
        f"The minimax schedule has worst-case radius sum `{minimax['max_radius_sum']:.6f}`; the preregistered power-series schedule has `{power['max_radius_sum']:.6f}` for this v3 look sequence.",
        "The minimax schedule is a design diagnostic. The v3 confirmatory analysis keeps its preregistered power-series spending, and no RL decisions are recomputed under the alternative schedule.",
        "",
        "Machine-readable output: `MINIMAX_ALPHA_SPENDING.json`; source: `minimax_alpha_spending.py`.",
    ])
    (ROOT / "MINIMAX_ALPHA_SPENDING.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(path)
    print(ROOT / "MINIMAX_ALPHA_SPENDING.md")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Generate a post-hoc practical-margin sensitivity diagnostic for v3."""

from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision


ROOT = Path(__file__).resolve().parent
ENVIRONMENTS = ("CartPole-v1", "Acrobot-v1", "MountainCar-v0", "Taxi-v4", "NonstationaryQueue-v0")
ALGORITHMS = ("PPO", "DQN", "A2C")
LOOKS = (1, 2, 3, 4)
MARGINS = (0.0, 0.025, 0.05, 0.10, 0.20, 0.30, 0.50)
FAMILY_ALPHA = 0.05
COMPARISON_COUNT = 15


def look_alpha(comparison_alpha: float, look: int) -> float:
    return comparison_alpha * 6.0 / (math.pi * math.pi * look * look)


def possible_threshold(comparison_alpha: float, look: int, margin: float) -> int:
    """Necessary per-arm n for any [0,1] data to cross the margin."""
    gap = 1.0 - margin
    return math.floor(2.0 * math.log(4.0 / look_alpha(comparison_alpha, look)) / (gap * gap)) + 1


def read_test_values() -> dict[tuple[str, str], list[float]]:
    values: dict[tuple[str, str], list[float]] = defaultdict(list)
    with (ROOT / "sb3_formal_v3/raw_seed_metrics.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["split"] == "test":
                values[(row["env_id"], row["algorithm"])].append(float(row["metric_normalized"]))
    for environment in ENVIRONMENTS:
        for algorithm in ALGORITHMS:
            if len(values[(environment, algorithm)]) != 20:
                raise ValueError(f"expected 20 test metrics for {environment}/{algorithm}")
    return values


def main() -> None:
    comparison_alpha = FAMILY_ALPHA / COMPARISON_COUNT
    values = read_test_values()
    rows = []
    for margin in MARGINS:
        threshold_row = {
            str(look): possible_threshold(comparison_alpha, look, margin) for look in LOOKS
        }
        decisions = Counter()
        for environment in ENVIRONMENTS:
            for first, second in combinations(ALGORITHMS, 2):
                result = sequential_decision(
                    values[(environment, first)],
                    values[(environment, second)],
                    ProtocolConfig(
                        alpha=comparison_alpha,
                        practical_margin=margin,
                        target_width=0.10,
                        initial_seeds=5,
                        batch_size=5,
                        max_seeds=20,
                        interval_method="hoeffding_unpaired",
                    ),
                )
                decisions[result["decision"]] += 1
        rows.append(
            {
                "margin": margin,
                "necessary_seeds_for_possible_superiority": threshold_row,
                "observed_v3_decision_counts_at_target_width_0.10": dict(sorted(decisions.items())),
            }
        )

    payload = {
        "status": "post_hoc_margin_sensitivity_diagnostic",
        "source": "sb3_formal_v3/raw_seed_metrics.csv",
        "family_alpha": FAMILY_ALPHA,
        "comparison_alpha": comparison_alpha,
        "looks": [5, 10, 15, 20],
        "margins": list(MARGINS),
        "rows": rows,
        "interpretation": {
            "necessary_threshold": "A threshold only says when an extreme bounded dataset could possibly cross the margin; it is not power or a sufficient sample size.",
            "observed_counts": "Decision counts reuse the frozen v3 test rows and are descriptive post-hoc sensitivity evidence.",
            "not_supported": ["universal margin", "prospective power", "algorithm ranking", "external reproducibility"],
        },
    }
    (ROOT / "margin_sensitivity_v3.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# v3 Practical-Margin Sensitivity Diagnostic",
        "",
        "This post-hoc diagnostic reuses the frozen selected-configuration v3 test rows. It changes only the practical superiority margin; the family alpha, four looks, unpaired Hoeffding interval, target width 0.10, and 20-seed cap remain fixed.",
        "",
        "The necessary-threshold columns are analytic: they identify the smallest per-algorithm sample size at which any metric in [0,1] could possibly cross the margin at a given look. They are not power calculations, sufficient sample sizes, or universal RL requirements.",
        "",
        "| Margin | Necessary n at look 1 | Necessary n at look 2 | Necessary n at look 3 | Necessary n at look 4 | Observed v3 decisions at n <= 20 |",
        "|---:|---:|---:|---:|---:|---|",
    ]
    for row in rows:
        counts = ", ".join(f"{key}={value}" for key, value in row["observed_v3_decision_counts_at_target_width_0.10"].items())
        thresholds = row["necessary_seeds_for_possible_superiority"]
        lines.append(
            f"| {row['margin']:.3f} | {thresholds['1']} | {thresholds['2']} | {thresholds['3']} | {thresholds['4']} | {counts} |"
        )
    lines.extend(
        [
            "",
            "For margins from 0.00 through 0.50, the observed v3 rows produce no superiority or 0.10-width decision within 20 seeds. This does not prove that all future data will behave similarly; the formal non-resolution theorem applies to the predeclared v3 margin and budget, while this table is a descriptive reuse of one stored sample.",
            "",
            "Generated by `margin_sensitivity_v3.py`; machine-readable output: `margin_sensitivity_v3.json`.",
        ]
    )
    (ROOT / "MARGIN_SENSITIVITY_V3.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("MARGIN_SENSITIVITY_V3.md")
    print("margin_sensitivity_v3.json")


if __name__ == "__main__":
    main()


# Tuning Stability Extension V1 Report

This is a supplementary, prospective-within-workspace diagnostic. It does
not amend or pool with the v3 confirmatory family.

## Frozen execution

- Rows: 1215 (1,200 validation candidate rows and 15 one-seed diagnostic rows).
- Validation seeds: 11000--11019; diagnostic test seed: 32000.
- Candidate grid: four configurations, shared by all 15 cells.
- Training: 4,096 steps, four checkpoints, five evaluation episodes.
- Runner SHA-256: `6c252c51334fe18655130c1746a2cbf9be17daf6a622a4f8f13acbb17124eacd`.
- Output SHA-256 (`summary.json`): `87a90e42a251516aaa9fa8bb334a8adf6064d7e1efef91066a5f245dc263400a`.
- Output SHA-256 (`raw_rows.json`): `aa225794004827531d59ef38f9718711583dbe6fb81cc1acacfb998f0ab8329d`.

## Selection comparison

The 20-seed selection differs from the v3 five-seed selection in 7/15 cells (0.4667).

| Cell | v3 selection | 20-seed selection |
|---|---|---|
| CartPole-v1:PPO | `lr3e4_short` | `lr3e4_long` |
| CartPole-v1:DQN | `lr3e4_long` | `lr3e4_short` |
| Acrobot-v1:PPO | `lr1e4_long` | `lr3e4_long` |
| Acrobot-v1:A2C | `lr1e4_long` | `lr1e4_short` |
| NonstationaryQueue-v0:PPO | `lr1e4_short` | `lr3e4_short` |
| NonstationaryQueue-v0:DQN | `lr3e4_short` | `lr3e4_long` |
| NonstationaryQueue-v0:A2C | `lr1e4_short` | `lr3e4_short` |

The remaining 8 cells retained the v3 selection.

## Interpretation boundary

The observed 7/15 change rate indicates selection sensitivity for this
fixed grid and task family. It is an observed-sample diagnostic, not a
population probability, a claim that either grid is optimal, or a
universal recommendation to use twenty validation seeds. The one-seed
diagnostic test rows are bookkeeping only and are not evidence for an
algorithm ranking or a new confirmatory comparison.

## Audit result

- PASS: all expected environments, algorithms, candidates, and seed ranges are present.
- PASS: 1,215 unique rows are bounded and candidate means recompute exactly.
- PASS: validation and diagnostic test seeds are disjoint from recorded prior ranges.
- PASS: no audit failures.

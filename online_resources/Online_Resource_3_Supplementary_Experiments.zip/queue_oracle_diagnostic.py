#!/usr/bin/env python3
"""Exact dynamic-programming sanity checks for the controlled queue task."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def transition(capacity: int, queue: int, action: int, arrival: int) -> int:
    served = int(action == 1 and queue > 0)
    return min(capacity, max(0, queue - served + arrival))


def solve_optimal(capacity: int, horizon: int, switch_step: int,
                  arrival_probabilities: tuple[float, float], service_cost: float):
    values = [[0.0] * (capacity + 1) for _ in range(horizon + 1)]
    policy = [[0] * (capacity + 1) for _ in range(horizon)]
    for step in range(horizon - 1, -1, -1):
        probability = arrival_probabilities[int(step >= switch_step)]
        for queue in range(capacity + 1):
            action_values = []
            for action in (0, 1):
                expected = 0.0
                for arrival, arrival_probability in ((0, 1.0 - probability), (1, probability)):
                    next_queue = transition(capacity, queue, action, arrival)
                    reward = -(next_queue + service_cost * action)
                    expected += arrival_probability * (reward + values[step + 1][next_queue])
                action_values.append(expected)
            policy[step][queue] = int(action_values[1] > action_values[0])
            values[step][queue] = max(action_values)
    return values, policy


def evaluate_policy(capacity: int, horizon: int, switch_step: int,
                    arrival_probabilities: tuple[float, float], service_cost: float,
                    action_rule) -> float:
    values = [[0.0] * (capacity + 1) for _ in range(horizon + 1)]
    for step in range(horizon - 1, -1, -1):
        probability = arrival_probabilities[int(step >= switch_step)]
        for queue in range(capacity + 1):
            action = int(action_rule(step, queue))
            expected = 0.0
            for arrival, arrival_probability in ((0, 1.0 - probability), (1, probability)):
                next_queue = transition(capacity, queue, action, arrival)
                reward = -(next_queue + service_cost * action)
                expected += arrival_probability * (reward + values[step + 1][next_queue])
            values[step][queue] = expected
    return values[0][0]


def run(capacity: int, horizon: int, switch_step: int,
        arrival_probabilities: tuple[float, float], service_cost: float) -> dict:
    values, policy = solve_optimal(capacity, horizon, switch_step, arrival_probabilities, service_cost)
    policies = {
        "always_idle": lambda _step, _queue: 0,
        "always_serve": lambda _step, _queue: 1,
        "serve_if_nonempty": lambda _step, queue: int(queue > 0),
    }
    policy_values = {
        name: evaluate_policy(capacity, horizon, switch_step, arrival_probabilities, service_cost, rule)
        for name, rule in policies.items()
    }
    mismatches = sum(
        policy[step][queue] != int(queue > 0)
        for step in range(horizon)
        for queue in range(capacity + 1)
    )
    return {
        "switch_step": switch_step,
        "optimal_value_from_empty": values[0][0],
        "policy_values_from_empty": policy_values,
        "serve_if_nonempty_gap": values[0][0] - policy_values["serve_if_nonempty"],
        "optimal_policy_vs_serve_if_nonempty_mismatches": mismatches,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="queue_oracle_diagnostic.json")
    parser.add_argument("--capacity", type=int, default=10)
    parser.add_argument("--horizon", type=int, default=200)
    parser.add_argument("--service-cost", type=float, default=0.25)
    args = parser.parse_args()
    if args.capacity < 1 or args.horizon < 2:
        parser.error("capacity must be positive and horizon must be at least 2")
    switch_steps = (1, 25, 50, 100, 150, args.horizon - 1)
    rows = [run(args.capacity, args.horizon, step, (0.25, 0.85), args.service_cost)
            for step in switch_steps]
    payload = {
        "status": "exact_controlled_environment_sanity_diagnostic",
        "warning": "This verifies the disclosed queue dynamics; it is not evidence of general RL algorithm performance.",
        "parameters": {
            "capacity": args.capacity,
            "horizon": args.horizon,
            "arrival_probabilities": [0.25, 0.85],
            "service_cost": args.service_cost,
            "switch_steps": list(switch_steps),
        },
        "results": rows,
        "interpretation": "The exact dynamic program is the oracle for this finite controlled task. Any learned-policy gap is task-specific diagnostic evidence, not a benchmark ranking.",
    }
    Path(args.output).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

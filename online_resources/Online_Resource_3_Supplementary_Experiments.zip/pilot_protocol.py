#!/usr/bin/env python3
"""Pilot simulation for a sequential, compute-aware RL evaluation protocol.

This prototype deliberately uses only the Python standard library. It is a
method-selection tool, not the final statistical implementation for a paper.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from statistics import NormalDist
from typing import Iterable


NORMAL = NormalDist()


@dataclass(frozen=True)
class ProtocolConfig:
    alpha: float = 0.05
    practical_margin: float = 0.05
    initial_seeds: int = 5
    batch_size: int = 5
    max_seeds: int = 20
    target_width: float = 0.10
    interval_method: str = "normal"
    bootstrap_resamples: int = 500


def alpha_spend(alpha: float, look: int) -> float:
    """Summable two-sided alpha spending schedule."""
    if look < 1:
        raise ValueError("look must be positive")
    return alpha * 6.0 / (math.pi * math.pi * look * look)


def mean(values: Iterable[float]) -> float:
    values = list(values)
    if not values:
        raise ValueError("at least one value is required")
    return sum(values) / len(values)


def mean_difference_interval(
    values_a: list[float], values_b: list[float], alpha: float
) -> tuple[float, float, float]:
    """Normal-approximation interval used only for the pilot.

    The production protocol must replace this with a pre-registered confidence
    sequence or another method whose assumptions and coverage are proven.
    """
    if len(values_a) != len(values_b) or len(values_a) < 2:
        raise ValueError("paired samples of length >= 2 are required")
    differences = [a - b for a, b in zip(values_a, values_b)]
    estimate = mean(differences)
    variance = sum((x - estimate) ** 2 for x in differences) / (len(differences) - 1)
    standard_error = math.sqrt(variance / len(differences))
    critical = NORMAL.inv_cdf(1.0 - alpha / 2.0)
    half_width = critical * standard_error
    return estimate, estimate - half_width, estimate + half_width


def empirical_bernstein_interval(
    values_a: list[float], values_b: list[float], alpha: float
) -> tuple[float, float, float]:
    """A conservative bounded-data interval for paired differences.

    The paired difference is mapped from [-1, 1] to [0, 1], then an
    empirical-Bernstein radius is applied. The result is a candidate for the
    production protocol; its exact finite-sample statement must be checked
    against the final estimand and sequential construction.
    """
    if len(values_a) != len(values_b) or len(values_a) < 2:
        raise ValueError("paired samples of length >= 2 are required")
    differences = [a - b for a, b in zip(values_a, values_b)]
    mapped = [(difference + 1.0) / 2.0 for difference in differences]
    mapped_mean = mean(mapped)
    variance = sum((x - mapped_mean) ** 2 for x in mapped) / (len(mapped) - 1)
    log_term = math.log(3.0 / alpha)
    radius = math.sqrt(2.0 * variance * log_term / len(mapped)) + 3.0 * log_term / len(mapped)
    estimate = 2.0 * mapped_mean - 1.0
    half_width = 2.0 * radius
    return estimate, max(-1.0, estimate - half_width), min(1.0, estimate + half_width)


def empirical_bernstein_unpaired_interval(
    values_a: list[float], values_b: list[float], alpha: float
) -> tuple[float, float, float]:
    """Conservative empirical-Bernstein interval for two bounded means.

    The one-sample radius uses the Maurer--Pontil-style bounded empirical
    variance form with a two-sided union allocation. This implementation is a
    candidate method: its sequential use still requires fixed looks and alpha
    spending, and the RL manuscript must retain the assumptions and citation
    audit before making a confirmatory claim.
    """
    if len(values_a) < 2 or len(values_b) < 2:
        raise ValueError("both samples must contain at least two values")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    if any(value < 0.0 or value > 1.0 for value in (*values_a, *values_b)):
        raise ValueError("inputs must lie in [0, 1]")

    def radius(values: list[float]) -> float:
        n = len(values)
        average = mean(values)
        variance = sum((value - average) ** 2 for value in values) / n
        # alpha/4 allocates two tails for each of the two means.
        log_term = math.log(8.0 / alpha)
        return math.sqrt(2.0 * variance * log_term / n) + 7.0 * log_term / (3.0 * (n - 1))

    estimate = mean(values_a) - mean(values_b)
    half_width = radius(values_a) + radius(values_b)
    return estimate, max(-1.0, estimate - half_width), min(1.0, estimate + half_width)


def hoeffding_interval(
    values_a: list[float], values_b: list[float], alpha: float
) -> tuple[float, float, float]:
    """Distribution-free bounded interval for paired differences.

    For independent paired differences in [-1, 1], Hoeffding's inequality
    gives a two-sided radius sqrt(2 log(2/alpha) / n). Sequential use still
    requires alpha spending across looks.
    """
    if len(values_a) != len(values_b) or not values_a:
        raise ValueError("paired samples are required")
    differences = [a - b for a, b in zip(values_a, values_b)]
    estimate = mean(differences)
    radius = math.sqrt(2.0 * math.log(2.0 / alpha) / len(differences))
    return estimate, max(-1.0, estimate - radius), min(1.0, estimate + radius)


def hoeffding_unpaired_interval(
    values_a: list[float], values_b: list[float], alpha: float
) -> tuple[float, float, float]:
    """Distribution-free interval for two independent bounded means.

    Each sample is assumed to lie in [0, 1].  Alpha is split equally between
    the two two-sided Hoeffding bounds, then the mean-difference interval is
    obtained by adding the two radii.  No seed-to-seed pairing is required.
    """
    if not values_a or not values_b:
        raise ValueError("both samples must be non-empty")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    if any(value < 0.0 or value > 1.0 for value in (*values_a, *values_b)):
        raise ValueError("unpaired Hoeffding inputs must lie in [0, 1]")
    estimate = mean(values_a) - mean(values_b)
    radius_a = math.sqrt(math.log(4.0 / alpha) / (2.0 * len(values_a)))
    radius_b = math.sqrt(math.log(4.0 / alpha) / (2.0 * len(values_b)))
    radius = radius_a + radius_b
    return estimate, max(-1.0, estimate - radius), min(1.0, estimate + radius)


def interval_for_config(
    values_a: list[float],
    values_b: list[float],
    alpha: float,
    method: str,
    bootstrap_resamples: int = 500,
    bootstrap_seed: int = 0,
) -> tuple[float, float, float]:
    if method == "normal":
        return mean_difference_interval(values_a, values_b, alpha)
    if method == "empirical_bernstein":
        return empirical_bernstein_interval(values_a, values_b, alpha)
    if method == "empirical_bernstein_unpaired":
        return empirical_bernstein_unpaired_interval(values_a, values_b, alpha)
    if method == "hoeffding":
        return hoeffding_interval(values_a, values_b, alpha)
    if method == "hoeffding_unpaired":
        return hoeffding_unpaired_interval(values_a, values_b, alpha)
    if method == "bootstrap":
        return bootstrap_interval(
            values_a,
            values_b,
            alpha,
            bootstrap_resamples,
            bootstrap_seed,
        )
    raise ValueError(f"unknown interval method: {method}")


def bootstrap_interval(
    values_a: list[float],
    values_b: list[float],
    alpha: float,
    resamples: int,
    seed: int,
) -> tuple[float, float, float]:
    """Paired percentile bootstrap interval for pilot comparison only."""
    if len(values_a) != len(values_b) or len(values_a) < 2:
        raise ValueError("paired samples of length >= 2 are required")
    if resamples < 100:
        raise ValueError("at least 100 bootstrap resamples are required")
    differences = [a - b for a, b in zip(values_a, values_b)]
    rng = random.Random(seed)
    n = len(differences)
    bootstrap_means = [
        sum(rng.choice(differences) for _ in range(n)) / n
        for _ in range(resamples)
    ]
    bootstrap_means.sort()
    estimate = mean(differences)

    def quantile(probability: float) -> float:
        index = probability * (len(bootstrap_means) - 1)
        lower_index = math.floor(index)
        upper_index = math.ceil(index)
        if lower_index == upper_index:
            return bootstrap_means[lower_index]
        weight = index - lower_index
        return bootstrap_means[lower_index] * (1.0 - weight) + bootstrap_means[upper_index] * weight

    return estimate, quantile(alpha / 2.0), quantile(1.0 - alpha / 2.0)


def sequential_decision(
    scores_a: list[float], scores_b: list[float], config: ProtocolConfig
) -> dict:
    """Apply the pre-specified sequential rule to two score sequences."""
    unpaired = config.interval_method in {
        "hoeffding_unpaired",
        "empirical_bernstein_unpaired",
    }
    if not unpaired and len(scores_a) != len(scores_b):
        raise ValueError("score lists must have the same length")
    available = min(len(scores_a), len(scores_b))
    if available < config.initial_seeds:
        raise ValueError("not enough scores for the initial look")

    for look, n in enumerate(
        range(config.initial_seeds, min(available, config.max_seeds) + 1, config.batch_size),
        start=1,
    ):
        n = min(n, available)
        look_alpha = alpha_spend(config.alpha, look)
        estimate, lower, upper = interval_for_config(
            scores_a[:n],
            scores_b[:n],
            look_alpha,
            config.interval_method,
            config.bootstrap_resamples,
            17_000_000 + look * 1000 + n,
        )
        if lower > config.practical_margin:
            return {
                "decision": "a_superior",
                "n": n,
                "estimate": estimate,
                "lower": lower,
                "upper": upper,
                "look": look,
            }
        if upper < -config.practical_margin:
            return {
                "decision": "b_superior",
                "n": n,
                "estimate": estimate,
                "lower": lower,
                "upper": upper,
                "look": look,
            }
        if upper - lower <= config.target_width:
            return {
                "decision": "inconclusive_precision",
                "n": n,
                "estimate": estimate,
                "lower": lower,
                "upper": upper,
                "look": look,
            }

    n = min(available, config.max_seeds)
    estimate, lower, upper = interval_for_config(
        scores_a[:n],
        scores_b[:n],
        alpha_spend(config.alpha, max(1, math.ceil(n / config.batch_size))),
        config.interval_method,
        config.bootstrap_resamples,
        19_000_000 + n,
    )
    return {
        "decision": "max_budget_inconclusive",
        "n": n,
        "estimate": estimate,
        "lower": lower,
        "upper": upper,
        "look": math.ceil(n / config.batch_size),
    }


def fixed_decision(
    scores_a: list[float], scores_b: list[float], config: ProtocolConfig
) -> dict:
    if config.interval_method in {
        "hoeffding_unpaired",
        "empirical_bernstein_unpaired",
    }:
        if not scores_a or not scores_b:
            raise ValueError("both samples must be non-empty")
    elif len(scores_a) != len(scores_b):
        raise ValueError("score lists must have the same length")
    n = min(len(scores_a), len(scores_b), config.max_seeds)
    estimate, lower, upper = interval_for_config(
        scores_a[:n],
        scores_b[:n],
        config.alpha,
        config.interval_method,
        config.bootstrap_resamples,
        23_000_000 + n,
    )
    if lower > config.practical_margin:
        decision = "a_superior"
    elif upper < -config.practical_margin:
        decision = "b_superior"
    else:
        decision = "inconclusive"
    return {"decision": decision, "n": n, "estimate": estimate, "lower": lower, "upper": upper}


def student_t(rng: random.Random, degrees_of_freedom: int) -> float:
    normal = rng.gauss(0.0, 1.0)
    chi_square = 2.0 * rng.gammavariate(degrees_of_freedom / 2.0, 1.0)
    return normal / math.sqrt(chi_square / degrees_of_freedom)


def draw_score(rng: random.Random, location: float, scale: float, scenario: str) -> float:
    if scenario == "normal":
        noise = rng.gauss(0.0, scale)
    elif scenario == "heavy_tail":
        noise = student_t(rng, 3) * scale / math.sqrt(3.0)
    elif scenario == "heteroscedastic":
        noise = rng.gauss(0.0, scale * (0.5 + 1.5 * rng.random()))
    elif scenario == "mixture":
        noise = rng.gauss(0.0, scale * (4.0 if rng.random() < 0.10 else 1.0))
    else:
        raise ValueError(f"unknown scenario: {scenario}")
    return max(0.0, min(1.0, location + noise))


def generate_scores(
    rng: random.Random,
    n: int,
    true_difference: float,
    scenario: str,
    scale: float = 0.12,
) -> tuple[list[float], list[float]]:
    baseline = 0.50
    scores_a = [draw_score(rng, baseline + true_difference, scale, scenario) for _ in range(n)]
    scores_b = [draw_score(rng, baseline, scale, scenario) for _ in range(n)]
    return scores_a, scores_b


def is_false_superiority(decision: str, true_difference: float, margin: float) -> bool:
    if true_difference > margin or true_difference < -margin:
        return False
    return decision in {"a_superior", "b_superior"}


def run_scenario(
    scenario: str,
    true_difference: float,
    replicates: int,
    config: ProtocolConfig,
    seed: int,
) -> dict:
    rng = random.Random(seed)
    sequential_results = []
    fixed_results = []
    for _ in range(replicates):
        scores_a, scores_b = generate_scores(
            rng, config.max_seeds, true_difference, scenario
        )
        sequential_results.append(sequential_decision(scores_a, scores_b, config))
        fixed_results.append(fixed_decision(scores_a, scores_b, config))

    sequential_false = sum(
        is_false_superiority(r["decision"], true_difference, config.practical_margin)
        for r in sequential_results
    )
    fixed_false = sum(
        is_false_superiority(r["decision"], true_difference, config.practical_margin)
        for r in fixed_results
    )
    sequential_n = mean(r["n"] for r in sequential_results)
    fixed_n = mean(r["n"] for r in fixed_results)
    return {
        "scenario": scenario,
        "true_difference": true_difference,
        "replicates": replicates,
        "sequential_false_superiority_rate": sequential_false / replicates,
        "fixed_false_superiority_rate": fixed_false / replicates,
        "sequential_mean_seeds": sequential_n,
        "fixed_mean_seeds": fixed_n,
        "sequential_median_seeds": sorted(r["n"] for r in sequential_results)[replicates // 2],
        "fixed_median_seeds": sorted(r["n"] for r in fixed_results)[replicates // 2],
        "sequential_decisions": {
            decision: sum(r["decision"] == decision for r in sequential_results)
            for decision in sorted({r["decision"] for r in sequential_results})
        },
        "fixed_decisions": {
            decision: sum(r["decision"] == decision for r in fixed_results)
            for decision in sorted({r["decision"] for r in fixed_results})
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replicates", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20261026)
    parser.add_argument("--output", default="pilot_results.json")
    parser.add_argument(
        "--interval-method",
        choices=("normal", "bootstrap", "empirical_bernstein", "hoeffding", "hoeffding_unpaired"),
        default="normal",
    )
    parser.add_argument("--initial-seeds", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=5)
    parser.add_argument("--max-seeds", type=int, default=20)
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    parser.add_argument("--bootstrap-resamples", type=int, default=500)
    args = parser.parse_args()
    config = ProtocolConfig(
        interval_method=args.interval_method,
        initial_seeds=args.initial_seeds,
        batch_size=args.batch_size,
        max_seeds=args.max_seeds,
        practical_margin=args.practical_margin,
        target_width=args.target_width,
        bootstrap_resamples=args.bootstrap_resamples,
    )
    scenarios = [
        ("normal", 0.0),
        ("heavy_tail", 0.0),
        ("heteroscedastic", 0.0),
        ("mixture", 0.0),
        ("normal", 0.15),
        ("heavy_tail", 0.15),
    ]
    results = [
        run_scenario(scenario, difference, args.replicates, config, args.seed + i)
        for i, (scenario, difference) in enumerate(scenarios)
    ]
    payload = {
        "status": "pilot_only",
        "warning": "Normal-approximation intervals are not the final protocol.",
        "config": config.__dict__,
        "results": results,
    }
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

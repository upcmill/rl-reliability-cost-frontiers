# Family-Size Planning Sensitivity

This table is an analytic planning diagnostic for the bounded finite-look interval.
It contains no RL observations and is not an empirical power curve or a universal seed rule.
The comparison family receives `family_alpha / comparisons`; equal samples are used for the radius calculations.

| Comparisons | Comparison alpha | First-look radius | Final-look radius | Necessary seeds/algorithm for possible superiority (final) | Seeds/algorithm for width <= 0.10 (final) |
|---:|---:|---:|---:|---:|---:|
| 1 | 0.05000000 | 1.397101 | 0.874775 | 17 | 6,122 |
| 3 | 0.01666667 | 1.546394 | 0.935464 | 20 | 7,001 |
| 9 | 0.00555556 | 1.682492 | 0.992448 | 22 | 7,880 |
| 15 | 0.00333333 | 1.742157 | 1.017859 | 23 | 8,289 |
| 30 | 0.00166667 | 1.819992 | 1.051357 | 25 | 8,843 |

The reference practical margin is `0.05` and the target width is `0.1`.
The displayed first and final looks are `1` and `4`; the full machine-readable table includes every listed look.
Increasing the number of comparisons tightens the per-comparison error allocation and increases the worst-case radius. These values guide preregistered budget planning; they do not describe the observed v3 decisions.

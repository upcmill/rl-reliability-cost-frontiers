import unittest

import gymnasium as gym

import partial_observable_env  # noqa: F401


class PartialObservableEnvironmentTests(unittest.TestCase):
    def test_masks_are_fixed_and_spaces_match(self):
        for environment_id, indices in (("MaskedCartPole-v1", (1, 3)), ("MaskedAcrobot-v1", (4, 5))):
            env = gym.make(environment_id)
            observation, _ = env.reset(seed=17)
            self.assertEqual(tuple(observation.shape), env.observation_space.shape)
            for index in indices:
                self.assertEqual(float(observation[index]), 0.0)
            self.assertEqual(float(env.observation_space.low[indices[0]]), 0.0)
            env.close()


if __name__ == "__main__":
    unittest.main()

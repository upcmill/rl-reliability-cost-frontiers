# Reproduction Manifest: v5 Resolution-Cost Extension

This manifest describes the post-v4 same-machine diagnostic. It is a
reproduction handoff, not evidence of an external rerun.

## Frozen design

- Tasks: `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`,
  `NonstationaryQueue-v0`.
- Algorithms: PPO, DQN, A2C.
- Configurations: copied from `sb3_formal_v3/summary.json` and checked by
  `audit_v5_extension.py`.
- Training seeds: `30400`--`31399`, 1,000 per task--algorithm cell.
- Training budget: 4,096 environment steps; checkpoints 1,024, 2,048, 3,072,
  and 4,096; five evaluation episodes per checkpoint.
- Interval: unpaired Hoeffding, comparison alpha `0.05/15`, look spending
  `6/(pi^2 k^2)`, practical margin `0.05`, target width `0.10`.
- Looks: 200, 400, 600, 800, and 1,000 seeds.

## Supported runtime

The executed run used the recorded arm64 research environment:

- Python 3.11.7, Apple Silicon arm64 macOS, CPU execution;
- Gymnasium 1.4.0;
- Stable-Baselines3 2.9.2;
- PyTorch 2.14.1;
- NumPy 2.2.6.

Exact package pins and wheel hashes remain in `requirements-rl-lock.txt` and
`REPRODUCTION_MANIFEST_V3.md`.

## Commands

```bash
./.rl-arm64-venv/bin/python v5_budget_extension.py \
  --output-dir sb3_v5_extension
./.rl-arm64-venv/bin/python audit_v5_extension.py
```

The runner intentionally writes the complete 15,000-row sequence. A reported
decision at 200 or 800 is a prefix resolution point, not an observed compute
saving. The authoritative audit is `V5_EXTENSION_AUDIT.json`; the raw file is
`sb3_v5_extension/raw_seed_metrics.csv`.

## Integrity

The v5 audit records SHA-256 values for the raw CSV, run configuration,
runner, and this preregistration. The observed decision counts are three
`a_superior`, one `b_superior`, and eleven `max_budget_inconclusive`. These
counts are descriptive evidence for the frozen task family and do not support
prospective power, universal seed requirements, general algorithm ranking, or
external reproducibility.

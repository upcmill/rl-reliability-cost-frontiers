# v6 Task-Family Extension Report

This report is generated from `sb3_v6_task_family/raw_seed_metrics.csv`.
The extension is a prospective same-machine scope diagnostic and is not
pooled with the v3 primary family.

## Frozen execution

- Tasks: `CliffWalking-v1, FrozenLake-v1`.
- FrozenLake options: `map_name=4x4`, `is_slippery=True`.
- Algorithms: `PPO, DQN, A2C`; test seeds per cell: 200.
- Validation seeds: 10 per candidate; training budget: 4096 steps; five evaluation episodes.
- Test looks: `[50, 100, 150, 200]`; comparison alpha: `0.00833333333333`.
- CliffWalking evaluation episodes are explicitly capped at 100 steps because its Gymnasium spec has no TimeLimit wrapper.

## Descriptive test metrics

| Environment | Algorithm | Selected configuration | Mean | SD | Median | Minimum | Maximum |
|---|---|---|---:|---:|---:|---:|---:|
| CliffWalking-v1 | PPO | `lr3e4_long` | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| CliffWalking-v1 | DQN | `lr3e4_long` | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| CliffWalking-v1 | A2C | `lr3e4_long` | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| FrozenLake-v1 | PPO | `lr3e4_long` | 0.042000 | 0.060865 | 0.000000 | 0.000000 | 0.250000 |
| FrozenLake-v1 | DQN | `lr3e4_short` | 0.201500 | 0.188615 | 0.150000 | 0.000000 | 0.800000 |
| FrozenLake-v1 | A2C | `lr3e4_long` | 0.042750 | 0.062284 | 0.000000 | 0.000000 | 0.300000 |

## Finite-look decisions

The following table reports the final 200-seed look. Every decision is
`max_budget_inconclusive`; the interval is a protocol result and does not
support an algorithm ranking.

| Environment | Comparison | Estimate | Lower | Upper | Decision |
|---|---|---:|---:|---:|---|
| CliffWalking-v1 | PPO_vs_DQN | 0.000000 | -0.307312 | 0.307312 | `max_budget_inconclusive` |
| CliffWalking-v1 | PPO_vs_A2C | 0.000000 | -0.307312 | 0.307312 | `max_budget_inconclusive` |
| CliffWalking-v1 | DQN_vs_A2C | 0.000000 | -0.307312 | 0.307312 | `max_budget_inconclusive` |
| FrozenLake-v1 | PPO_vs_DQN | -0.159500 | -0.466812 | 0.147812 | `max_budget_inconclusive` |
| FrozenLake-v1 | PPO_vs_A2C | -0.000750 | -0.308062 | 0.306562 | `max_budget_inconclusive` |
| FrozenLake-v1 | DQN_vs_A2C | 0.158750 | -0.148562 | 0.466062 | `max_budget_inconclusive` |

## Interpretation boundary

The extension demonstrates that the disclosed runner, validation/test
separation, bounded metric, and finite-look audit execute on two additional
discrete Gymnasium tasks. It does not establish universal PPO/DQN/A2C
rankings, a universal seed requirement, prospective power, external
reproducibility, or scientific replication. The six comparisons remain
unresolved at the registered 200-seed cap under the conservative family
allocation.

The raw data, run metadata, independent audit, and generator are archived
with this report.

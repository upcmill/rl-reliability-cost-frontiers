# v5 New-Seed Resolution-Cost Extension

This document freezes a post-v4 diagnostic before opening its new seed
sequence. It is intended to measure the observed resolution cost of the
already selected procedures. It does not amend the v3 primary analysis, and it
is not an independent replication because it uses the same codebase, machine,
task family, and v3-selected configurations.

## Scope

The extension retains the five v3 tasks and the three v3 algorithms. The
selected configuration for every task--algorithm cell is copied from
`sb3_formal_v3/summary.json`; no tuning, task selection, or metric selection is
performed after opening the new test seeds.

## New sequence and training

The extension uses previously unused training seeds `30400`--`31399` (1,000
seeds per task and algorithm). It trains for 4,096 environment steps and
evaluates checkpoints at 1,024, 2,048, 3,072, and 4,096 steps with five
episodes per checkpoint. The four-checkpoint normalized learning-curve metric
and v3 reward bounds are unchanged. All raw returns, normalized metrics,
runtime, and evaluation seed bases are retained.

## Sequential rule

The comparison family is the same 15 task--algorithm pairs as v3. Family alpha
is `0.05`, comparison alpha is `0.05/15`, and the unpaired Hoeffding interval
uses the v3 practical margin `0.05` and target width `0.10`. Looks occur after
200, 400, 600, 800, and 1,000 seeds per algorithm, with
`alpha_k = alpha_cmp * 6/(pi^2 k^2)`. The first terminal state for each pair is
reported as the observed resolution cost; all rows remain archived even after
a pair first resolves so that the sequence is auditable.

Because all three algorithms are evaluated in shared batches, this extension
does not claim pair-specific compute savings. The runner collects the complete
1,000-seed sequence for every cell so that every prefix can be audited under
the same execution record. The cost statement is therefore the number of new
seeds in the first prefix that reaches a terminal state, not an observed
wall-clock saving from stopping training at that prefix.

## Interpretation lock

The extension may support only the following bounded statements:

- which of the 15 frozen comparisons first reached superiority or precision at
  each disclosed look;
- the observed interval and estimate at that look;
- the number of new seeds used by that comparison.

It cannot support a universal seed requirement, a general algorithm ranking,
prospective power, a population distribution of task difficulty, or external
reproducibility. The extension is post-v4 and therefore remains diagnostic,
even though its seed range and analysis rule are frozen before execution.

## Deviations

Any change to task IDs, algorithm IDs, selected configurations, seed range,
training budget, evaluation aggregation, normalization bounds, alpha,
look schedule, practical margin, or target width must be recorded as a
deviation before the affected data are analyzed. Failed runs and partial rows
must be retained; missing runs must not be imputed.

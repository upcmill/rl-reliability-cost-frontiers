# Fixed-Configuration Queue Budget Follow-up

This report audits `sb3_queue_budget_followup_v1/`. It is a post-v3
resolution-cost diagnostic and does not replace or amend the frozen v3 primary
analysis.

## Design

- Task: `NonstationaryQueue-v0`.
- Algorithms: DQN and A2C only.
- Configurations: v3-selected `lr3e4_short` (DQN) and `lr1e4_short` (A2C),
  frozen before the appended runs.
- Metric: the v3 four-checkpoint normalized learning-curve metric in `[0,1]`.
- Test sequence: v3 seeds 20000--20019 followed by new seeds 20020--20399.
- Looks: total test-seed counts 200 and 400; cap 1000.
- Comparison alpha: `0.05/15 = 0.0033333333333333335`, retaining the v3
  family context.
- Interval: unpaired Hoeffding with the v3 practical margin 0.05 and width
  target 0.10.

The first 20 metrics are copied and byte-checked against the v3 raw CSV. The
remaining 380 seeds were trained in this follow-up. No validation selection or
algorithm-specific retuning was performed.

## Result

| Look (total seeds per algorithm) | Estimate (DQN - A2C) | Lower | Upper | Decision |
|---:|---:|---:|---:|---|
| 200 | 0.318424 | 0.042965 | 0.593883 | `max_budget_inconclusive` |
| 400 | 0.338355 | 0.126528 | 0.550181 | `a_superior` |

The comparison stopped at 400 total test seeds because the lower endpoint
`0.126528` exceeded the practical margin 0.05. Descriptive
metrics over the 400-seed fixed-configuration sequence were:

| Algorithm | Mean | Sample SD | Median | Minimum | Maximum |
|---|---:|---:|---:|---:|---:|
| DQN | 0.920646 | 0.012969 | 0.922171 | 0.793335 | 0.927220 |
| A2C | 0.582292 | 0.323813 | 0.664552 | 0.106171 | 0.924628 |

## Interpretation boundary

This is evidence that the stated conservative interval can resolve one
controlled queue comparison when the fixed configuration and test budget are
extended to 400 seeds. It is not a universal seed requirement, a general
DQN-versus-A2C ranking, an estimate of power across RL tasks, or an external
reproduction. Because the extension was initiated after v3 results were
observed, it remains a post-v3 diagnostic and must not be presented as a new
confirmatory preregistration.

The machine-readable audit is `QUEUE_BUDGET_FOLLOWUP_AUDIT.json`; raw rows,
source hashes, and the exact runner metadata are in
`sb3_queue_budget_followup_v1/`.

# Continuous-Control Supplement Preregistration

This document freezes a supplementary external-validity diagnostic before its
sealed test analysis. It does not revise, replace, or pool with the v3 primary
15-comparison family.

## Question

Does the same validation/sealed-test and finite-look unpaired interval execute
on a continuous-action Gymnasium task under the same fixed training budget?

## Task and algorithms

- Task: `Pendulum-v1`, Gymnasium 1.4.0.
- Algorithms: PPO and A2C from Stable-Baselines3 2.9.2, both with `MlpPolicy`
  and CPU execution. DQN is excluded because its action space is discrete.
- This is a scope diagnostic, not a claim that two algorithms represent all
  continuous-control methods.

## Metric and bound

`Pendulum-v1` has horizon 200. From the installed environment dynamics, the
per-step cost is
`theta^2 + 0.1 * theta_dot^2 + 0.001 * torque^2`, with bounds
`theta^2 <= pi^2`, `theta_dot^2 <= 64`, and `torque^2 <= 4`. The frozen
two-decimal normalization bound is `[-3254.72, 0]` (the unrounded lower
endpoint is approximately `-3254.72088`); the primary normalized metric is
`clip((raw_return + 3254.72) / 3254.72, 0, 1)`, averaged over checkpoints.
The raw episode returns are retained.

## Tuning, seeds, and budget

The four v3 candidate configurations are reused unchanged:
`lr3e4_long`, `lr1e4_long`, `lr3e4_short`, and `lr1e4_short`. Each candidate
uses five validation training seeds `10000`--`10004`. The highest validation
mean is selected with deterministic first-insertion tie breaking. Sealed test
training seeds are `20000`--`20019`, disjoint from validation.

Each run trains for 4096 environment steps and evaluates at 1024, 2048, 3072,
and 4096 steps using five evaluation episodes per checkpoint. Test looks are 5,
10, 15, and 20 seeds. The primary comparison is PPO minus A2C, with family and
comparison alpha 0.05, practical margin 0.05, target width 0.10, and the same
unpaired Hoeffding interval and alpha spending as v3.

## Reporting

The supplement must report all candidate validation metrics, selected
configurations, all sealed metrics, interval stop traces, runtime, software
metadata, source hashes, and an independent same-machine replay. It must not be
used to claim broad continuous-control generalization without a larger task
family and external reproduction.

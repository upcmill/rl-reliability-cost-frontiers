#!/usr/bin/env python3
"""Post-hoc calibration diagnostic for the candidate unpaired Bernstein interval.

This script is deliberately separate from the preregistered RL analysis.  It
checks simultaneous coverage at the same finite looks used by the protocol and
reports Monte Carlo uncertainty.  Simulation results cannot replace a theorem
or a citation audit for the interval.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from collections import Counter
from dataclasses import dataclass
from statistics import fmean
from typing import Callable

from pilot_protocol import (
    ProtocolConfig,
    alpha_spend,
    empirical_bernstein_unpaired_interval,
    hoeffding_unpaired_interval,
    sequential_decision,
)


Draw = Callable[[random.Random], float]


@dataclass(frozen=True)
class Scenario:
    name: str
    true_difference: float
    draw_a: Draw
    draw_b: Draw


def two_point(low: float, high: float, probability_high: float) -> Draw:
    return lambda rng: high if rng.random() < probability_high else low


def beta(a: float, b: float) -> Draw:
    return lambda rng: rng.betavariate(a, b)


SCENARIOS = (
    Scenario(
        "bounded_symmetric",
        0.0,
        two_point(0.25, 0.75, 0.5),
        two_point(0.25, 0.75, 0.5),
    ),
    Scenario(
        "skewed_bounded",
        0.2,
        beta(8.0, 2.0),
        beta(6.0, 4.0),
    ),
    Scenario(
        "rare_extreme_mixture",
        0.0,
        two_point(0.0, 1.0, 0.5),
        two_point(0.2, 0.8, 0.5),
    ),
    Scenario(
        "bounded_heavy_tail",
        0.0,
        beta(0.5, 0.5),
        beta(0.5, 0.5),
    ),
    Scenario(
        "heteroscedastic",
        0.0,
        two_point(0.0, 1.0, 0.5),
        two_point(0.35, 0.65, 0.5),
    ),
)


def wilson(successes: int, trials: int) -> dict[str, float]:
    z = 1.959963984540054
    p = successes / trials
    denominator = 1.0 + z * z / trials
    center = (p + z * z / (2.0 * trials)) / denominator
    radius = z * math.sqrt(p * (1.0 - p) / trials + z * z / (4.0 * trials * trials)) / denominator
    return {"estimate": p, "lower": max(0.0, center - radius), "upper": min(1.0, center + radius)}


def coverage_cell(
    scenario: Scenario,
    method: str,
    replicates: int,
    seed: int,
    config: ProtocolConfig,
) -> dict:
    rng = random.Random(seed)
    looks = list(range(config.initial_seeds, config.max_seeds + 1, config.batch_size))
    covered_by_look = Counter()
    simultaneous = 0
    for _ in range(replicates):
        values_a = [scenario.draw_a(rng) for _ in range(config.max_seeds)]
        values_b = [scenario.draw_b(rng) for _ in range(config.max_seeds)]
        all_covered = True
        for look_index, n in enumerate(looks, start=1):
            alpha = alpha_spend(config.alpha, look_index)
            if method == "empirical_bernstein_unpaired":
                _, lower, upper = empirical_bernstein_unpaired_interval(values_a[:n], values_b[:n], alpha)
            else:
                _, lower, upper = hoeffding_unpaired_interval(values_a[:n], values_b[:n], alpha)
            covered = lower <= scenario.true_difference <= upper
            all_covered = all_covered and covered
            covered_by_look[n] += int(covered)
        simultaneous += int(all_covered)
    return {
        "scenario": scenario.name,
        "method": method,
        "replicates": replicates,
        "true_difference": scenario.true_difference,
        "simultaneous_coverage": wilson(simultaneous, replicates),
        "coverage_by_look": {
            str(n): wilson(covered_by_look[n], replicates) for n in looks
        },
    }


def decision_cell(
    method: str,
    true_difference: float,
    replicates: int,
    seed: int,
    config: ProtocolConfig,
) -> dict:
    rng = random.Random(seed)
    local_config = ProtocolConfig(**{**config.__dict__, "interval_method": method})
    counts = Counter()
    seed_counts = []
    for _ in range(replicates):
        # Bernoulli outcomes give an exactly known mean difference and remain
        # within the protocol's [0, 1] metric bound.
        values_a = [float(rng.random() < 0.5 + true_difference) for _ in range(config.max_seeds)]
        values_b = [float(rng.random() < 0.5) for _ in range(config.max_seeds)]
        result = sequential_decision(values_a, values_b, local_config)
        counts[result["decision"]] += 1
        seed_counts.append(result["n"])
    false_superiority = counts["a_superior"] + counts["b_superior"] if abs(true_difference) <= config.practical_margin else 0
    power = counts["a_superior"] if true_difference > config.practical_margin else 0
    return {
        "method": method,
        "true_difference": true_difference,
        "replicates": replicates,
        "decision_counts": dict(sorted(counts.items())),
        "false_superiority_rate": wilson(false_superiority, replicates),
        "a_superiority_power": wilson(power, replicates),
        "mean_seeds": fmean(seed_counts),
        "max_budget_fraction": wilson(sum(n == config.max_seeds for n in seed_counts), replicates),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replicates", type=int, default=5000)
    parser.add_argument("--output", default="unpaired_empirical_bernstein_diagnostic.json")
    args = parser.parse_args()
    if args.replicates < 100:
        parser.error("use at least 100 replicates for a useful Monte Carlo interval")
    config = ProtocolConfig(
        alpha=0.05,
        practical_margin=0.05,
        initial_seeds=5,
        batch_size=5,
        max_seeds=20,
        target_width=0.10,
        interval_method="empirical_bernstein_unpaired",
    )
    methods = ("empirical_bernstein_unpaired", "hoeffding_unpaired")
    coverage = [
        coverage_cell(scenario, method, args.replicates, 730_000 + i * 10 + j, config)
        for i, scenario in enumerate(SCENARIOS)
        for j, method in enumerate(methods)
    ]
    decisions = [
        decision_cell(method, true_difference, args.replicates, 740_000 + i * 10 + j, config)
        for i, true_difference in enumerate((0.0, 0.10))
        for j, method in enumerate(methods)
    ]
    payload = {
        "status": "post_hoc_candidate_interval_diagnostic",
        "warning": "Simulation is not a proof of coverage, sequential validity, or publication readiness.",
        "config": config.__dict__,
        "methods": list(methods),
        "coverage": coverage,
        "decision_tradeoff": decisions,
        "predeclared_interpretation": {
            "coverage_gate": "The candidate is not eligible for a confirmatory claim unless every simultaneous-coverage lower 95% bound is at least 0.95 in this diagnostic and the formula passes an independent theorem/citation audit.",
            "error_gate": "The null false-superiority upper 95% bound is reported; a simulation result alone cannot establish finite-sample error control.",
            "status": "exploratory_until_theory_and_independent_audit_are_complete",
        },
    }
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

# v3 Validation-Selection Uncertainty Diagnostic

This post-hoc diagnostic resamples the five validation-seed rows jointly across all four candidates. It describes instability in the observed validation sample; frequencies are not population probabilities and do not alter v3 selection or test inference.

Each cell uses 20,000 deterministic bootstrap replicates. The resampling unit is a validation seed row, preserving the fact that all candidates were evaluated on the same five seed labels.

| Environment | Algorithm | v3 selected | Selected frequency | Frequency of runner-up | Entropy (nats) | Observed top-two gap |
|---|---|---|---:|---:|---:|---:|
| CartPole-v1 | PPO | lr3e4_short | 0.4758 | 0.4559 | 0.8949 | 0.000080 |
| CartPole-v1 | DQN | lr3e4_long | 0.5579 | 0.4421 | 0.6864 | 0.000160 |
| CartPole-v1 | A2C | lr3e4_short | 0.5366 | 0.2780 | 1.1149 | 0.003180 |
| Acrobot-v1 | PPO | lr1e4_long | 0.3963 | 0.3610 | 1.0783 | 0.014240 |
| Acrobot-v1 | DQN | lr1e4_short | 0.6526 | 0.2571 | 0.8449 | 0.036600 |
| Acrobot-v1 | A2C | lr1e4_long | 0.6856 | 0.1973 | 0.8638 | 0.050700 |
| MountainCar-v0 | PPO | lr3e4_long | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| MountainCar-v0 | DQN | lr3e4_long | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| MountainCar-v0 | A2C | lr3e4_long | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | PPO | lr3e4_long | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | DQN | lr3e4_long | 1.0000 | 0.0000 | 0.0000 | 0.000000 |
| Taxi-v4 | A2C | lr3e4_long | 0.7968 | 0.2031 | 0.5047 | 0.052931 |
| NonstationaryQueue-v0 | PPO | lr1e4_short | 0.4919 | 0.3156 | 1.0301 | 0.023963 |
| NonstationaryQueue-v0 | DQN | lr3e4_short | 0.7022 | 0.2979 | 0.6090 | 0.000398 |
| NonstationaryQueue-v0 | A2C | lr1e4_short | 0.4217 | 0.3302 | 1.0785 | 0.047257 |

The diagnostic reinforces that the selected configuration is part of the conditional estimand. It does not estimate the probability that a configuration is globally optimal, and it is not pooled with the sealed-test results.

Machine-readable output: `validation_selection_uncertainty_v3.json`; generator: `validation_selection_uncertainty.py`.

# Prospective v4 Seed-Budget Extension Report

This report audits the new-seed extension defined in
`FINAL_PREREGISTRATION_V4_EXTENSION.md`. It is separate from the v3 primary
analysis and is not a different-machine replication.

## Data integrity

The extension contains 6,000 rows: five tasks, three algorithms, and 400 test
seeds per cell. Training seeds are exactly 30000--30399 and do not overlap the
v3 or queue-follow-up ranges. Every cell uses the configuration selected by the
v3 validation stage; no extension tuning or test-data selection was performed.
All normalized metrics are in `[0,1]` and the full raw CSV is retained.

## Decisions

| Comparison | n at terminal/cap | Estimate | Family-adjusted interval | Decision |
|---|---:|---:|---|---|
| CartPole-v1 / PPO − DQN | 400 | 0.172163 | [-0.039663, 0.383989] | `max_budget_inconclusive` |
| CartPole-v1 / PPO − A2C | 400 | 0.003033 | [-0.208793, 0.214860] | `max_budget_inconclusive` |
| CartPole-v1 / DQN − A2C | 400 | -0.169129 | [-0.380955, 0.042697] | `max_budget_inconclusive` |
| Acrobot-v1 / PPO − DQN | 400 | -0.030467 | [-0.242293, 0.181359] | `max_budget_inconclusive` |
| Acrobot-v1 / PPO − A2C | 400 | 0.014380 | [-0.197446, 0.226206] | `max_budget_inconclusive` |
| Acrobot-v1 / DQN − A2C | 400 | 0.044847 | [-0.166979, 0.256673] | `max_budget_inconclusive` |
| MountainCar-v0 / PPO − DQN | 400 | -0.000353 | [-0.212179, 0.211473] | `max_budget_inconclusive` |
| MountainCar-v0 / PPO − A2C | 400 | 0.000000 | [-0.211826, 0.211826] | `max_budget_inconclusive` |
| MountainCar-v0 / DQN − A2C | 400 | 0.000353 | [-0.211473, 0.212179] | `max_budget_inconclusive` |
| Taxi-v4 / PPO − DQN | 400 | 0.000000 | [-0.211826, 0.211826] | `max_budget_inconclusive` |
| Taxi-v4 / PPO − A2C | 400 | 0.219632 | [0.007806, 0.431458] | `max_budget_inconclusive` |
| Taxi-v4 / DQN − A2C | 400 | 0.219632 | [0.007806, 0.431458] | `max_budget_inconclusive` |
| NonstationaryQueue-v0 / PPO − DQN | 400 | -0.225083 | [-0.436910, -0.013257] | `max_budget_inconclusive` |
| NonstationaryQueue-v0 / PPO − A2C | 400 | 0.117246 | [-0.094580, 0.329072] | `max_budget_inconclusive` |
| NonstationaryQueue-v0 / DQN − A2C | 200 | 0.345322 | [0.069863, 0.620781] | `a_superior` |

Only `NonstationaryQueue-v0` DQN−A2C reached a terminal superiority decision,
at the first 200-seed look (estimate `0.345322`, interval
`[0.069863, 0.620781]`). The remaining 14 comparisons reached the 400-seed cap
without superiority or target-precision decisions. The positive queue result
is evidence for this new seed sequence, fixed configuration, task, and budget;
it is not a general DQN ranking or a universal seed requirement.

The machine-readable audit is `V4_EXTENSION_AUDIT.json`; raw rows, source
hashes, and runtime metadata are in `sb3_v4_extension/`.

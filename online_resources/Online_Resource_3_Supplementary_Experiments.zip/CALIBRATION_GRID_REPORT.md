# Supplementary Calibration Grid

This report is a Monte Carlo diagnostic for the unpaired bounded
finite-look interval. It is not a proof, a representative sample of
RL seed distributions, or evidence of external reproducibility.

- Replicates per cell: `3000`
- Families: `8`; true differences: `5`
- Looks: `[5, 10, 15, 20]`; practical margin: `0.05`
- The two alpha settings are a single-comparison diagnostic (`0.05`) and the v3 family allocation (`0.05/15`).

## Aggregate checks

| Alpha | Cells | Minimum simultaneous coverage | Maximum false-superiority rate | Mean seed cost | Cells reaching a terminal decision |
|---:|---:|---:|---:|---:|---:|
| 0.05000000 | 40 | 1.0000 | 0.0000 | 20.00 | 0 |
| 0.00333333 | 40 | 1.0000 | 0.0000 | 20.00 | 0 |

The minimum coverage and maximum error-rate summaries are descriptive
over this fixed grid. They do not support extrapolation to arbitrary
bounded distributions or to RL training outcomes.

## Cell-level results

| Family | True difference | Alpha | Simultaneous coverage | False superiority | Mean seeds | Decision counts |
|---|---:|---:|---:|---:|---:|---|
| bernoulli | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | -0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | -0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | 0.00 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | 0.10 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | 0.20 | 0.05000000 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| bernoulli | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_wide | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| two_point_narrow | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_low_concentration | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_moderate_concentration | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| beta_high_concentration | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| lower_spike | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | -0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | -0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | 0.00 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | 0.10 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |
| upper_spike | 0.20 | 0.00333333 | 1.0000 | 0.0000 | 20.00 | `{'max_budget_inconclusive': 3000}` |

Monte Carlo Wilson intervals for individual proportions are stored in
the JSON artifact's `aggregate_intervals` field. The v3 primary claims
remain unchanged; this grid only makes the calibration boundary more
explicit.

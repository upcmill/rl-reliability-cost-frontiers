# Tuning Stability V20 Provenance Note

The v20 extension reuses `tuning_strength_runner.py`, which is also the
runner used for the earlier v2 and v3 tuning diagnostics. Its JSON payload
therefore retains the legacy values `status = tuning_strength_diagnostic_only`
and a warning that mentions the v2 primary analysis. Those strings are runner
metadata labels; they do not describe the v20 seed range or change its scope.

For v20, the authoritative scope is frozen in
`FINAL_PREREGISTRATION_TUNING_EXTENSION_V1.md` and checked by
`audit_tuning_stability_v20.py`:

- validation seeds are 11000--11019;
- the four-candidate grid and 4,096-step budget are unchanged;
- 1,200 validation rows and 15 bookkeeping test rows are present;
- all rows are disjoint from the recorded v3 and earlier diagnostic ranges;
- seven of 15 selections change relative to the v3 five-seed selection.

The legacy status field is retained in the raw JSON to preserve generated
artifact provenance. The report and manuscript use the v20 preregistration
and audit as the scope authority, and continue to label the result as a
supplementary selection-sensitivity diagnostic.

#!/usr/bin/env python3
"""Small real-Gymnasium/SB3 go/no-go experiment for the RL evaluation protocol."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
from itertools import combinations
import json
import platform
import random
import time
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
from stable_baselines3 import A2C, DQN, PPO

from nonstationary_queue_env import ENV_ID as QUEUE_ENV_ID
from pilot_protocol import ProtocolConfig, sequential_decision


DEFAULT_ENV_IDS = ("CartPole-v1", "Acrobot-v1")
ADDITIONAL_ENV_IDS = ("MountainCar-v0", "Taxi-v4")
ALGORITHMS = ("PPO", "DQN", "A2C")


def make_model(algorithm: str, env, seed: int, config: dict):
    common = dict(seed=seed, env=env, verbose=0, device="cpu")
    if algorithm == "PPO":
        return PPO(
            "MlpPolicy",
            n_steps=config["n_steps"],
            batch_size=config["batch_size"],
            n_epochs=1,
            learning_rate=config["learning_rate"],
            **common,
        )
    if algorithm == "DQN":
        return DQN(
            "MlpPolicy",
            buffer_size=config["buffer_size"],
            learning_starts=config["learning_starts"],
            batch_size=config["batch_size"],
            learning_rate=config["learning_rate"],
            train_freq=4,
            gradient_steps=1,
            **common,
        )
    if algorithm == "A2C":
        return A2C(
            "MlpPolicy",
            n_steps=config["n_steps"],
            learning_rate=config["learning_rate"],
            **common,
        )
    raise ValueError(f"unknown algorithm: {algorithm}")


def evaluate(model, env_id: str, seed: int, episodes: int) -> tuple[float, list[float]]:
    env = gym.make(env_id)
    returns = []
    for episode in range(episodes):
        obs, _ = env.reset(seed=seed + episode)
        done = False
        total = 0.0
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            if isinstance(action, np.ndarray) and action.size == 1:
                action = action.item()
            obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            total += float(reward)
        returns.append(total)
    env.close()
    return float(np.mean(returns)), returns


def normalize_returns(env_id: str, values: list[float]) -> list[float]:
    if env_id == "CartPole-v1":
        lower, upper = 0.0, 500.0
    elif env_id == "Acrobot-v1":
        lower, upper = -500.0, 0.0
    elif env_id == QUEUE_ENV_ID:
        # The queue task has 200 steps, capacity 10, and service cost 0.25.
        lower, upper = -200.0 * 10.25, 0.0
    elif env_id == "MountainCar-v0":
        lower, upper = -200.0, 0.0
    elif env_id == "Taxi-v4":
        # Taxi-v4 has at most 200 steps, a -10 illegal-action penalty, and a
        # +20 successful-dropoff reward.
        lower, upper = -2000.0, 20.0
    else:
        raise ValueError(f"no normalization bounds registered for {env_id}")
    return [max(0.0, min(1.0, (value - lower) / (upper - lower))) for value in values]


def train_curve(env_id: str, algorithm: str, train_seed: int, config: dict, checkpoints: list[int], eval_episodes: int) -> dict:
    env = gym.make(env_id)
    model = make_model(algorithm, env, train_seed, config)
    values = []
    raw_values = []
    evaluation_seeds = []
    started = time.perf_counter()
    trained = 0
    for checkpoint in checkpoints:
        model.learn(total_timesteps=checkpoint - trained, reset_num_timesteps=False)
        trained = checkpoint
        evaluation_seed = train_seed + 1_000_000 + checkpoint
        value, returns = evaluate(model, env_id, evaluation_seed, eval_episodes)
        values.append(value)
        raw_values.append(returns)
        evaluation_seeds.append(evaluation_seed)
    runtime = time.perf_counter() - started
    model.env.close()
    normalized = normalize_returns(env_id, values)
    return {
        "metric_normalized": float(np.mean(normalized)),
        "metric_raw": float(np.mean(values)),
        "checkpoint_normalized": normalized,
        "checkpoint_raw": values,
        "evaluation_seeds": evaluation_seeds,
        "evaluation_seed_base": train_seed + 1_000_000,
        "episode_returns": raw_values,
        "runtime_seconds": runtime,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validation-seeds", type=int, default=5)
    parser.add_argument("--test-seeds", type=int, default=10)
    parser.add_argument("--initial-test-seeds", type=int, default=5)
    parser.add_argument("--test-batch-size", type=int, default=5)
    parser.add_argument("--timesteps", type=int, default=2048)
    parser.add_argument("--checkpoints", type=int, default=2)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument(
        "--family-alpha",
        type=float,
        default=None,
        help="Optional family-wise alpha; it is divided equally across selected environments.",
    )
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    parser.add_argument(
        "--interval-method",
        choices=("normal", "bootstrap", "empirical_bernstein", "hoeffding", "hoeffding_unpaired"),
        default="hoeffding_unpaired",
    )
    parser.add_argument("--bootstrap-resamples", type=int, default=1000)
    parser.add_argument("--output-dir", default="sb3_pilot_results")
    parser.add_argument(
        "--environment-ids",
        default=",".join(DEFAULT_ENV_IDS),
        help="Comma-separated Gymnasium IDs; the controlled task is NonstationaryQueue-v0.",
    )
    args = parser.parse_args()

    environment_ids = tuple(item.strip() for item in args.environment_ids.split(",") if item.strip())
    if not environment_ids:
        parser.error("--environment-ids must contain at least one environment ID")
    unsupported = sorted(set(environment_ids) - set((*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)))
    if unsupported:
        parser.error(f"unsupported environment IDs: {', '.join(unsupported)}")

    if args.validation_seeds < 2:
        parser.error("--validation-seeds must be at least 2")
    if args.test_seeds < 1:
        parser.error("--test-seeds must be positive")
    if not 1 <= args.initial_test_seeds <= args.test_seeds:
        parser.error("--initial-test-seeds must be between 1 and --test-seeds")
    if args.test_batch_size < 1:
        parser.error("--test-batch-size must be positive")
    if args.checkpoints < 1 or args.timesteps < args.checkpoints:
        parser.error("--timesteps must be at least --checkpoints")
    if not 0.0 < args.alpha < 1.0:
        parser.error("--alpha must be in (0, 1)")
    if args.family_alpha is not None and not 0.0 < args.family_alpha < 1.0:
        parser.error("--family-alpha must be in (0, 1)")
    if not 0.0 <= args.practical_margin <= 1.0:
        parser.error("--practical-margin must be in [0, 1]")
    if not 0.0 < args.target_width <= 2.0:
        parser.error("--target-width must be in (0, 2]")

    pair_count = len(ALGORITHMS) * (len(ALGORITHMS) - 1) // 2
    comparison_count = len(environment_ids) * pair_count
    comparison_alpha = (
        args.alpha
        if args.family_alpha is None
        else args.family_alpha / comparison_count
    )

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = [args.timesteps * i // args.checkpoints for i in range(1, args.checkpoints + 1)]
    configs = {
        "default": {"learning_rate": 3e-4, "batch_size": 64, "n_steps": 256, "buffer_size": 5000, "learning_starts": 100},
        "small_lr": {"learning_rate": 1e-4, "batch_size": 64, "n_steps": 256, "buffer_size": 5000, "learning_starts": 100},
    }
    records = []
    summary = {}
    for env_id in environment_ids:
        for algorithm in ALGORITHMS:
            validation = {}
            for config_id, config in configs.items():
                values = []
                for seed in range(args.validation_seeds):
                    train_seed = 10_000 + seed
                    result = train_curve(env_id, algorithm, train_seed, config, checkpoints, args.eval_episodes)
                    values.append(result["metric_normalized"])
                    records.append({"env_id": env_id, "algorithm": algorithm, "config_id": config_id, "split": "validation", "seed": seed, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})
                validation[config_id] = values
            selected = max(validation, key=lambda key: float(np.mean(validation[key])))
            test_metrics = []
            curves = []
            for seed in range(args.test_seeds):
                train_seed = 20_000 + seed
                result = train_curve(env_id, algorithm, train_seed, configs[selected], checkpoints, args.eval_episodes)
                test_metrics.append(result["metric_normalized"])
                curves.append({"seed": seed, **result})
                records.append({"env_id": env_id, "algorithm": algorithm, "config_id": selected, "split": "test", "seed": seed, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})
            summary[f"{env_id}:{algorithm}"] = {"selected_config": selected, "validation": validation, "test_metrics": test_metrics, "curves": curves}

    protocol = ProtocolConfig(
        alpha=comparison_alpha,
        practical_margin=args.practical_margin,
        initial_seeds=args.initial_test_seeds,
        batch_size=args.test_batch_size,
        max_seeds=args.test_seeds,
        target_width=args.target_width,
        interval_method=args.interval_method,
        bootstrap_resamples=args.bootstrap_resamples,
    )
    comparisons = []
    for env_id in environment_ids:
        for algorithm_a, algorithm_b in combinations(ALGORITHMS, 2):
            scores_a = summary[f"{env_id}:{algorithm_a}"]["test_metrics"]
            scores_b = summary[f"{env_id}:{algorithm_b}"]["test_metrics"]
            comparisons.append({"env_id": env_id, "comparison": f"{algorithm_a}_vs_{algorithm_b}", "decision": sequential_decision(scores_a, scores_b, protocol)})

    fields = ["env_id", "algorithm", "config_id", "split", "seed", "train_seed", "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status"]
    with (output_dir / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    try:
        sb3_version = importlib.metadata.version("stable-baselines3")
    except importlib.metadata.PackageNotFoundError:
        sb3_version = "unknown"
    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    run_config = vars(args).copy()
    run_config["checkpoints_resolved"] = checkpoints
    run_config["comparison_alpha"] = comparison_alpha
    run_config["execution_mode"] = "full_replay"
    payload = {
        "status": "sb3_pilot_only",
        "warning": "Small CPU pilot; no publication claim.",
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "gymnasium": gym.__version__,
        "stable_baselines3": sb3_version,
        "mps_available": bool(torch.backends.mps.is_available()),
        "script_sha256": script_hash,
        "run_config": run_config,
        "candidate_configs": configs,
        "environment_ids": list(environment_ids),
        "algorithm_ids": list(ALGORITHMS),
        "protocol": protocol.__dict__,
        "alpha_scope": {
            "family_alpha": args.family_alpha,
            "comparisons": comparison_count,
            "environment_count": len(environment_ids),
            "algorithm_pair_count": pair_count,
            "comparison_alpha": comparison_alpha,
        },
        "summary": summary,
        "comparisons": comparisons,
    }
    with (output_dir / "run_config.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

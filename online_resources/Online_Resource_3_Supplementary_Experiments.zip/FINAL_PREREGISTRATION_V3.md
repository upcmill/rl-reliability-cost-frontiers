# Formal Study Preregistration (Version 3)

Version 3 is a new primary candidate that addresses the v2 tuning-budget
limitation before opening v3 sealed test analysis. V1 and v2 artifacts remain
immutable and are not pooled with v3.

## Research question

Under a fixed training budget and an equal expanded tuning budget, how do
statistical interval assumptions affect the reliability and actual test-seed
cost of sequential comparisons across five discrete-action RL tasks?

## Primary estimand and statistical protocol

For each task, algorithm, selected configuration, and fixed training budget, the
estimand is the difference between the two marginal expected normalized
learning-curve-area metrics over training seeds. Four candidate configurations
are evaluated on five validation seeds for every algorithm and task. The
selected configuration is frozen before sealed test seeds are read.

The primary interval is the unpaired Hoeffding interval with alpha spending at
5, 10, 15, and 20 test seeds. The practical margin is `0.05`; precision width
is `0.10`. Each algorithm's test sequence is assumed independent across its own
seeds and bounded in `[0,1]`; cross-algorithm independence is not needed for
the union-bound argument.

## Task family and normalization

The frozen family is `CartPole-v1`, `Acrobot-v1`, `MountainCar-v0`, `Taxi-v4`,
and `NonstationaryQueue-v0`, with bounds `[0,500]`, `[-500,0]`, `[-200,0]`,
`[-2000,20]`, and `[-2050,0]`. Gymnasium is version 1.4.0. `Taxi-v4` is used
because `Taxi-v3` is deprecated in that version. The queue is controlled and
diagnostic rather than a claim of a standard benchmark.

## Algorithms and expanded tuning grid

Algorithms are PPO, DQN, and A2C from Stable-Baselines3 2.9.2 with
`MlpPolicy`, CPU execution, and the following equal candidate grid:

| ID | Learning rate | n_steps | DQN buffer | DQN learning starts |
|---|---:|---:|---:|---:|
| `lr3e4_long` | `3e-4` | 256 | 5000 | 100 |
| `lr1e4_long` | `1e-4` | 256 | 5000 | 100 |
| `lr3e4_short` | `3e-4` | 128 | 10000 | 200 |
| `lr1e4_short` | `1e-4` | 128 | 10000 | 200 |

All candidates receive five validation seeds, identical training checkpoints,
and identical evaluation episodes. The highest validation mean is selected;
ties use the deterministic first-insertion rule.

## Seeds and budget

- Validation training seeds: `10000`–`10004` per candidate;
- Sealed test training seeds: `20000`–`20019`;
- Test batches: 5, 10, 15, and 20 seeds;
- Training: 4096 steps at checkpoints 1024, 2048, 3072, and 4096;
- Evaluation: 5 episodes per checkpoint;
- Evaluation seeds: deterministic functions of training seed and checkpoint.

## Family and execution

The primary family contains 5 tasks × 3 unordered algorithm pairs = 15
comparisons. Family alpha is `0.05`; comparison alpha is
`0.05/15 = 0.0033333333333333335`. The actual sequential runner trains and
evaluates batches, locks terminal decisions, and continues unresolved pairs to
20 seeds. Full-data replay is not evidence of compute savings.

## Reporting and deviations

The v3 package must include every validation candidate metric, selected
configuration, sealed test metric, interval, decision, stop trace, failure,
runtime, software version, hardware field, and source hash. V3 is separate from
v2; no v3 result may be used to revise the protocol after seeing test data.


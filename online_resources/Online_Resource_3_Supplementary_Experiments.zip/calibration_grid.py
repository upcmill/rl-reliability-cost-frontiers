#!/usr/bin/env python3
"""Calibrate the unpaired bounded interval over a fixed distribution grid.

This is a supplementary Monte Carlo diagnostic. It does not replace the
finite-look coverage argument and does not estimate coverage for arbitrary RL
seed distributions.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from collections import Counter
from dataclasses import dataclass
from statistics import fmean, median

from pilot_protocol import ProtocolConfig, alpha_spend, hoeffding_unpaired_interval, sequential_decision


DIFFERENCES = (-0.20, -0.10, 0.00, 0.10, 0.20)
FAMILIES = (
    ("bernoulli", None),
    ("two_point_wide", None),
    ("two_point_narrow", None),
    ("beta_low_concentration", 0.5),
    ("beta_moderate_concentration", 2.0),
    ("beta_high_concentration", 50.0),
    ("lower_spike", None),
    ("upper_spike", None),
)


@dataclass(frozen=True)
class CellSummary:
    family: str
    true_difference: float
    alpha: float
    replicates: int
    simultaneous_coverage: float
    coverage_by_look: dict[str, float]
    false_superiority_rate: float
    mean_seeds: float
    median_seeds: float
    decision_counts: dict[str, int]


def draw_value(family: str, mean: float, parameter: float | None, rng: random.Random) -> float:
    if not 0.0 <= mean <= 1.0:
        raise ValueError(f"mean outside [0,1]: {mean}")
    if family == "bernoulli":
        return float(rng.random() < mean)
    if family == "two_point_wide":
        probability_high = (mean - 0.1) / 0.8
        if not 0.0 <= probability_high <= 1.0:
            raise ValueError("wide two-point support requires a mean in [0.1, 0.9]")
        return 0.9 if rng.random() < probability_high else 0.1
    if family == "two_point_narrow":
        probability_high = (mean - 0.4) / 0.2
        if not 0.0 <= probability_high <= 1.0:
            raise ValueError("narrow two-point support requires a mean in [0.4, 0.6]")
        return 0.6 if rng.random() < probability_high else 0.4
    if family.startswith("beta_"):
        concentration = float(parameter)
        if mean in {0.0, 1.0}:
            return mean
        return rng.betavariate(mean * concentration, (1.0 - mean) * concentration)
    if family == "lower_spike":
        high = 0.75
        return high if rng.random() < mean / high else 0.0
    if family == "upper_spike":
        low = 0.25
        return 1.0 if rng.random() < (mean - low) / (1.0 - low) else low
    raise ValueError(f"unknown distribution family: {family}")


def wilson(successes: int, trials: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if trials <= 0:
        raise ValueError("trials must be positive")
    p = successes / trials
    denominator = 1.0 + z * z / trials
    center = (p + z * z / (2.0 * trials)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / trials + z * z / (4.0 * trials * trials)) / denominator
    return max(0.0, center - half), min(1.0, center + half)


def run_cell(
    family: str,
    parameter: float | None,
    true_difference: float,
    config: ProtocolConfig,
    replicates: int,
    seed: int,
) -> CellSummary:
    rng = random.Random(seed)
    looks = list(range(config.initial_seeds, config.max_seeds + 1, config.batch_size))
    covered_all = 0
    covered_by_look = Counter()
    false_superiority = 0
    seed_costs: list[int] = []
    decisions: Counter[str] = Counter()
    mean_a = 0.5 + true_difference / 2.0
    mean_b = 0.5 - true_difference / 2.0

    for _ in range(replicates):
        values_a = [draw_value(family, mean_a, parameter, rng) for _ in range(config.max_seeds)]
        values_b = [draw_value(family, mean_b, parameter, rng) for _ in range(config.max_seeds)]
        simultaneous = True
        for look_index, n in enumerate(looks, start=1):
            _, lower, upper = hoeffding_unpaired_interval(
                values_a[:n], values_b[:n], alpha_spend(config.alpha, look_index)
            )
            this_covered = lower <= true_difference <= upper
            simultaneous = simultaneous and this_covered
            if this_covered:
                covered_by_look[str(n)] += 1
        if simultaneous:
            covered_all += 1

        decision = sequential_decision(values_a, values_b, config)
        decisions[decision["decision"]] += 1
        seed_costs.append(int(decision["n"]))
        if abs(true_difference) <= config.practical_margin and decision["decision"] in {"a_superior", "b_superior"}:
            false_superiority += 1

    return CellSummary(
        family=family,
        true_difference=true_difference,
        alpha=config.alpha,
        replicates=replicates,
        simultaneous_coverage=covered_all / replicates,
        coverage_by_look={str(n): covered_by_look[str(n)] / replicates for n in looks},
        false_superiority_rate=false_superiority / replicates,
        mean_seeds=fmean(seed_costs),
        median_seeds=median(seed_costs),
        decision_counts=dict(sorted(decisions.items())),
    )


def build_report(payload: dict) -> str:
    lines = [
        "# Supplementary Calibration Grid",
        "",
        "This report is a Monte Carlo diagnostic for the unpaired bounded",
        "finite-look interval. It is not a proof, a representative sample of",
        "RL seed distributions, or evidence of external reproducibility.",
        "",
        f"- Replicates per cell: `{payload['config']['replicates']}`",
        f"- Families: `{len(payload['config']['families'])}`; true differences: `{len(payload['config']['differences'])}`",
        f"- Looks: `{payload['config']['looks']}`; practical margin: `{payload['config']['practical_margin']}`",
        "- The two alpha settings are a single-comparison diagnostic (`0.05`) and the v3 family allocation (`0.05/15`).",
        "",
        "## Aggregate checks",
        "",
        "| Alpha | Cells | Minimum simultaneous coverage | Maximum false-superiority rate | Mean seed cost | Cells reaching a terminal decision |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for alpha in payload["config"]["alphas"]:
        rows = [row for row in payload["results"] if row["alpha"] == alpha]
        min_coverage = min(row["simultaneous_coverage"] for row in rows)
        max_false = max(row["false_superiority_rate"] for row in rows)
        mean_cost = fmean(row["mean_seeds"] for row in rows)
        terminal_cells = sum(
            any(key in row["decision_counts"] for key in ("a_superior", "b_superior", "inconclusive_precision"))
            for row in rows
        )
        lines.append(f"| {alpha:.8f} | {len(rows)} | {min_coverage:.4f} | {max_false:.4f} | {mean_cost:.2f} | {terminal_cells} |")
    lines.extend([
        "",
        "The minimum coverage and maximum error-rate summaries are descriptive",
        "over this fixed grid. They do not support extrapolation to arbitrary",
        "bounded distributions or to RL training outcomes.",
        "",
        "## Cell-level results",
        "",
        "| Family | True difference | Alpha | Simultaneous coverage | False superiority | Mean seeds | Decision counts |",
        "|---|---:|---:|---:|---:|---:|---|",
    ])
    for row in payload["results"]:
        lines.append(
            f"| {row['family']} | {row['true_difference']:.2f} | {row['alpha']:.8f} | "
            f"{row['simultaneous_coverage']:.4f} | {row['false_superiority_rate']:.4f} | "
            f"{row['mean_seeds']:.2f} | `{row['decision_counts']}` |"
        )
    lines.extend([
        "",
        "Monte Carlo Wilson intervals for individual proportions are stored in",
        "the JSON artifact's `aggregate_intervals` field. The v3 primary claims",
        "remain unchanged; this grid only makes the calibration boundary more",
        "explicit.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replicates", type=int, default=3000)
    parser.add_argument("--output", default="calibration_grid.json")
    parser.add_argument("--report", default="CALIBRATION_GRID_REPORT.md")
    args = parser.parse_args()
    if args.replicates < 1:
        parser.error("--replicates must be positive")

    alphas = (0.05, 0.05 / 15.0)
    base = {
        "alpha": None,
        "practical_margin": 0.05,
        "initial_seeds": 5,
        "batch_size": 5,
        "max_seeds": 20,
        "target_width": 0.10,
        "interval_method": "hoeffding_unpaired",
        "bootstrap_resamples": 1000,
    }
    results = []
    cell_index = 0
    for alpha in alphas:
        config = ProtocolConfig(**{**base, "alpha": alpha})
        for family, parameter in FAMILIES:
            for true_difference in DIFFERENCES:
                row = run_cell(
                    family,
                    parameter,
                    true_difference,
                    config,
                    args.replicates,
                    920_000 + cell_index,
                )
                results.append(row.__dict__)
                cell_index += 1

    aggregate_intervals = {}
    for alpha in alphas:
        rows = [row for row in results if row["alpha"] == alpha]
        for metric in ("simultaneous_coverage", "false_superiority_rate"):
            values = [row[metric] for row in rows]
            aggregate_intervals[f"{alpha}:{metric}:min"] = min(values)
            aggregate_intervals[f"{alpha}:{metric}:max"] = max(values)
        for metric in ("simultaneous_coverage", "false_superiority_rate"):
            successes = round(sum(row[metric] * row["replicates"] for row in rows))
            trials = len(rows) * args.replicates
            lower, upper = wilson(successes, trials)
            aggregate_intervals[f"{alpha}:{metric}:pooled_wilson_95"] = {"lower": lower, "upper": upper}

    payload = {
        "status": "supplementary_calibration_grid_only",
        "warning": "Monte Carlo evidence is not a proof and does not represent arbitrary RL seed distributions.",
        "config": {
            "replicates": args.replicates,
            "alphas": list(alphas),
            "families": [name for name, _ in FAMILIES],
            "differences": list(DIFFERENCES),
            "looks": [5, 10, 15, 20],
            "practical_margin": 0.05,
            "target_width": 0.10,
            "interval_method": "hoeffding_unpaired",
        },
        "aggregate_intervals": aggregate_intervals,
        "results": results,
    }
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    with open(args.report, "w", encoding="utf-8") as handle:
        handle.write(build_report(payload))
    print(json.dumps({"status": payload["status"], "cells": len(results), "replicates_per_cell": args.replicates}, indent=2))


if __name__ == "__main__":
    main()

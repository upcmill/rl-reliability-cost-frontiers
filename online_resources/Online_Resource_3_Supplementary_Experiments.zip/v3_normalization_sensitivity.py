#!/usr/bin/env python3
"""Post-hoc raw-return normalization sensitivity for the frozen v3 sample."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

from pilot_protocol import ProtocolConfig, sequential_decision


BASELINE_BOUNDS = {
    "CartPole-v1": (0.0, 500.0),
    "Acrobot-v1": (-500.0, 0.0),
    "MountainCar-v0": (-200.0, 0.0),
    "Taxi-v4": (-2000.0, 20.0),
    "NonstationaryQueue-v0": (-2050.0, 0.0),
}

# These alternatives are sensitivity diagnostics, not new estimands for the
# confirmatory analysis. Tighter alternatives deliberately test clipping,
# while wider alternatives test the effect of expanding the nominal scale.
ALTERNATIVE_BOUNDS = {
    "CartPole-v1": {"tighter": (0.0, 200.0), "wider": (0.0, 1000.0)},
    "Acrobot-v1": {"tighter": (-200.0, 0.0), "wider": (-1000.0, 0.0)},
    "MountainCar-v0": {"tighter": (-110.0, 0.0), "wider": (-500.0, 0.0)},
    "Taxi-v4": {"tighter": (-2000.0, 200.0), "wider": (-4000.0, 20.0)},
    "NonstationaryQueue-v0": {"tighter": (-1000.0, 0.0), "wider": (-3000.0, 0.0)},
}


def normalize(value: float, bounds: tuple[float, float]) -> float:
    lower, upper = bounds
    return max(0.0, min(1.0, (value - lower) / (upper - lower)))


def load_test_metrics(csv_path: Path) -> dict[tuple[str, str], list[float]]:
    rows = defaultdict(list)
    with csv_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["split"] == "test":
                rows[(row["env_id"], row["algorithm"])].append(float(row["metric_raw"]))
    for key in rows:
        rows[key].sort()
    return dict(rows)


def run_scheme(raw: dict[tuple[str, str], list[float]], bounds_by_env: dict[str, tuple[float, float]]) -> dict:
    config = ProtocolConfig(
        alpha=0.05 / 15.0,
        practical_margin=0.05,
        initial_seeds=5,
        batch_size=5,
        max_seeds=20,
        target_width=0.10,
        interval_method="hoeffding_unpaired",
    )
    environments = sorted({env for env, _ in raw})
    algorithms = ("PPO", "DQN", "A2C")
    decisions = []
    for env_id in environments:
        normalized = {
            algorithm: [normalize(value, bounds_by_env[env_id]) for value in raw[(env_id, algorithm)]]
            for algorithm in algorithms
        }
        for a, b in (("PPO", "DQN"), ("PPO", "A2C"), ("DQN", "A2C")):
            decision = sequential_decision(normalized[a], normalized[b], config)
            decisions.append({"env_id": env_id, "comparison": f"{a}_vs_{b}", **decision})
    counts = Counter(row["decision"] for row in decisions)
    return {
        "decision_counts": dict(sorted(counts.items())),
        "max_budget_fraction": sum(row["decision"] == "max_budget_inconclusive" for row in decisions) / len(decisions),
        "decisions": decisions,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default="sb3_formal_v3/raw_seed_metrics.csv")
    parser.add_argument("--output", default="v3_normalization_sensitivity.json")
    args = parser.parse_args()
    raw = load_test_metrics(Path(args.input))
    expected = {(env, alg) for env in BASELINE_BOUNDS for alg in ("PPO", "DQN", "A2C")}
    if set(raw) != expected or any(len(values) != 20 for values in raw.values()):
        raise SystemExit("expected exactly 20 test rows for each v3 environment/algorithm cell")
    schemes = {"baseline": BASELINE_BOUNDS}
    for env_id, alternatives in ALTERNATIVE_BOUNDS.items():
        for name, bounds in alternatives.items():
            current = dict(BASELINE_BOUNDS)
            current[env_id] = bounds
            schemes[f"{env_id}:{name}"] = current
    results = {name: run_scheme(raw, bounds) for name, bounds in schemes.items()}
    payload = {
        "status": "post_hoc_v3_normalization_sensitivity",
        "warning": "Frozen raw test returns are reused; this does not replace the preregistered normalization or family analysis.",
        "metric": "four-checkpoint mean raw return per training seed",
        "primary_bounds": BASELINE_BOUNDS,
        "alternative_bounds": ALTERNATIVE_BOUNDS,
        "interval": {"method": "hoeffding_unpaired", "comparison_alpha": 0.05 / 15.0, "looks": [5, 10, 15, 20], "margin": 0.05, "target_width": 0.10},
        "results": results,
    }
    Path(args.output).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

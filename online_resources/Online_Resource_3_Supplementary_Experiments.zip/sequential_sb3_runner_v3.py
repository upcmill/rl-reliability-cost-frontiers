#!/usr/bin/env python3
"""Run the expanded-grid v3 sequential SB3 evaluation.

This is intentionally separate from the v2 runner so the v2 code hash and
artifacts remain immutable.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
from itertools import combinations
from pathlib import Path

import gymnasium as gym
import torch

from pilot_protocol import ProtocolConfig, sequential_decision
from sb3_pilot import (
    ADDITIONAL_ENV_IDS,
    ALGORITHMS,
    DEFAULT_ENV_IDS,
    QUEUE_ENV_ID,
    train_curve,
)


CONFIGS = {
    "lr3e4_long": {
        "learning_rate": 3e-4,
        "batch_size": 64,
        "n_steps": 256,
        "buffer_size": 5000,
        "learning_starts": 100,
    },
    "lr1e4_long": {
        "learning_rate": 1e-4,
        "batch_size": 64,
        "n_steps": 256,
        "buffer_size": 5000,
        "learning_starts": 100,
    },
    "lr3e4_short": {
        "learning_rate": 3e-4,
        "batch_size": 64,
        "n_steps": 128,
        "buffer_size": 10000,
        "learning_starts": 200,
    },
    "lr1e4_short": {
        "learning_rate": 1e-4,
        "batch_size": 64,
        "n_steps": 128,
        "buffer_size": 10000,
        "learning_starts": 200,
    },
}


def lock_resolved_decisions(decisions: dict[str, dict], locked: dict[str, dict], n: int):
    current = {}
    for comparison, decision in decisions.items():
        if comparison in locked:
            current[comparison] = locked[comparison]
        elif decision["decision"] != "max_budget_inconclusive":
            terminal = {**decision, "locked": True, "locked_at": n}
            locked[comparison] = terminal
            current[comparison] = terminal
        else:
            current[comparison] = {**decision, "locked": False}
    return current


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--environment-ids", default=",".join((*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID)))
    parser.add_argument("--validation-seeds", type=int, default=5)
    parser.add_argument("--test-seeds", type=int, default=20)
    parser.add_argument("--initial-test-seeds", type=int, default=5)
    parser.add_argument("--test-batch-size", type=int, default=5)
    parser.add_argument("--timesteps", type=int, default=4096)
    parser.add_argument("--checkpoints", type=int, default=4)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--family-alpha", type=float, default=0.05)
    parser.add_argument("--practical-margin", type=float, default=0.05)
    parser.add_argument("--target-width", type=float, default=0.10)
    parser.add_argument("--output-dir", default="sb3_formal_v3")
    args = parser.parse_args()
    args.environment_ids_resolved = tuple(x.strip() for x in args.environment_ids.split(",") if x.strip())
    supported = set((*DEFAULT_ENV_IDS, *ADDITIONAL_ENV_IDS, QUEUE_ENV_ID))
    unsupported = sorted(set(args.environment_ids_resolved) - supported)
    if unsupported:
        parser.error(f"unsupported environment IDs: {', '.join(unsupported)}")
    if args.validation_seeds < 2 or args.test_seeds < 1:
        parser.error("invalid seed counts")
    if not 1 <= args.initial_test_seeds <= args.test_seeds:
        parser.error("initial-test-seeds must be within test-seeds")
    if args.test_batch_size < 1 or args.checkpoints < 1 or args.timesteps < args.checkpoints:
        parser.error("invalid batch/checkpoint settings")
    if not 0 < args.family_alpha < 1:
        parser.error("family-alpha must be in (0,1)")
    args.comparison_count = len(args.environment_ids_resolved) * 3
    args.comparison_alpha = args.family_alpha / args.comparison_count
    return args


def main():
    args = parse_args()
    env_ids = args.environment_ids_resolved
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoints = [args.timesteps * i // args.checkpoints for i in range(1, args.checkpoints + 1)]
    protocol_kwargs = {
        "alpha": args.comparison_alpha,
        "practical_margin": args.practical_margin,
        "initial_seeds": args.initial_test_seeds,
        "batch_size": args.test_batch_size,
        "max_seeds": args.test_seeds,
        "target_width": args.target_width,
        "interval_method": "hoeffding_unpaired",
        "bootstrap_resamples": 1000,
    }
    records, summary, comparisons = [], {}, []

    for env_id in env_ids:
        validation, selected = {}, {}
        for algorithm in ALGORITHMS:
            validation[algorithm] = {}
            for config_id, config in CONFIGS.items():
                values = []
                for seed_offset in range(args.validation_seeds):
                    train_seed = 10000 + seed_offset
                    result = train_curve(env_id, algorithm, train_seed, config, checkpoints, args.eval_episodes)
                    values.append(result["metric_normalized"])
                    records.append({"env_id": env_id, "algorithm": algorithm, "config_id": config_id, "split": "validation", "seed": seed_offset, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})
                validation[algorithm][config_id] = values
            selected[algorithm] = max(CONFIGS, key=lambda key: sum(validation[algorithm][key]) / len(validation[algorithm][key]))

        metrics = {algorithm: [] for algorithm in ALGORITHMS}
        curves = {algorithm: [] for algorithm in ALGORITHMS}
        locked, trace, final = {}, [], None
        for batch_start in range(0, args.test_seeds, args.test_batch_size):
            batch_end = min(args.test_seeds, batch_start + args.test_batch_size)
            for seed_offset in range(batch_start, batch_end):
                train_seed = 20000 + seed_offset
                for algorithm in ALGORITHMS:
                    config_id = selected[algorithm]
                    result = train_curve(env_id, algorithm, train_seed, CONFIGS[config_id], checkpoints, args.eval_episodes)
                    metrics[algorithm].append(result["metric_normalized"])
                    curves[algorithm].append({"seed": seed_offset, "train_seed": train_seed, **result})
                    records.append({"env_id": env_id, "algorithm": algorithm, "config_id": config_id, "split": "test", "seed": seed_offset, "train_seed": train_seed, "evaluation_seed_base": result["evaluation_seed_base"], "metric_normalized": result["metric_normalized"], "metric_raw": result["metric_raw"], "runtime_seconds": result["runtime_seconds"], "status": "ok"})
            protocol = ProtocolConfig(**{**protocol_kwargs, "max_seeds": batch_end})
            provisional = {f"{a}_vs_{b}": sequential_decision(metrics[a], metrics[b], protocol) for a, b in combinations(ALGORITHMS, 2)}
            decisions = lock_resolved_decisions(provisional, locked, batch_end)
            trace.append({"n": batch_end, "decisions": decisions})
            if len(locked) == len(provisional) or batch_end == args.test_seeds:
                final = decisions
                break
        for algorithm in ALGORITHMS:
            summary[f"{env_id}:{algorithm}"] = {"selected_config": selected[algorithm], "validation": validation[algorithm], "test_metrics": metrics[algorithm], "curves": curves[algorithm]}
        comparisons.append({"env_id": env_id, "decisions": final, "stop_trace": trace})

    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    try:
        sb3_version = importlib.metadata.version("stable-baselines3")
    except importlib.metadata.PackageNotFoundError:
        sb3_version = "unknown"
    payload = {
        "status": "sb3_formal_v3_candidate",
        "warning": "Expanded-grid preregistered candidate; no publication claim.",
        "python_version": platform.python_version(),
        "python_arch": platform.machine(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "gymnasium": gym.__version__,
        "stable_baselines3": sb3_version,
        "mps_available": bool(torch.backends.mps.is_available()),
        "script_sha256": script_hash,
        "run_config": {"validation_seeds": args.validation_seeds, "test_seeds": args.test_seeds, "initial_test_seeds": args.initial_test_seeds, "test_batch_size": args.test_batch_size, "timesteps": args.timesteps, "checkpoints": args.checkpoints, "checkpoints_resolved": checkpoints, "eval_episodes": args.eval_episodes, "family_alpha": args.family_alpha, "comparison_alpha": args.comparison_alpha, "execution_mode": "actual_sequential_stop", "environment_ids": ",".join(env_ids)},
        "candidate_configs": CONFIGS,
        "environment_ids": list(env_ids),
        "algorithm_ids": list(ALGORITHMS),
        "protocol": protocol_kwargs,
        "alpha_scope": {"family_alpha": args.family_alpha, "comparisons": args.comparison_count, "environment_count": len(env_ids), "algorithm_pair_count": 3, "comparison_alpha": args.comparison_alpha},
        "summary": summary,
        "comparisons": comparisons,
    }
    fields = ["env_id", "algorithm", "config_id", "split", "seed", "train_seed", "evaluation_seed_base", "metric_normalized", "metric_raw", "runtime_seconds", "status"]
    with (output_dir / "raw_seed_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    for filename in ("run_config.json", "summary.json"):
        (output_dir / filename).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()


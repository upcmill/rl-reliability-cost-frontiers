# Continuous-Control Scope Expansion Preregistration

This document freezes a supplementary scope expansion before running the
MountainCarContinuous-v0 experiment. It is separate from the v3 primary family
and from the earlier Pendulum-v1 supplement; no results will be pooled into the
15-comparison family.

## Question and scope

Does the same validation-selection, sealed-test, and finite-look evaluation
workflow execute on a second continuous-action Gymnasium task? The result is a
scope diagnostic, not a claim about continuous-control algorithm rankings.

## Frozen design

- Environment: `MountainCarContinuous-v0`.
- Algorithms: PPO and A2C; DQN is excluded because it does not accept Box actions.
- Candidate configurations: the same four configurations used in v3.
- Validation: five seeds per candidate, training seeds 10000--10004.
- Selection: highest validation mean, deterministic first-insertion tie rule.
- Sealed test: selected configuration, training seeds 20000--20019.
- Training: 4096 environment steps; checkpoints 1024, 2048, 3072, 4096.
- Evaluation: five episodes per checkpoint.
- Sequential looks: 5, 10, 15, and 20 test seeds.
- Primary interval for this supplement: unpaired Hoeffding with comparison alpha 0.05.
- Practical margin: 0.05; target width: 0.10.

## Metric boundary

The environment source applies a per-step action penalty of at most 0.1 and a
terminal reward of 100. With the installed time limit, the conservative stored
raw-return bound is `[-100, 100]`. Raw returns will be retained and normalized
to `[0,1]` with clipping. This bound is a supplement-specific design choice;
it does not alter the v3 primary normalization.

## Reporting boundary

The supplement will report raw rows, selected configurations, stop traces,
intervals, and same-machine replay separately. It will not be pooled with
Pendulum-v1 or the v3 family, and it will not support claims about all
continuous-control tasks or all algorithms.

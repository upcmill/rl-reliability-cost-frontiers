#!/usr/bin/env python3
"""A small controlled nonstationary queueing task for RL evaluation studies."""

from __future__ import annotations

import gymnasium as gym
import numpy as np
from gymnasium import spaces
from gymnasium.envs.registration import register


ENV_ID = "NonstationaryQueue-v0"


class NonstationaryQueueEnv(gym.Env):
    """Finite-capacity queue with a known arrival-rate change halfway through.

    Action 0 leaves the server idle and action 1 attempts to serve one item.
    The observation exposes normalized queue length, phase, and time fraction.
    Rewards are negative queueing and service costs, bounded in
    ``[-(capacity + service_cost), 0]`` per step.
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        capacity: int = 10,
        horizon: int = 200,
        switch_step: int = 100,
        arrival_probabilities: tuple[float, float] = (0.25, 0.85),
        service_cost: float = 0.25,
    ) -> None:
        super().__init__()
        if capacity < 1 or horizon < 2 or not 0 < switch_step < horizon:
            raise ValueError("capacity, horizon, and switch_step are invalid")
        if any(not 0.0 < probability < 1.0 for probability in arrival_probabilities):
            raise ValueError("arrival probabilities must lie in (0, 1)")
        if service_cost < 0.0:
            raise ValueError("service_cost must be non-negative")
        self.capacity = int(capacity)
        self.horizon = int(horizon)
        self.switch_step = int(switch_step)
        self.arrival_probabilities = tuple(float(x) for x in arrival_probabilities)
        self.service_cost = float(service_cost)
        self.action_space = spaces.Discrete(2)
        self.observation_space = spaces.Box(
            low=np.zeros(3, dtype=np.float32),
            high=np.ones(3, dtype=np.float32),
            dtype=np.float32,
        )
        self.queue = 0
        self.step_count = 0

    @property
    def reward_lower_bound(self) -> float:
        return -(self.capacity + self.service_cost)

    @property
    def reward_upper_bound(self) -> float:
        return 0.0

    def _phase(self) -> int:
        return int(self.step_count >= self.switch_step)

    def _observation(self) -> np.ndarray:
        return np.asarray(
            [
                self.queue / self.capacity,
                float(self._phase()),
                self.step_count / self.horizon,
            ],
            dtype=np.float32,
        )

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        super().reset(seed=seed)
        self.queue = 0
        self.step_count = 0
        return self._observation(), {"phase": self._phase(), "queue": self.queue}

    def step(self, action: int):
        if not self.action_space.contains(action):
            raise ValueError(f"invalid action: {action}")
        phase = self._phase()
        arrival = int(self.np_random.random() < self.arrival_probabilities[phase])
        served = int(int(action) == 1 and self.queue > 0)
        self.queue = min(self.capacity, max(0, self.queue - served + arrival))
        self.step_count += 1
        reward = -(float(self.queue) + self.service_cost * int(action))
        truncated = self.step_count >= self.horizon
        return (
            self._observation(),
            reward,
            False,
            truncated,
            {
                "arrival": arrival,
                "served": served,
                "phase": phase,
                "queue": self.queue,
            },
        )


def register_nonstationary_queue() -> None:
    """Register the environment exactly once in the Gymnasium registry."""
    try:
        gym.spec(ENV_ID)
    except gym.error.Error:
        register(id=ENV_ID, entry_point="nonstationary_queue_env:NonstationaryQueueEnv")


register_nonstationary_queue()


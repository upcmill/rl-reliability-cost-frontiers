# Supplementary Information for: Resolution and Cost in Sequential Evaluation of Reinforcement Learning Algorithms: A Design Audit

**Status.** This supplement accompanies the v3 primary manuscript. It contains
diagnostic, scope-expansion, and resolution-cost analyses that were not pooled
into the preregistered v3 15-comparison family. It does not change the v3
estimand, alpha allocation, stopping rule, or primary decisions. Every numeric
statement below is traceable to a stored report, JSON summary, CSV file, or
audit script in the submission archive.

## S1. Evidence hierarchy and labeling

The package uses four evidence labels. **Formal** refers to the conditional
finite-look proposition and its algebraic corollaries. **Primary v3** refers to
the preregistered five-task, three-algorithm family with 20 sealed test seeds.
**Diagnostic** refers to analyses run to understand calibration, sensitivity,
or resolution cost without changing the primary estimand. **Repeatability**
refers to the same-machine cross-script replay; it is not independent
reproducibility. The supplement never upgrades a diagnostic into a primary
claim or a same-machine replay into an external replication.

| Evidence item | Status in the paper | Primary source |
|---|---|---|
| Conditional finite-look coverage proposition | Formal methodological result under registered assumptions | Preregistration and proof materials ([Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz)) |
| Deterministic theorem-number audit | Algebraic and boundary-value check; not a probabilistic proof | Theory audit and tests ([Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz)) |
| Independent theory reimplementation | Same-workspace formula cross-check; not external statistical review | Independent theory audit ([Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz)) |
| Independent raw-data recomputation | Same-workspace recomputation of all 15 primary decisions | Recomputed results and audit code ([Online Resource 2](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_2_Primary_v3.zip) and [Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz)) |
| 15 v3 comparisons at 20 sealed seeds | Primary v3 evidence | Primary data and preregistration ([Online Resource 2](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_2_Primary_v3.zip)) |
| Calibration grid | Monte Carlo diagnostic | Calibration report and data ([Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip)) |
| Normalization, margin, horizon, episode, and tuning checks | Post-hoc or prospective supplementary diagnostics | Sensitivity reports and data ([Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip)) |
| Partial-observation and continuous-control runs | Separately scoped execution diagnostics | Scope reports and data ([Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip)) |
| Queue follow-up, v4, and v5 | Same-family resolution-cost diagnostics | Extension reports and data ([Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip)) |
| v6 task-family extension | Two additional fixed discrete tasks; same-machine scope diagnostic | Preregistration, report, data, and audit ([Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip)) |
| Cross-script replay | Same-machine repeatability | Replay summary and code ([Online Resource 2](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_2_Primary_v3.zip) and [Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz)) |
| Seed-dependence stress test | Controlled assumption-failure diagnostic | Dependence diagnostic report and data ([Online Resource 4](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_4_Dependence_Diagnostics.zip)) |
| Known-block fallback | Controlled mitigation diagnostic under known independent blocks | Fallback diagnostic report and data ([Online Resource 4](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_4_Dependence_Diagnostics.zip)) |

## S2. Calibration grid

The calibration grid evaluates the registered unpaired bounded interval under
eight bounded distribution families, five true mean differences from -0.20 to
0.20, two alpha settings, four looks at 5, 10, 15, and 20 observations, and
3,000 Monte Carlo replicates per cell. The grid therefore contains 80 cells
and 240,000 replicates. The two alpha settings are single-comparison alpha
0.05 and the v3 comparison allocation 0.05/15.

| Alpha setting | Cells | Minimum simultaneous coverage | Maximum observed false-superiority rate | Mean seed cost | Cells with a terminal decision |
|---:|---:|---:|---:|---:|---:|
| 0.05 | 40 | 1.0000 | 0.0000 | 20.00 | 0 |
| 0.05/15 | 40 | 1.0000 | 0.0000 | 20.00 | 0 |

These are Monte Carlo summaries for the disclosed grid. They do not establish
coverage for arbitrary bounded distributions, RL training-seed distributions,
or a different stopping schedule. The raw cell-level output and Wilson
intervals, generation details, and distribution definitions are provided in
[Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip).

### S2.1 Seed-dependence assumption stress test

The coverage theorem assumes independence across sealed seed metrics within
each algorithm. To make this limitation concrete, we generated two
independent arms whose values are Bernoulli(0.5) but repeated within blocks of
size 1, 2, 5, 10, 20, or 50. The true difference is zero, and the same four
looks, alpha 0.05, 0.10 practical margin, and maximum of 200 observations are
used in every condition. Each condition has 5,000 replicates. Block size 1 is
the independent calibration reference; larger blocks reduce the effective
number of independent observations without changing the nominal sample count.

| Block size | Effective blocks at n=200 | Simultaneous coverage | 95% Wilson interval | False-superiority rate | 95% Wilson interval | Mean terminal seeds |
|---:|---:|---:|---|---:|---|---:|
| 1 | 200 | 1.0000 | [0.9992, 1.0000] | 0.0000 | [0.0000, 0.0008] | 200.00 |
| 2 | 100 | 0.9980 | [0.9963, 0.9989] | 0.0000 | [0.0000, 0.0008] | 200.00 |
| 5 | 40 | 0.9304 | [0.9230, 0.9371] | 0.0162 | [0.0131, 0.0201] | 197.74 |
| 10 | 20 | 0.7552 | [0.7431, 0.7669] | 0.1414 | [0.1320, 0.1513] | 180.91 |
| 20 | 10 | 0.4752 | [0.4614, 0.4891] | 0.3328 | [0.3199, 0.3460] | 159.16 |
| 50 | 4 | 0.1244 | [0.1155, 0.1338] | 0.7756 | [0.7638, 0.7869] | 101.67 |

This is an assumption stress test, not an RL experiment or a correction for
dependent training. It shows why exact same-machine replay cannot establish
the independence premise and why the conditional coverage language must remain
in the manuscript. The generator and machine-readable output are provided in
[Online Resource 4](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_4_Dependence_Diagnostics.zip).

### S2.2 Known-block dependence fallback

When the block partition is known and block means are independent, Proposition
3 gives a conservative fallback: discard partial trailing blocks and apply the
same interval to complete block means. The table uses the same 5,000 replicates
as the preceding stress diagnostic and compares the raw-count interval with
the block-aware interval.

| Block size | Effective blocks by look | Naive coverage | Fallback coverage | Naive false superiority | Fallback false superiority | Naive mean terminal n | Fallback mean terminal n |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | [50, 100, 150, 200] | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 200.00 | 200.00 |
| 2 | [25, 50, 75, 100] | 0.9982 | 1.0000 | 0.0002 | 0.0000 | 199.97 | 200.00 |
| 5 | [10, 20, 30, 40] | 0.9376 | 1.0000 | 0.0124 | 0.0000 | 198.25 | 200.00 |
| 10 | [5, 10, 15, 20] | 0.7706 | 1.0000 | 0.1370 | 0.0000 | 181.58 | 200.00 |
| 20 | [2, 5, 7, 10] | 0.4646 | 1.0000 | 0.3338 | 0.0000 | 158.16 | 200.00 |
| 50 | [1, 2, 3, 4] | 0.1264 | 1.0000 | 0.7812 | 0.0000 | 99.66 | 200.00 |

The fallback's estimated coverage was 1.0000 and its observed
false-superiority rate was 0.0000 in every tested block condition. This is a
Monte Carlo observation under the known independent-block model, not a proof
for unknown RL dependence. The effective sample-size reduction explains why
the fallback made no early decisions in this scenario. Its report, raw output,
and deterministic tests are provided in [Online Resource 4](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_4_Dependence_Diagnostics.zip).

## S3. Sensitivity and selection diagnostics

The following checks reuse stored rows or use separately disclosed fixed
configurations. They were not used to redefine the v3 hypothesis or to select
the reported primary result.

| Diagnostic | Changed quantity | Stored observation | Interpretation limit |
|---|---|---|---|
| Normalization sensitivity | One tighter and one wider bound per task, 11 schemes total | All 11 schemes retain 15/15 maximum-budget inconclusive decisions | Robustness for the stored rows; not a new estimand or universal normalization rule |
| Practical-margin sensitivity | Margin values 0.00, 0.025, 0.05, 0.10, 0.20, 0.30, 0.50 | Stored v3 rows remain 15/15 maximum-budget inconclusive at the tested margins | Descriptive sensitivity; not a universal practical margin or power curve |
| Training horizon | Fixed v3 selections, 16,384 environment steps | All 15 comparisons remain maximum-budget inconclusive | Horizon is part of the estimand; this does not prove general horizon sufficiency |
| Evaluation aggregation | Five versus ten episodes per checkpoint | All 15 decisions remain maximum-budget inconclusive | Does not establish a universal episode count |
| Tuning strength | Five versus ten versus twenty validation seeds with disjoint diagnostic tests | Four of 15 selections change at ten seeds; seven of 15 change at twenty seeds relative to v3 | Selection is configuration-conditional; these are observed-sample diagnostics, not probabilities of global optimality |
| Validation row bootstrap | Joint resampling of the five observed validation rows | Frequencies quantify observed-sample selection instability | Not a population selection probability or a confirmatory result |
| Validation-selected alpha spending | Four valid schedules selected by a validation bootstrap | No observed coverage failure or false-superiority decision in four bounded scenarios; selected cost was not uniformly best | Conditional selection diagnostic; not a universal efficiency claim or a replacement for v3 |

The prospective-within-workspace twenty-seed extension provides a second,
stronger tuning-budget check. It evaluated the same four candidates for each
of the 15 cells on validation seeds 11000--11019, disjoint from v3 and the
earlier diagnostics. Seven of 15 selected configurations changed relative to
the v3 five-seed selection: CartPole/PPO, CartPole/DQN, Acrobot/PPO,
Acrobot/A2C, NonstationaryQueue/PPO, NonstationaryQueue/DQN, and
NonstationaryQueue/A2C. This 7/15 rate is an observed fixed-family
selection-sensitivity result. It is not a population probability, an
optimality claim, or evidence for a universal twenty-seed rule. The frozen
design, raw rows, audit, and report are provided in [Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip).

### S3.1 Alternative intervals and pairing dependence

An additional diagnostic re-used one stored Acrobot pilot sequence to compare
paired and unpaired interval constructions under the same finite-look schedule.
It is intentionally outside the v3 confirmatory family. The paired normal and
paired bootstrap rows re-assigned DQN outcomes to 5,000 deterministic
permutations; the unpaired methods use the two marginal samples and are
invariant to that re-assignment. The terminal decision counts were:

| Interval construction | B superior | Precision only | Maximum-budget inconclusive | Mean seeds used |
|---|---:|---:|---:|---:|
| Paired normal | 16 | 121 | 4,863 | 9.867 |
| Paired bootstrap | 143 | 222 | 4,635 | 9.642 |
| Paired empirical Bernstein | 0 | 0 | 5,000 | 10.000 |
| Paired Hoeffding | 0 | 0 | 5,000 | 10.000 |

The changing paired counts are a sensitivity-to-pairing observation, not a
false-positive estimate: the same stored outcomes are being re-paired. A
separate unpaired empirical-Bernstein simulation found simultaneous coverage
of 1.0000 in every tested cell and no earlier resolution at 5--20 seeds, with
the lower 95% Monte Carlo bound reported as 0.99923. Those results are
exploratory and do not justify replacing the preregistered unpaired Hoeffding
interval without a new finite-sample/sequential proof and preregistration.

The source artifacts and diagnostic report are provided in [Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip).
This subsection does not support
claims that paired procedures are invalid in general or that the candidate
empirical-Bernstein method is more efficient.

The reports retain the exact alternative bounds, seed ranges, configuration
IDs, and recomputed decision records. The primary manuscript therefore reports
these analyses as sensitivity evidence rather than as additional confirmatory
comparisons.

### S3.2 Validation-selected alpha spending

Corollary 5 applies the same conditioning logic to a finite set of valid
alpha-spending schedules. The diagnostic defines four schedules with the same
comparison-level alpha: power-series, front-loaded, late-loaded, and finite-
look minimax. A bootstrap estimate of stopping cost from a validation sequence
selects one schedule, and a fresh sealed sequence is then evaluated under that
schedule. The looks are 50, 100, 150, and 200 observations, with practical
margin 0.05 and target width 0.20. The validation sequence contains 200
observations per algorithm so every candidate look is represented without
extrapolating the validation sample.

The diagnostic uses four bounded scenarios and 2,000 Monte Carlo repetitions
per scenario. There are no observed simultaneous-coverage failures or
false-superiority decisions. The selected mean costs and the best fixed-
schedule costs are:

| Scenario | True difference | Selected mean cost | Best fixed mean cost | Selected coverage | False-superiority rate |
|---|---:|---:|---:|---:|---:|
| Null Bernoulli | 0.000 | 200.00 | 200.00 | 1.0000 | 0.0000 |
| Large effect | 0.900 | 50.00 | 50.00 | 1.0000 | 0.0000 |
| Skewed effect | 0.400 | 121.53 | 119.88 | 1.0000 | 0.0000 |
| Two-point mixture | -0.320 | 175.20 | 173.98 | 1.0000 | 0.0000 |

The result supports the conditional selection argument for the listed bounded
scenarios, while showing that validation-selected spending is not automatically
more efficient than the best fixed schedule. It is a post-v3 statistical
diagnostic, not an RL experiment, a new confirmatory family, or evidence of a
universal cost-saving rule. The machine-readable output and generator are
provided in [Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip).

## S4. Scope-expansion diagnostics

### S4.1 Fixed-mask partial observation

The separate fixed-mask run uses `MaskedCartPole-v1` and `MaskedAcrobot-v1`,
with the disclosed velocity coordinates replaced by zero. It contains 240
rows: 120 validation rows and 120 selected-test rows, with six comparisons.
All six comparisons are maximum-budget inconclusive at 20 test seeds. The
wrapper tests, preregistration, raw rows, and replay output are provided in
[Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip). This is a fixed-mask execution pressure test, not evidence
for general POMDP performance.

### S4.2 Continuous-action tasks

The Pendulum supplement contains 80 rows and one PPO--A2C comparison. Its
estimate is -0.0009 with interval [-0.8757, 0.8739], and the comparison is
maximum-budget inconclusive. The separately preregistered
`MountainCarContinuous-v0` scope expansion also contains 80 rows and one
PPO--A2C comparison; the normalized means are 0.499982 and 0.499859, with
estimate 0.0001233 and interval [-0.8747, 0.8749]. Both are execution-scope
diagnostics, not continuous-control rankings or external replications.

### S4.3 Controlled queue validity

The custom `NonstationaryQueue-v0` task has capacity 10, horizon 200, a rate
switch at step 100, arrival probabilities 0.25 and 0.85, and service cost
0.25. The finite-state oracle and switch-time checks validate the disclosed
transition system; they do not establish broad external validity or a general
algorithm ranking. The diagnostic materials are provided in [Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip).

## S5. Resolution-cost extensions

The extensions use frozen v3-selected configurations and are reported as
observed costs for disclosed task--algorithm cells. They are not pooled into
the v3 family and do not estimate prospective power.

| Extension | New or reused sequence | Rows | Decision summary | Evidential scope |
|---|---|---:|---|---|
| Queue follow-up | Reuses the v3 20-seed prefix, then adds 380 seeds | 800 total queue rows | Inconclusive at 200; DQN--A2C resolves at 400 | One post-v3 controlled-task comparison |
| v4 | New seeds 30000--30399 | 6,000 | One queue DQN--A2C superiority decision at 200; 14/15 unresolved at 400 | Same-family new-seed budget observation |
| v5 | New seeds 30400--31399 | 15,000 | Four terminal decisions by 1,000; 11/15 unresolved at 1,000 | Same-machine resolution-cost diagnostic |
| v6 task-family extension | New tasks `CliffWalking-v1` and fixed `FrozenLake-v1`, seeds 41000--41199 | 1,440 | Six comparisons unresolved at 200 | Same-machine cross-family execution and scope diagnostic |

The v4 and v5 audits verify seed non-overlap, frozen configurations, bounded
metrics, row counts, stop traces, and recomputed decisions. Because the v5
runner retained the complete sequence, a prefix decision is a sample-resolution
location, not a measured wall-clock saving. These extensions do not support a
universal seed requirement, a general PPO/DQN/A2C ranking, or external
reproducibility.

The v6 extension uses ten validation seeds per candidate and 200 test seeds per
cell for two additional fixed discrete tasks. `CliffWalking-v1` evaluation is
explicitly capped at 100 steps because its Gymnasium spec has no TimeLimit
wrapper; `FrozenLake-v1` is fixed to the 4 x 4 slippery map. The raw artifact
contains 240 validation rows and 1,200 test rows. An independent audit
recomputes all 24 finite-look decisions from the raw CSV, and all six remain
`max_budget_inconclusive` at 200 seeds. The extension broadens execution scope
only; it is not pooled with v3 and does not support cross-family power,
algorithm ranking, external reproducibility, or scientific replication. Its
preregistration, report, raw rows, and audit are provided in [Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip).

## S6. Reproducibility materials

The package distinguishes three levels:

1. **Same-machine repeatability:** the independent replay script reproduces all
   15 v3 selected-test summaries with recorded mean absolute normalized-metric
   differences of 0.0.
2. **Different-machine reproducibility:** demonstrated by the returned Windows
   AMD64 sealed rerun. All 15 selected configurations and terminal decisions
   match; 14/15 cells have zero seed-level differences and the remaining
   `Acrobot-v1:DQN` cell has mean absolute difference 0.00105 and maximum
   difference 0.01640. The raw output and full audit are provided in [Online Resource 6](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_6_External_Rerun.zip).
3. **Independent-team identity:** not verified by the returned handoff. The
   rerun therefore does not establish scientific replication on a new task
   family.
4. **Scientific conclusion replication:** not demonstrated; it would require a
   new sealed study or independently selected task family.

The source archive contains raw seed-level CSV files, JSON summaries, source
hashes, package versions, preregistration files, audit scripts, and exact
commands. The data and code supporting this paper are supplied as [Online Resource 2](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_2_Primary_v3.zip) and [Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip) and [Online Resource 4](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_4_Dependence_Diagnostics.zip) and [Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz) and [Online Resource 6](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_6_External_Rerun.zip). The fixed release is v3.0.5; the archive series is available at https://doi.org/10.5281/zenodo.23949004.

## S7. Audit materials

Executable audit code, environment specifications, expected outputs, and
reproduction instructions are included with the code and provenance materials
in [Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz). These checks audit the stored package; they do not
perform an external replication or establish journal acceptance.

## S8. Data dictionary

Each seed-level row stores the task ID, algorithm ID, split, configuration ID,
training seed, checkpoint returns, normalized aggregate metric, raw aggregate
metric, software/runtime metadata, and provenance fields needed to reconstruct
the selected procedure. Validation rows identify all candidates; test rows
identify the frozen selected configuration. Summary JSON files store means,
interval endpoints, look traces, decisions, and terminal states. The raw CSV
is authoritative for row-level values; generated tables are derived views.
For a task--algorithm cell used in more than one unordered pair, a training
row is generated once and the stored row is reused by each applicable pair.
Pair decisions can therefore lock at different looks while the shared cell
continues to receive rows for any other open pair. This is why the reported
training-run counts are cell counts rather than pair counts.

## S9. Supplementary limitations

The calibration grid cannot replace a proof. The sensitivity analyses are
conditional on stored rows and fixed configurations. The continuous,
partial-observation, and v6 task-family runs are scope diagnostics rather than
domain-wide evidence. The queue is self-built, and the v6 CliffWalking results
are at the normalized floor under its short training budget. The larger-budget
extensions are motivated by the v3 boundary and use the same machine. No
supplementary item closes the four submission gates for external reruns, public
archiving, independent literature screening, or author declarations.

## S10. Supplementary claim--evidence map

| Supplementary claim | Evidence | Permitted wording |
|---|---|---|
| The conservative boundary persists on the disclosed calibration grid | 80 cells, 240,000 replicates, stored JSON and report | “In the tested grid, no terminal decision occurred by 20 observations.” |
| The v3 conclusion is insensitive to the tested normalization schemes | 11 stored-bound schemes and recomputed decisions | “The stored comparisons remained unresolved under these post-hoc schemes.” |
| Resolution cost varies within the frozen task family | Queue, v4, and v5 audits | “Observed resolution cost varied across disclosed frozen cells.” |
| The workflow executes on two additional fixed discrete tasks | V6 task-family audit, raw 1,440-row data set, and preregistration ([Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip)) | “The extension broadens execution scope; all six comparisons remained unresolved at 200 seeds.” |
| Seed dependence can invalidate nominal coverage | Six block-correlated bounded surrogate conditions | “The stress test illustrates the conditional independence requirement; it does not estimate dependence in RL.” |
| Same-machine replay is exact at recorded precision | 15 replay differences equal 0.0 | “The package supports same-machine cross-script repeatability.” |
| Different-machine reproducibility is established for the frozen protocol | Windows AMD64 sealed rerun, raw output, source/output hashes, and 15/15 matched decisions | Claim only the disclosed protocol/task family; do not call it scientific replication or independent-team evidence. |
| Twenty-validation-seed tuning is universally sufficient | The prospective extension changes 7/15 selections relative to v3 | Do not claim sufficiency; report observed selection sensitivity for the fixed grid and task family. |
| A universal seed budget or algorithm ranking is established | No population or cross-machine evidence | Do not claim it. |

## S11. V7 new-seed method comparison

V7 was frozen after the V1--V6 results had been inspected and therefore is a
post-hoc prospective validation rather than a confirmatory analysis of the
original preregistration. It evaluates the same five-task panel, three
algorithms, frozen configurations, and 15 comparisons on new training seeds
31,400--32,399 (15,000 successful training records). The original Hoeffding
interval and eight variance-adaptive or sensitivity methods were evaluated at
200, 400, 600, 800, and 1,000 seeds under the same comparison-level alpha.

At 1,000 seeds, the main Gamma-mixture empirical-Bernstein confidence sequence
was narrower than the original Hoeffding interval in all 15 comparisons. Its
mean and median paired width differences were -0.185260 and -0.179334. The
main Gamma setting produced four A-superior, two B-superior, five
precision-only, and four unresolved comparisons; Hoeffding produced three
A-superior, one B-superior, and eleven unresolved comparisons. The shared-arm
counterfactual prefixes were 11,800 and 14,600 training runs, respectively,
but all 15,000 runs were completed, so these are not realized compute savings.

The `rho x 0.1` sensitivity produced six superiority and five precision-only
decisions. The `rho x 10` sensitivity produced six total terminal decisions,
no precision-only decisions, and nine unresolved comparisons. A 50-seed block
sensitivity removed all four original Hoeffding superiority decisions, but the
blocks were not shown to be independent and therefore do not repair the
primary assumption. The registered-parameter S23.3 result is an
analytic-boundary check, not evidence that dependence is harmless. Complete
method counts, widths, prefix calculations, V5/V7 comparisons, and raw files
are listed in the S12 manifest.

This section supports only a fixed-panel interval-width and tuning-sensitivity
description. It does not establish unknown-distribution coverage,
task-population generalization, a universal seed budget, algorithm rankings,
independent-team replication, or realized compute savings.

## S12. Online Resource manifest

The following materials correspond to release v3.0.5. The Zenodo DOI
https://doi.org/10.5281/zenodo.23949004 identifies the archive series; the release fixes the
version used here.

| Resource | Content | Download |
|---|---|---|
| Supplementary narrative and tables | Extended methods, diagnostics, limitations, and claim--evidence map | [Online Resource 1](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_1_Supplement.pdf) |
| Primary v3 data package | Preregistration, row-level metrics, configurations, and summaries | [Online Resource 2](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_2_Primary_v3.zip) |
| Supplementary experiment package | V4--V7 extensions, sensitivity analyses, and scope diagnostics | [Online Resource 3](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_3_Supplementary_Experiments.zip) |
| Dependence diagnostics | Controlled seed-dependence stress test and known-block fallback | [Online Resource 4](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_4_Dependence_Diagnostics.zip) |
| Code and provenance package | Runner, audit scripts, environment metadata, references, and checksums | [Online Resource 5](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/submission_bundle_v3.tar.gz) |
| External rerun package | Windows raw data, audit, summaries, runtime metadata, logs, and checksums | [Online Resource 6](https://github.com/upcmill/rl-reliability-cost-frontiers/releases/download/v3.0.5/Online_Resource_6_External_Rerun.zip) |
